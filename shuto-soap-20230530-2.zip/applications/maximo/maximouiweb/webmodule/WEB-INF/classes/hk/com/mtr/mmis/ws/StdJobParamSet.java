package hk.com.mtr.mmis.ws;

public class StdJobParamSet {

	protected long buId ;
	
	protected java.util.Calendar lastUpdDatetime ;
	
	protected long lastUpdUserId ;
	
	protected long stdJobParamSetId ;
	
	protected java.lang.String stdJobParamSetName ;
	
	protected hk.com.mtr.mmis.ws.StdJobParamSubset[] stdJobParamSubsets ;
	
	
	
	
	public long getBuId() {
		return buId;
	}




	public void setBuId(long buId) {
		this.buId = buId;
	}




	public java.util.Calendar getLastUpdDatetime() {
		return lastUpdDatetime;
	}




	public void setLastUpdDatetime(java.util.Calendar lastUpdDatetime) {
		this.lastUpdDatetime = lastUpdDatetime;
	}




	public long getLastUpdUserId() {
		return lastUpdUserId;
	}




	public void setLastUpdUserId(long lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}




	public long getStdJobParamSetId() {
		return stdJobParamSetId;
	}




	public void setStdJobParamSetId(long stdJobParamSetId) {
		this.stdJobParamSetId = stdJobParamSetId;
	}




	public java.lang.String getStdJobParamSetName() {
		return stdJobParamSetName;
	}




	public void setStdJobParamSetName(java.lang.String stdJobParamSetName) {
		this.stdJobParamSetName = stdJobParamSetName;
	}




	public hk.com.mtr.mmis.ws.StdJobParamSubset[] getStdJobParamSubsets() {
		return stdJobParamSubsets;
	}




	public void setStdJobParamSubsets(hk.com.mtr.mmis.ws.StdJobParamSubset[] stdJobParamSubsets) {
		this.stdJobParamSubsets = stdJobParamSubsets;
	}




	public void addStdJobParamSubsets(hk.com.mtr.mmis.ws.StdJobParamSubset param){
        if (stdJobParamSubsets == null){
        stdJobParamSubsets = new hk.com.mtr.mmis.ws.StdJobParamSubset[]{};
        }

 
      //update the setting tracker
//     stdJobParamSubsetsTracker = true;
 

    java.util.List list =
 org.apache.axis2.databinding.utils.ConverterUtil.toList(stdJobParamSubsets);
    list.add(param);
    this.stdJobParamSubsets =
  (hk.com.mtr.mmis.ws.StdJobParamSubset[])list.toArray(
 new hk.com.mtr.mmis.ws.StdJobParamSubset[list.size()]);

  }
	
}
