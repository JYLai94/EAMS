package hk.com.mtr.mmis.ws;

public class RetrieveWorkOrderListE {

	protected hk.com.mtr.mmis.ws.RetrieveWorkOrderList retrieveWorkOrderList ;

	public hk.com.mtr.mmis.ws.RetrieveWorkOrderList getRetrieveWorkOrderList() {
		return retrieveWorkOrderList;
	}

	public void setRetrieveWorkOrderList(hk.com.mtr.mmis.ws.RetrieveWorkOrderList retrieveWorkOrderList) {
		this.retrieveWorkOrderList = retrieveWorkOrderList;
	}
	
	
	
}
