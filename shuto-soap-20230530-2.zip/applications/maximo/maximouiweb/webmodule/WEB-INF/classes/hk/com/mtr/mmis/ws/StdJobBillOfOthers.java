package hk.com.mtr.mmis.ws;

public class StdJobBillOfOthers {
	
	protected double amount ;
	
	protected long buId ;
	
	protected java.lang.String gcOtherCostCd ;
	
	protected java.util.Calendar lastUpdDatetime ;
	
	protected long lastUpdUserId ;
	
	protected java.lang.String rRemarks ;
	
	protected long stdJobBooId ;

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public long getBuId() {
		return buId;
	}

	public void setBuId(long buId) {
		this.buId = buId;
	}

	public java.lang.String getGcOtherCostCd() {
		return gcOtherCostCd;
	}

	public void setGcOtherCostCd(java.lang.String gcOtherCostCd) {
		this.gcOtherCostCd = gcOtherCostCd;
	}

	public java.util.Calendar getLastUpdDatetime() {
		return lastUpdDatetime;
	}

	public void setLastUpdDatetime(java.util.Calendar lastUpdDatetime) {
		this.lastUpdDatetime = lastUpdDatetime;
	}

	public long getLastUpdUserId() {
		return lastUpdUserId;
	}

	public void setLastUpdUserId(long lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public java.lang.String getrRemarks() {
		return rRemarks;
	}

	public void setrRemarks(java.lang.String rRemarks) {
		this.rRemarks = rRemarks;
	}

	public long getStdJobBooId() {
		return stdJobBooId;
	}

	public void setStdJobBooId(long stdJobBooId) {
		this.stdJobBooId = stdJobBooId;
	}
	
	
}
