package hk.com.mtr.mmis.ws;

public class StdJobBillOfLabour {

	protected long buId ;
	
	protected java.lang.String gcHrsTypeCd ;
	
	protected java.lang.String gcResourceTypeCd ;
	
	protected double labourMinutes ;
	
	protected java.util.Calendar lastUpdDatetime ;
	
	protected long lastUpdUserId ;
	
	protected long stdJobBolId ;

	public long getBuId() {
		return buId;
	}

	public void setBuId(long buId) {
		this.buId = buId;
	}

	public java.lang.String getGcHrsTypeCd() {
		return gcHrsTypeCd;
	}

	public void setGcHrsTypeCd(java.lang.String gcHrsTypeCd) {
		this.gcHrsTypeCd = gcHrsTypeCd;
	}

	public java.lang.String getGcResourceTypeCd() {
		return gcResourceTypeCd;
	}

	public void setGcResourceTypeCd(java.lang.String gcResourceTypeCd) {
		this.gcResourceTypeCd = gcResourceTypeCd;
	}

	public double getLabourMinutes() {
		return labourMinutes;
	}

	public void setLabourMinutes(double labourMinutes) {
		this.labourMinutes = labourMinutes;
	}

	public java.util.Calendar getLastUpdDatetime() {
		return lastUpdDatetime;
	}

	public void setLastUpdDatetime(java.util.Calendar lastUpdDatetime) {
		this.lastUpdDatetime = lastUpdDatetime;
	}

	public long getLastUpdUserId() {
		return lastUpdUserId;
	}

	public void setLastUpdUserId(long lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public long getStdJobBolId() {
		return stdJobBolId;
	}

	public void setStdJobBolId(long stdJobBolId) {
		this.stdJobBolId = stdJobBolId;
	}
	
}
