package hk.com.mtr.mmis.ws;

public class WoStatusHistoryVO {

	protected boolean closeWr ;
	
	protected java.lang.String cmplByCd ;
	
	protected java.lang.String cmplByName ;
	
	protected boolean ignoreEquipStruct ;
	
	protected boolean ignoreSupersede ;
	
	protected java.lang.String lastUpdUser ;
	
	protected boolean noCheckActLocation ;
	
	protected java.lang.String personInChgName ;
	
	protected java.lang.String reasonDesp ;
	
	protected java.lang.String statusDesc ;
	
	protected hk.com.mtr.mmis.ws.WoStatusHistory woStatusHistory ;

	public boolean isCloseWr() {
		return closeWr;
	}

	public void setCloseWr(boolean closeWr) {
		this.closeWr = closeWr;
	}

	public java.lang.String getCmplByCd() {
		return cmplByCd;
	}

	public void setCmplByCd(java.lang.String cmplByCd) {
		this.cmplByCd = cmplByCd;
	}

	public java.lang.String getCmplByName() {
		return cmplByName;
	}

	public void setCmplByName(java.lang.String cmplByName) {
		this.cmplByName = cmplByName;
	}

	public boolean isIgnoreEquipStruct() {
		return ignoreEquipStruct;
	}

	public void setIgnoreEquipStruct(boolean ignoreEquipStruct) {
		this.ignoreEquipStruct = ignoreEquipStruct;
	}

	public boolean isIgnoreSupersede() {
		return ignoreSupersede;
	}

	public void setIgnoreSupersede(boolean ignoreSupersede) {
		this.ignoreSupersede = ignoreSupersede;
	}

	public java.lang.String getLastUpdUser() {
		return lastUpdUser;
	}

	public void setLastUpdUser(java.lang.String lastUpdUser) {
		this.lastUpdUser = lastUpdUser;
	}

	public boolean isNoCheckActLocation() {
		return noCheckActLocation;
	}

	public void setNoCheckActLocation(boolean noCheckActLocation) {
		this.noCheckActLocation = noCheckActLocation;
	}

	public java.lang.String getPersonInChgName() {
		return personInChgName;
	}

	public void setPersonInChgName(java.lang.String personInChgName) {
		this.personInChgName = personInChgName;
	}

	public java.lang.String getReasonDesp() {
		return reasonDesp;
	}

	public void setReasonDesp(java.lang.String reasonDesp) {
		this.reasonDesp = reasonDesp;
	}

	public java.lang.String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(java.lang.String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public hk.com.mtr.mmis.ws.WoStatusHistory getWoStatusHistory() {
		return woStatusHistory;
	}

	public void setWoStatusHistory(hk.com.mtr.mmis.ws.WoStatusHistory woStatusHistory) {
		this.woStatusHistory = woStatusHistory;
	}
	
}
