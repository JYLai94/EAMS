package hk.com.mtr.mmis.ws;

public class Incident {
	
	protected java.lang.String incidentDesp ;
	
	protected java.lang.String incidentId ;

	public java.lang.String getIncidentDesp() {
		return incidentDesp;
	}

	public void setIncidentDesp(java.lang.String incidentDesp) {
		this.incidentDesp = incidentDesp;
	}

	public java.lang.String getIncidentId() {
		return incidentId;
	}

	public void setIncidentId(java.lang.String incidentId) {
		this.incidentId = incidentId;
	}


}
