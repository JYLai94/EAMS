package hk.com.mtr.mmis.ws;

public class WorkOrderVO {
	
    protected java.lang.String action ;

    protected java.util.Calendar actualCmplDate ;

    protected java.util.Calendar actualStartDate ;

    protected java.lang.String actualStartTime ;

    protected hk.com.mtr.mmis.ws.WoRelationship[] childWolist ;

    protected void validateChildWolist(hk.com.mtr.mmis.ws.WoRelationship[] param){//????

    }

public void addChildWolist(hk.com.mtr.mmis.ws.WoRelationship param){
   if (childWolist == null){
   childWolist = new hk.com.mtr.mmis.ws.WoRelationship[]{};
   }

java.util.List list =
org.apache.axis2.databinding.utils.ConverterUtil.toList(childWolist);
list.add(param);
this.childWolist =
(hk.com.mtr.mmis.ws.WoRelationship[])list.toArray(
new hk.com.mtr.mmis.ws.WoRelationship[list.size()]);

}

    protected java.lang.String cmpltmnryContractNo ;

    protected java.lang.String contractDesp ;

    protected java.lang.String contractNo ;

    protected java.lang.String contractor ;

    protected hk.com.mtr.mmis.ws.OrganizationUnit contractorInCharge ;

    protected java.lang.String detailIDs ;

    protected java.lang.String detailLoc ;

    protected java.util.Calendar earPlanStartDate ;

    protected hk.com.mtr.mmis.ws.HumanResource engineerInCharge ;

    protected hk.com.mtr.mmis.ws.EquipClass equipClass ;

    protected java.lang.String equipDownTime ;

    protected hk.com.mtr.mmis.ws.Equipment equipment ;

    protected java.lang.String finalizedInd ;

    protected java.lang.String gcFinanceRefNoCd ;

    protected java.lang.String gcPriorityCd ;

    protected java.lang.String gcProjectNoCd ;

    protected java.lang.String gcProjectTaskNoCd ;

    protected java.lang.String gcSvcBreakdownCd ;

    protected java.lang.String gcWorkNatureLv1Cd ;

    protected java.lang.String gcWorkNatureLv2Cd ;

    protected java.lang.String incidentNumber ;

    protected hk.com.mtr.mmis.ws.IncidentVO incidentVO ;

    protected java.lang.String labourCostCredit ;

    protected java.lang.String labourCostDebit ;

    protected java.util.Calendar lastPlanStartDate ;

    protected java.lang.String locale ;

    protected java.util.Calendar maintainerFinishWork ;

    protected java.util.Calendar maintainerSiteArrival ;

    protected java.util.Calendar maintainerStartWork ;

    protected java.lang.String materialCostCredit ;

    protected java.lang.String materialCostDebit ;

    protected java.lang.String oldWoNo ;

    protected java.lang.String oneOfRelatedMeasurementId ;

    protected java.util.Calendar openDate ;

    protected java.lang.String otherCostCredit ;

    protected java.lang.String otherCostDebit ;

    protected hk.com.mtr.mmis.ws.WoRelationship parentWoRelationship ;

    protected hk.com.mtr.mmis.ws.HumanResource personInCharge ;

    protected java.lang.String personInChargeUserId ;

    protected java.lang.String personInchrgCd ;

    protected java.util.Calendar planCmplDate ;

    protected java.util.Calendar planStartDate ;

    protected java.lang.String plannedCmplTime ;

    protected java.lang.String plannedStartTime ;

    protected java.lang.String primaryRecoveryTime ;

    protected long quantity ;

    protected java.lang.String[] relatedMeasurementIds ;

protected void validateRelatedMeasurementIds(java.lang.String[] param){

}

public void addRelatedMeasurementIds(java.lang.String param){
   if (relatedMeasurementIds == null){
   relatedMeasurementIds = new java.lang.String[]{};
   }



java.util.List list =
org.apache.axis2.databinding.utils.ConverterUtil.toList(relatedMeasurementIds);
list.add(param);
this.relatedMeasurementIds =
(java.lang.String[])list.toArray(
new java.lang.String[list.size()]);

}


    protected hk.com.mtr.mmis.ws.WoRelationship[] relatedWoList ;

protected void validateRelatedWoList(hk.com.mtr.mmis.ws.WoRelationship[] param){

}

public void addRelatedWoList(hk.com.mtr.mmis.ws.WoRelationship param){
   if (relatedWoList == null){
   relatedWoList = new hk.com.mtr.mmis.ws.WoRelationship[]{};
}

java.util.List list =
org.apache.axis2.databinding.utils.ConverterUtil.toList(relatedWoList);
list.add(param);
this.relatedWoList =
(hk.com.mtr.mmis.ws.WoRelationship[])list.toArray(
new hk.com.mtr.mmis.ws.WoRelationship[list.size()]);

}

    protected java.lang.String remark ;

    protected java.lang.String reservedField1 ;

    protected java.lang.String reservedField2 ;

    protected java.lang.String reservedField3 ;

    protected java.lang.String serviceDownTime ;

    protected boolean serviceDownTimeTracker = false ;

    protected java.lang.String serviceNotRequireTime ;

    protected java.lang.String shortLoc ;

    protected java.lang.String status ;

    protected java.lang.String statusDesc ;

    protected hk.com.mtr.mmis.ws.WoStatusHistoryVO statusHis ;

    protected hk.com.mtr.mmis.ws.StandardJob stdJob ;

    protected long stdJobParamListId ;

    protected boolean stdJobParamListIdTracker = false ;

    protected java.lang.String stdJobParamSetName ;

    protected double totalActualHour ;

    protected double totalActualLabourCost ;

    protected double totalActualMaterialCost ;

    protected double totalActualOtherCost ;

    protected double totalActualQuantity ;

    protected double totalPlanHour ;

    protected double totalPlanLabourCost ;

    protected double totalPlanMaterialCost ;

    protected double totalPlanOtherCost ;

	public java.lang.String getAction() {
		return action;
	}

	public void setAction(java.lang.String action) {
		this.action = action;
	}

	public java.util.Calendar getActualCmplDate() {
		return actualCmplDate;
	}

	public void setActualCmplDate(java.util.Calendar actualCmplDate) {
		this.actualCmplDate = actualCmplDate;
	}

	public java.util.Calendar getActualStartDate() {
		return actualStartDate;
	}

	public void setActualStartDate(java.util.Calendar actualStartDate) {
		this.actualStartDate = actualStartDate;
	}

	public java.lang.String getActualStartTime() {
		return actualStartTime;
	}

	public void setActualStartTime(java.lang.String actualStartTime) {
		this.actualStartTime = actualStartTime;
	}

	public hk.com.mtr.mmis.ws.WoRelationship[] getChildWolist() {
		return childWolist;
	}

	public void setChildWolist(hk.com.mtr.mmis.ws.WoRelationship[] childWolist) {
		this.childWolist = childWolist;
	}

	public java.lang.String getCmpltmnryContractNo() {
		return cmpltmnryContractNo;
	}

	public void setCmpltmnryContractNo(java.lang.String cmpltmnryContractNo) {
		this.cmpltmnryContractNo = cmpltmnryContractNo;
	}

	public java.lang.String getContractDesp() {
		return contractDesp;
	}

	public void setContractDesp(java.lang.String contractDesp) {
		this.contractDesp = contractDesp;
	}

	public java.lang.String getContractNo() {
		return contractNo;
	}

	public void setContractNo(java.lang.String contractNo) {
		this.contractNo = contractNo;
	}

	public java.lang.String getContractor() {
		return contractor;
	}

	public void setContractor(java.lang.String contractor) {
		this.contractor = contractor;
	}

	public hk.com.mtr.mmis.ws.OrganizationUnit getContractorInCharge() {
		return contractorInCharge;
	}

	public void setContractorInCharge(hk.com.mtr.mmis.ws.OrganizationUnit contractorInCharge) {
		this.contractorInCharge = contractorInCharge;
	}

	public java.lang.String getDetailIDs() {
		return detailIDs;
	}

	public void setDetailIDs(java.lang.String detailIDs) {
		this.detailIDs = detailIDs;
	}

	public java.lang.String getDetailLoc() {
		return detailLoc;
	}

	public void setDetailLoc(java.lang.String detailLoc) {
		this.detailLoc = detailLoc;
	}

	public java.util.Calendar getEarPlanStartDate() {
		return earPlanStartDate;
	}

	public void setEarPlanStartDate(java.util.Calendar earPlanStartDate) {
		this.earPlanStartDate = earPlanStartDate;
	}

	public hk.com.mtr.mmis.ws.HumanResource getEngineerInCharge() {
		return engineerInCharge;
	}

	public void setEngineerInCharge(hk.com.mtr.mmis.ws.HumanResource engineerInCharge) {
		this.engineerInCharge = engineerInCharge;
	}

	public hk.com.mtr.mmis.ws.EquipClass getEquipClass() {
		return equipClass;
	}

	public void setEquipClass(hk.com.mtr.mmis.ws.EquipClass equipClass) {
		this.equipClass = equipClass;
	}

	public java.lang.String getEquipDownTime() {
		return equipDownTime;
	}

	public void setEquipDownTime(java.lang.String equipDownTime) {
		this.equipDownTime = equipDownTime;
	}

	public hk.com.mtr.mmis.ws.Equipment getEquipment() {
		return equipment;
	}

	public void setEquipment(hk.com.mtr.mmis.ws.Equipment equipment) {
		this.equipment = equipment;
	}

	public java.lang.String getFinalizedInd() {
		return finalizedInd;
	}

	public void setFinalizedInd(java.lang.String finalizedInd) {
		this.finalizedInd = finalizedInd;
	}

	public java.lang.String getGcFinanceRefNoCd() {
		return gcFinanceRefNoCd;
	}

	public void setGcFinanceRefNoCd(java.lang.String gcFinanceRefNoCd) {
		this.gcFinanceRefNoCd = gcFinanceRefNoCd;
	}

	public java.lang.String getGcPriorityCd() {
		return gcPriorityCd;
	}

	public void setGcPriorityCd(java.lang.String gcPriorityCd) {
		this.gcPriorityCd = gcPriorityCd;
	}

	public java.lang.String getGcProjectNoCd() {
		return gcProjectNoCd;
	}

	public void setGcProjectNoCd(java.lang.String gcProjectNoCd) {
		this.gcProjectNoCd = gcProjectNoCd;
	}

	public java.lang.String getGcProjectTaskNoCd() {
		return gcProjectTaskNoCd;
	}

	public void setGcProjectTaskNoCd(java.lang.String gcProjectTaskNoCd) {
		this.gcProjectTaskNoCd = gcProjectTaskNoCd;
	}

	public java.lang.String getGcSvcBreakdownCd() {
		return gcSvcBreakdownCd;
	}

	public void setGcSvcBreakdownCd(java.lang.String gcSvcBreakdownCd) {
		this.gcSvcBreakdownCd = gcSvcBreakdownCd;
	}

	public java.lang.String getGcWorkNatureLv1Cd() {
		return gcWorkNatureLv1Cd;
	}

	public void setGcWorkNatureLv1Cd(java.lang.String gcWorkNatureLv1Cd) {
		this.gcWorkNatureLv1Cd = gcWorkNatureLv1Cd;
	}

	public java.lang.String getGcWorkNatureLv2Cd() {
		return gcWorkNatureLv2Cd;
	}

	public void setGcWorkNatureLv2Cd(java.lang.String gcWorkNatureLv2Cd) {
		this.gcWorkNatureLv2Cd = gcWorkNatureLv2Cd;
	}

	public java.lang.String getIncidentNumber() {
		return incidentNumber;
	}

	public void setIncidentNumber(java.lang.String incidentNumber) {
		this.incidentNumber = incidentNumber;
	}

	public hk.com.mtr.mmis.ws.IncidentVO getIncidentVO() {
		return incidentVO;
	}

	public void setIncidentVO(hk.com.mtr.mmis.ws.IncidentVO incidentVO) {
		this.incidentVO = incidentVO;
	}

	public java.lang.String getLabourCostCredit() {
		return labourCostCredit;
	}

	public void setLabourCostCredit(java.lang.String labourCostCredit) {
		this.labourCostCredit = labourCostCredit;
	}

	public java.lang.String getLabourCostDebit() {
		return labourCostDebit;
	}

	public void setLabourCostDebit(java.lang.String labourCostDebit) {
		this.labourCostDebit = labourCostDebit;
	}

	public java.util.Calendar getLastPlanStartDate() {
		return lastPlanStartDate;
	}

	public void setLastPlanStartDate(java.util.Calendar lastPlanStartDate) {
		this.lastPlanStartDate = lastPlanStartDate;
	}

	public java.lang.String getLocale() {
		return locale;
	}

	public void setLocale(java.lang.String locale) {
		this.locale = locale;
	}

	public java.util.Calendar getMaintainerFinishWork() {
		return maintainerFinishWork;
	}

	public void setMaintainerFinishWork(java.util.Calendar maintainerFinishWork) {
		this.maintainerFinishWork = maintainerFinishWork;
	}

	public java.util.Calendar getMaintainerSiteArrival() {
		return maintainerSiteArrival;
	}

	public void setMaintainerSiteArrival(java.util.Calendar maintainerSiteArrival) {
		this.maintainerSiteArrival = maintainerSiteArrival;
	}

	public java.util.Calendar getMaintainerStartWork() {
		return maintainerStartWork;
	}

	public void setMaintainerStartWork(java.util.Calendar maintainerStartWork) {
		this.maintainerStartWork = maintainerStartWork;
	}

	public java.lang.String getMaterialCostCredit() {
		return materialCostCredit;
	}

	public void setMaterialCostCredit(java.lang.String materialCostCredit) {
		this.materialCostCredit = materialCostCredit;
	}

	public java.lang.String getMaterialCostDebit() {
		return materialCostDebit;
	}

	public void setMaterialCostDebit(java.lang.String materialCostDebit) {
		this.materialCostDebit = materialCostDebit;
	}

	public java.lang.String getOldWoNo() {
		return oldWoNo;
	}

	public void setOldWoNo(java.lang.String oldWoNo) {
		this.oldWoNo = oldWoNo;
	}

	public java.lang.String getOneOfRelatedMeasurementId() {
		return oneOfRelatedMeasurementId;
	}

	public void setOneOfRelatedMeasurementId(java.lang.String oneOfRelatedMeasurementId) {
		this.oneOfRelatedMeasurementId = oneOfRelatedMeasurementId;
	}

	public java.util.Calendar getOpenDate() {
		return openDate;
	}

	public void setOpenDate(java.util.Calendar openDate) {
		this.openDate = openDate;
	}

	public java.lang.String getOtherCostCredit() {
		return otherCostCredit;
	}

	public void setOtherCostCredit(java.lang.String otherCostCredit) {
		this.otherCostCredit = otherCostCredit;
	}

	public java.lang.String getOtherCostDebit() {
		return otherCostDebit;
	}

	public void setOtherCostDebit(java.lang.String otherCostDebit) {
		this.otherCostDebit = otherCostDebit;
	}

	public hk.com.mtr.mmis.ws.WoRelationship getParentWoRelationship() {
		return parentWoRelationship;
	}

	public void setParentWoRelationship(hk.com.mtr.mmis.ws.WoRelationship parentWoRelationship) {
		this.parentWoRelationship = parentWoRelationship;
	}

	public hk.com.mtr.mmis.ws.HumanResource getPersonInCharge() {
		return personInCharge;
	}

	public void setPersonInCharge(hk.com.mtr.mmis.ws.HumanResource personInCharge) {
		this.personInCharge = personInCharge;
	}

	public java.lang.String getPersonInChargeUserId() {
		return personInChargeUserId;
	}

	public void setPersonInChargeUserId(java.lang.String personInChargeUserId) {
		this.personInChargeUserId = personInChargeUserId;
	}

	public java.lang.String getPersonInchrgCd() {
		return personInchrgCd;
	}

	public void setPersonInchrgCd(java.lang.String personInchrgCd) {
		this.personInchrgCd = personInchrgCd;
	}

	public java.util.Calendar getPlanCmplDate() {
		return planCmplDate;
	}

	public void setPlanCmplDate(java.util.Calendar planCmplDate) {
		this.planCmplDate = planCmplDate;
	}

	public java.util.Calendar getPlanStartDate() {
		return planStartDate;
	}

	public void setPlanStartDate(java.util.Calendar planStartDate) {
		this.planStartDate = planStartDate;
	}

	public java.lang.String getPlannedCmplTime() {
		return plannedCmplTime;
	}

	public void setPlannedCmplTime(java.lang.String plannedCmplTime) {
		this.plannedCmplTime = plannedCmplTime;
	}

	public java.lang.String getPlannedStartTime() {
		return plannedStartTime;
	}

	public void setPlannedStartTime(java.lang.String plannedStartTime) {
		this.plannedStartTime = plannedStartTime;
	}

	public java.lang.String getPrimaryRecoveryTime() {
		return primaryRecoveryTime;
	}

	public void setPrimaryRecoveryTime(java.lang.String primaryRecoveryTime) {
		this.primaryRecoveryTime = primaryRecoveryTime;
	}

	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	public java.lang.String[] getRelatedMeasurementIds() {
		return relatedMeasurementIds;
	}

	public void setRelatedMeasurementIds(java.lang.String[] relatedMeasurementIds) {
		this.relatedMeasurementIds = relatedMeasurementIds;
	}

	public hk.com.mtr.mmis.ws.WoRelationship[] getRelatedWoList() {
		return relatedWoList;
	}

	public void setRelatedWoList(hk.com.mtr.mmis.ws.WoRelationship[] relatedWoList) {
		this.relatedWoList = relatedWoList;
	}

	public java.lang.String getRemark() {
		return remark;
	}

	public void setRemark(java.lang.String remark) {
		this.remark = remark;
	}

	public java.lang.String getReservedField1() {
		return reservedField1;
	}

	public void setReservedField1(java.lang.String reservedField1) {
		this.reservedField1 = reservedField1;
	}

	public java.lang.String getReservedField2() {
		return reservedField2;
	}

	public void setReservedField2(java.lang.String reservedField2) {
		this.reservedField2 = reservedField2;
	}

	public java.lang.String getReservedField3() {
		return reservedField3;
	}

	public void setReservedField3(java.lang.String reservedField3) {
		this.reservedField3 = reservedField3;
	}

	public java.lang.String getServiceDownTime() {
		return serviceDownTime;
	}

	public void setServiceDownTime(java.lang.String serviceDownTime) {
		this.serviceDownTime = serviceDownTime;
	}

	public boolean isServiceDownTimeTracker() {
		return serviceDownTimeTracker;
	}

	public void setServiceDownTimeTracker(boolean serviceDownTimeTracker) {
		this.serviceDownTimeTracker = serviceDownTimeTracker;
	}

	public java.lang.String getServiceNotRequireTime() {
		return serviceNotRequireTime;
	}

	public void setServiceNotRequireTime(java.lang.String serviceNotRequireTime) {
		this.serviceNotRequireTime = serviceNotRequireTime;
	}

	public java.lang.String getShortLoc() {
		return shortLoc;
	}

	public void setShortLoc(java.lang.String shortLoc) {
		this.shortLoc = shortLoc;
	}

	public java.lang.String getStatus() {
		return status;
	}

	public void setStatus(java.lang.String status) {
		this.status = status;
	}

	public java.lang.String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(java.lang.String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public hk.com.mtr.mmis.ws.WoStatusHistoryVO getStatusHis() {
		return statusHis;
	}

	public void setStatusHis(hk.com.mtr.mmis.ws.WoStatusHistoryVO statusHis) {
		this.statusHis = statusHis;
	}

	public hk.com.mtr.mmis.ws.StandardJob getStdJob() {
		return stdJob;
	}

	public void setStdJob(hk.com.mtr.mmis.ws.StandardJob stdJob) {
		this.stdJob = stdJob;
	}

	public long getStdJobParamListId() {
		return stdJobParamListId;
	}

	public void setStdJobParamListId(long stdJobParamListId) {
		this.stdJobParamListId = stdJobParamListId;
	}

	public boolean isStdJobParamListIdTracker() {
		return stdJobParamListIdTracker;
	}

	public void setStdJobParamListIdTracker(boolean stdJobParamListIdTracker) {
		this.stdJobParamListIdTracker = stdJobParamListIdTracker;
	}

	public java.lang.String getStdJobParamSetName() {
		return stdJobParamSetName;
	}

	public void setStdJobParamSetName(java.lang.String stdJobParamSetName) {
		this.stdJobParamSetName = stdJobParamSetName;
	}

	public double getTotalActualHour() {
		return totalActualHour;
	}

	public void setTotalActualHour(double totalActualHour) {
		this.totalActualHour = totalActualHour;
	}

	public double getTotalActualLabourCost() {
		return totalActualLabourCost;
	}

	public void setTotalActualLabourCost(double totalActualLabourCost) {
		this.totalActualLabourCost = totalActualLabourCost;
	}

	public double getTotalActualMaterialCost() {
		return totalActualMaterialCost;
	}

	public void setTotalActualMaterialCost(double totalActualMaterialCost) {
		this.totalActualMaterialCost = totalActualMaterialCost;
	}

	public double getTotalActualOtherCost() {
		return totalActualOtherCost;
	}

	public void setTotalActualOtherCost(double totalActualOtherCost) {
		this.totalActualOtherCost = totalActualOtherCost;
	}

	public double getTotalActualQuantity() {
		return totalActualQuantity;
	}

	public void setTotalActualQuantity(double totalActualQuantity) {
		this.totalActualQuantity = totalActualQuantity;
	}

	public double getTotalPlanHour() {
		return totalPlanHour;
	}

	public void setTotalPlanHour(double totalPlanHour) {
		this.totalPlanHour = totalPlanHour;
	}

	public double getTotalPlanLabourCost() {
		return totalPlanLabourCost;
	}

	public void setTotalPlanLabourCost(double totalPlanLabourCost) {
		this.totalPlanLabourCost = totalPlanLabourCost;
	}

	public double getTotalPlanMaterialCost() {
		return totalPlanMaterialCost;
	}

	public void setTotalPlanMaterialCost(double totalPlanMaterialCost) {
		this.totalPlanMaterialCost = totalPlanMaterialCost;
	}

	public double getTotalPlanOtherCost() {
		return totalPlanOtherCost;
	}

	public void setTotalPlanOtherCost(double totalPlanOtherCost) {
		this.totalPlanOtherCost = totalPlanOtherCost;
	}

//    protected double localTotalPlanQuantity ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localTotalPlanQuantityTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return double
//*/
//public  double getTotalPlanQuantity(){
//return localTotalPlanQuantity;
//}
//
//
//
///**
//* Auto generated setter method
//* @param param TotalPlanQuantity
//*/
//public void setTotalPlanQuantity(double param){
//
//       // setting primitive attribute tracker to true
//       
//               if (java.lang.Double.isNaN(param)) {
//           localTotalPlanQuantityTracker = false;
//              
//       } else {
//          localTotalPlanQuantityTracker = true;
//       }
//   
//            this.localTotalPlanQuantity=param;
//    
//
//}
//
//
///**
//* field for TotalRecoveryTime
//*/
//
//
//    protected java.lang.String localTotalRecoveryTime ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localTotalRecoveryTimeTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return java.lang.String
//*/
//public  java.lang.String getTotalRecoveryTime(){
//return localTotalRecoveryTime;
//}
//
//
//
///**
//* Auto generated setter method
//* @param param TotalRecoveryTime
//*/
//public void setTotalRecoveryTime(java.lang.String param){
//
//       if (param != null){
//          //update the setting tracker
//          localTotalRecoveryTimeTracker = true;
//       } else {
//          localTotalRecoveryTimeTracker = false;
//              
//       }
//   
//            this.localTotalRecoveryTime=param;
//    
//
//}
//
//
///**
//* field for TotalResponseTime
//*/
//
//
//    protected java.lang.String localTotalResponseTime ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localTotalResponseTimeTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return java.lang.String
//*/
//public  java.lang.String getTotalResponseTime(){
//return localTotalResponseTime;
//}
//
//
//
///**
//* Auto generated setter method
//* @param param TotalResponseTime
//*/
//public void setTotalResponseTime(java.lang.String param){
//
//       if (param != null){
//          //update the setting tracker
//          localTotalResponseTimeTracker = true;
//       } else {
//          localTotalResponseTimeTracker = false;
//              
//       }
//   
//            this.localTotalResponseTime=param;
//    
//
//}
//
//
///**
//* field for TotalSuspensionTime
//*/
//
//
//    protected java.lang.String localTotalSuspensionTime ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localTotalSuspensionTimeTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return java.lang.String
//*/
//public  java.lang.String getTotalSuspensionTime(){
//return localTotalSuspensionTime;
//}
//
//
//
///**
//* Auto generated setter method
//* @param param TotalSuspensionTime
//*/
//public void setTotalSuspensionTime(java.lang.String param){
//
//       if (param != null){
//          //update the setting tracker
//          localTotalSuspensionTimeTracker = true;
//       } else {
//          localTotalSuspensionTimeTracker = false;
//              
//       }
//   
//            this.localTotalSuspensionTime=param;
//    
//
//}
//
//
///**
//* field for WoActDelLabourCostVOs
//* This was an Array!
//*/
//
//
//    protected hk.com.mtr.mmis.ws.WoActBolVO[] localWoActDelLabourCostVOs ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWoActDelLabourCostVOsTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return hk.com.mtr.mmis.ws.WoActBolVO[]
//*/
//public  hk.com.mtr.mmis.ws.WoActBolVO[] getWoActDelLabourCostVOs(){
//return localWoActDelLabourCostVOs;
//}
//
//
//
//
//
//
///**
//* validate the array for WoActDelLabourCostVOs
//*/
//protected void validateWoActDelLabourCostVOs(hk.com.mtr.mmis.ws.WoActBolVO[] param){
//
//}
//
//
///**
//* Auto generated setter method
//* @param param WoActDelLabourCostVOs
//*/
//public void setWoActDelLabourCostVOs(hk.com.mtr.mmis.ws.WoActBolVO[] param){
//
//   validateWoActDelLabourCostVOs(param);
//
//
//          if (param != null){
//             //update the setting tracker
//             localWoActDelLabourCostVOsTracker = true;
//          } else {
//             localWoActDelLabourCostVOsTracker = true;
//                 
//          }
//      
//      this.localWoActDelLabourCostVOs=param;
//}
//
//
//
///**
//* Auto generated add method for the array for convenience
//* @param param hk.com.mtr.mmis.ws.WoActBolVO
//*/
//public void addWoActDelLabourCostVOs(hk.com.mtr.mmis.ws.WoActBolVO param){
//   if (localWoActDelLabourCostVOs == null){
//   localWoActDelLabourCostVOs = new hk.com.mtr.mmis.ws.WoActBolVO[]{};
//   }
//
//
// //update the setting tracker
//localWoActDelLabourCostVOsTracker = true;
//
//
//java.util.List list =
//org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoActDelLabourCostVOs);
//list.add(param);
//this.localWoActDelLabourCostVOs =
//(hk.com.mtr.mmis.ws.WoActBolVO[])list.toArray(
//new hk.com.mtr.mmis.ws.WoActBolVO[list.size()]);
//
//}
//
//
///**
//* field for WoActDelMaterialCostVOs
//* This was an Array!
//*/
//
//
//    protected hk.com.mtr.mmis.ws.WoActBomVO[] localWoActDelMaterialCostVOs ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWoActDelMaterialCostVOsTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return hk.com.mtr.mmis.ws.WoActBomVO[]
//*/
//public  hk.com.mtr.mmis.ws.WoActBomVO[] getWoActDelMaterialCostVOs(){
//return localWoActDelMaterialCostVOs;
//}
//
//
//
//
//
//
///**
//* validate the array for WoActDelMaterialCostVOs
//*/
//protected void validateWoActDelMaterialCostVOs(hk.com.mtr.mmis.ws.WoActBomVO[] param){
//
//}
//
//
///**
//* Auto generated setter method
//* @param param WoActDelMaterialCostVOs
//*/
//public void setWoActDelMaterialCostVOs(hk.com.mtr.mmis.ws.WoActBomVO[] param){
//
//   validateWoActDelMaterialCostVOs(param);
//
//
//          if (param != null){
//             //update the setting tracker
//             localWoActDelMaterialCostVOsTracker = true;
//          } else {
//             localWoActDelMaterialCostVOsTracker = true;
//                 
//          }
//      
//      this.localWoActDelMaterialCostVOs=param;
//}
//
//
//
///**
//* Auto generated add method for the array for convenience
//* @param param hk.com.mtr.mmis.ws.WoActBomVO
//*/
//public void addWoActDelMaterialCostVOs(hk.com.mtr.mmis.ws.WoActBomVO param){
//   if (localWoActDelMaterialCostVOs == null){
//   localWoActDelMaterialCostVOs = new hk.com.mtr.mmis.ws.WoActBomVO[]{};
//   }
//
//
// //update the setting tracker
//localWoActDelMaterialCostVOsTracker = true;
//
//
//java.util.List list =
//org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoActDelMaterialCostVOs);
//list.add(param);
//this.localWoActDelMaterialCostVOs =
//(hk.com.mtr.mmis.ws.WoActBomVO[])list.toArray(
//new hk.com.mtr.mmis.ws.WoActBomVO[list.size()]);
//
//}
//
//
///**
//* field for WoActDelOtherCostVOs
//* This was an Array!
//*/
//
//
//    protected hk.com.mtr.mmis.ws.WoActBooVO[] localWoActDelOtherCostVOs ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWoActDelOtherCostVOsTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return hk.com.mtr.mmis.ws.WoActBooVO[]
//*/
//public  hk.com.mtr.mmis.ws.WoActBooVO[] getWoActDelOtherCostVOs(){
//return localWoActDelOtherCostVOs;
//}
//
//
//
//
//
//
///**
//* validate the array for WoActDelOtherCostVOs
//*/
//protected void validateWoActDelOtherCostVOs(hk.com.mtr.mmis.ws.WoActBooVO[] param){
//
//}
//
//
///**
//* Auto generated setter method
//* @param param WoActDelOtherCostVOs
//*/
//public void setWoActDelOtherCostVOs(hk.com.mtr.mmis.ws.WoActBooVO[] param){
//
//   validateWoActDelOtherCostVOs(param);
//
//
//          if (param != null){
//             //update the setting tracker
//             localWoActDelOtherCostVOsTracker = true;
//          } else {
//             localWoActDelOtherCostVOsTracker = true;
//                 
//          }
//      
//      this.localWoActDelOtherCostVOs=param;
//}
//
//
//
///**
//* Auto generated add method for the array for convenience
//* @param param hk.com.mtr.mmis.ws.WoActBooVO
//*/
//public void addWoActDelOtherCostVOs(hk.com.mtr.mmis.ws.WoActBooVO param){
//   if (localWoActDelOtherCostVOs == null){
//   localWoActDelOtherCostVOs = new hk.com.mtr.mmis.ws.WoActBooVO[]{};
//   }
//
//
// //update the setting tracker
//localWoActDelOtherCostVOsTracker = true;
//
//
//java.util.List list =
//org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoActDelOtherCostVOs);
//list.add(param);
//this.localWoActDelOtherCostVOs =
//(hk.com.mtr.mmis.ws.WoActBooVO[])list.toArray(
//new hk.com.mtr.mmis.ws.WoActBooVO[list.size()]);
//
//}
//
//
///**
//* field for WoActLabourCostVOs
//* This was an Array!
//*/
//
//
//    protected hk.com.mtr.mmis.ws.WoActBolVO[] localWoActLabourCostVOs ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWoActLabourCostVOsTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return hk.com.mtr.mmis.ws.WoActBolVO[]
//*/
//public  hk.com.mtr.mmis.ws.WoActBolVO[] getWoActLabourCostVOs(){
//return localWoActLabourCostVOs;
//}
//
//
//
//
//
//
///**
//* validate the array for WoActLabourCostVOs
//*/
//protected void validateWoActLabourCostVOs(hk.com.mtr.mmis.ws.WoActBolVO[] param){
//
//}
//
//
///**
//* Auto generated setter method
//* @param param WoActLabourCostVOs
//*/
//public void setWoActLabourCostVOs(hk.com.mtr.mmis.ws.WoActBolVO[] param){
//
//   validateWoActLabourCostVOs(param);
//
//
//          if (param != null){
//             //update the setting tracker
//             localWoActLabourCostVOsTracker = true;
//          } else {
//             localWoActLabourCostVOsTracker = true;
//                 
//          }
//      
//      this.localWoActLabourCostVOs=param;
//}
//
//
//
///**
//* Auto generated add method for the array for convenience
//* @param param hk.com.mtr.mmis.ws.WoActBolVO
//*/
//public void addWoActLabourCostVOs(hk.com.mtr.mmis.ws.WoActBolVO param){
//   if (localWoActLabourCostVOs == null){
//   localWoActLabourCostVOs = new hk.com.mtr.mmis.ws.WoActBolVO[]{};
//   }
//
//
// //update the setting tracker
//localWoActLabourCostVOsTracker = true;
//
//
//java.util.List list =
//org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoActLabourCostVOs);
//list.add(param);
//this.localWoActLabourCostVOs =
//(hk.com.mtr.mmis.ws.WoActBolVO[])list.toArray(
//new hk.com.mtr.mmis.ws.WoActBolVO[list.size()]);
//
//}
//
//
///**
//* field for WoActLocationVOs
//* This was an Array!
//*/
//
//
//    protected hk.com.mtr.mmis.ws.LocationRangeVO[] localWoActLocationVOs ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWoActLocationVOsTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return hk.com.mtr.mmis.ws.LocationRangeVO[]
//*/
//public  hk.com.mtr.mmis.ws.LocationRangeVO[] getWoActLocationVOs(){
//return localWoActLocationVOs;
//}
//
//
//
//
//
//
///**
//* validate the array for WoActLocationVOs
//*/
//protected void validateWoActLocationVOs(hk.com.mtr.mmis.ws.LocationRangeVO[] param){
//
//}
//
//
///**
//* Auto generated setter method
//* @param param WoActLocationVOs
//*/
//public void setWoActLocationVOs(hk.com.mtr.mmis.ws.LocationRangeVO[] param){
//
//   validateWoActLocationVOs(param);
//
//
//          if (param != null){
//             //update the setting tracker
//             localWoActLocationVOsTracker = true;
//          } else {
//             localWoActLocationVOsTracker = true;
//                 
//          }
//      
//      this.localWoActLocationVOs=param;
//}
//
//
//
///**
//* Auto generated add method for the array for convenience
//* @param param hk.com.mtr.mmis.ws.LocationRangeVO
//*/
//public void addWoActLocationVOs(hk.com.mtr.mmis.ws.LocationRangeVO param){
//   if (localWoActLocationVOs == null){
//   localWoActLocationVOs = new hk.com.mtr.mmis.ws.LocationRangeVO[]{};
//   }
//
//
// //update the setting tracker
//localWoActLocationVOsTracker = true;
//
//
//java.util.List list =
//org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoActLocationVOs);
//list.add(param);
//this.localWoActLocationVOs =
//(hk.com.mtr.mmis.ws.LocationRangeVO[])list.toArray(
//new hk.com.mtr.mmis.ws.LocationRangeVO[list.size()]);
//
//}
//
//
///**
//* field for WoActMaterialCostVOs
//* This was an Array!
//*/
//
//
//    protected hk.com.mtr.mmis.ws.WoActBomVO[] localWoActMaterialCostVOs ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWoActMaterialCostVOsTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return hk.com.mtr.mmis.ws.WoActBomVO[]
//*/
//public  hk.com.mtr.mmis.ws.WoActBomVO[] getWoActMaterialCostVOs(){
//return localWoActMaterialCostVOs;
//}
//
//
//
//
//
//
///**
//* validate the array for WoActMaterialCostVOs
//*/
//protected void validateWoActMaterialCostVOs(hk.com.mtr.mmis.ws.WoActBomVO[] param){
//
//}
//
//
///**
//* Auto generated setter method
//* @param param WoActMaterialCostVOs
//*/
//public void setWoActMaterialCostVOs(hk.com.mtr.mmis.ws.WoActBomVO[] param){
//
//   validateWoActMaterialCostVOs(param);
//
//
//          if (param != null){
//             //update the setting tracker
//             localWoActMaterialCostVOsTracker = true;
//          } else {
//             localWoActMaterialCostVOsTracker = true;
//                 
//          }
//      
//      this.localWoActMaterialCostVOs=param;
//}
//
//
//
///**
//* Auto generated add method for the array for convenience
//* @param param hk.com.mtr.mmis.ws.WoActBomVO
//*/
//public void addWoActMaterialCostVOs(hk.com.mtr.mmis.ws.WoActBomVO param){
//   if (localWoActMaterialCostVOs == null){
//   localWoActMaterialCostVOs = new hk.com.mtr.mmis.ws.WoActBomVO[]{};
//   }
//
//
// //update the setting tracker
//localWoActMaterialCostVOsTracker = true;
//
//
//java.util.List list =
//org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoActMaterialCostVOs);
//list.add(param);
//this.localWoActMaterialCostVOs =
//(hk.com.mtr.mmis.ws.WoActBomVO[])list.toArray(
//new hk.com.mtr.mmis.ws.WoActBomVO[list.size()]);
//
//}
//
//
///**
//* field for WoActOtherCostVOs
//* This was an Array!
//*/
//
//
//    protected hk.com.mtr.mmis.ws.WoActBooVO[] localWoActOtherCostVOs ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWoActOtherCostVOsTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return hk.com.mtr.mmis.ws.WoActBooVO[]
//*/
//public  hk.com.mtr.mmis.ws.WoActBooVO[] getWoActOtherCostVOs(){
//return localWoActOtherCostVOs;
//}
//
//
//
//
//
//
///**
//* validate the array for WoActOtherCostVOs
//*/
//protected void validateWoActOtherCostVOs(hk.com.mtr.mmis.ws.WoActBooVO[] param){
//
//}
//
//
///**
//* Auto generated setter method
//* @param param WoActOtherCostVOs
//*/
//public void setWoActOtherCostVOs(hk.com.mtr.mmis.ws.WoActBooVO[] param){
//
//   validateWoActOtherCostVOs(param);
//
//
//          if (param != null){
//             //update the setting tracker
//             localWoActOtherCostVOsTracker = true;
//          } else {
//             localWoActOtherCostVOsTracker = true;
//                 
//          }
//      
//      this.localWoActOtherCostVOs=param;
//}
//
//
//
///**
//* Auto generated add method for the array for convenience
//* @param param hk.com.mtr.mmis.ws.WoActBooVO
//*/
//public void addWoActOtherCostVOs(hk.com.mtr.mmis.ws.WoActBooVO param){
//   if (localWoActOtherCostVOs == null){
//   localWoActOtherCostVOs = new hk.com.mtr.mmis.ws.WoActBooVO[]{};
//   }
//
//
// //update the setting tracker
//localWoActOtherCostVOsTracker = true;
//
//
//java.util.List list =
//org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoActOtherCostVOs);
//list.add(param);
//this.localWoActOtherCostVOs =
//(hk.com.mtr.mmis.ws.WoActBooVO[])list.toArray(
//new hk.com.mtr.mmis.ws.WoActBooVO[list.size()]);
//
//}
//
//
///**
//* field for WoDesp
//*/
//
//
//    protected java.lang.String localWoDesp ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWoDespTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return java.lang.String
//*/
//public  java.lang.String getWoDesp(){
//return localWoDesp;
//}
//
//
//
///**
//* Auto generated setter method
//* @param param WoDesp
//*/
//public void setWoDesp(java.lang.String param){
//
//       if (param != null){
//          //update the setting tracker
//          localWoDespTracker = true;
//       } else {
//          localWoDespTracker = false;
//              
//       }
//   
//            this.localWoDesp=param;
//    
//
//}
//
//
///**
//* field for WoEquipAssocs
//* This was an Array!
//*/
//
//
//    protected long[] localWoEquipAssocs ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWoEquipAssocsTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return long[]
//*/
//public  long[] getWoEquipAssocs(){
//return localWoEquipAssocs;
//}
//
//
//
//
//
//
///**
//* validate the array for WoEquipAssocs
//*/
//protected void validateWoEquipAssocs(long[] param){
//
//}
//
//
///**
//* Auto generated setter method
//* @param param WoEquipAssocs
//*/
//public void setWoEquipAssocs(long[] param){
//
//   validateWoEquipAssocs(param);
//
//
//          if (param != null){
//             //update the setting tracker
//             localWoEquipAssocsTracker = true;
//          } else {
//             localWoEquipAssocsTracker = true;
//                 
//          }
//      
//      this.localWoEquipAssocs=param;
//}
//
//
//
//
///**
//* field for WoFailureDetailVOs
//* This was an Array!
//*/
//
//
//    protected hk.com.mtr.mmis.ws.WoFailureDetailVO[] localWoFailureDetailVOs ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWoFailureDetailVOsTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return hk.com.mtr.mmis.ws.WoFailureDetailVO[]
//*/
//public  hk.com.mtr.mmis.ws.WoFailureDetailVO[] getWoFailureDetailVOs(){
//return localWoFailureDetailVOs;
//}
//
//
//
//
//
//
///**
//* validate the array for WoFailureDetailVOs
//*/
//protected void validateWoFailureDetailVOs(hk.com.mtr.mmis.ws.WoFailureDetailVO[] param){
//
//}
//
//
///**
//* Auto generated setter method
//* @param param WoFailureDetailVOs
//*/
//public void setWoFailureDetailVOs(hk.com.mtr.mmis.ws.WoFailureDetailVO[] param){
//
//   validateWoFailureDetailVOs(param);
//
//
//          if (param != null){
//             //update the setting tracker
//             localWoFailureDetailVOsTracker = true;
//          } else {
//             localWoFailureDetailVOsTracker = true;
//                 
//          }
//      
//      this.localWoFailureDetailVOs=param;
//}
//
//
//
///**
//* Auto generated add method for the array for convenience
//* @param param hk.com.mtr.mmis.ws.WoFailureDetailVO
//*/
//public void addWoFailureDetailVOs(hk.com.mtr.mmis.ws.WoFailureDetailVO param){
//   if (localWoFailureDetailVOs == null){
//   localWoFailureDetailVOs = new hk.com.mtr.mmis.ws.WoFailureDetailVO[]{};
//   }
//
//
// //update the setting tracker
//localWoFailureDetailVOsTracker = true;
//
//
//java.util.List list =
//org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoFailureDetailVOs);
//list.add(param);
//this.localWoFailureDetailVOs =
//(hk.com.mtr.mmis.ws.WoFailureDetailVO[])list.toArray(
//new hk.com.mtr.mmis.ws.WoFailureDetailVO[list.size()]);
//
//}
//
//
///**
//* field for WoFailureInfoVO
//*/
//
//
//    protected hk.com.mtr.mmis.ws.WoFailureInfoVO localWoFailureInfoVO ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWoFailureInfoVOTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return hk.com.mtr.mmis.ws.WoFailureInfoVO
//*/
//public  hk.com.mtr.mmis.ws.WoFailureInfoVO getWoFailureInfoVO(){
//return localWoFailureInfoVO;
//}
//
//
//
///**
//* Auto generated setter method
//* @param param WoFailureInfoVO
//*/
//public void setWoFailureInfoVO(hk.com.mtr.mmis.ws.WoFailureInfoVO param){
//
//       if (param != null){
//          //update the setting tracker
//          localWoFailureInfoVOTracker = true;
//       } else {
//          localWoFailureInfoVOTracker = false;
//              
//       }
//   
//            this.localWoFailureInfoVO=param;
//    
//
//}
//
//
///**
//* field for WoFollowupActionVOs
//* This was an Array!
//*/
//
//
//    protected hk.com.mtr.mmis.ws.WoFollowupActionVO[] localWoFollowupActionVOs ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWoFollowupActionVOsTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return hk.com.mtr.mmis.ws.WoFollowupActionVO[]
//*/
//public  hk.com.mtr.mmis.ws.WoFollowupActionVO[] getWoFollowupActionVOs(){
//return localWoFollowupActionVOs;
//}
//
//
//
//
//
//
///**
//* validate the array for WoFollowupActionVOs
//*/
//protected void validateWoFollowupActionVOs(hk.com.mtr.mmis.ws.WoFollowupActionVO[] param){
//
//}
//
//
///**
//* Auto generated setter method
//* @param param WoFollowupActionVOs
//*/
//public void setWoFollowupActionVOs(hk.com.mtr.mmis.ws.WoFollowupActionVO[] param){
//
//   validateWoFollowupActionVOs(param);
//
//
//          if (param != null){
//             //update the setting tracker
//             localWoFollowupActionVOsTracker = true;
//          } else {
//             localWoFollowupActionVOsTracker = true;
//                 
//          }
//      
//      this.localWoFollowupActionVOs=param;
//}
//
//
//
///**
//* Auto generated add method for the array for convenience
//* @param param hk.com.mtr.mmis.ws.WoFollowupActionVO
//*/
//public void addWoFollowupActionVOs(hk.com.mtr.mmis.ws.WoFollowupActionVO param){
//   if (localWoFollowupActionVOs == null){
//   localWoFollowupActionVOs = new hk.com.mtr.mmis.ws.WoFollowupActionVO[]{};
//   }
//
//
// //update the setting tracker
//localWoFollowupActionVOsTracker = true;
//
//
//java.util.List list =
//org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoFollowupActionVOs);
//list.add(param);
//this.localWoFollowupActionVOs =
//(hk.com.mtr.mmis.ws.WoFollowupActionVO[])list.toArray(
//new hk.com.mtr.mmis.ws.WoFollowupActionVO[list.size()]);
//
//}
//
//
///**
//* field for WoJobRequirementVOs
//* This was an Array!
//*/
//
//
//    protected hk.com.mtr.mmis.ws.WoJobRequirementVO[] localWoJobRequirementVOs ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWoJobRequirementVOsTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return hk.com.mtr.mmis.ws.WoJobRequirementVO[]
//*/
//public  hk.com.mtr.mmis.ws.WoJobRequirementVO[] getWoJobRequirementVOs(){
//return localWoJobRequirementVOs;
//}
//
//
//
//
//
//
///**
//* validate the array for WoJobRequirementVOs
//*/
//protected void validateWoJobRequirementVOs(hk.com.mtr.mmis.ws.WoJobRequirementVO[] param){
//
//}
//
//
///**
//* Auto generated setter method
//* @param param WoJobRequirementVOs
//*/
//public void setWoJobRequirementVOs(hk.com.mtr.mmis.ws.WoJobRequirementVO[] param){
//
//   validateWoJobRequirementVOs(param);
//
//
//          if (param != null){
//             //update the setting tracker
//             localWoJobRequirementVOsTracker = true;
//          } else {
//             localWoJobRequirementVOsTracker = true;
//                 
//          }
//      
//      this.localWoJobRequirementVOs=param;
//}
//
//
//
///**
//* Auto generated add method for the array for convenience
//* @param param hk.com.mtr.mmis.ws.WoJobRequirementVO
//*/
//public void addWoJobRequirementVOs(hk.com.mtr.mmis.ws.WoJobRequirementVO param){
//   if (localWoJobRequirementVOs == null){
//   localWoJobRequirementVOs = new hk.com.mtr.mmis.ws.WoJobRequirementVO[]{};
//   }
//
//
// //update the setting tracker
//localWoJobRequirementVOsTracker = true;
//
//
//java.util.List list =
//org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoJobRequirementVOs);
//list.add(param);
//this.localWoJobRequirementVOs =
//(hk.com.mtr.mmis.ws.WoJobRequirementVO[])list.toArray(
//new hk.com.mtr.mmis.ws.WoJobRequirementVO[list.size()]);
//
//}
//
//
///**
//* field for WoNo
//*/
//
//
//    protected java.lang.String localWoNo ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWoNoTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return java.lang.String
//*/
//public  java.lang.String getWoNo(){
//return localWoNo;
//}
//
//
//
///**
//* Auto generated setter method
//* @param param WoNo
//*/
//public void setWoNo(java.lang.String param){
//
//       if (param != null){
//          //update the setting tracker
//          localWoNoTracker = true;
//       } else {
//          localWoNoTracker = false;
//              
//       }
//   
//            this.localWoNo=param;
//    
//
//}
//
//
///**
//* field for WoPlanLabourCostVOs
//* This was an Array!
//*/
//
//
//    protected hk.com.mtr.mmis.ws.WoPlanBolVO[] localWoPlanLabourCostVOs ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWoPlanLabourCostVOsTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return hk.com.mtr.mmis.ws.WoPlanBolVO[]
//*/
//public  hk.com.mtr.mmis.ws.WoPlanBolVO[] getWoPlanLabourCostVOs(){
//return localWoPlanLabourCostVOs;
//}
//
//
//
//
//
//
///**
//* validate the array for WoPlanLabourCostVOs
//*/
//protected void validateWoPlanLabourCostVOs(hk.com.mtr.mmis.ws.WoPlanBolVO[] param){
//
//}
//
//
///**
//* Auto generated setter method
//* @param param WoPlanLabourCostVOs
//*/
//public void setWoPlanLabourCostVOs(hk.com.mtr.mmis.ws.WoPlanBolVO[] param){
//
//   validateWoPlanLabourCostVOs(param);
//
//
//          if (param != null){
//             //update the setting tracker
//             localWoPlanLabourCostVOsTracker = true;
//          } else {
//             localWoPlanLabourCostVOsTracker = true;
//                 
//          }
//      
//      this.localWoPlanLabourCostVOs=param;
//}
//
//
//
///**
//* Auto generated add method for the array for convenience
//* @param param hk.com.mtr.mmis.ws.WoPlanBolVO
//*/
//public void addWoPlanLabourCostVOs(hk.com.mtr.mmis.ws.WoPlanBolVO param){
//   if (localWoPlanLabourCostVOs == null){
//   localWoPlanLabourCostVOs = new hk.com.mtr.mmis.ws.WoPlanBolVO[]{};
//   }
//
//
// //update the setting tracker
//localWoPlanLabourCostVOsTracker = true;
//
//
//java.util.List list =
//org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoPlanLabourCostVOs);
//list.add(param);
//this.localWoPlanLabourCostVOs =
//(hk.com.mtr.mmis.ws.WoPlanBolVO[])list.toArray(
//new hk.com.mtr.mmis.ws.WoPlanBolVO[list.size()]);
//
//}
//
//
///**
//* field for WoPlanLocationVOs
//* This was an Array!
//*/
//
//
//    protected hk.com.mtr.mmis.ws.LocationRangeVO[] localWoPlanLocationVOs ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWoPlanLocationVOsTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return hk.com.mtr.mmis.ws.LocationRangeVO[]
//*/
//public  hk.com.mtr.mmis.ws.LocationRangeVO[] getWoPlanLocationVOs(){
//return localWoPlanLocationVOs;
//}
//
//
//
//
//
//
///**
//* validate the array for WoPlanLocationVOs
//*/
//protected void validateWoPlanLocationVOs(hk.com.mtr.mmis.ws.LocationRangeVO[] param){
//
//}
//
//
///**
//* Auto generated setter method
//* @param param WoPlanLocationVOs
//*/
//public void setWoPlanLocationVOs(hk.com.mtr.mmis.ws.LocationRangeVO[] param){
//
//   validateWoPlanLocationVOs(param);
//
//
//          if (param != null){
//             //update the setting tracker
//             localWoPlanLocationVOsTracker = true;
//          } else {
//             localWoPlanLocationVOsTracker = true;
//                 
//          }
//      
//      this.localWoPlanLocationVOs=param;
//}
//
//
//
///**
//* Auto generated add method for the array for convenience
//* @param param hk.com.mtr.mmis.ws.LocationRangeVO
//*/
//public void addWoPlanLocationVOs(hk.com.mtr.mmis.ws.LocationRangeVO param){
//   if (localWoPlanLocationVOs == null){
//   localWoPlanLocationVOs = new hk.com.mtr.mmis.ws.LocationRangeVO[]{};
//   }
//
//
// //update the setting tracker
//localWoPlanLocationVOsTracker = true;
//
//
//java.util.List list =
//org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoPlanLocationVOs);
//list.add(param);
//this.localWoPlanLocationVOs =
//(hk.com.mtr.mmis.ws.LocationRangeVO[])list.toArray(
//new hk.com.mtr.mmis.ws.LocationRangeVO[list.size()]);
//
//}
//
//
///**
//* field for WoPlanMaterialCostVOs
//* This was an Array!
//*/
//
//
//    protected hk.com.mtr.mmis.ws.WoPlanBomVO[] localWoPlanMaterialCostVOs ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWoPlanMaterialCostVOsTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return hk.com.mtr.mmis.ws.WoPlanBomVO[]
//*/
//public  hk.com.mtr.mmis.ws.WoPlanBomVO[] getWoPlanMaterialCostVOs(){
//return localWoPlanMaterialCostVOs;
//}
//
//
//
//
//
//
///**
//* validate the array for WoPlanMaterialCostVOs
//*/
//protected void validateWoPlanMaterialCostVOs(hk.com.mtr.mmis.ws.WoPlanBomVO[] param){
//
//}
//
//
///**
//* Auto generated setter method
//* @param param WoPlanMaterialCostVOs
//*/
//public void setWoPlanMaterialCostVOs(hk.com.mtr.mmis.ws.WoPlanBomVO[] param){
//
//   validateWoPlanMaterialCostVOs(param);
//
//
//          if (param != null){
//             //update the setting tracker
//             localWoPlanMaterialCostVOsTracker = true;
//          } else {
//             localWoPlanMaterialCostVOsTracker = true;
//                 
//          }
//      
//      this.localWoPlanMaterialCostVOs=param;
//}
//
//
//
///**
//* Auto generated add method for the array for convenience
//* @param param hk.com.mtr.mmis.ws.WoPlanBomVO
//*/
//public void addWoPlanMaterialCostVOs(hk.com.mtr.mmis.ws.WoPlanBomVO param){
//   if (localWoPlanMaterialCostVOs == null){
//   localWoPlanMaterialCostVOs = new hk.com.mtr.mmis.ws.WoPlanBomVO[]{};
//   }
//
//
// //update the setting tracker
//localWoPlanMaterialCostVOsTracker = true;
//
//
//java.util.List list =
//org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoPlanMaterialCostVOs);
//list.add(param);
//this.localWoPlanMaterialCostVOs =
//(hk.com.mtr.mmis.ws.WoPlanBomVO[])list.toArray(
//new hk.com.mtr.mmis.ws.WoPlanBomVO[list.size()]);
//
//}
//
//
///**
//* field for WoPlanOtherCostVOs
//* This was an Array!
//*/
//
//
//    protected hk.com.mtr.mmis.ws.WoPlanBooVO[] localWoPlanOtherCostVOs ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWoPlanOtherCostVOsTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return hk.com.mtr.mmis.ws.WoPlanBooVO[]
//*/
//public  hk.com.mtr.mmis.ws.WoPlanBooVO[] getWoPlanOtherCostVOs(){
//return localWoPlanOtherCostVOs;
//}
//
//
//
//
//
//
///**
//* validate the array for WoPlanOtherCostVOs
//*/
//protected void validateWoPlanOtherCostVOs(hk.com.mtr.mmis.ws.WoPlanBooVO[] param){
//
//}
//
//
///**
//* Auto generated setter method
//* @param param WoPlanOtherCostVOs
//*/
//public void setWoPlanOtherCostVOs(hk.com.mtr.mmis.ws.WoPlanBooVO[] param){
//
//   validateWoPlanOtherCostVOs(param);
//
//
//          if (param != null){
//             //update the setting tracker
//             localWoPlanOtherCostVOsTracker = true;
//          } else {
//             localWoPlanOtherCostVOsTracker = true;
//                 
//          }
//      
//      this.localWoPlanOtherCostVOs=param;
//}
//
//
//
///**
//* Auto generated add method for the array for convenience
//* @param param hk.com.mtr.mmis.ws.WoPlanBooVO
//*/
//public void addWoPlanOtherCostVOs(hk.com.mtr.mmis.ws.WoPlanBooVO param){
//   if (localWoPlanOtherCostVOs == null){
//   localWoPlanOtherCostVOs = new hk.com.mtr.mmis.ws.WoPlanBooVO[]{};
//   }
//
//
// //update the setting tracker
//localWoPlanOtherCostVOsTracker = true;
//
//
//java.util.List list =
//org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoPlanOtherCostVOs);
//list.add(param);
//this.localWoPlanOtherCostVOs =
//(hk.com.mtr.mmis.ws.WoPlanBooVO[])list.toArray(
//new hk.com.mtr.mmis.ws.WoPlanBooVO[list.size()]);
//
//}
//
//
///**
//* field for WoRecoveryVO
//*/
//
//
//    protected hk.com.mtr.mmis.ws.WoRecoveryVO localWoRecoveryVO ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWoRecoveryVOTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return hk.com.mtr.mmis.ws.WoRecoveryVO
//*/
//public  hk.com.mtr.mmis.ws.WoRecoveryVO getWoRecoveryVO(){
//return localWoRecoveryVO;
//}
//
//
//
///**
//* Auto generated setter method
//* @param param WoRecoveryVO
//*/
//public void setWoRecoveryVO(hk.com.mtr.mmis.ws.WoRecoveryVO param){
//
//       if (param != null){
//          //update the setting tracker
//          localWoRecoveryVOTracker = true;
//       } else {
//          localWoRecoveryVOTracker = false;
//              
//       }
//   
//            this.localWoRecoveryVO=param;
//    
//
//}
//
//
///**
//* field for WoStatusHistoryVOs
//* This was an Array!
//*/
//
//
//    protected hk.com.mtr.mmis.ws.WoStatusHistoryVO[] localWoStatusHistoryVOs ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWoStatusHistoryVOsTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return hk.com.mtr.mmis.ws.WoStatusHistoryVO[]
//*/
//public  hk.com.mtr.mmis.ws.WoStatusHistoryVO[] getWoStatusHistoryVOs(){
//return localWoStatusHistoryVOs;
//}
//
//
//
//
//
//
///**
//* validate the array for WoStatusHistoryVOs
//*/
//protected void validateWoStatusHistoryVOs(hk.com.mtr.mmis.ws.WoStatusHistoryVO[] param){
//
//}
//
//
///**
//* Auto generated setter method
//* @param param WoStatusHistoryVOs
//*/
//public void setWoStatusHistoryVOs(hk.com.mtr.mmis.ws.WoStatusHistoryVO[] param){
//
//   validateWoStatusHistoryVOs(param);
//
//
//          if (param != null){
//             //update the setting tracker
//             localWoStatusHistoryVOsTracker = true;
//          } else {
//             localWoStatusHistoryVOsTracker = true;
//                 
//          }
//      
//      this.localWoStatusHistoryVOs=param;
//}
//
//
//
///**
//* Auto generated add method for the array for convenience
//* @param param hk.com.mtr.mmis.ws.WoStatusHistoryVO
//*/
//public void addWoStatusHistoryVOs(hk.com.mtr.mmis.ws.WoStatusHistoryVO param){
//   if (localWoStatusHistoryVOs == null){
//   localWoStatusHistoryVOs = new hk.com.mtr.mmis.ws.WoStatusHistoryVO[]{};
//   }
//
//
// //update the setting tracker
//localWoStatusHistoryVOsTracker = true;
//
//
//java.util.List list =
//org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoStatusHistoryVOs);
//list.add(param);
//this.localWoStatusHistoryVOs =
//(hk.com.mtr.mmis.ws.WoStatusHistoryVO[])list.toArray(
//new hk.com.mtr.mmis.ws.WoStatusHistoryVO[list.size()]);
//
//}
//
//
///**
//* field for WoSuspensionVOs
//* This was an Array!
//*/
//
//
//    protected hk.com.mtr.mmis.ws.WoSuspensionVO[] localWoSuspensionVOs ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWoSuspensionVOsTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return hk.com.mtr.mmis.ws.WoSuspensionVO[]
//*/
//public  hk.com.mtr.mmis.ws.WoSuspensionVO[] getWoSuspensionVOs(){
//return localWoSuspensionVOs;
//}
//
//
//
//
//
//
///**
//* validate the array for WoSuspensionVOs
//*/
//protected void validateWoSuspensionVOs(hk.com.mtr.mmis.ws.WoSuspensionVO[] param){
//
//}
//
//
///**
//* Auto generated setter method
//* @param param WoSuspensionVOs
//*/
//public void setWoSuspensionVOs(hk.com.mtr.mmis.ws.WoSuspensionVO[] param){
//
//   validateWoSuspensionVOs(param);
//
//
//          if (param != null){
//             //update the setting tracker
//             localWoSuspensionVOsTracker = true;
//          } else {
//             localWoSuspensionVOsTracker = true;
//                 
//          }
//      
//      this.localWoSuspensionVOs=param;
//}
//
//
//
///**
//* Auto generated add method for the array for convenience
//* @param param hk.com.mtr.mmis.ws.WoSuspensionVO
//*/
//public void addWoSuspensionVOs(hk.com.mtr.mmis.ws.WoSuspensionVO param){
//   if (localWoSuspensionVOs == null){
//   localWoSuspensionVOs = new hk.com.mtr.mmis.ws.WoSuspensionVO[]{};
//   }
//
//
// //update the setting tracker
//localWoSuspensionVOsTracker = true;
//
//
//java.util.List list =
//org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoSuspensionVOs);
//list.add(param);
//this.localWoSuspensionVOs =
//(hk.com.mtr.mmis.ws.WoSuspensionVO[])list.toArray(
//new hk.com.mtr.mmis.ws.WoSuspensionVO[list.size()]);
//
//}
//
//
///**
//* field for WoTaskVOs
//* This was an Array!
//*/
//
//
//    protected hk.com.mtr.mmis.ws.WoTaskVO[] localWoTaskVOs ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWoTaskVOsTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return hk.com.mtr.mmis.ws.WoTaskVO[]
//*/
//public  hk.com.mtr.mmis.ws.WoTaskVO[] getWoTaskVOs(){
//return localWoTaskVOs;
//}
//
//
//
//
//
//
///**
//* validate the array for WoTaskVOs
//*/
//protected void validateWoTaskVOs(hk.com.mtr.mmis.ws.WoTaskVO[] param){
//
//}
//
//
///**
//* Auto generated setter method
//* @param param WoTaskVOs
//*/
//public void setWoTaskVOs(hk.com.mtr.mmis.ws.WoTaskVO[] param){
//
//   validateWoTaskVOs(param);
//
//
//          if (param != null){
//             //update the setting tracker
//             localWoTaskVOsTracker = true;
//          } else {
//             localWoTaskVOsTracker = true;
//                 
//          }
//      
//      this.localWoTaskVOs=param;
//}
//
//
//
///**
//* Auto generated add method for the array for convenience
//* @param param hk.com.mtr.mmis.ws.WoTaskVO
//*/
//public void addWoTaskVOs(hk.com.mtr.mmis.ws.WoTaskVO param){
//   if (localWoTaskVOs == null){
//   localWoTaskVOs = new hk.com.mtr.mmis.ws.WoTaskVO[]{};
//   }
//
//
// //update the setting tracker
//localWoTaskVOsTracker = true;
//
//
//java.util.List list =
//org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoTaskVOs);
//list.add(param);
//this.localWoTaskVOs =
//(hk.com.mtr.mmis.ws.WoTaskVO[])list.toArray(
//new hk.com.mtr.mmis.ws.WoTaskVO[list.size()]);
//
//}
//
//
///**
//* field for WorkGrp
//*/
//
//
//    protected hk.com.mtr.mmis.ws.WorkGrp localWorkGrp ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWorkGrpTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return hk.com.mtr.mmis.ws.WorkGrp
//*/
//public  hk.com.mtr.mmis.ws.WorkGrp getWorkGrp(){
//return localWorkGrp;
//}
//
//
//
///**
//* Auto generated setter method
//* @param param WorkGrp
//*/
//public void setWorkGrp(hk.com.mtr.mmis.ws.WorkGrp param){
//
//       if (param != null){
//          //update the setting tracker
//          localWorkGrpTracker = true;
//       } else {
//          localWorkGrpTracker = false;
//              
//       }
//   
//            this.localWorkGrp=param;
//    
//
//}
//
//
///**
//* field for WorkRequests
//* This was an Array!
//*/
//
//
//    protected hk.com.mtr.mmis.ws.WorkRequest[] localWorkRequests ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWorkRequestsTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return hk.com.mtr.mmis.ws.WorkRequest[]
//*/
//public  hk.com.mtr.mmis.ws.WorkRequest[] getWorkRequests(){
//return localWorkRequests;
//}
//
//
//
//
//
//
///**
//* validate the array for WorkRequests
//*/
//protected void validateWorkRequests(hk.com.mtr.mmis.ws.WorkRequest[] param){
//
//}
//
//
///**
//* Auto generated setter method
//* @param param WorkRequests
//*/
//public void setWorkRequests(hk.com.mtr.mmis.ws.WorkRequest[] param){
//
//   validateWorkRequests(param);
//
//
//          if (param != null){
//             //update the setting tracker
//             localWorkRequestsTracker = true;
//          } else {
//             localWorkRequestsTracker = true;
//                 
//          }
//      
//      this.localWorkRequests=param;
//}
//
//
//
///**
//* Auto generated add method for the array for convenience
//* @param param hk.com.mtr.mmis.ws.WorkRequest
//*/
//public void addWorkRequests(hk.com.mtr.mmis.ws.WorkRequest param){
//   if (localWorkRequests == null){
//   localWorkRequests = new hk.com.mtr.mmis.ws.WorkRequest[]{};
//   }
//
//
// //update the setting tracker
//localWorkRequestsTracker = true;
//
//
//java.util.List list =
//org.apache.axis2.databinding.utils.ConverterUtil.toList(localWorkRequests);
//list.add(param);
//this.localWorkRequests =
//(hk.com.mtr.mmis.ws.WorkRequest[])list.toArray(
//new hk.com.mtr.mmis.ws.WorkRequest[list.size()]);
//
//}
//
//
///**
//* field for WorkTimeRequire
//*/
//
//
//    protected java.lang.String localWorkTimeRequire ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWorkTimeRequireTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return java.lang.String
//*/
//public  java.lang.String getWorkTimeRequire(){
//return localWorkTimeRequire;
//}
//
//
//
///**
//* Auto generated setter method
//* @param param WorkTimeRequire
//*/
//public void setWorkTimeRequire(java.lang.String param){
//
//       if (param != null){
//          //update the setting tracker
//          localWorkTimeRequireTracker = true;
//       } else {
//          localWorkTimeRequireTracker = false;
//              
//       }
//   
//            this.localWorkTimeRequire=param;
//    
//
//}
//
//
///**
//* field for WrId
//*/
//
//
//    protected java.lang.String localWrId ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localWrIdTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return java.lang.String
//*/
//public  java.lang.String getWrId(){
//return localWrId;
//}
//
//
//
///**
//* Auto generated setter method
//* @param param WrId
//*/
//public void setWrId(java.lang.String param){
//
//       if (param != null){
//          //update the setting tracker
//          localWrIdTracker = true;
//       } else {
//          localWrIdTracker = false;
//              
//       }
//   
//            this.localWrId=param;
//    
//
//}
//
//
///**
//* field for EquipmentReferenceName
//*/
//
//
//    protected java.lang.String localEquipmentReferenceName ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localEquipmentReferenceNameTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return java.lang.String
//*/
//public  java.lang.String getEquipmentReferenceName(){
//return localEquipmentReferenceName;
//}
//
//
//
///**
//* Auto generated setter method
//* @param param EquipmentReferenceName
//*/
//public void setEquipmentReferenceName(java.lang.String param){
//
//       if (param != null){
//          //update the setting tracker
//          localEquipmentReferenceNameTracker = true;
//       } else {
//          localEquipmentReferenceNameTracker = false;
//              
//       }
//   
//            this.localEquipmentReferenceName=param;
//    
//
//}
//
//
///**
//* field for Segment1
//*/
//
//
//    protected java.lang.String localSegment1 ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localSegment1Tracker = false ;
//
//
///**
//* Auto generated getter method
//* @return java.lang.String
//*/
//public  java.lang.String getSegment1(){
//return localSegment1;
//}
//
//
//
///**
//* Auto generated setter method
//* @param param Segment1
//*/
//public void setSegment1(java.lang.String param){
//
//       if (param != null){
//          //update the setting tracker
//          localSegment1Tracker = true;
//       } else {
//          localSegment1Tracker = false;
//              
//       }
//   
//            this.localSegment1=param;
//    
//
//}
//
//
///**
//* field for Segment2
//*/
//
//
//    protected java.lang.String localSegment2 ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localSegment2Tracker = false ;
//
//
///**
//* Auto generated getter method
//* @return java.lang.String
//*/
//public  java.lang.String getSegment2(){
//return localSegment2;
//}
//
//
//
///**
//* Auto generated setter method
//* @param param Segment2
//*/
//public void setSegment2(java.lang.String param){
//
//       if (param != null){
//          //update the setting tracker
//          localSegment2Tracker = true;
//       } else {
//          localSegment2Tracker = false;
//              
//       }
//   
//            this.localSegment2=param;
//    
//
//}
//
//
///**
//* field for Segment3
//*/
//
//
//    protected java.lang.String localSegment3 ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localSegment3Tracker = false ;
//
//
///**
//* Auto generated getter method
//* @return java.lang.String
//*/
//public  java.lang.String getSegment3(){
//return localSegment3;
//}
//
//
//
///**
//* Auto generated setter method
//* @param param Segment3
//*/
//public void setSegment3(java.lang.String param){
//
//       if (param != null){
//          //update the setting tracker
//          localSegment3Tracker = true;
//       } else {
//          localSegment3Tracker = false;
//              
//       }
//   
//            this.localSegment3=param;
//    
//
//}
//
//
///**
//* field for Segment4
//*/
//
//
//    protected java.lang.String localSegment4 ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localSegment4Tracker = false ;
//
//
///**
//* Auto generated getter method
//* @return java.lang.String
//*/
//public  java.lang.String getSegment4(){
//return localSegment4;
//}
//
//
//
///**
//* Auto generated setter method
//* @param param Segment4
//*/
//public void setSegment4(java.lang.String param){
//
//       if (param != null){
//          //update the setting tracker
//          localSegment4Tracker = true;
//       } else {
//          localSegment4Tracker = false;
//              
//       }
//   
//            this.localSegment4=param;
//    
//
//}
//
//
///**
//* field for TotalLabourCostVariance
//*/
//
//
//    protected double localTotalLabourCostVariance ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localTotalLabourCostVarianceTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return double
//*/
//public  double getTotalLabourCostVariance(){
//return localTotalLabourCostVariance;
//}
//
//
//
///**
//* Auto generated setter method
//* @param param TotalLabourCostVariance
//*/
//public void setTotalLabourCostVariance(double param){
//
//       // setting primitive attribute tracker to true
//       
//               if (java.lang.Double.isNaN(param)) {
//           localTotalLabourCostVarianceTracker = false;
//              
//       } else {
//          localTotalLabourCostVarianceTracker = true;
//       }
//   
//            this.localTotalLabourCostVariance=param;
//    
//
//}
//
//
///**
//* field for TotalMaterialsCostVariance
//*/
//
//
//    protected double localTotalMaterialsCostVariance ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localTotalMaterialsCostVarianceTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return double
//*/
//public  double getTotalMaterialsCostVariance(){
//return localTotalMaterialsCostVariance;
//}
//
//
//
///**
//* Auto generated setter method
//* @param param TotalMaterialsCostVariance
//*/
//public void setTotalMaterialsCostVariance(double param){
//
//       // setting primitive attribute tracker to true
//       
//               if (java.lang.Double.isNaN(param)) {
//           localTotalMaterialsCostVarianceTracker = false;
//              
//       } else {
//          localTotalMaterialsCostVarianceTracker = true;
//       }
//   
//            this.localTotalMaterialsCostVariance=param;
//    
//
//}
//
//
///**
//* field for TotalOtherCostVariance
//*/
//
//
//    protected double localTotalOtherCostVariance ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localTotalOtherCostVarianceTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return double
//*/
//public  double getTotalOtherCostVariance(){
//return localTotalOtherCostVariance;
//}
//
//
//
///**
//* Auto generated setter method
//* @param param TotalOtherCostVariance
//*/
//public void setTotalOtherCostVariance(double param){
//
//       // setting primitive attribute tracker to true
//       
//               if (java.lang.Double.isNaN(param)) {
//           localTotalOtherCostVarianceTracker = false;
//              
//       } else {
//          localTotalOtherCostVarianceTracker = true;
//       }
//   
//            this.localTotalOtherCostVariance=param;
//    
//
//}
//
//
///**
//* field for FinalCostFlag
//*/
//
//
//    protected java.lang.String localFinalCostFlag ;
//
///*  This tracker boolean wil be used to detect whether the user called the set method
//*   for this attribute. It will be used to determine whether to include this field
//*   in the serialized XML
//*/
//protected boolean localFinalCostFlagTracker = false ;
//
//
///**
//* Auto generated getter method
//* @return java.lang.String
//*/
//public  java.lang.String getFinalCostFlag(){
//return localFinalCostFlag;
//}
//
//
//
///**
//* Auto generated setter method
//* @param param FinalCostFlag
//*/
//public void setFinalCostFlag(java.lang.String param){
//
//       if (param != null){
//          //update the setting tracker
//          localFinalCostFlagTracker = true;
//       } else {
//          localFinalCostFlagTracker = false;
//              
//       }
//   
//            this.localFinalCostFlag=param;
//    
//
//}
//                  
//             
//
//
    
    
    
    
    
}
