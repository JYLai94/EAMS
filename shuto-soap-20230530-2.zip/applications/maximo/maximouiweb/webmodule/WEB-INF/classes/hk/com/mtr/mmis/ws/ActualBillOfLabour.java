package hk.com.mtr.mmis.ws;

public class ActualBillOfLabour {

	protected double amount ;
	protected java.lang.String calculatedInd ;
	protected java.lang.String chargingWkGrpId ;
	protected java.lang.String creditAccount ;
	protected java.lang.String debitAccount ;
	protected java.lang.String gcHrsTypeCd ;
	protected java.lang.String gcReferenceTypeCd ;
	protected java.lang.String gcResourceTypeCd ;
	protected java.lang.String gcWorkNatureLv1Cd ;
	protected java.lang.String gcWorkNatureLv2Cd ;
	protected java.lang.String hrUserId ;
	protected double labourMinutes ;
	protected java.lang.String referenceNo ;
	protected java.lang.String remarks1 ;
	protected java.lang.String remarks2 ;
	protected java.lang.String remarks3 ;
	protected java.lang.String status ;
	protected java.util.Calendar txnDate ;
	protected long woActualBolId ;
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public java.lang.String getCalculatedInd() {
		return calculatedInd;
	}
	public void setCalculatedInd(java.lang.String calculatedInd) {
		this.calculatedInd = calculatedInd;
	}
	public java.lang.String getChargingWkGrpId() {
		return chargingWkGrpId;
	}
	public void setChargingWkGrpId(java.lang.String chargingWkGrpId) {
		this.chargingWkGrpId = chargingWkGrpId;
	}
	public java.lang.String getCreditAccount() {
		return creditAccount;
	}
	public void setCreditAccount(java.lang.String creditAccount) {
		this.creditAccount = creditAccount;
	}
	public java.lang.String getDebitAccount() {
		return debitAccount;
	}
	public void setDebitAccount(java.lang.String debitAccount) {
		this.debitAccount = debitAccount;
	}
	public java.lang.String getGcHrsTypeCd() {
		return gcHrsTypeCd;
	}
	public void setGcHrsTypeCd(java.lang.String gcHrsTypeCd) {
		this.gcHrsTypeCd = gcHrsTypeCd;
	}
	public java.lang.String getGcReferenceTypeCd() {
		return gcReferenceTypeCd;
	}
	public void setGcReferenceTypeCd(java.lang.String gcReferenceTypeCd) {
		this.gcReferenceTypeCd = gcReferenceTypeCd;
	}
	public java.lang.String getGcResourceTypeCd() {
		return gcResourceTypeCd;
	}
	public void setGcResourceTypeCd(java.lang.String gcResourceTypeCd) {
		this.gcResourceTypeCd = gcResourceTypeCd;
	}
	public java.lang.String getGcWorkNatureLv1Cd() {
		return gcWorkNatureLv1Cd;
	}
	public void setGcWorkNatureLv1Cd(java.lang.String gcWorkNatureLv1Cd) {
		this.gcWorkNatureLv1Cd = gcWorkNatureLv1Cd;
	}
	public java.lang.String getGcWorkNatureLv2Cd() {
		return gcWorkNatureLv2Cd;
	}
	public void setGcWorkNatureLv2Cd(java.lang.String gcWorkNatureLv2Cd) {
		this.gcWorkNatureLv2Cd = gcWorkNatureLv2Cd;
	}
	public java.lang.String getHrUserId() {
		return hrUserId;
	}
	public void setHrUserId(java.lang.String hrUserId) {
		this.hrUserId = hrUserId;
	}
	public double getLabourMinutes() {
		return labourMinutes;
	}
	public void setLabourMinutes(double labourMinutes) {
		this.labourMinutes = labourMinutes;
	}
	public java.lang.String getReferenceNo() {
		return referenceNo;
	}
	public void setReferenceNo(java.lang.String referenceNo) {
		this.referenceNo = referenceNo;
	}
	public java.lang.String getRemarks1() {
		return remarks1;
	}
	public void setRemarks1(java.lang.String remarks1) {
		this.remarks1 = remarks1;
	}
	public java.lang.String getRemarks2() {
		return remarks2;
	}
	public void setRemarks2(java.lang.String remarks2) {
		this.remarks2 = remarks2;
	}
	public java.lang.String getRemarks3() {
		return remarks3;
	}
	public void setRemarks3(java.lang.String remarks3) {
		this.remarks3 = remarks3;
	}
	public java.lang.String getStatus() {
		return status;
	}
	public void setStatus(java.lang.String status) {
		this.status = status;
	}
	public java.util.Calendar getTxnDate() {
		return txnDate;
	}
	public void setTxnDate(java.util.Calendar txnDate) {
		this.txnDate = txnDate;
	}
	public long getWoActualBolId() {
		return woActualBolId;
	}
	public void setWoActualBolId(long woActualBolId) {
		this.woActualBolId = woActualBolId;
	}
	
	
}
