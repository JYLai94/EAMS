package hk.com.mtr.mmis.ws;

public interface WorkOrderServiceInterface {
	
	public  RetrieveWorkOrderResponseE retrieveWorkOrder
    (
       RetrieveWorkOrderE retrieveWorkOrder
     )
    		 throws WorkOrderException;
	
	public hk.com.mtr.mmis.ws.RetrieveWorkOrderListResponseE retrieveWorkOrderList
    (
      hk.com.mtr.mmis.ws.RetrieveWorkOrderListE retrieveWorkOrderList
     )
throws WorkOrderException;

}
