package hk.com.mtr.mmis.ws;

public class RetrieveWorkOrderE {
	
	  protected hk.com.mtr.mmis.ws.RetrieveWorkOrder retrieveWorkOrder ;

	public hk.com.mtr.mmis.ws.RetrieveWorkOrder getRetrieveWorkOrder() {
		return retrieveWorkOrder;
	}

	public void setRetrieveWorkOrder(hk.com.mtr.mmis.ws.RetrieveWorkOrder retrieveWorkOrder) {
		this.retrieveWorkOrder = retrieveWorkOrder;
	}
      


}
