package hk.com.mtr.mmis.ws;

public class IncidentVO {

	protected hk.com.mtr.mmis.ws.Incident incident ;

	public hk.com.mtr.mmis.ws.Incident getIncident() {
		return incident;
	}

	public void setIncident(hk.com.mtr.mmis.ws.Incident incident) {
		this.incident = incident;
	}

}
