package hk.com.mtr.mmis.ws;

import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import psdi.app.workorder.WO;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.server.MXServer;
import psdi.util.MXException;

public class WorkOrderService implements WorkOrderServiceInterface {

	public final static String ERROR_CODE_1 = "1";
	public final static String ERROR_CODE_1_MSG = "Work Order Number does not exist.";
	/*public final static String ERROR_CODE_2 = "2";
	public final static String ERROR_CODE_2_MSG = "Work Order status not in \"Released\", \"Complete\" and \"Closed\".";*/
	public final static String ERROR_CODE_3 = "3";
	public final static String ERROR_CODE_3_MSG = "Unexpected system error: ";
    
	
	public hk.com.mtr.mmis.ws.RetrieveWorkOrderResponseE retrieveWorkOrder(hk.com.mtr.mmis.ws.RetrieveWorkOrderE retrieveWorkOrder0) throws  WorkOrderException{
    	RetrieveWorkOrderResponseE retrieveWorkOrderResponseE = new RetrieveWorkOrderResponseE();
    	RetrieveWorkOrderResponse retrieveWorkOrderResponse = new RetrieveWorkOrderResponse();
    	String workOrderNo = retrieveWorkOrder0.getRetrieveWorkOrder().workOrderNo;
    	WorkOrderVO workOrderVO = retrieveWorkOrder(workOrderNo);
 		retrieveWorkOrderResponse.set_return(workOrderVO);
 		retrieveWorkOrderResponseE.setRetrieveWorkOrderResponse(retrieveWorkOrderResponse);
    	return retrieveWorkOrderResponseE;
//                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#retrieveWorkOrder");
	}
	
	public hk.com.mtr.mmis.ws.RetrieveWorkOrderListResponseE retrieveWorkOrderList(
			hk.com.mtr.mmis.ws.RetrieveWorkOrderListE retrieveWorkOrderList2) throws WorkOrderException {
		RetrieveWorkOrderListResponseE retrieveWorkOrderListResponseE = new RetrieveWorkOrderListResponseE();
//		try {
			String workOrderNoArray[] = retrieveWorkOrderList2.getRetrieveWorkOrderList().workOrderNo;
			WorkOrderVO[] workOrderVOList = new WorkOrderVO[workOrderNoArray.length];
			boolean isEmpty = true;
			for (int i = 0; i < workOrderNoArray.length; i++) {
				// workOrderVOList[i] = new WorkOrderVO();
				try {
					workOrderVOList[i] = retrieveWorkOrder(workOrderNoArray[i]);
					if(isEmpty){
						if(workOrderVOList[i]!=null){
							isEmpty=false;
						}
					}
				}catch (WorkOrderException ex) {
					ex.printStackTrace();
					if(ERROR_CODE_3.equals(ex.getFaultMessage().getMMISWebServiceException().getErrorCode())){
						MMISWebServiceExceptionE mmisWebServiceExceptionE = new MMISWebServiceExceptionE();
			    		MMISWebServiceException mmisWebServiceException = new MMISWebServiceException();
			    		mmisWebServiceException.setErrorCode(ERROR_CODE_3);
			    		mmisWebServiceException.setErrorMessage(ex.getFaultMessage().getMMISWebServiceException().getErrorMessage());
			    		mmisWebServiceExceptionE.setMMISWebServiceException(mmisWebServiceException);
			    		WorkOrderException workOrderException = new WorkOrderException();
			    		workOrderException.setFaultMessage(mmisWebServiceExceptionE);
			    		throw workOrderException;
					}
				}
			}
			if(isEmpty){
				MMISWebServiceExceptionE mmisWebServiceExceptionE = new MMISWebServiceExceptionE();
	     		MMISWebServiceException mmisWebServiceException = new MMISWebServiceException();
	     		mmisWebServiceException.setErrorCode(ERROR_CODE_1);
	     		mmisWebServiceException.setErrorMessage(ERROR_CODE_1_MSG);
	     		mmisWebServiceExceptionE.setMMISWebServiceException(mmisWebServiceException);
	     		WorkOrderException workOrderException = new WorkOrderException();
	     		workOrderException.setFaultMessage(mmisWebServiceExceptionE);
	     		throw workOrderException;
			}
			RetrieveWorkOrderListResponse retrieveWorkOrderListResponse = new RetrieveWorkOrderListResponse();
			retrieveWorkOrderListResponse.set_return(workOrderVOList);
			retrieveWorkOrderListResponseE.setRetrieveWorkOrderListResponse(retrieveWorkOrderListResponse);
//		}
//		catch (Exception ex) {
//			MMISWebServiceExceptionE mmisWebServiceExceptionE = new MMISWebServiceExceptionE();
//    		MMISWebServiceException mmisWebServiceException = new MMISWebServiceException();
//    		mmisWebServiceException.setErrorCode(ERROR_CODE_3);
//    		mmisWebServiceException.setErrorMessage(ERROR_CODE_3_MSG + ex.getMessage());
//    		mmisWebServiceExceptionE.setMMISWebServiceException(mmisWebServiceException);
//    		WorkOrderException workOrderException = new WorkOrderException();
//    		workOrderException.setFaultMessage(mmisWebServiceExceptionE);
//    		throw workOrderException;
//		}
		return retrieveWorkOrderListResponseE;
		// //TODO : fill this with the necessary business logic
		// throw new java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#retrieveWorkOrderList");
	}

	
	private WorkOrderVO retrieveWorkOrder(String workOrderNo) throws WorkOrderException {
		WorkOrderVO workOrderVO = new WorkOrderVO();
     	WO woMbo=null;
		try {
			woMbo = (WO)findWO(workOrderNo);
		}
		catch (Exception ex) {
			MMISWebServiceExceptionE mmisWebServiceExceptionE = new MMISWebServiceExceptionE();
    		MMISWebServiceException mmisWebServiceException = new MMISWebServiceException();
    		mmisWebServiceException.setErrorCode(ERROR_CODE_3);
    		mmisWebServiceException.setErrorMessage(ERROR_CODE_3_MSG + ex.getMessage());
    		mmisWebServiceExceptionE.setMMISWebServiceException(mmisWebServiceException);
    		WorkOrderException workOrderException = new WorkOrderException();
    		workOrderException.setFaultMessage(mmisWebServiceExceptionE);
    		throw workOrderException;
//    		MMISWebServiceException errorInfo = new MMISWebServiceException();
//			errorInfo.setErrorCode(ERROR_CODE_3);
//			errorInfo.setErrorMessage(ERROR_CODE_3_MSG + ex.getMessage());
//			throw new WorkOrderException(ex.getMessage(), errorInfo,ex.getCause());
		}  
     	if(woMbo==null){
     		MMISWebServiceExceptionE mmisWebServiceExceptionE = new MMISWebServiceExceptionE();
     		MMISWebServiceException mmisWebServiceException = new MMISWebServiceException();
     		mmisWebServiceException.setErrorCode(ERROR_CODE_1);
     		mmisWebServiceException.setErrorMessage(ERROR_CODE_1_MSG);
     		mmisWebServiceExceptionE.setMMISWebServiceException(mmisWebServiceException);
     		WorkOrderException workOrderException = new WorkOrderException();
     		workOrderException.setFaultMessage(mmisWebServiceExceptionE);
     		throw workOrderException;
     	}
     	if(woMbo!=null){
     		SimpleDateFormat datestrT=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX");//2023-02-01T00:00:00.000Z
//     		SimpleDateFormat HHmm = new SimpleDateFormat("HH:mm");
     		try {
 	//    		<action/>
 		    	workOrderVO.setAction("");//No use
 		    	
 		    	if(woMbo.getDate("actfinish")!=null){
 		    		Calendar calendarActfinish = Calendar.getInstance();  
 		    		calendarActfinish.setTime(datestrT.parse(datestrT.format(woMbo.getDate("actfinish"))));
 			    	workOrderVO.setActualCmplDate(calendarActfinish);
 	            }else{
 	            	workOrderVO.setActualCmplDate(null);
 	            }
 		    	
 		    	if(woMbo.getDate("actstart")!=null){
 		    		Calendar calendarActstart = Calendar.getInstance();  
 		    		calendarActstart.setTime(datestrT.parse(datestrT.format(woMbo.getDate("actstart"))));
 		    		workOrderVO.setActualStartDate(calendarActstart);
 	//		    	<actualStartTime>00:00</actualStartTime>
// 					Date date1 = datestrT.parse(datestrT.format(woMbo.getDate("actstart")));
// 					String sdate=HHmm.format(date1);
// 					workOrderVO.setActualStartTime(sdate);
 					workOrderVO.setActualStartTime(datestrT.format(woMbo.getDate("actstart")).substring(11, 16));
 		    	}else{
 		    		workOrderVO.setActualStartDate(null);
 		    		workOrderVO.setActualStartTime("00:00");
 		    	}
 		    	
 		    	workOrderVO.setCmpltmnryContractNo(woMbo.getString("mtr_cmpltmnry_contract_no"));
 		    	workOrderVO.setContractDesp(woMbo.getString("mtr_warrcontract.description"));
				workOrderVO.setContractNo(woMbo.getString("contract"));
				workOrderVO.setContractor(woMbo.getString("mtr_warrcontract.vendor"));
 		    	
				OrganizationUnit organizationUnit = new OrganizationUnit();
 				organizationUnit.setOuCd(woMbo.getString("vendor"));
 				organizationUnit.setOuId(woMbo.getString("mtr_companies.companiesid"));
 				organizationUnit.setOuName(woMbo.getString("mtr_companies.name"));
 				organizationUnit.setParentOrgnizationCodeName(woMbo.getString("mtr_companies.companychildren.name"));
 				organizationUnit.setParentOrgnizationUnitName(woMbo.getString("mtr_companies.companychildren.name"));
 				organizationUnit.setParentOuId(woMbo.getString("mtr_companies.parentcompany"));
 				workOrderVO.setContractorInCharge(organizationUnit);
 		    	
 				workOrderVO.setDetailIDs("");//No use
 				
 				workOrderVO.setDetailLoc("");//No use
 		    	
 				HumanResource hHumanResource = new HumanResource();
 				hHumanResource.setHrName(woMbo.getString("mtr_engineer_incharged.displayname"));
 				hHumanResource.setHrNo(woMbo.getString("mtr_engineer_incharged"));
 				hHumanResource.setHrUserId(woMbo.getString("mtr_engineer_incharged"));
 				workOrderVO.setEngineerInCharge(hHumanResource);
 		    	
 				EquipClass equipClass = new EquipClass();
 				equipClass.setEquipClassCd(woMbo.getString("classstructure.hierarchypath"));
 				equipClass.setEquipClassDesp(woMbo.getString("classstructure.classification.description"));
 				equipClass.setEquipClassId(woMbo.getLong("classstructure.classification.classificationuid"));
 				workOrderVO.setEquipClass(equipClass);
 		    	
 				if(woMbo.getDate("actfinish")!=null && woMbo.getDate("mtr_assetshutdown")!=null){
 					workOrderVO.setEquipDownTime(getDistanceDateTime(woMbo.getDate("mtr_assetshutdown"),woMbo.getDate("actfinish")));
 				}else{
 					workOrderVO.setEquipDownTime("0 00:00:00");
 				}
 		    	
 				Equipment equipment = new Equipment();
 				equipment.setEquipDesp(woMbo.getString("asset.description"));
 				equipment.setEquipId(woMbo.getLong("asset.assetid"));
 				equipment.setEquipNo(woMbo.getString("assetnum"));
 				workOrderVO.setEquipment(equipment);
 		    	
 				workOrderVO.setFinalizedInd(woMbo.getString("mtr_finalized_ind"));
 		 		//        <gcFinanceRefNoCd/>
 		 				workOrderVO.setGcFinanceRefNoCd(woMbo.getString("mtr_gc_finance_ref_no_cd"));
 		 		//        <gcPriorityCd>10</gcPriorityCd>
 		 				workOrderVO.setGcPriorityCd(woMbo.getString("wopriority"));
 		 		//        <gcProjectNoCd/>
 		 				workOrderVO.setGcProjectNoCd(woMbo.getString("mtr_gc_project_no_cd"));
 		 		//        <gcProjectTaskNoCd/>
 		 				workOrderVO.setGcProjectTaskNoCd(woMbo.getString("mtr_gc_project_task_no_cd"));
 		 		//        <gcSvcBreakdownCd/>
 		 				workOrderVO.setGcSvcBreakdownCd(woMbo.getString("mtr_gc_svc_breakdown_cd"));
 		 		//		<gcWorkNatureLv1Cd>PM</gcWorkNatureLv1Cd>
 		 				workOrderVO.setGcWorkNatureLv1Cd(woMbo.getString("mtr_gc_work_nature_lv1_cd"));
 		 		//        <gcWorkNatureLv2Cd>IX</gcWorkNatureLv2Cd>
 		 				workOrderVO.setGcWorkNatureLv2Cd(woMbo.getString("mtr_gc_work_nature_lv2_cd"));
 		    	
 				if("INCIDENT".equals(woMbo.getString("origrecordclass"))){
 	//				workOrderVO.setIncidentNumber(woMbo.getString("origrecordid"));
 					workOrderVO.setIncidentNumber(woMbo.getString("origticket.ticketuid"));
 				}else{
 					workOrderVO.setIncidentNumber("");
 				}
 				MboSetRemote relatedrecordMboSet = woMbo.getMboSet("$RELATEDRECORD","RELATEDRECORD",
 		         		   "recordkey=:wonum and class=:woclass and siteid=:siteid and relatedrecclass in (select value from synonymdomain where domainid ='TKCLASS' and maxvalue in ('INCIDENT'))");
 				relatedrecordMboSet.reset();
 				if(!relatedrecordMboSet.isEmpty()){
 					IncidentVO incidentVO = new IncidentVO();
 					Incident incident = new Incident();
 	//				incident.setIncidentDesp(relatedrecordMboSet.getMbo(0).getString("relatedrectkt.description"));
 					incident.setIncidentDesp(relatedrecordMboSet.getMbo(0).getString("relatedrectkt.description"));
 					incident.setIncidentId(relatedrecordMboSet.getMbo(0).getString("relatedreckey"));
 					incidentVO.setIncident(incident);
 					workOrderVO.setIncidentVO(incidentVO);
 				}
 		    	
 			 	//			 <labourCostCredit/>
 				MboSetRemote labtransMboSetCredit = woMbo.getMboSet("$LABTRANSCredit","LABTRANS",
 						"refwo in (select wonum from workorder where (wonum=:wonum or (parent=:wonum and istask = :yes)) and siteid=:siteid ) and glcreditacct is not null");
 				labtransMboSetCredit.reset();
 				if(!labtransMboSetCredit.isEmpty()){
 					workOrderVO.setLabourCostCredit(labtransMboSetCredit.getMbo(0).getString("glcreditacct"));
 				}else{
 					workOrderVO.setLabourCostCredit("");
 				}
 	//	            <labourCostDebit>001.24.01.72813.00000.0000000</labourCostDebit>
 				MboSetRemote labtransMboSetDebit = woMbo.getMboSet("$LABTRANSDebit","LABTRANS",
 						"refwo in (select wonum from workorder where (wonum=:wonum or (parent=:wonum and istask = :yes)) and siteid=:siteid ) and gldebitacct is not null");
 				labtransMboSetDebit.reset();
 				if(!labtransMboSetDebit.isEmpty()){
 					workOrderVO.setLabourCostDebit(labtransMboSetDebit.getMbo(0).getString("gldebitacct"));
 				}else{
 					workOrderVO.setLabourCostDebit("");
 				}
 	//	            <locale/>
 				workOrderVO.setLocale("");//No use  	
 		    	
 				MboSetRemote recoverySetCredit = woMbo.getMboSet("MTR_RECOVERY");
 				recoverySetCredit.setOrderBy("mtr_recoveryid desc");
 				if(!recoverySetCredit.isEmpty()){
 	//	            <maintainerFinishWork>2015-06-17T00:00:00.000+08:00</maintainerFinishWork>
 					if(recoverySetCredit.getMbo(0).getDate("mtr_engineer_finishwork_datetime")!=null){
 						Calendar calendarMtr_engineer_finishwork_datetime = Calendar.getInstance();
 						calendarMtr_engineer_finishwork_datetime.setTime(datestrT.parse(datestrT.format(recoverySetCredit.getMbo(0).getDate("mtr_engineer_finishwork_datetime"))));
 				    	workOrderVO.setMaintainerFinishWork(calendarMtr_engineer_finishwork_datetime);
 		            }
 	//	            <maintainerStartWork>2015-06-17T00:00:00.000+08:00</maintainerStartWork>
 					if(recoverySetCredit.getMbo(0).getDate("mtr_engineer_startwork_datetime")!=null){
 						Calendar calendarMtr_engineer_startwork_datetime = Calendar.getInstance();
 						calendarMtr_engineer_startwork_datetime.setTime(datestrT.parse(datestrT.format(recoverySetCredit.getMbo(0).getDate("mtr_engineer_startwork_datetime"))));
 				    	workOrderVO.setMaintainerStartWork(calendarMtr_engineer_startwork_datetime);
 		            }
 				}
 				
 	//	            <materialCostCredit/>
 				MboSetRemote matusetransMboSetCredit = woMbo.getMboSet("$MATUSETRANSCredit","MATUSETRANS",
 						"refwo in (select wonum from workorder where (wonum=:wonum or (parent=:wonum and istask = :yes)) and siteid=:siteid ) and glcreditacct is not null");
 				matusetransMboSetCredit.reset();
 				if(!matusetransMboSetCredit.isEmpty()){
 					workOrderVO.setMaterialCostCredit(matusetransMboSetCredit.getMbo(0).getString("glcreditacct"));
 				}else{
 					workOrderVO.setMaterialCostCredit("");
 				}
 				
// 	            <materialCostDebit>001.24.01.72813.00000.0000000</materialCostDebit>
			workOrderVO.setMaterialCostDebit("");
			MboSetRemote matusetransMboSetDebit = woMbo.getMboSet("$MATUSETRANSDebit","MATUSETRANS",
					"refwo in (select wonum from workorder where (wonum=:wonum or (parent=:wonum and istask = :yes)) and siteid=:siteid ) and gldebitacct is not null");
			matusetransMboSetDebit.reset();
			if(!matusetransMboSetDebit.isEmpty()){
				workOrderVO.setMaterialCostCredit(matusetransMboSetDebit.getMbo(0).getString("gldebitacct"));
			}else{
				workOrderVO.setMaterialCostCredit("");
			}
			
//	            <oldWoNo/>
	            workOrderVO.setOldWoNo("");//No use
		
//	            <oneOfRelatedMeasurementId/>//CBM RESULT - select RESULT_ID from CBM_WO_RESULT_ASSOC where WO_NO = :woNo
	            MboSetRemote cbmWoResultAssocMboSet = woMbo.getMboSet("$CBM_WO_RESULT_ASSOC", "CBM_WO_RESULT_ASSOC", 
	            		"wo_no=:wonum and siteid=:siteid");
	            cbmWoResultAssocMboSet.reset();
	            if(!cbmWoResultAssocMboSet.isEmpty()){
	            	workOrderVO.setOneOfRelatedMeasurementId(cbmWoResultAssocMboSet.getMbo(0).getString("result_id"));
	            }else{
	            	workOrderVO.setOneOfRelatedMeasurementId("");
	            }
	            
//	            <openDate>2015-07-06T03:27:08.998+08:00</openDate>
	            MboSetRemote wostatusMboSet = woMbo.getMboSet("$WOSTATUS", "WOSTATUS", "wonum = :wonum and siteid=:siteid and status='OPEN'");
	            wostatusMboSet.setOrderBy("changedate desc");
	            wostatusMboSet.reset();
	            if(!wostatusMboSet.isEmpty()){
	            	Calendar calendarChangedate = Calendar.getInstance();
	            	calendarChangedate.setTime(datestrT.parse(datestrT.format(wostatusMboSet.getMbo(0).getDate("changedate"))));
		    		workOrderVO.setOpenDate(calendarChangedate);
	            }else{
	            	workOrderVO.setOpenDate(null);
	            }
 		    
//	            <otherCostCredit/>
 		            MboSetRemote servrectransCreditMboSet = woMbo.getMboSet("$SHOWACTUALSERVICE","SERVRECTRANS",
 							"refwo in (select wonum from workorder where (wonum=:wonum or (parent=:wonum and istask = :yes)) and siteid=:siteid ) and plustrepord = :no and glcreditacct is not null");
 		            servrectransCreditMboSet.reset();
 		            if(!servrectransCreditMboSet.isEmpty()){
 		            	workOrderVO.setOtherCostCredit(servrectransCreditMboSet.getMbo(0).getString("glcreditacct"));
 		            }else{
 		            	workOrderVO.setOtherCostCredit("");
 		            }
 		            
 	//	            <otherCostDebit>001.24.01.72813.00000.0000000</otherCostDebit>
 		            MboSetRemote servrectransDebitMboSet = woMbo.getMboSet("$SHOWACTUALSERVICE","SERVRECTRANS",
 							"refwo in (select wonum from workorder where (wonum=:wonum or (parent=:wonum and istask = :yes)) and siteid=:siteid ) and plustrepord = :no and gldebitacct is not null");
 		            servrectransDebitMboSet.reset();
 		            if(!servrectransDebitMboSet.isEmpty()){
 		            	workOrderVO.setOtherCostDebit(servrectransDebitMboSet.getMbo(0).getString("gldebitacct"));
 		            }else{
 		            	workOrderVO.setOtherCostDebit("");
 		            }
 			
 		            
 		    	
 		    	
 		    	
 		    	
     		 } catch (Exception e) {
	    			e.printStackTrace();
					MMISWebServiceExceptionE mmisWebServiceExceptionE = new MMISWebServiceExceptionE();
		    		MMISWebServiceException mmisWebServiceException = new MMISWebServiceException();
		    		mmisWebServiceException.setErrorCode(ERROR_CODE_3);
		    		mmisWebServiceException.setErrorMessage(ERROR_CODE_3_MSG+e.getMessage());
		    		mmisWebServiceExceptionE.setMMISWebServiceException(mmisWebServiceException);
		    		WorkOrderException workOrderException = new WorkOrderException();
		    		workOrderException.setFaultMessage(mmisWebServiceExceptionE);
		    		throw workOrderException;
			 }
     	}
	return workOrderVO;
	}
	
    private MboRemote findWO(String workOrderNo) throws RemoteException, MXException {
        MboSetRemote  woMboSet = MXServer.getMXServer().getMboSet("WORKORDER", MXServer.getMXServer().getSystemUserInfo());
        woMboSet.setWhere("WONUM='"+workOrderNo +"'");
        woMboSet.reset();
        MboRemote woMbo = null; 
        if (!woMboSet.isEmpty())
        {
        	woMbo = woMboSet.getMbo(0);
        }
        return woMbo;
   }
    
    /**
     * Count the time difference between two times
     * two-one
     * The difference is a few seconds, a few milliseconds
     */
   private static String getDistanceDateTime(Date one, Date two) {
       long day = 0;//Days difference
       long hour = 0;//Hours difference
       long min = 0;//Minutes difference
       long second=0;//Seconds difference
       long diff=0 ;//milliseconds difference
       String result = "";
       final Calendar c = Calendar.getInstance();
//                    c.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
       c.setTime(one);
       long time1 = one.getTime();
       long time2 = two.getTime();
       diff = time2 - time1;
       day = diff / (24 * 60 * 60 * 1000);
       hour = (diff / (60 * 60 * 1000) - day * 24);
       min = ((diff / (60 * 1000)) - day * 24 * 60 - hour * 60);
       second = diff/1000;
       System.out.println("day="+day+" hour="+hour+" min="+min+" ss="+second%60+" SSS="+diff%1000);
       String daystr = day%30+"days";
       String hourStr = hour%24+"hours";
		String minStr = min%60+"minutes";
		String secondStr = second%60+"seconds";
		if (day!=0){
			result = result + daystr;
		}
		if (hour!=0){
			result = result + hourStr;
		}
		if (min!=0){
			result = result + minStr;
		}
		if (second!=0){
			result = result + secondStr;
		}
		return result;
   }         

}
