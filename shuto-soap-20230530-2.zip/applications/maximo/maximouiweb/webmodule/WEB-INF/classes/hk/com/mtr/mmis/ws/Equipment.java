package hk.com.mtr.mmis.ws;

public class Equipment {
	
	 protected java.lang.String equipDesp ;
	 
	 protected long equipId ;
	 
	 protected java.lang.String equipNo ;

	public java.lang.String getEquipDesp() {
		return equipDesp;
	}

	public void setEquipDesp(java.lang.String equipDesp) {
		this.equipDesp = equipDesp;
	}

	public long getEquipId() {
		return equipId;
	}

	public void setEquipId(long equipId) {
		this.equipId = equipId;
	}

	public java.lang.String getEquipNo() {
		return equipNo;
	}

	public void setEquipNo(java.lang.String equipNo) {
		this.equipNo = equipNo;
	}
	 
	 
	 

}
