package hk.com.mtr.mmis.ws;

public class RetrieveWorkOrderListResponseE {

	protected hk.com.mtr.mmis.ws.RetrieveWorkOrderListResponse retrieveWorkOrderListResponse ;

	public hk.com.mtr.mmis.ws.RetrieveWorkOrderListResponse getRetrieveWorkOrderListResponse() {
		return retrieveWorkOrderListResponse;
	}

	public void setRetrieveWorkOrderListResponse(
			hk.com.mtr.mmis.ws.RetrieveWorkOrderListResponse retrieveWorkOrderListResponse) {
		this.retrieveWorkOrderListResponse = retrieveWorkOrderListResponse;
	}

}
