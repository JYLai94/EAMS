package hk.com.mtr.mmis.ws;

public class WorkGrp {

	protected java.lang.String wkGrpCd ;
	
	protected java.lang.String wkGrpId ;
	
	protected java.lang.String wkGrpName ;

	public java.lang.String getWkGrpCd() {
		return wkGrpCd;
	}

	public void setWkGrpCd(java.lang.String wkGrpCd) {
		this.wkGrpCd = wkGrpCd;
	}

	public java.lang.String getWkGrpId() {
		return wkGrpId;
	}

	public void setWkGrpId(java.lang.String wkGrpId) {
		this.wkGrpId = wkGrpId;
	}

	public java.lang.String getWkGrpName() {
		return wkGrpName;
	}

	public void setWkGrpName(java.lang.String wkGrpName) {
		this.wkGrpName = wkGrpName;
	}
	
}
