package hk.com.mtr.mmis.ws;

public class RetrieveWorkOrderList {

	protected java.lang.String[] workOrderNo ;

	public java.lang.String[] getWorkOrderNo() {
		return workOrderNo;
	}

	public void setWorkOrderNo(java.lang.String[] workOrderNo) {
		this.workOrderNo = workOrderNo;
	}
	
	
}
