package hk.com.mtr.mmis.ws;

public class MMISWebServiceExceptionE {
	
	protected hk.com.mtr.mmis.ws.MMISWebServiceException MMISWebServiceException ;

	public hk.com.mtr.mmis.ws.MMISWebServiceException getMMISWebServiceException() {
		return MMISWebServiceException;
	}

	public void setMMISWebServiceException(hk.com.mtr.mmis.ws.MMISWebServiceException param) {
		MMISWebServiceException = param;
	}

     


}
