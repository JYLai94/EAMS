package hk.com.mtr.mmis.ws;

public class StandardJob {
	
	protected java.lang.String desp ;
	
	protected java.lang.String stdJobCd ;
	
	protected long stdJobId ;
	
	protected hk.com.mtr.mmis.ws.StdJobParamSet[] stdJobParamSets ;

	public java.lang.String getDesp() {
		return desp;
	}

	public void setDesp(java.lang.String desp) {
		this.desp = desp;
	}

	public java.lang.String getStdJobCd() {
		return stdJobCd;
	}

	public void setStdJobCd(java.lang.String stdJobCd) {
		this.stdJobCd = stdJobCd;
	}

	public long getStdJobId() {
		return stdJobId;
	}

	public void setStdJobId(long stdJobId) {
		this.stdJobId = stdJobId;
	}

	public hk.com.mtr.mmis.ws.StdJobParamSet[] getStdJobParamSets() {
		return stdJobParamSets;
	}

	public void setStdJobParamSets(hk.com.mtr.mmis.ws.StdJobParamSet[] stdJobParamSets) {
		this.stdJobParamSets = stdJobParamSets;
	}
	
	
	
}
