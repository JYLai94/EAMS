package hk.com.mtr.mmis.ws;

public class StockRate {

	protected java.util.Calendar effEndDate ;
	
	protected java.util.Calendar effStartDate ;
	
	protected java.util.Calendar lastUpdDatetime ;
	protected long lastUpdUserId ;
	protected long ltockRateId ;
	protected double unitRate ;
	public java.util.Calendar getEffEndDate() {
		return effEndDate;
	}
	public void setEffEndDate(java.util.Calendar effEndDate) {
		this.effEndDate = effEndDate;
	}
	public java.util.Calendar getEffStartDate() {
		return effStartDate;
	}
	public void setEffStartDate(java.util.Calendar effStartDate) {
		this.effStartDate = effStartDate;
	}
	public java.util.Calendar getLastUpdDatetime() {
		return lastUpdDatetime;
	}
	public void setLastUpdDatetime(java.util.Calendar lastUpdDatetime) {
		this.lastUpdDatetime = lastUpdDatetime;
	}
	public long getLastUpdUserId() {
		return lastUpdUserId;
	}
	public void setLastUpdUserId(long lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}
	public long getLtockRateId() {
		return ltockRateId;
	}
	public void setLtockRateId(long ltockRateId) {
		this.ltockRateId = ltockRateId;
	}
	public double getUnitRate() {
		return unitRate;
	}
	public void setUnitRate(double unitRate) {
		this.unitRate = unitRate;
	}
	
	
	
	
}
