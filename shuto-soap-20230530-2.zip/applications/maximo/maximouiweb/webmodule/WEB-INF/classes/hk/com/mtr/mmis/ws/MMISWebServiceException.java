package hk.com.mtr.mmis.ws;

public class MMISWebServiceException {
	
	protected java.lang.String errorCode ;
      
	protected java.lang.String errorMessage ;

	public java.lang.String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(java.lang.String errorCode) {
		this.errorCode = errorCode;
	}

	public java.lang.String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(java.lang.String errorMessage) {
		this.errorMessage = errorMessage;
	}
           


}
