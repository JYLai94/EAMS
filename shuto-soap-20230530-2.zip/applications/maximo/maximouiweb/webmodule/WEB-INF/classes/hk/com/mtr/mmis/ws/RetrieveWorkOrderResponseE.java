package hk.com.mtr.mmis.ws;

public class RetrieveWorkOrderResponseE implements java.io.Serializable {
	
	private static final long serialVersionUID = -1369472250457833637L;
	
	protected hk.com.mtr.mmis.ws.RetrieveWorkOrderResponse retrieveWorkOrderResponse ;
	
	public hk.com.mtr.mmis.ws.RetrieveWorkOrderResponse getRetrieveWorkOrderResponse() {
		return retrieveWorkOrderResponse;
	}
	public void setRetrieveWorkOrderResponse(hk.com.mtr.mmis.ws.RetrieveWorkOrderResponse retrieveWorkOrderResponse) {
		this.retrieveWorkOrderResponse = retrieveWorkOrderResponse;
	}
     


}
