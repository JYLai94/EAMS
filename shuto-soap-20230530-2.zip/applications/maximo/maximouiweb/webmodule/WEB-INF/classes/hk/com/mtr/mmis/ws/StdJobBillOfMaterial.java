package hk.com.mtr.mmis.ws;

public class StdJobBillOfMaterial {

}
