package hk.com.mtr.mmis.ws;

public class WoActBolVO {

	protected java.lang.Object[] laborCostResourceTypes ;
	
	protected java.lang.String labourType ;
	
	protected java.lang.String resourceDesp ;
	
	protected java.lang.String resourceTypeDesp ;
	
	protected hk.com.mtr.mmis.ws.ActualBillOfLabour woLabourCost ;
	
	
	
	
	
	
	public java.lang.Object[] getLaborCostResourceTypes() {
		return laborCostResourceTypes;
	}






	public void setLaborCostResourceTypes(java.lang.Object[] laborCostResourceTypes) {
		this.laborCostResourceTypes = laborCostResourceTypes;
	}






	public java.lang.String getLabourType() {
		return labourType;
	}






	public void setLabourType(java.lang.String labourType) {
		this.labourType = labourType;
	}






	public java.lang.String getResourceDesp() {
		return resourceDesp;
	}






	public void setResourceDesp(java.lang.String resourceDesp) {
		this.resourceDesp = resourceDesp;
	}






	public java.lang.String getResourceTypeDesp() {
		return resourceTypeDesp;
	}






	public void setResourceTypeDesp(java.lang.String resourceTypeDesp) {
		this.resourceTypeDesp = resourceTypeDesp;
	}






	public hk.com.mtr.mmis.ws.ActualBillOfLabour getWoLabourCost() {
		return woLabourCost;
	}






	public void setWoLabourCost(hk.com.mtr.mmis.ws.ActualBillOfLabour woLabourCost) {
		this.woLabourCost = woLabourCost;
	}






	public void addLaborCostResourceTypes(java.lang.Object param){
        if (laborCostResourceTypes == null){
        	laborCostResourceTypes = new java.lang.Object[]{};
        }

 
      //update the setting tracker
//     localLaborCostResourceTypesTracker = true;
 

    java.util.List list =
 org.apache.axis2.databinding.utils.ConverterUtil.toList(laborCostResourceTypes);
    list.add(param);
    this.laborCostResourceTypes =
  (java.lang.Object[])list.toArray(
 new java.lang.Object[list.size()]);

  }
}
