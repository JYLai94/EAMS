package hk.com.mtr.mmis.ws;

public class HumanResource {
	
	protected java.lang.String hrName ;
	protected java.lang.String hrNo ;
	protected java.lang.String hrUserId ;
	
	public java.lang.String getHrName() {
		return hrName;
	}
	public void setHrName(java.lang.String hrName) {
		this.hrName = hrName;
	}
	public java.lang.String getHrNo() {
		return hrNo;
	}
	public void setHrNo(java.lang.String hrNo) {
		this.hrNo = hrNo;
	}
	public java.lang.String getHrUserId() {
		return hrUserId;
	}
	public void setHrUserId(java.lang.String hrUserId) {
		this.hrUserId = hrUserId;
	}

}
