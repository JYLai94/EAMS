package hk.com.mtr.mmis.ws;

public class WoStatusHistory {

	protected java.lang.String actualCmplTime ;
	
	protected java.util.Calendar actualStartDate ;
	
	protected java.lang.String actualStartTime ;
	
	protected java.lang.String cmplByCd ;
	
	protected java.lang.String cmplByName ;
	
	protected java.lang.String cmplPersonInChrg ;
	
	protected java.lang.String completeBy ;
	
	protected java.lang.String contactEmailList ;
	
	protected java.lang.String gcReasonCd ;
	
	protected java.util.Calendar lastUpdDatetime ;
	
	protected long lastUpdUserId ;
	
	protected java.lang.String personInChrgCd ;
	
	protected java.lang.String personInChrgName ;
	
	protected java.lang.String remark ;
	
	protected java.lang.String status ;
	
	protected java.util.Calendar statusDate ;
	
	protected java.lang.String statusDateTime ;
	
	protected java.lang.String supersededByWoNo ;
	
	protected long woStatusHisId ;

	public java.lang.String getActualCmplTime() {
		return actualCmplTime;
	}

	public void setActualCmplTime(java.lang.String actualCmplTime) {
		this.actualCmplTime = actualCmplTime;
	}

	public java.util.Calendar getActualStartDate() {
		return actualStartDate;
	}

	public void setActualStartDate(java.util.Calendar actualStartDate) {
		this.actualStartDate = actualStartDate;
	}

	public java.lang.String getActualStartTime() {
		return actualStartTime;
	}

	public void setActualStartTime(java.lang.String actualStartTime) {
		this.actualStartTime = actualStartTime;
	}

	public java.lang.String getCmplByCd() {
		return cmplByCd;
	}

	public void setCmplByCd(java.lang.String cmplByCd) {
		this.cmplByCd = cmplByCd;
	}

	public java.lang.String getCmplByName() {
		return cmplByName;
	}

	public void setCmplByName(java.lang.String cmplByName) {
		this.cmplByName = cmplByName;
	}

	public java.lang.String getCmplPersonInChrg() {
		return cmplPersonInChrg;
	}

	public void setCmplPersonInChrg(java.lang.String cmplPersonInChrg) {
		this.cmplPersonInChrg = cmplPersonInChrg;
	}

	public java.lang.String getCompleteBy() {
		return completeBy;
	}

	public void setCompleteBy(java.lang.String completeBy) {
		this.completeBy = completeBy;
	}

	public java.lang.String getContactEmailList() {
		return contactEmailList;
	}

	public void setContactEmailList(java.lang.String contactEmailList) {
		this.contactEmailList = contactEmailList;
	}

	public java.lang.String getGcReasonCd() {
		return gcReasonCd;
	}

	public void setGcReasonCd(java.lang.String gcReasonCd) {
		this.gcReasonCd = gcReasonCd;
	}

	public java.util.Calendar getLastUpdDatetime() {
		return lastUpdDatetime;
	}

	public void setLastUpdDatetime(java.util.Calendar lastUpdDatetime) {
		this.lastUpdDatetime = lastUpdDatetime;
	}

	public long getLastUpdUserId() {
		return lastUpdUserId;
	}

	public void setLastUpdUserId(long lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public java.lang.String getPersonInChrgCd() {
		return personInChrgCd;
	}

	public void setPersonInChrgCd(java.lang.String personInChrgCd) {
		this.personInChrgCd = personInChrgCd;
	}

	public java.lang.String getPersonInChrgName() {
		return personInChrgName;
	}

	public void setPersonInChrgName(java.lang.String personInChrgName) {
		this.personInChrgName = personInChrgName;
	}

	public java.lang.String getRemark() {
		return remark;
	}

	public void setRemark(java.lang.String remark) {
		this.remark = remark;
	}

	public java.lang.String getStatus() {
		return status;
	}

	public void setStatus(java.lang.String status) {
		this.status = status;
	}

	public java.util.Calendar getStatusDate() {
		return statusDate;
	}

	public void setStatusDate(java.util.Calendar statusDate) {
		this.statusDate = statusDate;
	}

	public java.lang.String getStatusDateTime() {
		return statusDateTime;
	}

	public void setStatusDateTime(java.lang.String statusDateTime) {
		this.statusDateTime = statusDateTime;
	}

	public java.lang.String getSupersededByWoNo() {
		return supersededByWoNo;
	}

	public void setSupersededByWoNo(java.lang.String supersededByWoNo) {
		this.supersededByWoNo = supersededByWoNo;
	}

	public long getWoStatusHisId() {
		return woStatusHisId;
	}

	public void setWoStatusHisId(long woStatusHisId) {
		this.woStatusHisId = woStatusHisId;
	}
	
	
	
	
	
	
}
