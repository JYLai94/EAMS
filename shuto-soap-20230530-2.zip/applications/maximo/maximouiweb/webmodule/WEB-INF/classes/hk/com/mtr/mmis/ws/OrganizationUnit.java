package hk.com.mtr.mmis.ws;

public class OrganizationUnit {
	
	protected java.lang.String ouCd ;
      
	protected java.lang.String ouId ;
           
	protected java.lang.String ouName ;

	protected java.lang.String parentOrgnizationCodeName ;
   
	protected java.lang.String parentOrgnizationUnitName ;
           
	protected java.lang.String parentOuId ;

	public java.lang.String getOuCd() {
		return ouCd;
	}

	public void setOuCd(java.lang.String ouCd) {
		this.ouCd = ouCd;
	}

	public java.lang.String getOuId() {
		return ouId;
	}

	public void setOuId(java.lang.String ouId) {
		this.ouId = ouId;
	}

	public java.lang.String getOuName() {
		return ouName;
	}

	public void setOuName(java.lang.String ouName) {
		this.ouName = ouName;
	}

	public java.lang.String getParentOrgnizationCodeName() {
		return parentOrgnizationCodeName;
	}

	public void setParentOrgnizationCodeName(java.lang.String parentOrgnizationCodeName) {
		this.parentOrgnizationCodeName = parentOrgnizationCodeName;
	}

	public java.lang.String getParentOrgnizationUnitName() {
		return parentOrgnizationUnitName;
	}

	public void setParentOrgnizationUnitName(java.lang.String parentOrgnizationUnitName) {
		this.parentOrgnizationUnitName = parentOrgnizationUnitName;
	}

	public java.lang.String getParentOuId() {
		return parentOuId;
	}

	public void setParentOuId(java.lang.String parentOuId) {
		this.parentOuId = parentOuId;
	}
           
}
