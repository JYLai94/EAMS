package hk.com.mtr.mmis.ws;

public class StdJobParamSubset {
	
	protected java.lang.String adjustScheduleCd ;
	
	protected long buId ;
	
	protected java.lang.String changeRemark ;
	
	protected java.lang.String contractCd ;
	
	protected long contractID ;
	
	protected java.lang.String contractNO ;
	
	protected long dayPreference ;
	
	protected java.util.Calendar effEndDate ;
	
	protected java.util.Calendar effStartDate ;
	
	protected long estimateJobDur ;
	
	protected boolean factorFitment ;
	
	protected double firstMeasurementInterval ;
	
	protected double firstMeasurementMaxAdv ;
	
	protected double firstMeasurementMaxPost ;
	
	protected long firstMeasurementTypeId ;
	
	protected java.lang.String firstMeasurementTypeName ;
	
	protected java.lang.String firstMeasurementUom ;
	
	protected java.lang.String gcFinanceRefNoCD ;
	
	protected java.lang.String gcPriorityCd ;
	
	protected java.lang.String gcProjectNoCD ;
	
	protected java.lang.String gcProjectTakkNoCD ;
	
	protected java.lang.String gcSsdCalculationMethodCd ;
	
	protected java.lang.String gcTabuMethodCd ;
	
	protected java.lang.String gcWorkTimeReqCd ;
	
	protected java.util.Calendar lastUpdDatetime ;
	
	protected long lastUpdUserId ;
	
	protected long maxOverdue ;
	
	protected java.lang.String maxTlrncMeasurementName ;
	
	protected double maxTlrncMeasurementRange ;
	
	protected long maxTlrncMeasurementTypeId ;
	
	protected long maxToleranceRange ;
	
	protected boolean mtMeasurementEmpty ;
	
	protected java.lang.String mtUom ;
	
	protected java.lang.String schFactorFitment ;
	
	protected java.lang.String schFactorStdJobCd ;
	
	protected java.lang.String schFactorStdJobId ;
	
	protected double secondMeasurementInterval ;
	
	protected double secondMeasurementMaxAdv ;
	
	protected double secondMeasurementMaxPost ;
	
	protected long secondMeasurementTypeId ;
	
	protected java.lang.String secondMeasurementTypeName ;
	
	protected java.lang.String secondMeasurementUom ;
	
	protected java.lang.String statutoryInd ;
	
	protected hk.com.mtr.mmis.ws.StdJobBillOfLabour[] stdJobBillOfLabours ;
	
	protected hk.com.mtr.mmis.ws.StdJobBillOfMaterial[] stdJobBillOfMaterials ;
	
	protected hk.com.mtr.mmis.ws.StdJobBillOfOthers[] stdJobBillOfOtherses ;
	
	protected long StdJobParamSubsetId ;
	
	protected long TimeInterval ;
	
	protected long TimeMaxAdv ;
	
	protected long TimeMaxPost ;
	
	protected hk.com.mtr.mmis.ws.WorkGrp WkGrp ;
	
	protected java.lang.String WkGrpCd ;
	
	
	
	
	public java.lang.String getAdjustScheduleCd() {
		return adjustScheduleCd;
	}

	public void setAdjustScheduleCd(java.lang.String adjustScheduleCd) {
		this.adjustScheduleCd = adjustScheduleCd;
	}

	public long getBuId() {
		return buId;
	}

	public void setBuId(long buId) {
		this.buId = buId;
	}

	public java.lang.String getChangeRemark() {
		return changeRemark;
	}

	public void setChangeRemark(java.lang.String changeRemark) {
		this.changeRemark = changeRemark;
	}

	public java.lang.String getContractCd() {
		return contractCd;
	}

	public void setContractCd(java.lang.String contractCd) {
		this.contractCd = contractCd;
	}

	public long getContractID() {
		return contractID;
	}

	public void setContractID(long contractID) {
		this.contractID = contractID;
	}

	public java.lang.String getContractNO() {
		return contractNO;
	}

	public void setContractNO(java.lang.String contractNO) {
		this.contractNO = contractNO;
	}

	public long getDayPreference() {
		return dayPreference;
	}

	public void setDayPreference(long dayPreference) {
		this.dayPreference = dayPreference;
	}

	public java.util.Calendar getEffEndDate() {
		return effEndDate;
	}

	public void setEffEndDate(java.util.Calendar effEndDate) {
		this.effEndDate = effEndDate;
	}

	public java.util.Calendar getEffStartDate() {
		return effStartDate;
	}

	public void setEffStartDate(java.util.Calendar effStartDate) {
		this.effStartDate = effStartDate;
	}

	public long getEstimateJobDur() {
		return estimateJobDur;
	}

	public void setEstimateJobDur(long estimateJobDur) {
		this.estimateJobDur = estimateJobDur;
	}

	public boolean isFactorFitment() {
		return factorFitment;
	}

	public void setFactorFitment(boolean factorFitment) {
		this.factorFitment = factorFitment;
	}

	public double getFirstMeasurementInterval() {
		return firstMeasurementInterval;
	}

	public void setFirstMeasurementInterval(double firstMeasurementInterval) {
		this.firstMeasurementInterval = firstMeasurementInterval;
	}

	public double getFirstMeasurementMaxAdv() {
		return firstMeasurementMaxAdv;
	}

	public void setFirstMeasurementMaxAdv(double firstMeasurementMaxAdv) {
		this.firstMeasurementMaxAdv = firstMeasurementMaxAdv;
	}

	public double getFirstMeasurementMaxPost() {
		return firstMeasurementMaxPost;
	}

	public void setFirstMeasurementMaxPost(double firstMeasurementMaxPost) {
		this.firstMeasurementMaxPost = firstMeasurementMaxPost;
	}

	public long getFirstMeasurementTypeId() {
		return firstMeasurementTypeId;
	}

	public void setFirstMeasurementTypeId(long firstMeasurementTypeId) {
		this.firstMeasurementTypeId = firstMeasurementTypeId;
	}

	public java.lang.String getFirstMeasurementTypeName() {
		return firstMeasurementTypeName;
	}

	public void setFirstMeasurementTypeName(java.lang.String firstMeasurementTypeName) {
		this.firstMeasurementTypeName = firstMeasurementTypeName;
	}

	public java.lang.String getFirstMeasurementUom() {
		return firstMeasurementUom;
	}

	public void setFirstMeasurementUom(java.lang.String firstMeasurementUom) {
		this.firstMeasurementUom = firstMeasurementUom;
	}

	public java.lang.String getGcFinanceRefNoCD() {
		return gcFinanceRefNoCD;
	}

	public void setGcFinanceRefNoCD(java.lang.String gcFinanceRefNoCD) {
		this.gcFinanceRefNoCD = gcFinanceRefNoCD;
	}

	public java.lang.String getGcPriorityCd() {
		return gcPriorityCd;
	}

	public void setGcPriorityCd(java.lang.String gcPriorityCd) {
		this.gcPriorityCd = gcPriorityCd;
	}

	public java.lang.String getGcProjectNoCD() {
		return gcProjectNoCD;
	}

	public void setGcProjectNoCD(java.lang.String gcProjectNoCD) {
		this.gcProjectNoCD = gcProjectNoCD;
	}

	public java.lang.String getGcProjectTakkNoCD() {
		return gcProjectTakkNoCD;
	}

	public void setGcProjectTakkNoCD(java.lang.String gcProjectTakkNoCD) {
		this.gcProjectTakkNoCD = gcProjectTakkNoCD;
	}

	public java.lang.String getGcSsdCalculationMethodCd() {
		return gcSsdCalculationMethodCd;
	}

	public void setGcSsdCalculationMethodCd(java.lang.String gcSsdCalculationMethodCd) {
		this.gcSsdCalculationMethodCd = gcSsdCalculationMethodCd;
	}

	public java.lang.String getGcTabuMethodCd() {
		return gcTabuMethodCd;
	}

	public void setGcTabuMethodCd(java.lang.String gcTabuMethodCd) {
		this.gcTabuMethodCd = gcTabuMethodCd;
	}

	public java.lang.String getGcWorkTimeReqCd() {
		return gcWorkTimeReqCd;
	}

	public void setGcWorkTimeReqCd(java.lang.String gcWorkTimeReqCd) {
		this.gcWorkTimeReqCd = gcWorkTimeReqCd;
	}

	public java.util.Calendar getLastUpdDatetime() {
		return lastUpdDatetime;
	}

	public void setLastUpdDatetime(java.util.Calendar lastUpdDatetime) {
		this.lastUpdDatetime = lastUpdDatetime;
	}

	public long getLastUpdUserId() {
		return lastUpdUserId;
	}

	public void setLastUpdUserId(long lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}

	public long getMaxOverdue() {
		return maxOverdue;
	}

	public void setMaxOverdue(long maxOverdue) {
		this.maxOverdue = maxOverdue;
	}

	public java.lang.String getMaxTlrncMeasurementName() {
		return maxTlrncMeasurementName;
	}

	public void setMaxTlrncMeasurementName(java.lang.String maxTlrncMeasurementName) {
		this.maxTlrncMeasurementName = maxTlrncMeasurementName;
	}

	public double getMaxTlrncMeasurementRange() {
		return maxTlrncMeasurementRange;
	}

	public void setMaxTlrncMeasurementRange(double maxTlrncMeasurementRange) {
		this.maxTlrncMeasurementRange = maxTlrncMeasurementRange;
	}

	public long getMaxTlrncMeasurementTypeId() {
		return maxTlrncMeasurementTypeId;
	}

	public void setMaxTlrncMeasurementTypeId(long maxTlrncMeasurementTypeId) {
		this.maxTlrncMeasurementTypeId = maxTlrncMeasurementTypeId;
	}

	public long getMaxToleranceRange() {
		return maxToleranceRange;
	}

	public void setMaxToleranceRange(long maxToleranceRange) {
		this.maxToleranceRange = maxToleranceRange;
	}

	public boolean isMtMeasurementEmpty() {
		return mtMeasurementEmpty;
	}

	public void setMtMeasurementEmpty(boolean mtMeasurementEmpty) {
		this.mtMeasurementEmpty = mtMeasurementEmpty;
	}

	public java.lang.String getMtUom() {
		return mtUom;
	}

	public void setMtUom(java.lang.String mtUom) {
		this.mtUom = mtUom;
	}

	public java.lang.String getSchFactorFitment() {
		return schFactorFitment;
	}

	public void setSchFactorFitment(java.lang.String schFactorFitment) {
		this.schFactorFitment = schFactorFitment;
	}

	public java.lang.String getSchFactorStdJobCd() {
		return schFactorStdJobCd;
	}

	public void setSchFactorStdJobCd(java.lang.String schFactorStdJobCd) {
		this.schFactorStdJobCd = schFactorStdJobCd;
	}

	public java.lang.String getSchFactorStdJobId() {
		return schFactorStdJobId;
	}

	public void setSchFactorStdJobId(java.lang.String schFactorStdJobId) {
		this.schFactorStdJobId = schFactorStdJobId;
	}

	public double getSecondMeasurementInterval() {
		return secondMeasurementInterval;
	}

	public void setSecondMeasurementInterval(double secondMeasurementInterval) {
		this.secondMeasurementInterval = secondMeasurementInterval;
	}

	public double getSecondMeasurementMaxAdv() {
		return secondMeasurementMaxAdv;
	}

	public void setSecondMeasurementMaxAdv(double secondMeasurementMaxAdv) {
		this.secondMeasurementMaxAdv = secondMeasurementMaxAdv;
	}

	public double getSecondMeasurementMaxPost() {
		return secondMeasurementMaxPost;
	}

	public void setSecondMeasurementMaxPost(double secondMeasurementMaxPost) {
		this.secondMeasurementMaxPost = secondMeasurementMaxPost;
	}

	public long getSecondMeasurementTypeId() {
		return secondMeasurementTypeId;
	}

	public void setSecondMeasurementTypeId(long secondMeasurementTypeId) {
		this.secondMeasurementTypeId = secondMeasurementTypeId;
	}

	public java.lang.String getSecondMeasurementTypeName() {
		return secondMeasurementTypeName;
	}

	public void setSecondMeasurementTypeName(java.lang.String secondMeasurementTypeName) {
		this.secondMeasurementTypeName = secondMeasurementTypeName;
	}

	public java.lang.String getSecondMeasurementUom() {
		return secondMeasurementUom;
	}

	public void setSecondMeasurementUom(java.lang.String secondMeasurementUom) {
		this.secondMeasurementUom = secondMeasurementUom;
	}

	public java.lang.String getStatutoryInd() {
		return statutoryInd;
	}

	public void setStatutoryInd(java.lang.String statutoryInd) {
		this.statutoryInd = statutoryInd;
	}

	public hk.com.mtr.mmis.ws.StdJobBillOfLabour[] getStdJobBillOfLabours() {
		return stdJobBillOfLabours;
	}

	public void setStdJobBillOfLabours(hk.com.mtr.mmis.ws.StdJobBillOfLabour[] stdJobBillOfLabours) {
		this.stdJobBillOfLabours = stdJobBillOfLabours;
	}

	public hk.com.mtr.mmis.ws.StdJobBillOfMaterial[] getStdJobBillOfMaterials() {
		return stdJobBillOfMaterials;
	}

	public void setStdJobBillOfMaterials(hk.com.mtr.mmis.ws.StdJobBillOfMaterial[] stdJobBillOfMaterials) {
		this.stdJobBillOfMaterials = stdJobBillOfMaterials;
	}

	public hk.com.mtr.mmis.ws.StdJobBillOfOthers[] getStdJobBillOfOtherses() {
		return stdJobBillOfOtherses;
	}

	public void setStdJobBillOfOtherses(hk.com.mtr.mmis.ws.StdJobBillOfOthers[] stdJobBillOfOtherses) {
		this.stdJobBillOfOtherses = stdJobBillOfOtherses;
	}

	public long getStdJobParamSubsetId() {
		return StdJobParamSubsetId;
	}

	public void setStdJobParamSubsetId(long stdJobParamSubsetId) {
		StdJobParamSubsetId = stdJobParamSubsetId;
	}

	public long getTimeInterval() {
		return TimeInterval;
	}

	public void setTimeInterval(long timeInterval) {
		TimeInterval = timeInterval;
	}

	public long getTimeMaxAdv() {
		return TimeMaxAdv;
	}

	public void setTimeMaxAdv(long timeMaxAdv) {
		TimeMaxAdv = timeMaxAdv;
	}

	public long getTimeMaxPost() {
		return TimeMaxPost;
	}

	public void setTimeMaxPost(long timeMaxPost) {
		TimeMaxPost = timeMaxPost;
	}

	public hk.com.mtr.mmis.ws.WorkGrp getWkGrp() {
		return WkGrp;
	}

	public void setWkGrp(hk.com.mtr.mmis.ws.WorkGrp wkGrp) {
		WkGrp = wkGrp;
	}

	public java.lang.String getWkGrpCd() {
		return WkGrpCd;
	}

	public void setWkGrpCd(java.lang.String wkGrpCd) {
		WkGrpCd = wkGrpCd;
	}

	public void addStdJobBillOfLabours(hk.com.mtr.mmis.ws.StdJobBillOfLabour param){
        if (stdJobBillOfLabours == null){
        stdJobBillOfLabours = new hk.com.mtr.mmis.ws.StdJobBillOfLabour[]{};
        }

 

    java.util.List list =
 org.apache.axis2.databinding.utils.ConverterUtil.toList(stdJobBillOfLabours);
    list.add(param);
    this.stdJobBillOfLabours =
  (hk.com.mtr.mmis.ws.StdJobBillOfLabour[])list.toArray(
		  new hk.com.mtr.mmis.ws.StdJobBillOfLabour[list.size()]);

  }
	
	public void addStdJobBillOfMaterials(hk.com.mtr.mmis.ws.StdJobBillOfMaterial param){
        if (stdJobBillOfMaterials == null){
        stdJobBillOfMaterials = new hk.com.mtr.mmis.ws.StdJobBillOfMaterial[]{};
        }

 

    java.util.List list =
 org.apache.axis2.databinding.utils.ConverterUtil.toList(stdJobBillOfMaterials);
    list.add(param);
    this.stdJobBillOfMaterials =
  (hk.com.mtr.mmis.ws.StdJobBillOfMaterial[])list.toArray(
 new hk.com.mtr.mmis.ws.StdJobBillOfMaterial[list.size()]);

  }
	
	public void addStdJobBillOfOtherses(hk.com.mtr.mmis.ws.StdJobBillOfOthers param){
        if (stdJobBillOfOtherses == null){
        stdJobBillOfOtherses = new hk.com.mtr.mmis.ws.StdJobBillOfOthers[]{};
        }

 
      //update the setting tracker
//     stdJobBillOfOthersesTracker = true;
 

    java.util.List list =
 org.apache.axis2.databinding.utils.ConverterUtil.toList(stdJobBillOfOtherses);
    list.add(param);
    this.stdJobBillOfOtherses =
  (hk.com.mtr.mmis.ws.StdJobBillOfOthers[])list.toArray(
 new hk.com.mtr.mmis.ws.StdJobBillOfOthers[list.size()]);

  }
	
	
	
}
