package hk.com.mtr.mmis.ws;

public class RetrieveWorkOrderResponse {
	
	  protected hk.com.mtr.mmis.ws.WorkOrderVO _return ;

	public hk.com.mtr.mmis.ws.WorkOrderVO get_return() {
		return _return;
	}

	public void set_return(hk.com.mtr.mmis.ws.WorkOrderVO _return) {
		this._return = _return;
	}
	  

}
