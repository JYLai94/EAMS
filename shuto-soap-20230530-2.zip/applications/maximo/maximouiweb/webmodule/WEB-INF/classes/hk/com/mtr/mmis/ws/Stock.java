package hk.com.mtr.mmis.ws;

public class Stock {
	
	protected long arriveDays ;
	
	protected long buId ;
	
	protected java.lang.String gcUomCd ;
	
	protected java.util.Calendar lastAvailableDate ;
	
	protected java.util.Calendar lastUpdDatetime ;
	
	protected long lastUpdUserId ;
	
	protected java.lang.String onDemandInd ;
	
	protected double quantityAvailable ;
	
	protected java.lang.String status ;
	
	protected java.lang.String stockCd ;
	
	protected long stockId ;
	
	protected java.lang.String stockName ;
	
	protected hk.com.mtr.mmis.ws.StockRate[] stockRates ;
	
	protected java.lang.String stockType ;
	
	protected double unitRate ;
	
	
	public long getArriveDays() {
		return arriveDays;
	}

	public void setArriveDays(long arriveDays) {
		this.arriveDays = arriveDays;
	}

	public long getBuId() {
		return buId;
	}







	public void setBuId(long buId) {
		this.buId = buId;
	}







	public java.lang.String getGcUomCd() {
		return gcUomCd;
	}







	public void setGcUomCd(java.lang.String gcUomCd) {
		this.gcUomCd = gcUomCd;
	}







	public java.util.Calendar getLastAvailableDate() {
		return lastAvailableDate;
	}







	public void setLastAvailableDate(java.util.Calendar lastAvailableDate) {
		this.lastAvailableDate = lastAvailableDate;
	}







	public java.util.Calendar getLastUpdDatetime() {
		return lastUpdDatetime;
	}







	public void setLastUpdDatetime(java.util.Calendar lastUpdDatetime) {
		this.lastUpdDatetime = lastUpdDatetime;
	}







	public long getLastUpdUserId() {
		return lastUpdUserId;
	}







	public void setLastUpdUserId(long lastUpdUserId) {
		this.lastUpdUserId = lastUpdUserId;
	}







	public java.lang.String getOnDemandInd() {
		return onDemandInd;
	}







	public void setOnDemandInd(java.lang.String onDemandInd) {
		this.onDemandInd = onDemandInd;
	}







	public double getQuantityAvailable() {
		return quantityAvailable;
	}







	public void setQuantityAvailable(double quantityAvailable) {
		this.quantityAvailable = quantityAvailable;
	}







	public java.lang.String getStatus() {
		return status;
	}







	public void setStatus(java.lang.String status) {
		this.status = status;
	}







	public java.lang.String getStockCd() {
		return stockCd;
	}







	public void setStockCd(java.lang.String stockCd) {
		this.stockCd = stockCd;
	}







	public long getStockId() {
		return stockId;
	}







	public void setStockId(long stockId) {
		this.stockId = stockId;
	}







	public java.lang.String getStockName() {
		return stockName;
	}







	public void setStockName(java.lang.String stockName) {
		this.stockName = stockName;
	}







	public hk.com.mtr.mmis.ws.StockRate[] getStockRates() {
		return stockRates;
	}







	public void setStockRates(hk.com.mtr.mmis.ws.StockRate[] stockRates) {
		this.stockRates = stockRates;
	}







	public java.lang.String getStockType() {
		return stockType;
	}







	public void setStockType(java.lang.String stockType) {
		this.stockType = stockType;
	}







	public double getUnitRate() {
		return unitRate;
	}







	public void setUnitRate(double unitRate) {
		this.unitRate = unitRate;
	}







	public void addStockRates(hk.com.mtr.mmis.ws.StockRate param){
        if (stockRates == null){
        	stockRates = new hk.com.mtr.mmis.ws.StockRate[]{};
        }

 
      //update the setting tracker
//     localStockRatesTracker = true;
 

    java.util.List list =
 org.apache.axis2.databinding.utils.ConverterUtil.toList(stockRates);
    list.add(param);
    this.stockRates =
  (hk.com.mtr.mmis.ws.StockRate[])list.toArray(
 new hk.com.mtr.mmis.ws.StockRate[list.size()]);

  }
	
	
	

}
