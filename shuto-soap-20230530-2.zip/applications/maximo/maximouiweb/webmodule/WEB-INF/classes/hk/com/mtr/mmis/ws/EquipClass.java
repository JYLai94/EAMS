package hk.com.mtr.mmis.ws;

public class EquipClass {
	
	protected java.lang.String equipClassCd ;
	protected java.lang.String equipClassDesp ;
	protected long equipClassId ;
	public java.lang.String getEquipClassCd() {
		return equipClassCd;
	}
	public void setEquipClassCd(java.lang.String equipClassCd) {
		this.equipClassCd = equipClassCd;
	}
	public java.lang.String getEquipClassDesp() {
		return equipClassDesp;
	}
	public void setEquipClassDesp(java.lang.String equipClassDesp) {
		this.equipClassDesp = equipClassDesp;
	}
	public long getEquipClassId() {
		return equipClassId;
	}
	public void setEquipClassId(long equipClassId) {
		this.equipClassId = equipClassId;
	}
	
}
