package hk.com.mtr.mmis.ws.ois;

public class oisWoCreationInputVO {

    private String equipNo;
    private String equipType;
    private String inHouseInd;
    private String infoContractor;
    private String lineCode;
    private String locationCode;
    private String majorFailureSymptomCode;
    private String majorMinor;
    private String majorMinorfailureCode;
    private String planCmplTime;
    private String planStartTime;
    private String priorityCodeCd;
    private String reportTime;
    private String shutDownTime;
    private String stdJobCode;
    private String symptomCodeCd;
    private String woDesp;
    private String workNatureLv1;
    private String workNatureLv2;
    private String remark;

    public String getEquipNo() {
        return equipNo;
    }

    public void setEquipNo(String equipNo) {
        this.equipNo = equipNo;
    }

    public String getPriorityCodeCd() {
        return priorityCodeCd;
    }

    public void setPriorityCodeCd(String priorityCodeCd) {
        this.priorityCodeCd = priorityCodeCd;
    }

    public String getSymptomCodeCd() {
        return symptomCodeCd;
    }

    public void setSymptomCodeCd(String symptomCodeCd) {
        this.symptomCodeCd = symptomCodeCd;
    }

    public String getEquipType() {
        return equipType;
    }

    public void setEquipType(String equipType) {
        this.equipType = equipType;
    }

    public String getInHouseInd() {
        return inHouseInd;
    }

    public void setInHouseInd(String inHouseInd) {
        this.inHouseInd = inHouseInd;
    }

    public String getInfoContractor() {
        return infoContractor;
    }

    public void setInfoContractor(String infoContractor) {
        this.infoContractor = infoContractor;
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public String getLocationCode() {
        return locationCode;
    }

    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }

    public String getMajorFailureSymptomCode() {
        return majorFailureSymptomCode;
    }

    public void setMajorFailureSymptomCode(String majorFailureSymptomCode) {
        this.majorFailureSymptomCode = majorFailureSymptomCode;
    }

    public String getMajorMinor() {
        return majorMinor;
    }

    public void setMajorMinor(String majorMinor) {
        this.majorMinor = majorMinor;
    }

    public String getMajorMinorfailureCode() {
        return majorMinorfailureCode;
    }

    public void setMajorMinorfailureCode(String majorMinorfailureCode) {
        this.majorMinorfailureCode = majorMinorfailureCode;
    }

    public String getPlanCmplTime() {
        return planCmplTime;
    }

    public void setPlanCmplTime(String planCmplTime) {
        this.planCmplTime = planCmplTime;
    }

    public String getPlanStartTime() {
        return planStartTime;
    }

    public void setPlanStartTime(String planStartTime) {
        this.planStartTime = planStartTime;
    }


    public String getReportTime() {
        return reportTime;
    }

    public void setReportTime(String reportTime) {
        this.reportTime = reportTime;
    }

    public String getShutDownTime() {
        return shutDownTime;
    }

    public void setShutDownTime(String shutDownTime) {
        this.shutDownTime = shutDownTime;
    }

    public String getStdJobCode() {
        return stdJobCode;
    }

    public void setStdJobCode(String stdJobCode) {
        this.stdJobCode = stdJobCode;
    }

    public String getWoDesp() {
        return woDesp;
    }

    public void setWoDesp(String woDesp) {
        this.woDesp = woDesp;
    }

    public String getWorkNatureLv1() {
        return workNatureLv1;
    }

    public void setWorkNatureLv1(String workNatureLv1) {
        this.workNatureLv1 = workNatureLv1;
    }

    public String getWorkNatureLv2() {
        return workNatureLv2;
    }

    public void setWorkNatureLv2(String workNatureLv2) {
        this.workNatureLv2 = workNatureLv2;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }



}
