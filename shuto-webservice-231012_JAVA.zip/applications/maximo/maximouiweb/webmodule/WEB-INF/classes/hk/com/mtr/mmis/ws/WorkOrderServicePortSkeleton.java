
/**
 * WorkOrderServicePortSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: SNAPSHOT  Built on : Jan 10, 2009 (05:26:14 CST)
 */
package hk.com.mtr.mmis.ws;

import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import psdi.app.workorder.WO;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.server.MXServer;
import psdi.util.MXException;

/**
 *  WorkOrderServicePortSkeleton java skeleton for the axisService
 */
public class WorkOrderServicePortSkeleton implements WorkOrderServicePortSkeletonInterface{
        
	public final static String ERROR_CODE_1 = "1";
	public final static String ERROR_CODE_1_MSG = "Work Order Number does not exist.";
	/*public final static String ERROR_CODE_2 = "2";
	public final static String ERROR_CODE_2_MSG = "Work Order status not in \"Released\", \"Complete\" and \"Closed\".";*/
	public final static String ERROR_CODE_3 = "3";
	public final static String ERROR_CODE_3_MSG = "Unexpected system error: ";
        
	public hk.com.mtr.mmis.ws.RetrieveWorkOrderResponseE retrieveWorkOrder(hk.com.mtr.mmis.ws.RetrieveWorkOrderE retrieveWorkOrder0) throws  WorkOrderException{
    	RetrieveWorkOrderResponseE retrieveWorkOrderResponseE = new RetrieveWorkOrderResponseE();
    	RetrieveWorkOrderResponse retrieveWorkOrderResponse = new RetrieveWorkOrderResponse();
    	String workOrderNo = retrieveWorkOrder0.getRetrieveWorkOrder().localWorkOrderNo;
    	WorkOrderVO workOrderVO = retrieveWorkOrder(workOrderNo);
 		retrieveWorkOrderResponse.set_return(workOrderVO);
 		retrieveWorkOrderResponseE.setRetrieveWorkOrderResponse(retrieveWorkOrderResponse);
    	return retrieveWorkOrderResponseE;
//                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#retrieveWorkOrder");
	}
	
	public hk.com.mtr.mmis.ws.RetrieveWorkOrderListResponseE retrieveWorkOrderList(
			hk.com.mtr.mmis.ws.RetrieveWorkOrderListE retrieveWorkOrderList2) throws WorkOrderException {
		RetrieveWorkOrderListResponseE retrieveWorkOrderListResponseE = new RetrieveWorkOrderListResponseE();
//		try {
			String workOrderNoArray[] = retrieveWorkOrderList2.getRetrieveWorkOrderList().localWorkOrderNo;
			WorkOrderVO[] workOrderVOList = new WorkOrderVO[workOrderNoArray.length];
			boolean isEmpty = true;
			for (int i = 0; i < workOrderNoArray.length; i++) {
				// workOrderVOList[i] = new WorkOrderVO();
				try {
					workOrderVOList[i] = retrieveWorkOrder(workOrderNoArray[i]);
					if(isEmpty){
						if(workOrderVOList[i]!=null){
							isEmpty=false;
						}
					}
				}catch (WorkOrderException ex) {
					ex.printStackTrace();
					if(ERROR_CODE_3.equals(ex.getFaultMessage().getMMISWebServiceException().getErrorCode())){
						MMISWebServiceExceptionE mmisWebServiceExceptionE = new MMISWebServiceExceptionE();
			    		MMISWebServiceException mmisWebServiceException = new MMISWebServiceException();
			    		mmisWebServiceException.setErrorCode(ERROR_CODE_3);
			    		mmisWebServiceException.setErrorMessage(ex.getFaultMessage().getMMISWebServiceException().getErrorMessage());
			    		mmisWebServiceExceptionE.setMMISWebServiceException(mmisWebServiceException);
			    		WorkOrderException workOrderException = new WorkOrderException();
			    		workOrderException.setFaultMessage(mmisWebServiceExceptionE);
			    		throw workOrderException;
					}
				}
			}
			if(isEmpty){
				MMISWebServiceExceptionE mmisWebServiceExceptionE = new MMISWebServiceExceptionE();
	     		MMISWebServiceException mmisWebServiceException = new MMISWebServiceException();
	     		mmisWebServiceException.setErrorCode(ERROR_CODE_1);
	     		mmisWebServiceException.setErrorMessage(ERROR_CODE_1_MSG);
	     		mmisWebServiceExceptionE.setMMISWebServiceException(mmisWebServiceException);
	     		WorkOrderException workOrderException = new WorkOrderException();
	     		workOrderException.setFaultMessage(mmisWebServiceExceptionE);
	     		throw workOrderException;
			}
			RetrieveWorkOrderListResponse retrieveWorkOrderListResponse = new RetrieveWorkOrderListResponse();
			retrieveWorkOrderListResponse.set_return(workOrderVOList);
			retrieveWorkOrderListResponseE.setRetrieveWorkOrderListResponse(retrieveWorkOrderListResponse);
//		}
//		catch (Exception ex) {
//			MMISWebServiceExceptionE mmisWebServiceExceptionE = new MMISWebServiceExceptionE();
//    		MMISWebServiceException mmisWebServiceException = new MMISWebServiceException();
//    		mmisWebServiceException.setErrorCode(ERROR_CODE_3);
//    		mmisWebServiceException.setErrorMessage(ERROR_CODE_3_MSG + ex.getMessage());
//    		mmisWebServiceExceptionE.setMMISWebServiceException(mmisWebServiceException);
//    		WorkOrderException workOrderException = new WorkOrderException();
//    		workOrderException.setFaultMessage(mmisWebServiceExceptionE);
//    		throw workOrderException;
//		}
		return retrieveWorkOrderListResponseE;
		// //TODO : fill this with the necessary business logic
		// throw new java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#retrieveWorkOrderList");
	}


	private WorkOrderVO retrieveWorkOrder(String workOrderNo) throws WorkOrderException {
		WorkOrderVO workOrderVO = new WorkOrderVO();
     	WO woMbo=null;
		try {
			woMbo = (WO)findWO(workOrderNo);
		}
		catch (Exception ex) {
			MMISWebServiceExceptionE mmisWebServiceExceptionE = new MMISWebServiceExceptionE();
    		MMISWebServiceException mmisWebServiceException = new MMISWebServiceException();
    		mmisWebServiceException.setErrorCode(ERROR_CODE_3);
    		mmisWebServiceException.setErrorMessage(ERROR_CODE_3_MSG + ex.getMessage());
    		mmisWebServiceExceptionE.setMMISWebServiceException(mmisWebServiceException);
    		WorkOrderException workOrderException = new WorkOrderException();
    		workOrderException.setFaultMessage(mmisWebServiceExceptionE);
    		throw workOrderException;
//    		MMISWebServiceException errorInfo = new MMISWebServiceException();
//			errorInfo.setErrorCode(ERROR_CODE_3);
//			errorInfo.setErrorMessage(ERROR_CODE_3_MSG + ex.getMessage());
//			throw new WorkOrderException(ex.getMessage(), errorInfo,ex.getCause());
		}  
     	if(woMbo==null){
     		MMISWebServiceExceptionE mmisWebServiceExceptionE = new MMISWebServiceExceptionE();
     		MMISWebServiceException mmisWebServiceException = new MMISWebServiceException();
     		mmisWebServiceException.setErrorCode(ERROR_CODE_1);
     		mmisWebServiceException.setErrorMessage(ERROR_CODE_1_MSG);
     		mmisWebServiceExceptionE.setMMISWebServiceException(mmisWebServiceException);
     		WorkOrderException workOrderException = new WorkOrderException();
     		workOrderException.setFaultMessage(mmisWebServiceExceptionE);
     		throw workOrderException;
     	}
     	if(woMbo!=null){
     		SimpleDateFormat datestrT=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX");//2023-02-01T00:00:00.000Z
//     		SimpleDateFormat HHmm = new SimpleDateFormat("HH:mm");
     		try {
 	//    		<action/>
 		    	workOrderVO.setAction("");//No use
 		    	
// 		    	Calendar calendar = Calendar.getInstance();  
 		    	
 	// 	    	<actualCmplDate>2015-06-17T00:00:00.000+08:00</actualCmplDate>
 		    	if(woMbo.getDate("actfinish")!=null){
 		    		Calendar calendarActfinish = Calendar.getInstance();  
 		    		calendarActfinish.setTime(datestrT.parse(datestrT.format(woMbo.getDate("actfinish"))));
 			    	workOrderVO.setActualCmplDate(calendarActfinish);
 	            }else{
 	            	workOrderVO.setActualCmplDate(null);
 	            }
 		    	
 	//	    	<actualStartDate>2015-06-17T00:00:00.000+08:00</actualStartDate> 
 		    	if(woMbo.getDate("actstart")!=null){
 		    		Calendar calendarActstart = Calendar.getInstance();  
 		    		calendarActstart.setTime(datestrT.parse(datestrT.format(woMbo.getDate("actstart"))));
 		    		workOrderVO.setActualStartDate(calendarActstart);
 	//		    	<actualStartTime>00:00</actualStartTime>
// 					Date date1 = datestrT.parse(datestrT.format(woMbo.getDate("actstart")));
// 					String sdate=HHmm.format(date1);
// 					workOrderVO.setActualStartTime(sdate);
 					workOrderVO.setActualStartTime(datestrT.format(woMbo.getDate("actstart")).substring(11, 16));
 		    	}else{
 		    		workOrderVO.setActualStartDate(null);
 		    		workOrderVO.setActualStartTime("00:00");
 		    	}
 		    	
 	
 				
 		//		<cmpltmnryContractNo/>
 				workOrderVO.setCmpltmnryContractNo(woMbo.getString("mtr_cmpltmnry_contract_no"));
 				
 		//		<contractDesp>M1010-09E MTCE SERVICES FOR AFC OF AT&amp;D, TKL &amp; WRL AND LRL(TESTING)</contractDesp>
 				workOrderVO.setContractDesp(woMbo.getString("mtr_warrcontract.description"));
 				
 	//			<contractNo>1024221</contractNo>
 				workOrderVO.setContractNo(woMbo.getString("contract"));
 				
 		//		<contractor>CONTRACTOR1</contractor>
 				workOrderVO.setContractor(woMbo.getString("mtr_warrcontract.vendor"));
 				
 		//		 <contractorInCharge> 
 		//         <ouCd/>
 		//         <ouId/>
 		//         <ouName/>
 		//         <parentOrgnizationCodeName/>
 		//         <parentOrgnizationUnitName/>
 		//         <parentOuId/>
 		//      </contractorInCharge>
 				OrganizationUnit organizationUnit = new OrganizationUnit();
 				organizationUnit.setOuCd(woMbo.getString("vendor"));
 				organizationUnit.setOuId(woMbo.getString("mtr_companies.companiesid"));
 				organizationUnit.setOuName(woMbo.getString("mtr_companies.name"));
 				organizationUnit.setParentOrgnizationCodeName(woMbo.getString("mtr_companies.companychildren.name"));
 				organizationUnit.setParentOrgnizationUnitName(woMbo.getString("mtr_companies.companychildren.name"));
 				organizationUnit.setParentOuId(woMbo.getString("mtr_companies.parentcompany"));
 				workOrderVO.setContractorInCharge(organizationUnit);
 				
 		//		<detailIDs/>
 				workOrderVO.setDetailIDs("");//No use
 				
 		//        <detailLoc/
 				workOrderVO.setDetailLoc("");//No use
 				
 		//		<engineerInCharge>
 		//        <hrName/>
 		//        <hrNo/>
 		//        <hrUserId/>
 		//     </engineerInCharge>
 				HumanResource hHumanResource = new HumanResource();
 				hHumanResource.setHrName(woMbo.getString("mtr_engineer_incharged.displayname"));
 				hHumanResource.setHrNo(woMbo.getString("mtr_engineer_incharged"));
 				hHumanResource.setHrUserId(woMbo.getString("mtr_engineer_incharged"));
 				workOrderVO.setEngineerInCharge(hHumanResource);
 				
 		//        <equipClass>
 		//        <equipClassCd>AFC-AVM</equipClassCd>
 		//        <equipClassDesp>ADD VALUE MACHINE</equipClassDesp>
 		//        <equipClassId>10016038</equipClassId>
 		//     		</equipClass>
 				EquipClass equipClass = new EquipClass();
 				equipClass.setEquipClassCd(woMbo.getString("classstructure.hierarchypath"));
 				equipClass.setEquipClassDesp(woMbo.getString("classstructure.classification.description"));
 				equipClass.setEquipClassId(woMbo.getLong("classstructure.classification.classificationuid"));
 				workOrderVO.setEquipClass(equipClass);
 				
 		//		<equipDownTime>0 00:00:00</equipDownTime>
 	//			= ENGINEER_FINISHWORK_DATETIME - SHUTDOWN_DATETIME 
 	//			ENGINEER_FINISHWORK_DATETIME ：ACTFINISH
 	//			SHUTDOWN_DATETIME ：MTR_ASSETSHUTDOWN
 	
 	//			MboSetRemote assetStatusStartSet = woMbo.getMboSet("$ASSETSTATUSStart","ASSETSTATUS",
 	//         		   "wonum=:wonum and assetnum=:assetnum and siteid=:siteid");
 	//			assetStatusStartSet.reset();
 	//			if(!assetStatusStartSet.isEmpty()){
 	//				workOrderVO.setEquipDownTime(MXFormat.doubleToDuration(assetStatusStartSet.sum("downtime")));
 	//			}else{
 	//				workOrderVO.setEquipDownTime("0 00:00:00");
 	//			}
 				
 				if(woMbo.getDate("actfinish")!=null && woMbo.getDate("mtr_assetshutdown")!=null){
 					workOrderVO.setEquipDownTime(getDistanceDateTime(woMbo.getDate("mtr_assetshutdown"),woMbo.getDate("actfinish")));
 				}else{
 					workOrderVO.setEquipDownTime("0 00:00:00");
 				}
 				
 				
 				
 		//		 <equipment>
 		//         <equipDesp>IA: AVM Cash only (Type C)</equipDesp>
 		//         <equipId>13921036</equipId>
 		//         <equipNo>080-AFC-AVM-ERGAVM1</equipNo>
 		//      </equipment>
 				
 				Equipment equipment = new Equipment();
 				equipment.setEquipDesp(woMbo.getString("asset.description"));
 				equipment.setEquipId(woMbo.getLong("asset.assetid"));
 				equipment.setEquipNo(woMbo.getString("assetnum"));
 				workOrderVO.setEquipment(equipment);
 				
 		//		<finalizedInd>N</finalizedInd>
 				workOrderVO.setFinalizedInd(woMbo.getString("mtr_finalized_ind"));
 		//        <gcFinanceRefNoCd/>
 				workOrderVO.setGcFinanceRefNoCd(woMbo.getString("mtr_gc_finance_ref_no_cd"));
 		//        <gcPriorityCd>10</gcPriorityCd>
 				workOrderVO.setGcPriorityCd(woMbo.getString("wopriority"));
 		//        <gcProjectNoCd/>
 				workOrderVO.setGcProjectNoCd(woMbo.getString("mtr_gc_project_no_cd"));
 		//        <gcProjectTaskNoCd/>
 				workOrderVO.setGcProjectTaskNoCd(woMbo.getString("mtr_gc_project_task_no_cd"));
 		//        <gcSvcBreakdownCd/>
 				workOrderVO.setGcSvcBreakdownCd(woMbo.getString("mtr_gc_svc_breakdown_cd"));
 		//		<gcWorkNatureLv1Cd>PM</gcWorkNatureLv1Cd>
 				workOrderVO.setGcWorkNatureLv1Cd(woMbo.getString("mtr_gc_work_nature_lv1_cd"));
 		//        <gcWorkNatureLv2Cd>IX</gcWorkNatureLv2Cd>
 				workOrderVO.setGcWorkNatureLv2Cd(woMbo.getString("mtr_gc_work_nature_lv2_cd"));
 				
 		//        <incidentNumber/>
 	//			 <incidentVO>
 	//             <incident>
 	//                <incidentDesp/>
 	//                <incidentId/>
 	//             </incident>
 	//          </incidentVO>
 				if("INCIDENT".equals(woMbo.getString("origrecordclass"))){
 	//				workOrderVO.setIncidentNumber(woMbo.getString("origrecordid"));
 					workOrderVO.setIncidentNumber(woMbo.getString("origticket.ticketuid"));
 				}else{
 					workOrderVO.setIncidentNumber("");
 				}
 				MboSetRemote relatedrecordMboSet = woMbo.getMboSet("$RELATEDRECORD","RELATEDRECORD",
 		         		   "recordkey=:wonum and class=:woclass and siteid=:siteid and relatedrecclass in (select value from synonymdomain where domainid ='TKCLASS' and maxvalue in ('INCIDENT'))");
 				relatedrecordMboSet.reset();
 				if(!relatedrecordMboSet.isEmpty()){
 					IncidentVO incidentVO = new IncidentVO();
 					Incident incident = new Incident();
 	//				incident.setIncidentDesp(relatedrecordMboSet.getMbo(0).getString("relatedrectkt.description"));
 					incident.setIncidentDesp(relatedrecordMboSet.getMbo(0).getString("relatedrectkt.description"));
 					incident.setIncidentId(relatedrecordMboSet.getMbo(0).getString("relatedreckey"));
 					incidentVO.setIncident(incident);
 					workOrderVO.setIncidentVO(incidentVO);
 				}
 				
 	//			 <labourCostCredit/>
 				MboSetRemote labtransMboSetCredit = woMbo.getMboSet("$LABTRANSCredit","LABTRANS",
 						"refwo in (select wonum from workorder where (wonum=:wonum or (parent=:wonum and istask = :yes)) and siteid=:siteid ) and glcreditacct is not null");
 				labtransMboSetCredit.reset();
 				if(!labtransMboSetCredit.isEmpty()){
 					workOrderVO.setLabourCostCredit(labtransMboSetCredit.getMbo(0).getString("glcreditacct"));
 				}else{
 					workOrderVO.setLabourCostCredit("");
 				}
 	//	            <labourCostDebit>001.24.01.72813.00000.0000000</labourCostDebit>
 				MboSetRemote labtransMboSetDebit = woMbo.getMboSet("$LABTRANSDebit","LABTRANS",
 						"refwo in (select wonum from workorder where (wonum=:wonum or (parent=:wonum and istask = :yes)) and siteid=:siteid ) and gldebitacct is not null");
 				labtransMboSetDebit.reset();
 				if(!labtransMboSetDebit.isEmpty()){
 					workOrderVO.setLabourCostDebit(labtransMboSetDebit.getMbo(0).getString("gldebitacct"));
 				}else{
 					workOrderVO.setLabourCostDebit("");
 				}
 	//	            <locale/>
 				workOrderVO.setLocale("");//No use
 				
 				
 	
 				MboSetRemote recoverySetCredit = woMbo.getMboSet("MTR_RECOVERY");
 				recoverySetCredit.setOrderBy("mtr_recoveryid desc");
 				if(!recoverySetCredit.isEmpty()){
 	//	            <maintainerFinishWork>2015-06-17T00:00:00.000+08:00</maintainerFinishWork>
 					if(recoverySetCredit.getMbo(0).getDate("mtr_engineer_finishwork_datetime")!=null){
 						Calendar calendarMtr_engineer_finishwork_datetime = Calendar.getInstance();
 						calendarMtr_engineer_finishwork_datetime.setTime(datestrT.parse(datestrT.format(recoverySetCredit.getMbo(0).getDate("mtr_engineer_finishwork_datetime"))));
 				    	workOrderVO.setMaintainerFinishWork(calendarMtr_engineer_finishwork_datetime);
 		            }
 	//	            <maintainerStartWork>2015-06-17T00:00:00.000+08:00</maintainerStartWork>
 					if(recoverySetCredit.getMbo(0).getDate("mtr_engineer_startwork_datetime")!=null){
 						Calendar calendarMtr_engineer_startwork_datetime = Calendar.getInstance();
 						calendarMtr_engineer_startwork_datetime.setTime(datestrT.parse(datestrT.format(recoverySetCredit.getMbo(0).getDate("mtr_engineer_startwork_datetime"))));
 				    	workOrderVO.setMaintainerStartWork(calendarMtr_engineer_startwork_datetime);
 		            }
 				}
 				
 	//	            <materialCostCredit/>
 				MboSetRemote matusetransMboSetCredit = woMbo.getMboSet("$MATUSETRANSCredit","MATUSETRANS",
 						"refwo in (select wonum from workorder where (wonum=:wonum or (parent=:wonum and istask = :yes)) and siteid=:siteid ) and glcreditacct is not null");
 				matusetransMboSetCredit.reset();
 				if(!matusetransMboSetCredit.isEmpty()){
 					workOrderVO.setMaterialCostCredit(matusetransMboSetCredit.getMbo(0).getString("glcreditacct"));
 				}else{
 					workOrderVO.setMaterialCostCredit("");
 				}
 				
 	//            <materialCostDebit>001.24.01.72813.00000.0000000</materialCostDebit>
 				workOrderVO.setMaterialCostDebit("");
 				MboSetRemote matusetransMboSetDebit = woMbo.getMboSet("$MATUSETRANSDebit","MATUSETRANS",
 						"refwo in (select wonum from workorder where (wonum=:wonum or (parent=:wonum and istask = :yes)) and siteid=:siteid ) and gldebitacct is not null");
 				matusetransMboSetDebit.reset();
 				if(!matusetransMboSetDebit.isEmpty()){
 					workOrderVO.setMaterialCostCredit(matusetransMboSetDebit.getMbo(0).getString("gldebitacct"));
 				}else{
 					workOrderVO.setMaterialCostCredit("");
 				}
 				
 	//	            <oldWoNo/>
 		            workOrderVO.setOldWoNo("");//No use
 			
 	//	            <oneOfRelatedMeasurementId/>//CBM RESULT - select RESULT_ID from CBM_WO_RESULT_ASSOC where WO_NO = :woNo
 		            MboSetRemote cbmWoResultAssocMboSet = woMbo.getMboSet("$CBM_WO_RESULT_ASSOC", "CBM_WO_RESULT_ASSOC", 
 		            		"wo_no=:wonum and siteid=:siteid");
 		            cbmWoResultAssocMboSet.reset();
 		            if(!cbmWoResultAssocMboSet.isEmpty()){
 		            	workOrderVO.setOneOfRelatedMeasurementId(cbmWoResultAssocMboSet.getMbo(0).getString("result_id"));
 		            }else{
 		            	workOrderVO.setOneOfRelatedMeasurementId("");
 		            }
 		            
 	//	            <openDate>2015-07-06T03:27:08.998+08:00</openDate>
 		            MboSetRemote wostatusMboSet = woMbo.getMboSet("$WOSTATUS", "WOSTATUS", "wonum = :wonum and siteid=:siteid and status='OPEN'");
 		            wostatusMboSet.setOrderBy("changedate desc");
 		            wostatusMboSet.reset();
 		            if(!wostatusMboSet.isEmpty()){
 		            	Calendar calendarChangedate = Calendar.getInstance();
 		            	calendarChangedate.setTime(datestrT.parse(datestrT.format(wostatusMboSet.getMbo(0).getDate("changedate"))));
 			    		workOrderVO.setOpenDate(calendarChangedate);
 		            }else{
 		            	workOrderVO.setOpenDate(null);
 		            }
 		            
 	//	            <otherCostCredit/>
 		            MboSetRemote servrectransCreditMboSet = woMbo.getMboSet("$SHOWACTUALSERVICE","SERVRECTRANS",
 							"refwo in (select wonum from workorder where (wonum=:wonum or (parent=:wonum and istask = :yes)) and siteid=:siteid ) and plustrepord = :no and glcreditacct is not null");
 		            servrectransCreditMboSet.reset();
 		            if(!servrectransCreditMboSet.isEmpty()){
 		            	workOrderVO.setOtherCostCredit(servrectransCreditMboSet.getMbo(0).getString("glcreditacct"));
 		            }else{
 		            	workOrderVO.setOtherCostCredit("");
 		            }
 		            
 	//	            <otherCostDebit>001.24.01.72813.00000.0000000</otherCostDebit>
 		            MboSetRemote servrectransDebitMboSet = woMbo.getMboSet("$SHOWACTUALSERVICE","SERVRECTRANS",
 							"refwo in (select wonum from workorder where (wonum=:wonum or (parent=:wonum and istask = :yes)) and siteid=:siteid ) and plustrepord = :no and gldebitacct is not null");
 		            servrectransDebitMboSet.reset();
 		            if(!servrectransDebitMboSet.isEmpty()){
 		            	workOrderVO.setOtherCostDebit(servrectransDebitMboSet.getMbo(0).getString("gldebitacct"));
 		            }else{
 		            	workOrderVO.setOtherCostDebit("");
 		            }
 			
 	//	            <parentWoRelationship>
 	//	               <assocWoNo/>
 	//	               <gcRelationshipTypeCd/>
 	//	            </parentWoRelationship>   
 		            
 		            
 		            MboSetRemote relatedWoSet = woMbo.getMboSet("RELATEDWO");
 		            if(!relatedWoSet.isEmpty()){
 			            WoRelationship woRelationship = new WoRelationship();
 			            woRelationship.setAssocWoNo(relatedWoSet.getMbo(0).getString("relatedrecwonum"));
 			            woRelationship.setGcRelationshipTypeCd(relatedWoSet.getMbo(0).getString("relatetype"));
 			            workOrderVO.setParentWoRelationship(woRelationship);  
 		            }
 		            
 	//	            <personInCharge>
 	//	               <hrName/>
 	//	               <hrNo/>
 	//	               <hrUserId/>
 	//	            </personInCharge>
 		            HumanResource humanResource = new HumanResource();
 		            humanResource.setHrName(woMbo.getString("ownerperson.displayname"));
 		            humanResource.setHrNo(woMbo.getString("owner"));
 		            humanResource.setHrUserId(woMbo.getString("owner"));
 		            workOrderVO.setPersonInCharge(humanResource);
 		            
 	//	            <personInChargeUserId/>
 		            workOrderVO.setPersonInChargeUserId(woMbo.getString("owner"));
 	//	            <personInchrgCd/>
 		            workOrderVO.setPersonInchrgCd(woMbo.getString("owner"));
 		            
 		            if(woMbo.getDate("targcompdate")!=null){
 	//		            <planCmplDate>2015-06-02T00:00:00.000+08:00</planCmplDate>
 		            	Calendar calendarTargcompdate = Calendar.getInstance();
 		            	calendarTargcompdate.setTime(datestrT.parse(datestrT.format(woMbo.getDate("targcompdate"))));
 				    	workOrderVO.setPlanCmplDate(calendarTargcompdate);
 	//		            <plannedCmplTime>00:00</plannedCmplTime>
// 						String plannedCmplTime=HHmm.format(woMbo.getDate("targcompdate"));
 						workOrderVO.setPlannedCmplTime(datestrT.format(woMbo.getDate("targcompdate")).substring(11, 16));
 		            }else{
 		            	workOrderVO.setPlanCmplDate(null);
 		            	workOrderVO.setPlannedCmplTime("00:00");
 		            }
 		            
 		            if(woMbo.getDate("targstartdate")!=null){
 	//	            <planStartDate>2015-05-31T00:00:00.000+08:00</planStartDate>
 		            	Calendar calendarTargstartdate = Calendar.getInstance();
 		            	calendarTargstartdate.setTime(datestrT.parse(datestrT.format(woMbo.getDate("targstartdate"))));
 		            	workOrderVO.setPlanStartDate(calendarTargstartdate);
 	//		            <plannedStartTime>00:00</plannedStartTime>
// 						String plannedStartTime=HHmm.format(woMbo.getDate("targstartdate"));
 						workOrderVO.setPlannedCmplTime(datestrT.format(woMbo.getDate("targstartdate")).substring(11, 16));
 		            }else{
 		            	workOrderVO.setPlanStartDate(null);
 		            	workOrderVO.setPlannedCmplTime("00:00");
 		            }
 	
 	//	            <primaryRecoveryTime>0 00:00:00</primaryRecoveryTime>
 					workOrderVO.setPrimaryRecoveryTime(woMbo.getString("mtr_tempservrecv"));
 					
 	//				 <quantity>0</quantity>
 					workOrderVO.setQuantity(woMbo.getLong("MTR_QUANTITY"));
 					
 	//		            <relatedWoList/>
 					MboSetRemote relatedWoSets = woMbo.getMboSet("RELATEDWO");
 					if(!relatedWoSets.isEmpty()){
 						WoRelationship [] woRelationshipArray = new WoRelationship[relatedWoSets.count()];
 						for(int i=0;i<relatedWoSets.count();i++){
 							woRelationshipArray[i] = new WoRelationship();
 							woRelationshipArray[i].setAssocWoNo(relatedWoSet.getMbo(i).getString("relatedrecwonum"));
 							woRelationshipArray[i].setGcRelationshipTypeCd(relatedWoSet.getMbo(i).getString("relatetype"));
 						}
 						workOrderVO.setRelatedWoList(woRelationshipArray);
 					}
 					
 	//		            <remark/>
 					workOrderVO.setRemark(woMbo.getString("remarkdesc").replace("<!-- RICH TEXT -->", ""));
 					MboSetRemote mtrFailureDetailsMboSet = woMbo.getMboSet("$MTR_FAILUREDETAILS","MTR_FAILUREDETAILS",
 							"wonum=:wonum and siteid=:siteid");
 					mtrFailureDetailsMboSet.reset();
 					if(!mtrFailureDetailsMboSet.isEmpty()){
 	//		            <reservedField1/>
 						workOrderVO.setReservedField1(mtrFailureDetailsMboSet.getMbo(0).getString("mtr_reserved_field1"));//To be discussed
 		//		            <reservedField2/>
 						workOrderVO.setReservedField2(mtrFailureDetailsMboSet.getMbo(0).getString("mtr_reserved_field2"));//To be discussed
 		//		            <reservedField3/>
 						workOrderVO.setReservedField3(mtrFailureDetailsMboSet.getMbo(0).getString("mtr_reserved_field3"));//To be discussed
 					}
 	//		            <serviceDownTime>0 00:00:00</serviceDownTime>
 					workOrderVO.setServiceDownTime(woMbo.getString("mtr_assetshutdown"));
 	//		            <serviceNotRequireTime>0 00:00:00</serviceNotRequireTime>
 	//				'= equipDownTime - (EQUIPMENT opertion start time - equipment operation end time)
 					workOrderVO.setServiceNotRequireTime("0 00:00:00");//????????
 	//		            <shortLoc/>
 					workOrderVO.setShortLoc("");//????????
 	//		            <status>CM</status>
 					workOrderVO.setStatus(woMbo.getString("status"));
 	//		            <statusDesc>Completed</statusDesc>
 					workOrderVO.setStatusDesc(woMbo.getString("uxsynonymdomain.description"));
 					
 	//				<statusHis>
 	//	               <closeWr>false</closeWr>
 	//	               <cmplByCd/>
 	//	               <cmplByName/>
 	//	               <ignoreEquipStruct>false</ignoreEquipStruct>
 	//	               <ignoreSupersede>false</ignoreSupersede>
 	//	               <lastUpdUser/>
 	//	               <noCheckActLocation>true</noCheckActLocation>
 	//	               <personInChgName/>
 	//	               <reasonDesp/>
 	//	               <statusDesc/>
 	//	               <woStatusHistory>
 	//	                  <actualCmplTime/>
 	//	                  <actualStartTime/>
 	//	                  <cmplByCd/>
 	//	                  <cmplByName/>
 	//	                  <cmplPersonInChrg/>
 	//	                  <completeBy/>
 	//	                  <contactEmailList/>
 	//	                  <gcReasonCd/>
 	//	                  <lastUpdUserId>0</lastUpdUserId>
 	//	                  <personInChrgCd/>
 	//	                  <personInChrgName/>
 	//	                  <remark/>
 	//	                  <status/>
 	//	                  <statusDateTime/>
 	//	                  <supersededByWoNo/>
 	//	                  <woStatusHisId>0</woStatusHisId>
 	//	               </woStatusHistory>
 	//	            </statusHis>
 					WoStatusHistoryVO woStatusHistoryVO = new WoStatusHistoryVO();
 					woStatusHistoryVO.setCloseWr("CLOSE".equals(woMbo.getTranslator().toInternalString("WOSTATUS", woMbo.getString("status")))?true:false);
 					MboSetRemote woStatusComMboSet = woMbo.getMboSet("$wostatuscomp", "WOSTATUS", "wonum = :wonum and siteid=:siteid"
 							+ " and status in (select value from SYNONYMDOMAIN where domainid='WOSTATUS' and maxvalue='COMP')");
 					woStatusComMboSet.setOrderBy("changedate desc");
 					woStatusComMboSet.reset();
 					if(!woStatusComMboSet.isEmpty()){
 						woStatusHistoryVO.setCmplByCd(woStatusComMboSet.getMbo(0).getString("changeby"));
 						woStatusHistoryVO.setCmplByName(woStatusComMboSet.getMbo(0).getString("mtr_changeby.displayname"));
 					}
 					woStatusHistoryVO.setIgnoreEquipStruct(false);
 					woStatusHistoryVO.setIgnoreSupersede(false);
 					MboSetRemote woStatusMboSet = woMbo.getMboSet("$wostatuscomp", "WOSTATUS", "wonum = :wonum and siteid=:siteid");
 					woStatusMboSet.setOrderBy("changedate desc");
 					woStatusMboSet.reset();
 					woStatusHistoryVO.setLastUpdUser(woStatusMboSet.getMbo(0).getString("changeby"));
 					
 					woStatusHistoryVO.setNoCheckActLocation(true);
 					woStatusHistoryVO.setPersonInChgName(woStatusMboSet.getMbo(0).getString("changeby"));
 					woStatusHistoryVO.setReasonDesp(woStatusMboSet.getMbo(0).getString("memo"));
 					woStatusHistoryVO.setStatusDesc(woMbo.getString("uxsynonymdomain.description"));
 					WoStatusHistory woStatusHistory = new WoStatusHistory();
 					
 					if(woMbo.getDate("actfinish")!=null){
 						woStatusHistory.setActualCmplTime(datestrT.format(woMbo.getDate("actfinish")));
 		            }else{
 		            	woStatusHistory.setActualCmplTime("");
 		            }
 			    	
 			    	if(woMbo.getDate("actstart")!=null){
 			    		woStatusHistory.setActualStartTime(datestrT.format(woMbo.getDate("actstart")));
 			    	}else{
 			    		woStatusHistory.setActualStartTime("");
 			    	}
 			    	if(!woStatusComMboSet.isEmpty()){
 			    		woStatusHistory.setCmplByCd(woStatusComMboSet.getMbo(0).getString("changeby"));
 			    		woStatusHistory.setCmplByName(woStatusComMboSet.getMbo(0).getString("mtr_changeby.displayname"));
 			    		woStatusHistory.setCmplPersonInChrg(woStatusComMboSet.getMbo(0).getString("changeby"));
 			    		woStatusHistory.setCompleteBy(woStatusComMboSet.getMbo(0).getString("changeby"));
 			    	}
 					woStatusHistory.setContactEmailList(woStatusMboSet.getMbo(0).getString("mtr_contact_email_list"));
 					woStatusHistory.setGcReasonCd(woStatusMboSet.getMbo(0).getString("memo"));
 					woStatusHistory.setLastUpdUserId(woStatusMboSet.getMbo(0).getLong("mtr_changeby.personuid"));
 					woStatusHistory.setPersonInChrgCd(woStatusMboSet.getMbo(0).getString("changeby"));
 					woStatusHistory.setPersonInChrgName(woStatusMboSet.getMbo(0).getString("mtr_changeby.displayname"));
 					woStatusHistory.setRemark(woStatusMboSet.getMbo(0).getString("memo"));
 					woStatusHistory.setStatus(woMbo.getString("status"));
 					woStatusHistory.setStatusDateTime(datestrT.format(woStatusMboSet.getMbo(0).getDate("changedate")));
 					woStatusHistory.setSupersededByWoNo(woMbo.getString("mtr_supersede_wo"));
 					woStatusHistory.setWoStatusHisId(woStatusMboSet.getMbo(0).getUniqueIDValue());
 					woStatusHistoryVO.setWoStatusHistory(woStatusHistory);
 					workOrderVO.setStatusHis(woStatusHistoryVO);
 					
 	//				<stdJob>
 	//	               <desp>test</desp>
 	//	               <stdJobCd>TESTXX204</stdJobCd>
 	//	               <stdJobId>10204487</stdJobId>
 	//	               <stdJobParamSets>
 	//	                  <buId>0</buId>
 	//	                  <lastUpdUserId>0</lastUpdUserId>
 	//	                  <stdJobParamSetId>10203324</stdJobParamSetId>
 	//	                  <stdJobParamSetName>DEFAULT</stdJobParamSetName>
 	//	               </stdJobParamSets>
 	//	            </stdJob>
 					StandardJob standardJob = new StandardJob();
 					standardJob.setDesp(woMbo.getString("wo_rev_jobplan.description"));
 					standardJob.setStdJobCd(woMbo.getString("jpnum"));
 					standardJob.setStdJobId(woMbo.getLong("wo_rev_jobplan.jobplanid"));
 					MboSetRemote jobplanMboSet = woMbo.getMboSet("WO_REV_JOBPLAN");
 					if(!jobplanMboSet.isEmpty()){
 						MboRemote jobplanMbo = jobplanMboSet.getMbo(0);
 						MboSetRemote jobtaskMboSet = jobplanMbo.getMboSet("JOBTASK");
 						if(!jobtaskMboSet.isEmpty()){
 							StdJobParamSet [] stdJobParamSetArray = new StdJobParamSet[jobtaskMboSet.count()];  
 							for(int i=0;i<jobtaskMboSet.count();i++){
 								stdJobParamSetArray[i] = new StdJobParamSet();
 								stdJobParamSetArray[i].setBuId(jobtaskMboSet.getMbo(i).getLong("jobtaskownergroup.persongroupid"));
 								stdJobParamSetArray[i].setLastUpdUserId(woMbo.getLong("wo_rev_jobplan.mtr_pluscchangeby.personuid"));
 								stdJobParamSetArray[i].setStdJobParamSetId(jobtaskMboSet.getMbo(i).getUniqueIDValue());
 								stdJobParamSetArray[i].setStdJobParamSetName(jobtaskMboSet.getMbo(i).getString("description"));		
 							}
 							standardJob.setStdJobParamSets(stdJobParamSetArray);	
 						}
 					}
 					workOrderVO.setStdJob(standardJob);
 					
 	//				 <stdJobParamListId>10203324</stdJobParamListId>
 					workOrderVO.setStdJobParamListId(woMbo.getLong("wo_rev_jobplan.jobplanid"));
 	//		            <stdJobParamSetName/>
 					workOrderVO.setStdJobParamSetName(woMbo.getString("wo_rev_jobplan.description"));
 					
 					MboSetRemote labtransMboSet = woMbo.getMboSet("$SHOWACTUALLABOR","LABTRANS",
 							"refwo in (select wonum from workorder where (wonum=:wonum or (parent=:wonum and istask = :yes)) and siteid=:siteid )");
 					labtransMboSet.reset();
 	//		        <totalActualHour>0.0</totalActualHour>
 					workOrderVO.setTotalActualHour(labtransMboSet.sum("regularhrs"));
 	//		        <totalActualLabourCost>0.0</totalActualLabourCost>
 					workOrderVO.setTotalActualLabourCost(labtransMboSet.sum("linecost"));
 	
 					MboSetRemote matusetransMboSet = woMbo.getMboSet("$SHOWACTUALMATERIAL","MATUSETRANS",
 							"refwo in (select wonum from workorder where (wonum=:wonum or (parent=:wonum and istask = :yes)) and siteid=:siteid )");
 					matusetransMboSet.reset();
 	//		            <totalActualMaterialCost>0.0</totalActualMaterialCost>
 					workOrderVO.setTotalActualMaterialCost(matusetransMboSet.sum("linecost"));
 					
 	//	            <totalActualOtherCost>0.0</totalActualOtherCost>//WPSERVICE+WPTOOL
 					double totalActualOtherCost = 0.0D;
 					MboSetRemote servrectransMboSet = woMbo.getMboSet("$SHOWACTUALSERVICE","SERVRECTRANS",
 							"refwo in (select wonum from workorder where (wonum=:wonum or (parent=:wonum and istask = :yes)) and siteid=:siteid ) and plustrepord = :no");
 					servrectransMboSet.reset();
 					totalActualOtherCost +=servrectransMboSet.sum("loadedcost");
 					MboSetRemote tooltransMboSet = woMbo.getMboSet("$SHOWACTUALTOOL","TOOLTRANS",
 							"refwo in (select wonum from workorder where (wonum=:wonum or (parent=:wonum and istask = :yes)) and siteid=:siteid )");
 					tooltransMboSet.reset();
 					totalActualOtherCost +=tooltransMboSet.sum("linecost");
 					workOrderVO.setTotalActualOtherCost(totalActualOtherCost);
 					
 	//		            <totalActualQuantity>0.0</totalActualQuantity>
 					workOrderVO.setTotalActualQuantity(matusetransMboSet.sum("quantity"));
 					
 					MboSetRemote wplaborMboSet = woMbo.getMboSet("$SHOWPLANLABOR","WPLABOR",
 							"wonum in (select wonum from workorder where (wonum=:wonum or (parent=:wonum and istask = :yes)) and siteid=:siteid )");
 					wplaborMboSet.reset();
 	//		            <totalPlanHour>0.0</totalPlanHour>
 					workOrderVO.setTotalPlanHour(wplaborMboSet.sum("laborhrs"));
 	//		            <totalPlanLabourCost>0.0</totalPlanLabourCost>
 					double totalPlanLabourCost=0.0D;
 					for(int j=0;j<wplaborMboSet.count();j++){
 						totalPlanLabourCost += wplaborMboSet.getMbo(j).getDouble("linecost");
 	        	    }
 					workOrderVO.setTotalPlanLabourCost(totalPlanLabourCost);
 					
 					MboSetRemote wpmaterialMboSet = woMbo.getMboSet("$SHOWPLANMATERIAL","WPMATERIAL",
 							"wonum in (select wonum from workorder where (wonum=:wonum or (parent=:wonum and istask = :yes)) and siteid=:siteid )");
 					wpmaterialMboSet.reset();
 	//		            <totalPlanMaterialCost>0.0</totalPlanMaterialCost>
 					workOrderVO.setTotalPlanMaterialCost(wpmaterialMboSet.sum("linecost"));//UNITCOST
 	//		            <totalPlanQuantity>0.0</totalPlanQuantity>
 					workOrderVO.setTotalPlanQuantity(wpmaterialMboSet.sum("itemqty"));
 					
 	//	            <totalPlanOtherCost>0.0</totalPlanOtherCost>//WPSERVICE+WPTOOL
 					double totalPlanOtherCost = 0.0D;
 					MboSetRemote wpserviceMboSet = woMbo.getMboSet("$SHOWPLANSERVICE","WPSERVICE",
 							"wonum in (select wonum from workorder where (wonum=:wonum or (parent=:wonum and istask = :yes)) and siteid=:siteid )");
 					wpserviceMboSet.reset();
 					totalPlanOtherCost += wpserviceMboSet.sum("linecost");
 					
 					MboSetRemote wpToolMboSet = woMbo.getMboSet("$SHOWPLANTOOL","WPTOOL",
 							"wonum in (select wonum from workorder where (wonum=:wonum or (parent=:wonum and istask = :yes)) and siteid=:siteid )");
 					wpToolMboSet.reset();
 					totalPlanOtherCost += wpToolMboSet.sum("linecost");
 					workOrderVO.setTotalPlanOtherCost(totalPlanOtherCost);
 					
 	
 					
 	//		            <woActLabourCostVOs/>//No use
 					if(!labtransMboSet.isEmpty()){
 						WoActBolVO[] woActBolVOArray = new WoActBolVO[labtransMboSet.count()];
 						MboRemote labtransMbo = null;
 						for(int i=0;i<labtransMboSet.count();i++){
 							labtransMbo = labtransMboSet.getMbo(i);
 							woActBolVOArray[i] = new WoActBolVO();
 			//				woActBolVOArray[i].setLaborCostResourceTypes(param);
 							woActBolVOArray[i].setLabourType(labtransMbo.getString("transtype"));
 							woActBolVOArray[i].setResourceDesp(labtransMbo.getString("craft"));
 							woActBolVOArray[i].setResourceTypeDesp(labtransMbo.getString("craft.description"));
 							
 							ActualBillOfLabour actualBillOfLabour = new ActualBillOfLabour();
 							actualBillOfLabour.setAmount(labtransMbo.getDouble("linecost"));
 							actualBillOfLabour.setCalculatedInd("");
 							actualBillOfLabour.setChargingWkGrpId(labtransMbo.getString("laborcode"));
 							actualBillOfLabour.setCreditAccount(labtransMbo.getString("glcreditacct"));
 							actualBillOfLabour.setDebitAccount(labtransMbo.getString("gldebitacct"));
 							actualBillOfLabour.setGcHrsTypeCd(labtransMbo.getString("transtype"));
 							actualBillOfLabour.setGcReferenceTypeCd("");
 							actualBillOfLabour.setGcResourceTypeCd(labtransMbo.getString("craft"));
 							actualBillOfLabour.setGcWorkNatureLv1Cd("");
 							actualBillOfLabour.setGcWorkNatureLv2Cd("");
 							actualBillOfLabour.setHrUserId("");
 							actualBillOfLabour.setLabourMinutes(labtransMbo.getDouble("regularhrs"));
 							actualBillOfLabour.setReferenceNo("");
 							actualBillOfLabour.setRemarks1(labtransMbo.getString("memo"));
 							actualBillOfLabour.setRemarks2(labtransMbo.getString("memo_longdescription").replace("<!-- RICH TEXT -->", ""));
 							actualBillOfLabour.setRemarks3(labtransMbo.getString("mtr_remarks3"));
 							actualBillOfLabour.setStatus("");
 							if(labtransMbo.getDate("transdate")!=null){
 								Calendar calendarTransdate = Calendar.getInstance();
 								calendarTransdate.setTime(datestrT.parse(datestrT.format(labtransMbo.getDate("transdate"))));
 								actualBillOfLabour.setTxnDate(calendarTransdate);
 							}else{
 								actualBillOfLabour.setTxnDate(null);
 							}
 							actualBillOfLabour.setWoActualBolId(0);
 							
 							woActBolVOArray[i].setWoLabourCost(actualBillOfLabour);
 						}
 						workOrderVO.setWoActLabourCostVOs(woActBolVOArray);
 					}else{
 						workOrderVO.setWoActLabourCostVOs(null);
 					}
 					
 	//				 <woActLocationVOs>
 	//	               <gcDirectionCd/>
 	//	               <gcDirectionDesp/>
 	//	               <kmFrom>0.0</kmFrom>
 	//	               <kmTo>0.0</kmTo>
 	//	               <lineCd/>
 	//	               <lineId>10000129</lineId>
 	//	               <locationFromCd>S080AFF</locationFromCd>
 	//	               <locationFromId>10023014</locationFromId>
 	//	               <locationToCd/>
 	//	               <locationToId>0</locationToId>
 	//	               <locationType/>
 	//	               <refLocFromId>0</refLocFromId>
 	//	               <refLocToId>0</refLocToId>
 	//	               <rootFromLocCd/>
 	//	               <rootFromLocId>0</rootFromLocId>
 	//	               <rootToLocCd/>
 	//	               <rootToLocId>0</rootToLocId>
 	//	               <selectedFromLocId>0</selectedFromLocId>
 	//	               <selectedKmFrom>0.0</selectedKmFrom>
 	//	               <selectedKmTo>0.0</selectedKmTo>
 	//	               <selectedToLocId>0</selectedToLocId>
 	//	               <subLocationFrom/>
 	//	               <subLocationTo/>
 	//	               <supplementInfo/>
 	//	            </woActLocationVOs>
 					
 					
 					MboSetRemote multiAssetLocciMboSet = woMbo.getMboSet("$MULTIASSETLOCCI","MULTIASSETLOCCI",
 							"recordkey=:wonum and recordclass=:woclass and worksiteid=:siteid and isprimary=0 and location is not null");
 					if(!multiAssetLocciMboSet.isEmpty()){
 						LocationRangeVO[] locationRangeVOArray = new LocationRangeVO[multiAssetLocciMboSet.count()];
 						MboRemote multiAssetLocciMbo = null;
 						for(int i=0;i<multiAssetLocciMboSet.count();i++){
 							multiAssetLocciMbo = multiAssetLocciMboSet.getMbo(i);
 							locationRangeVOArray[i] = new LocationRangeVO();
 							locationRangeVOArray[i].setGcDirectionCd(multiAssetLocciMbo.getString("location.mtr_direction"));
 							locationRangeVOArray[i].setGcDirectionDesp("");
 							locationRangeVOArray[i].setKmFrom(multiAssetLocciMbo.getDouble("startmeasure"));
 							locationRangeVOArray[i].setKmTo(multiAssetLocciMbo.getDouble("endmeasure"));
 							locationRangeVOArray[i].setLineCd(multiAssetLocciMbo.getString("location.mtr_line"));
 							locationRangeVOArray[i].setLineId(multiAssetLocciMbo.getLong("location.mtr_line"));//?????? Changing the character type to a numeric type in the database
 							locationRangeVOArray[i].setLocationFromCd("");//??????
 							locationRangeVOArray[i].setLocationFromId(0);//??????
 							locationRangeVOArray[i].setLocationToCd("");//??????
 							locationRangeVOArray[i].setLocationToId(0);//??????
 							locationRangeVOArray[i].setLocationType(multiAssetLocciMbo.getString("location.type"));
 							locationRangeVOArray[i].setRefLocFromId(0);//??????
 							locationRangeVOArray[i].setRefLocToId(0);//??????
 							locationRangeVOArray[i].setRootFromLocCd("");//??????
 							locationRangeVOArray[i].setRootFromLocId(0);//??????
 							locationRangeVOArray[i].setRootToLocCd("");//??????
 							locationRangeVOArray[i].setRootToLocId(0);//??????
 							locationRangeVOArray[i].setSelectedFromLocId(0);//??????
 							locationRangeVOArray[i].setSelectedKmFrom(0);//??????
 							locationRangeVOArray[i].setSelectedKmTo(0);//??????
 							locationRangeVOArray[i].setSelectedToLocId(0);//??????
 							locationRangeVOArray[i].setSubLocationFrom("");//??????
 							locationRangeVOArray[i].setSubLocationTo(woMbo.getString("mtr_actsublocation"));
 							locationRangeVOArray[i].setSupplementInfo(woMbo.getString("mtr_actlocsuppinfo"));
 						}
 						workOrderVO.setWoActLocationVOs(locationRangeVOArray);
 					}
 					
 	//				<woActMaterialCostVOs/>//No use
 					if(!matusetransMboSet.isEmpty()){
 						WoActBomVO[] woActBomVOArray = new WoActBomVO[matusetransMboSet.count()];
 						MboRemote matusetransMbo = null;
 						for(int i=0;i<matusetransMboSet.count();i++){
 							matusetransMbo = matusetransMboSet.getMbo(i);
 							woActBomVOArray[i] = new WoActBomVO();
 							woActBomVOArray[i].setDefAmount(0);
 							woActBomVOArray[i].setStockCode(matusetransMbo.getString("itemnum"));
 							woActBomVOArray[i].setStockName(matusetransMbo.getString("item.description"));
 							woActBomVOArray[i].setUnitCost(matusetransMbo.getDouble("unitcost"));
 							woActBomVOArray[i].setUom(matusetransMbo.getString("issueunit"));
 							woActBomVOArray[i].setWorkGroupCd(matusetransMbo.getString("mtr_workgroup"));
 							ActualBillOfMaterial actualBillOfMaterial = new ActualBillOfMaterial();
 							actualBillOfMaterial.setAmount(matusetransMbo.getDouble("linecost"));
 							actualBillOfMaterial.setCalculatedInd(matusetransMbo.getString("mtr_calculated_ind"));
 							actualBillOfMaterial.setChargingWkGrpId(matusetransMbo.getString("mtr_workgroup"));
 							actualBillOfMaterial.setCreditAccount(matusetransMbo.getString("glcreditacct"));
 							actualBillOfMaterial.setDebitAccount(matusetransMbo.getString("gldebitacct"));
 							actualBillOfMaterial.setGcReferenceTypeCd(woMbo.getString("mtr_gc_reference_type_cd"));
 							actualBillOfMaterial.setQuantity(matusetransMbo.getDouble("quantity"));
 							actualBillOfMaterial.setReferenceNo(matusetransMbo.getString("mtr_reference_no"));
 							actualBillOfMaterial.setRemarks1(matusetransMbo.getString("memo"));
 							actualBillOfMaterial.setRemarks2(matusetransMbo.getString("mtr_remarks2"));
 							actualBillOfMaterial.setRemarks3(matusetransMbo.getString("mtr_remarks3"));
 							actualBillOfMaterial.setStatus(matusetransMbo.getString("mtr_status"));
 							actualBillOfMaterial.setStockId(matusetransMbo.getLong("item.itemid"));
 							if(matusetransMbo.getDate("actualdate")!=null){
 								Calendar calendarActualdate = Calendar.getInstance();
 								calendarActualdate.setTime(datestrT.parse(datestrT.format(matusetransMbo.getDate("actualdate"))));
 								actualBillOfMaterial.setTxnDate(calendarActualdate);
 							}else{
 								actualBillOfMaterial.setTxnDate(null);
 							}
 							actualBillOfMaterial.setWoActualBomId(matusetransMbo.getLong("mtr_woactualbolid"));
 							woActBomVOArray[i].setWoMaterialCost(actualBillOfMaterial);
 						}
 						workOrderVO.setWoActMaterialCostVOs(woActBomVOArray);
 					}
 					
 	//	            <woActOtherCostVOs/>//No use
 					if(!servrectransMboSet.isEmpty()){
 						WoActBooVO[] woActOtherCostVOsArray = new WoActBooVO[servrectransMboSet.count()];
 						MboRemote servrectransMbo = null;
 						for(int i=0;i<servrectransMboSet.count();i++){
 							servrectransMbo = servrectransMboSet.getMbo(i);
 							woActOtherCostVOsArray[i] = new WoActBooVO();
 							woActOtherCostVOsArray[i].setDefAmount(0);
 							woActOtherCostVOsArray[i].setOtherCostDesp(servrectransMbo.getString("description"));
 							woActOtherCostVOsArray[i].setWorkGroupCd(servrectransMbo.getString("mtr_workgroup")); 
 							ActualBillOfOther actualBillOfOther = new ActualBillOfOther();
 							actualBillOfOther.setAmount(0);
 							actualBillOfOther.setChargingWkGrpId(servrectransMbo.getString("mtr_workgroup")); 
 							actualBillOfOther.setCreditAccount(servrectransMbo.getString("glcreditacct"));
 							actualBillOfOther.setDebitAccount(servrectransMbo.getString("gldebitacct"));
 							actualBillOfOther.setGcOtherCostCd(servrectransMbo.getString("description"));
 							actualBillOfOther.setGcReferenceTypeCd("");
 							actualBillOfOther.setReferenceNo("");
 							actualBillOfOther.setRemarks1(servrectransMbo.getString("memo"));
 							actualBillOfOther.setRemarks2("");
 							actualBillOfOther.setRemarks3("");
 							actualBillOfOther.setStatus("");
 							if(servrectransMbo.getDate("transdate")!=null){
 								Calendar calendarTransdate = Calendar.getInstance(); 
 								calendarTransdate.setTime(datestrT.parse(datestrT.format(servrectransMbo.getDate("transdate"))));
 								actualBillOfOther.setTxnDate(calendarTransdate);
 							}else{
 								actualBillOfOther.setTxnDate(null);
 							}
 							woActOtherCostVOsArray[i].setWoOtherCost(actualBillOfOther);
 						}
 						workOrderVO.setWoActOtherCostVOs(woActOtherCostVOsArray);
 					}
 					
 					
 	//	            <woDesp>test</woDesp>
 					workOrderVO.setWoDesp(woMbo.getString("description"));
 					
 	//				<woFailureDetailVOs>
 	//	               <isRoot>false</isRoot>
 	//	            </woFailureDetailVOs>	
 					if(!mtrFailureDetailsMboSet.isEmpty()){
 						WoFailureDetailVO[] woFailureDetailVOArray = new WoFailureDetailVO[mtrFailureDetailsMboSet.count()];
 						for(int i=0;i<multiAssetLocciMboSet.count();i++){
 							woFailureDetailVOArray[i]= new WoFailureDetailVO();
 							woFailureDetailVOArray[i].setIsRoot(mtrFailureDetailsMboSet.getMbo(i).getBoolean("mtr_root_component_ind"));
 						}
 						workOrderVO.setWoFailureDetailVOs(woFailureDetailVOArray);
 					}
 					
 	//				<woFailureInfoVO>
 	//	               <consequenceDesp/>
 	//	               <impactDesp/>
 	//	               <reportTime/>
 	//	               <shutDownTime/>
 	//	               <symptomDesp/>
 	//	               <woFailureInfo>
 	//	                  <gcConsequenceCd/>
 	//	                  <gcImpactCd/>
 	//	                  <gcSymptomCd/>
 	//	                  <impactDesp/>
 	//	                  <incidentId/>
 	//	                  <reportUserName/>
 	//	                  <woNo>3110834218</woNo>
 	//	               </woFailureInfo>
 	//	            </woFailureInfoVO>
 					WoFailureInfoVO woFailureInfoVO = new WoFailureInfoVO();
 					WoFailureInfo woFailureInfo = new WoFailureInfo();
 					MboSetRemote wMWoFailureInfoMboSet = woMbo.getMboSet("$MTR_FAILUREINFO","MTR_FAILUREINFO",
 							"wonum=:wonum and siteid=:siteid");
 					wMWoFailureInfoMboSet.reset();
 					if(!wMWoFailureInfoMboSet.isEmpty()){
 						woFailureInfoVO.setConsequenceDesp(wMWoFailureInfoMboSet.getMbo(0).getString("gc_consequence_cd"));
 						woFailureInfoVO.setImpactDesp(wMWoFailureInfoMboSet.getMbo(0).getString("impact_desp"));
 						woFailureInfo.setGcConsequenceCd(wMWoFailureInfoMboSet.getMbo(0).getString("gc_consequence_cd"));
 						woFailureInfo.setGcImpactCd(wMWoFailureInfoMboSet.getMbo(0).getString("gc_impact_cd"));
 						woFailureInfo.setImpactDesp(wMWoFailureInfoMboSet.getMbo(0).getString("impact_desp"));
 						woFailureInfo.setIncidentId(wMWoFailureInfoMboSet.getMbo(0).getString("incident_id"));
 					}
 					if(woMbo.getDate("reportdate")!=null){
 						woFailureInfoVO.setReportTime(datestrT.format(woMbo.getDate("reportdate")));
 			    	}else{
 			    		woFailureInfoVO.setReportTime("");
 			    	}
 					if(woMbo.getDate("mtr_assetshutdown")!=null){
 						woFailureInfoVO.setShutDownTime(datestrT.format(woMbo.getDate("mtr_assetshutdown")));
 			    	}else{
 			    		woFailureInfoVO.setShutDownTime("");
 			    	}
 					MboSetRemote mtrSymptomMboSet = woMbo.getMboSet("$MTR_SYMPTOM","MTR_SYMPTOM",
 							"mtr_symptom=:mtr_symptom and siteid=:siteid");
 					mtrSymptomMboSet.reset();
 					if(!mtrSymptomMboSet.isEmpty()){
 						woFailureInfoVO.setSymptomDesp(mtrSymptomMboSet.getMbo(0).getString("description"));
 					}else{
 						woFailureInfoVO.setSymptomDesp("");
 					}
 					
 					woFailureInfo.setGcSymptomCd(woMbo.getString("mtr_symptom"));
 					woFailureInfo.setReportUserName(woMbo.getString("reportedby"));
 					woFailureInfo.setWoNo(workOrderNo);
 					woFailureInfoVO.setWoFailureInfo(woFailureInfo);
 					workOrderVO.setWoFailureInfoVO(woFailureInfoVO);
 					
 	                //<woFollowupActionVOs/>//No use
 					WoFollowupActionVO[] woFollowupActionVOArray = new WoFollowupActionVO[]{};
 					workOrderVO.setWoFollowupActionVOs(woFollowupActionVOArray);
 	                //<woJobRequirementVOs/>//No use
 					WoJobRequirementVO[] woJobRequirementVOArray = new WoJobRequirementVO[]{};
 					workOrderVO.setWoJobRequirementVOs(woJobRequirementVOArray);
 	//		            <woNo>3110834218</woNo>
 					workOrderVO.setWoNo(workOrderNo);
 	//		            <woPlanLabourCostVOs/>//No use
 					WoPlanBolVO[] woPlanBolVOArray = new WoPlanBolVO[]{};
 					workOrderVO.setWoPlanLabourCostVOs(woPlanBolVOArray);
 					
 	//				<woPlanLocationVOs>
 	//	               <gcDirectionCd/>
 	//	               <gcDirectionDesp/>
 	//	               <kmFrom>0.0</kmFrom>
 	//	               <kmTo>0.0</kmTo>
 	//	               <lineCd/>
 	//	               <lineId>10000129</lineId>
 	//	               <locationFromCd>S080AFF</locationFromCd>
 	//	               <locationFromId>10023014</locationFromId>
 	//	               <locationToCd/>
 	//	               <locationToId>0</locationToId>
 	//	               <locationType/>
 	//	               <refLocFromId>0</refLocFromId>
 	//	               <refLocToId>0</refLocToId>
 	//	               <rootFromLocCd/>
 	//	               <rootFromLocId>0</rootFromLocId>
 	//	               <rootToLocCd/>
 	//	               <rootToLocId>0</rootToLocId>
 	//	               <selectedFromLocId>0</selectedFromLocId>
 	//	               <selectedKmFrom>0.0</selectedKmFrom>
 	//	               <selectedKmTo>0.0</selectedKmTo>
 	//	               <selectedToLocId>0</selectedToLocId>
 	//	               <subLocationFrom/>
 	//	               <subLocationTo/>
 	//	               <supplementInfo/>
 	//	            </woPlanLocationVOs>	
 					LocationRangeVO[] woPlanLRangeVOArray = new LocationRangeVO[1];//??????
 					LocationRangeVO woPlanLRangeVO = new LocationRangeVO();
 					woPlanLRangeVO.setGcDirectionCd("");
 					woPlanLRangeVO.setGcDirectionDesp("");
 					woPlanLRangeVO.setKmFrom(0);
 					woPlanLRangeVO.setKmTo(0);
 					woPlanLRangeVO.setLineCd("");
 					woPlanLRangeVO.setLineId(0);
 					woPlanLRangeVO.setLocationFromCd("");
 					woPlanLRangeVO.setLocationFromId(0);
 					woPlanLRangeVO.setLocationToCd("");
 					woPlanLRangeVO.setLocationToId(0);
 					woPlanLRangeVO.setLocationType("");
 					woPlanLRangeVO.setRefLocFromId(0);
 					woPlanLRangeVO.setRefLocToId(0);
 					woPlanLRangeVO.setRootFromLocCd("");
 					woPlanLRangeVO.setRootFromLocId(0);
 					woPlanLRangeVO.setRootToLocCd("");
 					woPlanLRangeVO.setRootToLocId(0);
 					woPlanLRangeVO.setSelectedFromLocId(0);
 					woPlanLRangeVO.setSelectedKmFrom(0);
 					woPlanLRangeVO.setSelectedKmTo(0);
 					woPlanLRangeVO.setSelectedToLocId(0);
 					woPlanLRangeVO.setSubLocationFrom("");
 					woPlanLRangeVO.setSubLocationTo("");
 					woPlanLRangeVO.setSupplementInfo("");
 					woPlanLRangeVOArray[0] = woPlanLRangeVO;
 					workOrderVO.setWoPlanLocationVOs(woPlanLRangeVOArray);
 					
 	//				  <woPlanMaterialCostVOs/>//No use
 					WoPlanBomVO[] woPlanBomVOArray = new WoPlanBomVO[]{};
 					workOrderVO.setWoPlanMaterialCostVOs(woPlanBomVOArray);
 	//		            <woPlanOtherCostVOs/>//No use
 					WoPlanBooVO[] woPlanBooVOArray = new WoPlanBooVO[] {};
 					workOrderVO.setWoPlanOtherCostVOs(woPlanBooVOArray);
 					
 	//				  <woRecoveryVO>
 	//	               <contractorCd/>
 	//	               <contractorFinishWorkTime/>
 	//	               <contractorSiteArrivalTime/>
 	//	               <contractorStartWorkTime/>
 	//	               <engineerCd/>
 	//	               <finishWorkTime>00:00</finishWorkTime>
 	//	               <informContractorTime/>
 	//	               <siteArrivalTime/>
 	//	               <startWorkTime>00:00</startWorkTime>
 	//	               <tempSvcRecoveryTime/>
 	//	               <woRecovery>
 	//	                  <contractorIncharged/>
 	//	                  <engineerFinishworkDatetime>2015-06-17T00:00:00.000+08:00</engineerFinishworkDatetime>
 	//	                  <engineerIncharged/>
 	//	                  <engineerStartworkDatetime>2015-06-17T00:00:00.000+08:00</engineerStartworkDatetime>
 	//	                  <woNo>3110834218</woNo>
 	//	               </woRecovery>
 	//	            </woRecoveryVO>
 					
 					if(!recoverySetCredit.isEmpty()){
 	//		            <maintainerFinishWork>2015-06-17T00:00:00.000+08:00</maintainerFinishWork>
 						if(recoverySetCredit.getMbo(0).getDate("mtr_engineer_finishwork_datetime")!=null){
 							Calendar calendarMtr_engineer_finishwork_datetime = Calendar.getInstance();
 							calendarMtr_engineer_finishwork_datetime.setTime(datestrT.parse(datestrT.format(recoverySetCredit.getMbo(0).getDate("mtr_engineer_finishwork_datetime"))));
 					    	workOrderVO.setMaintainerFinishWork(calendarMtr_engineer_finishwork_datetime);
 			            }
 	//		            <maintainerStartWork>2015-06-17T00:00:00.000+08:00</maintainerStartWork>
 						if(recoverySetCredit.getMbo(0).getDate("mtr_engineer_startwork_datetime")!=null){
 							Calendar calendarMtr_engineer_startwork_datetime = Calendar.getInstance();
 							calendarMtr_engineer_startwork_datetime.setTime(datestrT.parse(datestrT.format(recoverySetCredit.getMbo(0).getDate("mtr_engineer_startwork_datetime"))));
 					    	workOrderVO.setMaintainerStartWork(calendarMtr_engineer_startwork_datetime);
 			            }
 					}
 					
 					WoRecoveryVO woRecoveryVO = new WoRecoveryVO();
 					WoRecovery woRecovery = new WoRecovery();
 					if(!recoverySetCredit.isEmpty()){
 						if(recoverySetCredit.getMbo(0).getDate("mtr_contractor_incharged")!=null){
 							woRecoveryVO.setContractorCd(datestrT.format(recoverySetCredit.getMbo(0).getDate("mtr_contractor_incharged")));
 						}else{
 							woRecoveryVO.setContractorCd("");
 						}
 						if(recoverySetCredit.getMbo(0).getDate("mtr_engineer_incharged")!=null){
 							woRecoveryVO.setEngineerCd(datestrT.format(recoverySetCredit.getMbo(0).getDate("mtr_engineer_incharged")));
 						}else{
 							woRecoveryVO.setEngineerCd("");
 						}
 						if(recoverySetCredit.getMbo(0).getDate("mtr_contractor_incharged")!=null){
 							woRecovery.setContractorIncharged(datestrT.format(recoverySetCredit.getMbo(0).getDate("mtr_contractor_incharged")));
 						}else{
 							woRecovery.setContractorIncharged("");
 						}
 						if(recoverySetCredit.getMbo(0).getDate("mtr_engineer_incharged")!=null){
 							woRecovery.setEngineerIncharged(datestrT.format(recoverySetCredit.getMbo(0).getDate("mtr_engineer_incharged")));
 						}else{
 							woRecovery.setEngineerIncharged("");
 						}
 					}else{
 						woRecoveryVO.setContractorCd("");
 						woRecoveryVO.setEngineerCd("");
 						woRecovery.setContractorIncharged("");
 						woRecovery.setEngineerIncharged("");
 					}
 					
 					if(woMbo.getDate("mtr_confinish")!=null){
 						woRecoveryVO.setContractorFinishWorkTime(datestrT.format(woMbo.getDate("mtr_confinish")));
 					}else{
 						woRecoveryVO.setContractorFinishWorkTime("");
 					}
 					if(woMbo.getDate("mtr_consitearrival")!=null){
 						woRecoveryVO.setContractorSiteArrivalTime(datestrT.format(woMbo.getDate("mtr_consitearrival")));
 					}else{
 						woRecoveryVO.setContractorSiteArrivalTime("");
 					}
 					if(woMbo.getDate("mtr_constart")!=null){
 						woRecoveryVO.setContractorStartWorkTime(datestrT.format(woMbo.getDate("mtr_constart")));
 					}else{
 						woRecoveryVO.setContractorStartWorkTime("");
 					}
 					if(woMbo.getDate("actfinish")!=null){
 						Calendar calendarActfinish = Calendar.getInstance();
 						calendarActfinish.setTime(datestrT.parse(datestrT.format(woMbo.getDate("actfinish"))));
 						woRecovery.setEngineerFinishworkDatetime(calendarActfinish);
 						woRecoveryVO.setFinishWorkTime(datestrT.format(woMbo.getDate("actfinish")).substring(11, 16));
 					}else{
 						woRecoveryVO.setFinishWorkTime("");
 						woRecovery.setEngineerFinishworkDatetime(null);
 					}
 					if(woMbo.getDate("mtr_inform_contractor_date")!=null){
 						woRecoveryVO.setInformContractorTime(datestrT.format(woMbo.getDate("mtr_inform_contractor_date")));
 					}else{
 						woRecoveryVO.setInformContractorTime("");
 					}
 					if(woMbo.getDate("mtr_sitearrival")!=null){
 						woRecoveryVO.setSiteArrivalTime(datestrT.format(woMbo.getDate("mtr_sitearrival")));
 					}else{
 						woRecoveryVO.setSiteArrivalTime("");
 					}
 					if(woMbo.getDate("actstart")!=null){
 						Calendar calendarActstart = Calendar.getInstance();
 						calendarActstart.setTime(datestrT.parse(datestrT.format(woMbo.getDate("actstart"))));
 						woRecovery.setEngineerStartworkDatetime(calendarActstart);
 						woRecoveryVO.setStartWorkTime(datestrT.format(woMbo.getDate("actstart")).substring(11, 16));
 					}else{
 						woRecoveryVO.setStartWorkTime("");
 						woRecovery.setEngineerStartworkDatetime(null);
 					}
 					if(woMbo.getDate("mtr_tempservrecv")!=null){
 						woRecoveryVO.setTempSvcRecoveryTime(datestrT.format(woMbo.getDate("mtr_tempservrecv")));
 					}else{
 						woRecoveryVO.setTempSvcRecoveryTime("");
 					}
 					woRecovery.setWoNo(workOrderNo);
 					woRecoveryVO.setWoRecovery(woRecovery);
 					workOrderVO.setWoRecoveryVO(woRecoveryVO);
 					
 	//		            <woSuspensionVOs/>//No use
 					WoSuspensionVO[] woSuspensionVOArray = new WoSuspensionVO[] {};
 					workOrderVO.setWoSuspensionVOs(woSuspensionVOArray);
 					
 	//		            <woTaskVOs/>//No use
 					MboSetRemote wpTaskMboSet = woMbo.getMboSet("SHOWTASKS");
 					if(!wpTaskMboSet.isEmpty()){
 						WoTaskVO[] woTaskVOArray = new WoTaskVO[wpTaskMboSet.count()];
 						MboRemote woTaskMbo = null;
 						for(int i=0;i<wpTaskMboSet.count();i++){
 							woTaskMbo = wpTaskMboSet.getMbo(i);
 							woTaskVOArray[i] = new WoTaskVO();
 							woTaskVOArray[i].setPersonInChargeUserCd(woTaskMbo.getString("ownerperson.displayname"));
 							woTaskVOArray[i].setTaskDesp(woTaskMbo.getString("description"));
 							WoTask woTask = new WoTask();
 	//						<xs:element minOccurs="0" name="actualComplDate" type="xs:dateTime"/>
 	//				          <xs:element minOccurs="0" name="actualStartDate" type="xs:dateTime"/>
 	//				          <xs:element minOccurs="0" name="gcTaskCd" type="xs:string"/>
 	//				          <xs:element minOccurs="0" name="personInChargeUserId" type="xs:string"/>
 	//				          <xs:element minOccurs="0" name="remarks" type="xs:string"/>
 	//				          <xs:element minOccurs="0" name="reservedField1" type="xs:string"/>
 	//				          <xs:element minOccurs="0" name="reservedField2" type="xs:string"/>
 	//				          <xs:element minOccurs="0" name="reservedField3" type="xs:string"/>
 	//				          <xs:element minOccurs="0" name="scheduleFinishdate" type="xs:dateTime"/>
 	//				          <xs:element minOccurs="0" name="scheduleStartdate" type="xs:dateTime"/>
 	//				          <xs:element minOccurs="0" name="sequenceNo" type="xs:long"/>
 	//				          <xs:element minOccurs="0" name="status" type="xs:string"/>
 	//				          <xs:element minOccurs="0" name="taskId" type="xs:long"/>
 							if(woTaskMbo.getDate("actfinish")!=null){
 								Calendar calendarActfinish = Calendar.getInstance();  
 								calendarActfinish.setTime(datestrT.parse(datestrT.format(woTaskMbo.getDate("actfinish"))));
 								woTask.setActualComplDate(calendarActfinish);
 				            }else{
 				            	woTask.setActualComplDate(null);
 				            }
 							if(woTaskMbo.getDate("actstart")!=null){
 								Calendar calendarActstart = Calendar.getInstance();  
 								calendarActstart.setTime(datestrT.parse(datestrT.format(woTaskMbo.getDate("actstart"))));
 								woTask.setActualStartDate(calendarActstart);
 				            }else{
 				            	woTask.setActualStartDate(null);
 				            }
 							woTask.setGcTaskCd(woTaskMbo.getString("description"));
 							woTask.setPersonInChargeUserId(woTaskMbo.getString("owner"));
 							woTask.setRemarks(woTaskMbo.getString("remarkdesc"));
 							woTask.setReservedField1(woTaskMbo.getString("mtr_reserved_field1"));
 							woTask.setReservedField2(woTaskMbo.getString("mtr_reserved_field2"));
 							woTask.setReservedField3(woTaskMbo.getString("mtr_reserved_field3"));
 							if(woTaskMbo.getDate("schedfinish")!=null){
 								Calendar calendarSchedfinish = Calendar.getInstance();
 								calendarSchedfinish.setTime(datestrT.parse(datestrT.format(woTaskMbo.getDate("schedfinish"))));
 								woTask.setScheduleFinishdate(calendarSchedfinish);
 				            }else{
 				            	woTask.setScheduleFinishdate(null);
 				            }
 							if(woTaskMbo.getDate("schedstart")!=null){
 								Calendar calendarSchedstart = Calendar.getInstance();
 								calendarSchedstart.setTime(datestrT.parse(datestrT.format(woTaskMbo.getDate("schedstart"))));
 								woTask.setScheduleStartdate(calendarSchedstart);
 				            }else{
 				            	woTask.setScheduleStartdate(null);
 				            }
 							woTask.setSequenceNo(woTaskMbo.getInt("wosequence"));
 							woTask.setStatus(woTaskMbo.getString("status"));
 							woTask.setTaskId(woTaskMbo.getLong("taskid"));
 							woTaskVOArray[i].setWoTask(woTask);
 						}
 						workOrderVO.setWoTaskVOs(woTaskVOArray);
 					}
 					
 					
 					
 	//				 <workGrp>
 	//	               <wkGrpCd>COWTAFC</wkGrpCd>
 	//	               <wkGrpId>10004182</wkGrpId>
 	//	               <wkGrpName>M1010-09E for Thales AFC-WRL</wkGrpName>
 	//	            </workGrp>
 					
 					WorkGrp workGrp = new WorkGrp();
 					workGrp.setWkGrpCd(woMbo.getString("persongroup"));
 					workGrp.setWkGrpId(woMbo.getLong("workorderpersongroup.persongroupid")+"");
 					workGrp.setWkGrpName(woMbo.getString("workorderpersongroup.description"));
 					workOrderVO.setWorkGrp(workGrp);
 					
 	//				 <workRequests/>
 					WorkRequest[] workRequestArray = new WorkRequest[1];
 					workRequestArray[0] = new WorkRequest();
 					workRequestArray[0].setWrId(woMbo.getString("mtr_wr_id"));
 					workOrderVO.setWorkRequests(workRequestArray);
 	//		            <workTimeRequire/>
 					workOrderVO.setWorkTimeRequire(woMbo.getFloat("estdur")+"");
 	//		            <wrId/>
 					workOrderVO.setWrId(woMbo.getString("mtr_wr_id"));
 	//		            <equipmentReferenceName>10137879</equipmentReferenceName>
 					workOrderVO.setEquipmentReferenceName(woMbo.getString("asset.assetnum"));
 	//		            <segment1>AFC</segment1>
 					workOrderVO.setSegment1("");//??????
 	//		            <segment2>OCTOPUS</segment2>
 					workOrderVO.setSegment2("");//??????
 	//		            <segment3/>
 					workOrderVO.setSegment3("");//??????
 	//		            <segment4/>
 					workOrderVO.setSegment4("");//??????
 					
 					workOrderVO.setTotalLabourCostVariance(workOrderVO.getTotalPlanLabourCost()-workOrderVO.getTotalActualLabourCost());
 					workOrderVO.setTotalMaterialsCostVariance(workOrderVO.getTotalPlanMaterialCost()-workOrderVO.getTotalActualMaterialCost());
 					workOrderVO.setTotalOtherCostVariance(workOrderVO.getTotalPlanLabourCost()-workOrderVO.getTotalActualOtherCost());
 	
 					/*
 	//		            <totalLabourCostVariance>0.0</totalLabourCostVariance>
 					if(!labtransMboSet.isEmpty()){
 						double[] x = new double[labtransMboSet.count()];
 						for (int i=0;i<labtransMboSet.count();i++){
 							x[i] = labtransMboSet.getMbo(i).getDouble("linecost");
 						}
 						double totalLabourCostVariance = Variance(x);
 						workOrderVO.setTotalLabourCostVariance(totalLabourCostVariance);
 					}else{
 						workOrderVO.setTotalLabourCostVariance(0);
 					}
 	
 	//	            <totalMaterialsCostVariance>0.0</totalMaterialsCostVariance>
 					if(!matusetransMboSet.isEmpty()){
 						double[] x = new double[matusetransMboSet.count()];
 						for (int i=0;i<matusetransMboSet.count();i++){
 							x[i] = matusetransMboSet.getMbo(i).getDouble("linecost");
 						}
 						double totalMaterialsCostVariance = Variance(x);
 						workOrderVO.setTotalMaterialsCostVariance(totalMaterialsCostVariance);
 					}else{
 						workOrderVO.setTotalMaterialsCostVariance(0);
 					}
 	
 	//		        <totalOtherCostVariance>0.0</totalOtherCostVariance>
 					if(!servrectransMboSet.isEmpty()||!tooltransMboSet.isEmpty()){
 						double[] x = new double[servrectransMboSet.count()+tooltransMboSet.count()];
 						int i=0;
 						for (;i<servrectransMboSet.count();i++){
 							x[i] = servrectransMboSet.getMbo(i).getDouble("loadedcost");
 						}
 						for (int j=0;j<tooltransMboSet.count();j++){
 							x[i+j] = tooltransMboSet.getMbo(j).getDouble("linecost");
 						}
 						double totalOtherCostVariance = Variance(x);
 						workOrderVO.setTotalOtherCostVariance(totalOtherCostVariance);
 					}else{
 						workOrderVO.setTotalOtherCostVariance(0);
 					}
 					*/
 					
 	//		            <finalCostFlag>N</finalCostFlag>
 	//				FINALIZED_IND='Y' or status in ('VD','SP','CL')
 					if("Y".equals(woMbo.getString("mtr_finalized_ind"))
 							||"VD".equals(woMbo.getString("status"))
 							||"SP".equals(woMbo.getString("status"))
 							||"CL".equals(woMbo.getString("status"))){
 						workOrderVO.setFinalCostFlag("Y");
 					}else{
 						workOrderVO.setFinalCostFlag("N");
 					}
 					
 	//	            <totalRecoveryTime>0 00:00:00</totalRecoveryTime> 
 	//			= engineerFinishworkDatetime.getTime() - reportDate.getTime() - suspensionTime - notRequireMillTime;
 					
 				if(woMbo.getDate("actfinish")!=null){
 					workOrderVO.setTotalRecoveryTime(getDistanceDateTime(woMbo.getDate("actfinish"), woMbo.getDate("reportdate")));
 				}else{
 					workOrderVO.setTotalRecoveryTime("0 00:00:00");
 				}
 	//	            <totalResponseTime>0 00:00:00</totalResponseTime>
 	//			= (Math.abs(workOrderVO.getMaintainerSiteArrival().getTime() - workOrderVO.getWoFailureInfoVO().getWoFailureInfo().getReportDatetime().getTime()) - notRequireMillTime)
 				
 				workOrderVO.setTotalResponseTime("0 00:00:0");
 	//	            <totalSuspensionTime>0 00:00:00</totalSuspensionTime>
 	//			'+= woSuspension.getResumeDatetime().getTime() - woSuspension.getSuspensionStarttime().getTime()
 	//			String suspensionTime1 = suspensionVO.getSuspensionTime();//This place is add by kit on 2012-04-24 for resolving the issue#6921			
 	//			WoSuspension woSuspension = suspensionVO.getWoSuspension();			
 	//			woSuspension.setSuspensionStarttime(CalendarUtil.transformStrToDate(woSuspension.getSuspensionStarttime(), suspensionTime1!=null?suspensionTime1:"00:00"));//This place is add by kit on 2012-04-24 for resolving the issue#6921			
 	//			woSuspension.setResumeDatetime(CalendarUtil .transformStrToDate(woSuspension.getResumeDatetime(), resumeTime1!=null?resumeTime1:"00:00"));//This place is add by kit on 2012-04-24 for resolving the issue#6921			
 	//			if (woSuspension.getResumeDatetime() != null			
 	//					&& woSuspension.getSuspensionStarttime() != null) {	
 	//				suspensionTime += woSuspension.getResumeDatetime().getTime()		
 	//						- woSuspension.getSuspensionStarttime().getTime();
 				workOrderVO.setTotalSuspensionTime("");
 					
 	    		 } catch (Exception e) {
 	    			e.printStackTrace();
 					MMISWebServiceExceptionE mmisWebServiceExceptionE = new MMISWebServiceExceptionE();
 		    		MMISWebServiceException mmisWebServiceException = new MMISWebServiceException();
 		    		mmisWebServiceException.setErrorCode(ERROR_CODE_3);
 		    		mmisWebServiceException.setErrorMessage(ERROR_CODE_3_MSG+e.getMessage());
 		    		mmisWebServiceExceptionE.setMMISWebServiceException(mmisWebServiceException);
 		    		WorkOrderException workOrderException = new WorkOrderException();
 		    		workOrderException.setFaultMessage(mmisWebServiceExceptionE);
 		    		throw workOrderException;
 			 }
     	}
		return workOrderVO;
	}
                 
    private MboRemote findWO(String workOrderNo) throws RemoteException, MXException {
         MboSetRemote  woMboSet = MXServer.getMXServer().getMboSet("WORKORDER", MXServer.getMXServer().getSystemUserInfo());
         woMboSet.setWhere("WONUM='"+workOrderNo +"'");
         woMboSet.reset();
         MboRemote woMbo = null; 
         if (!woMboSet.isEmpty())
         {
         	woMbo = woMboSet.getMbo(0);
         }
         return woMbo;
    }  
     
   //Variance s^2=[(x1-x)^2 +...(xn-x)^2]/n or s^2=[(x1-x)^2 +...(xn-x)^2]/(n-1)
    public static double Variance(double[] x) { 
       int m=x.length;
       double sum=0;
       for(int i=0;i<m;i++){//sue for peace
         sum+=x[i];
       }
       double dAve=sum/m;//averaging
       double dVar=0;
       for(int i=0;i<m;i++){//Find Variance
         dVar+=(x[i]-dAve)*(x[i]-dAve);
       }
       return dVar/m;
    }
     
     /**
      * Count the time difference between two times
      * two-one
      * The difference is a few seconds, a few milliseconds
      */
    public static String getDistanceDateTime(Date one, Date two) {
        long day = 0;//Days difference
        long hour = 0;//Hours difference
        long min = 0;//Minutes difference
        long second=0;//Seconds difference
        long diff=0 ;//milliseconds difference
        String result = "";
        final Calendar c = Calendar.getInstance();
//                     c.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        c.setTime(one);
        long time1 = one.getTime();
        long time2 = two.getTime();
        diff = time2 - time1;
        day = diff / (24 * 60 * 60 * 1000);
        hour = (diff / (60 * 60 * 1000) - day * 24);
        min = ((diff / (60 * 1000)) - day * 24 * 60 - hour * 60);
        second = diff/1000;
        System.out.println("day="+day+" hour="+hour+" min="+min+" ss="+second%60+" SSS="+diff%1000);
        String daystr = day%30+"days";
        String hourStr = hour%24+"hours";
		String minStr = min%60+"minutes";
		String secondStr = second%60+"seconds";
		if (day!=0){
			result = result + daystr;
		}
		if (hour!=0){
			result = result + hourStr;
		}
		if (min!=0){
			result = result + minStr;
		}
		if (second!=0){
			result = result + secondStr;
		}
		return result;
    }         
     
}
    