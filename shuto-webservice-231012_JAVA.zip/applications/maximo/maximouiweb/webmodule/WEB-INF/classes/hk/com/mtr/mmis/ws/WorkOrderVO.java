
/**
 * WorkOrderVO.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: SNAPSHOT  Built on : Jan 10, 2009 (05:26:17 CST)
 */
            
                package hk.com.mtr.mmis.ws;
            

            /**
            *  WorkOrderVO bean class
            */
        
        public  class WorkOrderVO extends hk.com.mtr.mmis.ws.BaseVO
        implements org.apache.axis2.databinding.ADBBean{
        /* This type was generated from the piece of schema that had
                name = workOrderVO
                Namespace URI = http://ws.mmis.mtr.com.hk/
                Namespace Prefix = ns1
                */
            

        private static java.lang.String generatePrefix(java.lang.String namespace) {
            if(namespace.equals("http://ws.mmis.mtr.com.hk/")){
                return "ns1";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        

                        /**
                        * field for Action
                        */

                        
                                    protected java.lang.String localAction ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localActionTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getAction(){
                               return localAction;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Action
                               */
                               public void setAction(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localActionTracker = true;
                                       } else {
                                          localActionTracker = false;
                                              
                                       }
                                   
                                            this.localAction=param;
                                    

                               }
                            

                        /**
                        * field for ActualCmplDate
                        */

                        
                                    protected java.util.Calendar localActualCmplDate ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localActualCmplDateTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.util.Calendar
                           */
                           public  java.util.Calendar getActualCmplDate(){
                               return localActualCmplDate;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ActualCmplDate
                               */
                               public void setActualCmplDate(java.util.Calendar param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localActualCmplDateTracker = true;
                                       } else {
                                          localActualCmplDateTracker = false;
                                              
                                       }
                                   
                                            this.localActualCmplDate=param;
                                    

                               }
                            

                        /**
                        * field for ActualStartDate
                        */

                        
                                    protected java.util.Calendar localActualStartDate ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localActualStartDateTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.util.Calendar
                           */
                           public  java.util.Calendar getActualStartDate(){
                               return localActualStartDate;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ActualStartDate
                               */
                               public void setActualStartDate(java.util.Calendar param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localActualStartDateTracker = true;
                                       } else {
                                          localActualStartDateTracker = false;
                                              
                                       }
                                   
                                            this.localActualStartDate=param;
                                    

                               }
                            

                        /**
                        * field for ActualStartTime
                        */

                        
                                    protected java.lang.String localActualStartTime ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localActualStartTimeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getActualStartTime(){
                               return localActualStartTime;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ActualStartTime
                               */
                               public void setActualStartTime(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localActualStartTimeTracker = true;
                                       } else {
                                          localActualStartTimeTracker = false;
                                              
                                       }
                                   
                                            this.localActualStartTime=param;
                                    

                               }
                            

                        /**
                        * field for ChildWolist
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WoRelationship[] localChildWolist ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localChildWolistTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WoRelationship[]
                           */
                           public  hk.com.mtr.mmis.ws.WoRelationship[] getChildWolist(){
                               return localChildWolist;
                           }

                           
                        


                               
                              /**
                               * validate the array for ChildWolist
                               */
                              protected void validateChildWolist(hk.com.mtr.mmis.ws.WoRelationship[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param ChildWolist
                              */
                              public void setChildWolist(hk.com.mtr.mmis.ws.WoRelationship[] param){
                              
                                   validateChildWolist(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localChildWolistTracker = true;
                                          } else {
                                             localChildWolistTracker = true;
                                                 
                                          }
                                      
                                      this.localChildWolist=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.WoRelationship
                             */
                             public void addChildWolist(hk.com.mtr.mmis.ws.WoRelationship param){
                                   if (localChildWolist == null){
                                   localChildWolist = new hk.com.mtr.mmis.ws.WoRelationship[]{};
                                   }

                            
                                 //update the setting tracker
                                localChildWolistTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localChildWolist);
                               list.add(param);
                               this.localChildWolist =
                             (hk.com.mtr.mmis.ws.WoRelationship[])list.toArray(
                            new hk.com.mtr.mmis.ws.WoRelationship[list.size()]);

                             }
                             

                        /**
                        * field for CmpltmnryContractNo
                        */

                        
                                    protected java.lang.String localCmpltmnryContractNo ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localCmpltmnryContractNoTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getCmpltmnryContractNo(){
                               return localCmpltmnryContractNo;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param CmpltmnryContractNo
                               */
                               public void setCmpltmnryContractNo(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localCmpltmnryContractNoTracker = true;
                                       } else {
                                          localCmpltmnryContractNoTracker = false;
                                              
                                       }
                                   
                                            this.localCmpltmnryContractNo=param;
                                    

                               }
                            

                        /**
                        * field for ContractDesp
                        */

                        
                                    protected java.lang.String localContractDesp ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localContractDespTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getContractDesp(){
                               return localContractDesp;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ContractDesp
                               */
                               public void setContractDesp(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localContractDespTracker = true;
                                       } else {
                                          localContractDespTracker = false;
                                              
                                       }
                                   
                                            this.localContractDesp=param;
                                    

                               }
                            

                        /**
                        * field for ContractNo
                        */

                        
                                    protected java.lang.String localContractNo ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localContractNoTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getContractNo(){
                               return localContractNo;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ContractNo
                               */
                               public void setContractNo(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localContractNoTracker = true;
                                       } else {
                                          localContractNoTracker = false;
                                              
                                       }
                                   
                                            this.localContractNo=param;
                                    

                               }
                            

                        /**
                        * field for Contractor
                        */

                        
                                    protected java.lang.String localContractor ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localContractorTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getContractor(){
                               return localContractor;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Contractor
                               */
                               public void setContractor(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localContractorTracker = true;
                                       } else {
                                          localContractorTracker = false;
                                              
                                       }
                                   
                                            this.localContractor=param;
                                    

                               }
                            

                        /**
                        * field for ContractorInCharge
                        */

                        
                                    protected hk.com.mtr.mmis.ws.OrganizationUnit localContractorInCharge ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localContractorInChargeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.OrganizationUnit
                           */
                           public  hk.com.mtr.mmis.ws.OrganizationUnit getContractorInCharge(){
                               return localContractorInCharge;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ContractorInCharge
                               */
                               public void setContractorInCharge(hk.com.mtr.mmis.ws.OrganizationUnit param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localContractorInChargeTracker = true;
                                       } else {
                                          localContractorInChargeTracker = false;
                                              
                                       }
                                   
                                            this.localContractorInCharge=param;
                                    

                               }
                            

                        /**
                        * field for DetailIDs
                        */

                        
                                    protected java.lang.String localDetailIDs ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localDetailIDsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getDetailIDs(){
                               return localDetailIDs;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param DetailIDs
                               */
                               public void setDetailIDs(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localDetailIDsTracker = true;
                                       } else {
                                          localDetailIDsTracker = false;
                                              
                                       }
                                   
                                            this.localDetailIDs=param;
                                    

                               }
                            

                        /**
                        * field for DetailLoc
                        */

                        
                                    protected java.lang.String localDetailLoc ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localDetailLocTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getDetailLoc(){
                               return localDetailLoc;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param DetailLoc
                               */
                               public void setDetailLoc(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localDetailLocTracker = true;
                                       } else {
                                          localDetailLocTracker = false;
                                              
                                       }
                                   
                                            this.localDetailLoc=param;
                                    

                               }
                            

                        /**
                        * field for EarPlanStartDate
                        */

                        
                                    protected java.util.Calendar localEarPlanStartDate ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localEarPlanStartDateTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.util.Calendar
                           */
                           public  java.util.Calendar getEarPlanStartDate(){
                               return localEarPlanStartDate;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param EarPlanStartDate
                               */
                               public void setEarPlanStartDate(java.util.Calendar param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localEarPlanStartDateTracker = true;
                                       } else {
                                          localEarPlanStartDateTracker = false;
                                              
                                       }
                                   
                                            this.localEarPlanStartDate=param;
                                    

                               }
                            

                        /**
                        * field for EngineerInCharge
                        */

                        
                                    protected hk.com.mtr.mmis.ws.HumanResource localEngineerInCharge ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localEngineerInChargeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.HumanResource
                           */
                           public  hk.com.mtr.mmis.ws.HumanResource getEngineerInCharge(){
                               return localEngineerInCharge;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param EngineerInCharge
                               */
                               public void setEngineerInCharge(hk.com.mtr.mmis.ws.HumanResource param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localEngineerInChargeTracker = true;
                                       } else {
                                          localEngineerInChargeTracker = false;
                                              
                                       }
                                   
                                            this.localEngineerInCharge=param;
                                    

                               }
                            

                        /**
                        * field for EquipClass
                        */

                        
                                    protected hk.com.mtr.mmis.ws.EquipClass localEquipClass ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localEquipClassTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.EquipClass
                           */
                           public  hk.com.mtr.mmis.ws.EquipClass getEquipClass(){
                               return localEquipClass;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param EquipClass
                               */
                               public void setEquipClass(hk.com.mtr.mmis.ws.EquipClass param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localEquipClassTracker = true;
                                       } else {
                                          localEquipClassTracker = false;
                                              
                                       }
                                   
                                            this.localEquipClass=param;
                                    

                               }
                            

                        /**
                        * field for EquipDownTime
                        */

                        
                                    protected java.lang.String localEquipDownTime ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localEquipDownTimeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getEquipDownTime(){
                               return localEquipDownTime;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param EquipDownTime
                               */
                               public void setEquipDownTime(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localEquipDownTimeTracker = true;
                                       } else {
                                          localEquipDownTimeTracker = false;
                                              
                                       }
                                   
                                            this.localEquipDownTime=param;
                                    

                               }
                            

                        /**
                        * field for Equipment
                        */

                        
                                    protected hk.com.mtr.mmis.ws.Equipment localEquipment ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localEquipmentTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.Equipment
                           */
                           public  hk.com.mtr.mmis.ws.Equipment getEquipment(){
                               return localEquipment;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Equipment
                               */
                               public void setEquipment(hk.com.mtr.mmis.ws.Equipment param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localEquipmentTracker = true;
                                       } else {
                                          localEquipmentTracker = false;
                                              
                                       }
                                   
                                            this.localEquipment=param;
                                    

                               }
                            

                        /**
                        * field for FinalizedInd
                        */

                        
                                    protected java.lang.String localFinalizedInd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localFinalizedIndTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getFinalizedInd(){
                               return localFinalizedInd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param FinalizedInd
                               */
                               public void setFinalizedInd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localFinalizedIndTracker = true;
                                       } else {
                                          localFinalizedIndTracker = false;
                                              
                                       }
                                   
                                            this.localFinalizedInd=param;
                                    

                               }
                            

                        /**
                        * field for GcFinanceRefNoCd
                        */

                        
                                    protected java.lang.String localGcFinanceRefNoCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcFinanceRefNoCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcFinanceRefNoCd(){
                               return localGcFinanceRefNoCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcFinanceRefNoCd
                               */
                               public void setGcFinanceRefNoCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcFinanceRefNoCdTracker = true;
                                       } else {
                                          localGcFinanceRefNoCdTracker = false;
                                              
                                       }
                                   
                                            this.localGcFinanceRefNoCd=param;
                                    

                               }
                            

                        /**
                        * field for GcPriorityCd
                        */

                        
                                    protected java.lang.String localGcPriorityCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcPriorityCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcPriorityCd(){
                               return localGcPriorityCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcPriorityCd
                               */
                               public void setGcPriorityCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcPriorityCdTracker = true;
                                       } else {
                                          localGcPriorityCdTracker = false;
                                              
                                       }
                                   
                                            this.localGcPriorityCd=param;
                                    

                               }
                            

                        /**
                        * field for GcProjectNoCd
                        */

                        
                                    protected java.lang.String localGcProjectNoCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcProjectNoCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcProjectNoCd(){
                               return localGcProjectNoCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcProjectNoCd
                               */
                               public void setGcProjectNoCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcProjectNoCdTracker = true;
                                       } else {
                                          localGcProjectNoCdTracker = false;
                                              
                                       }
                                   
                                            this.localGcProjectNoCd=param;
                                    

                               }
                            

                        /**
                        * field for GcProjectTaskNoCd
                        */

                        
                                    protected java.lang.String localGcProjectTaskNoCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcProjectTaskNoCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcProjectTaskNoCd(){
                               return localGcProjectTaskNoCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcProjectTaskNoCd
                               */
                               public void setGcProjectTaskNoCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcProjectTaskNoCdTracker = true;
                                       } else {
                                          localGcProjectTaskNoCdTracker = false;
                                              
                                       }
                                   
                                            this.localGcProjectTaskNoCd=param;
                                    

                               }
                            

                        /**
                        * field for GcSvcBreakdownCd
                        */

                        
                                    protected java.lang.String localGcSvcBreakdownCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcSvcBreakdownCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcSvcBreakdownCd(){
                               return localGcSvcBreakdownCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcSvcBreakdownCd
                               */
                               public void setGcSvcBreakdownCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcSvcBreakdownCdTracker = true;
                                       } else {
                                          localGcSvcBreakdownCdTracker = false;
                                              
                                       }
                                   
                                            this.localGcSvcBreakdownCd=param;
                                    

                               }
                            

                        /**
                        * field for GcWorkNatureLv1Cd
                        */

                        
                                    protected java.lang.String localGcWorkNatureLv1Cd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcWorkNatureLv1CdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcWorkNatureLv1Cd(){
                               return localGcWorkNatureLv1Cd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcWorkNatureLv1Cd
                               */
                               public void setGcWorkNatureLv1Cd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcWorkNatureLv1CdTracker = true;
                                       } else {
                                          localGcWorkNatureLv1CdTracker = false;
                                              
                                       }
                                   
                                            this.localGcWorkNatureLv1Cd=param;
                                    

                               }
                            

                        /**
                        * field for GcWorkNatureLv2Cd
                        */

                        
                                    protected java.lang.String localGcWorkNatureLv2Cd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcWorkNatureLv2CdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcWorkNatureLv2Cd(){
                               return localGcWorkNatureLv2Cd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcWorkNatureLv2Cd
                               */
                               public void setGcWorkNatureLv2Cd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcWorkNatureLv2CdTracker = true;
                                       } else {
                                          localGcWorkNatureLv2CdTracker = false;
                                              
                                       }
                                   
                                            this.localGcWorkNatureLv2Cd=param;
                                    

                               }
                            

                        /**
                        * field for IncidentNumber
                        */

                        
                                    protected java.lang.String localIncidentNumber ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localIncidentNumberTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getIncidentNumber(){
                               return localIncidentNumber;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param IncidentNumber
                               */
                               public void setIncidentNumber(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localIncidentNumberTracker = true;
                                       } else {
                                          localIncidentNumberTracker = false;
                                              
                                       }
                                   
                                            this.localIncidentNumber=param;
                                    

                               }
                            

                        /**
                        * field for IncidentVO
                        */

                        
                                    protected hk.com.mtr.mmis.ws.IncidentVO localIncidentVO ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localIncidentVOTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.IncidentVO
                           */
                           public  hk.com.mtr.mmis.ws.IncidentVO getIncidentVO(){
                               return localIncidentVO;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param IncidentVO
                               */
                               public void setIncidentVO(hk.com.mtr.mmis.ws.IncidentVO param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localIncidentVOTracker = true;
                                       } else {
                                          localIncidentVOTracker = false;
                                              
                                       }
                                   
                                            this.localIncidentVO=param;
                                    

                               }
                            

                        /**
                        * field for LabourCostCredit
                        */

                        
                                    protected java.lang.String localLabourCostCredit ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localLabourCostCreditTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getLabourCostCredit(){
                               return localLabourCostCredit;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param LabourCostCredit
                               */
                               public void setLabourCostCredit(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localLabourCostCreditTracker = true;
                                       } else {
                                          localLabourCostCreditTracker = false;
                                              
                                       }
                                   
                                            this.localLabourCostCredit=param;
                                    

                               }
                            

                        /**
                        * field for LabourCostDebit
                        */

                        
                                    protected java.lang.String localLabourCostDebit ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localLabourCostDebitTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getLabourCostDebit(){
                               return localLabourCostDebit;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param LabourCostDebit
                               */
                               public void setLabourCostDebit(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localLabourCostDebitTracker = true;
                                       } else {
                                          localLabourCostDebitTracker = false;
                                              
                                       }
                                   
                                            this.localLabourCostDebit=param;
                                    

                               }
                            

                        /**
                        * field for LastPlanStartDate
                        */

                        
                                    protected java.util.Calendar localLastPlanStartDate ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localLastPlanStartDateTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.util.Calendar
                           */
                           public  java.util.Calendar getLastPlanStartDate(){
                               return localLastPlanStartDate;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param LastPlanStartDate
                               */
                               public void setLastPlanStartDate(java.util.Calendar param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localLastPlanStartDateTracker = true;
                                       } else {
                                          localLastPlanStartDateTracker = false;
                                              
                                       }
                                   
                                            this.localLastPlanStartDate=param;
                                    

                               }
                            

                        /**
                        * field for Locale
                        */

                        
                                    protected java.lang.String localLocale ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localLocaleTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getLocale(){
                               return localLocale;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Locale
                               */
                               public void setLocale(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localLocaleTracker = true;
                                       } else {
                                          localLocaleTracker = false;
                                              
                                       }
                                   
                                            this.localLocale=param;
                                    

                               }
                            

                        /**
                        * field for MaintainerFinishWork
                        */

                        
                                    protected java.util.Calendar localMaintainerFinishWork ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localMaintainerFinishWorkTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.util.Calendar
                           */
                           public  java.util.Calendar getMaintainerFinishWork(){
                               return localMaintainerFinishWork;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param MaintainerFinishWork
                               */
                               public void setMaintainerFinishWork(java.util.Calendar param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localMaintainerFinishWorkTracker = true;
                                       } else {
                                          localMaintainerFinishWorkTracker = false;
                                              
                                       }
                                   
                                            this.localMaintainerFinishWork=param;
                                    

                               }
                            

                        /**
                        * field for MaintainerSiteArrival
                        */

                        
                                    protected java.util.Calendar localMaintainerSiteArrival ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localMaintainerSiteArrivalTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.util.Calendar
                           */
                           public  java.util.Calendar getMaintainerSiteArrival(){
                               return localMaintainerSiteArrival;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param MaintainerSiteArrival
                               */
                               public void setMaintainerSiteArrival(java.util.Calendar param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localMaintainerSiteArrivalTracker = true;
                                       } else {
                                          localMaintainerSiteArrivalTracker = false;
                                              
                                       }
                                   
                                            this.localMaintainerSiteArrival=param;
                                    

                               }
                            

                        /**
                        * field for MaintainerStartWork
                        */

                        
                                    protected java.util.Calendar localMaintainerStartWork ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localMaintainerStartWorkTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.util.Calendar
                           */
                           public  java.util.Calendar getMaintainerStartWork(){
                               return localMaintainerStartWork;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param MaintainerStartWork
                               */
                               public void setMaintainerStartWork(java.util.Calendar param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localMaintainerStartWorkTracker = true;
                                       } else {
                                          localMaintainerStartWorkTracker = false;
                                              
                                       }
                                   
                                            this.localMaintainerStartWork=param;
                                    

                               }
                            

                        /**
                        * field for MaterialCostCredit
                        */

                        
                                    protected java.lang.String localMaterialCostCredit ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localMaterialCostCreditTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getMaterialCostCredit(){
                               return localMaterialCostCredit;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param MaterialCostCredit
                               */
                               public void setMaterialCostCredit(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localMaterialCostCreditTracker = true;
                                       } else {
                                          localMaterialCostCreditTracker = false;
                                              
                                       }
                                   
                                            this.localMaterialCostCredit=param;
                                    

                               }
                            

                        /**
                        * field for MaterialCostDebit
                        */

                        
                                    protected java.lang.String localMaterialCostDebit ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localMaterialCostDebitTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getMaterialCostDebit(){
                               return localMaterialCostDebit;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param MaterialCostDebit
                               */
                               public void setMaterialCostDebit(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localMaterialCostDebitTracker = true;
                                       } else {
                                          localMaterialCostDebitTracker = false;
                                              
                                       }
                                   
                                            this.localMaterialCostDebit=param;
                                    

                               }
                            

                        /**
                        * field for OldWoNo
                        */

                        
                                    protected java.lang.String localOldWoNo ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localOldWoNoTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getOldWoNo(){
                               return localOldWoNo;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param OldWoNo
                               */
                               public void setOldWoNo(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localOldWoNoTracker = true;
                                       } else {
                                          localOldWoNoTracker = false;
                                              
                                       }
                                   
                                            this.localOldWoNo=param;
                                    

                               }
                            

                        /**
                        * field for OneOfRelatedMeasurementId
                        */

                        
                                    protected java.lang.String localOneOfRelatedMeasurementId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localOneOfRelatedMeasurementIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getOneOfRelatedMeasurementId(){
                               return localOneOfRelatedMeasurementId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param OneOfRelatedMeasurementId
                               */
                               public void setOneOfRelatedMeasurementId(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localOneOfRelatedMeasurementIdTracker = true;
                                       } else {
                                          localOneOfRelatedMeasurementIdTracker = false;
                                              
                                       }
                                   
                                            this.localOneOfRelatedMeasurementId=param;
                                    

                               }
                            

                        /**
                        * field for OpenDate
                        */

                        
                                    protected java.util.Calendar localOpenDate ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localOpenDateTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.util.Calendar
                           */
                           public  java.util.Calendar getOpenDate(){
                               return localOpenDate;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param OpenDate
                               */
                               public void setOpenDate(java.util.Calendar param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localOpenDateTracker = true;
                                       } else {
                                          localOpenDateTracker = false;
                                              
                                       }
                                   
                                            this.localOpenDate=param;
                                    

                               }
                            

                        /**
                        * field for OtherCostCredit
                        */

                        
                                    protected java.lang.String localOtherCostCredit ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localOtherCostCreditTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getOtherCostCredit(){
                               return localOtherCostCredit;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param OtherCostCredit
                               */
                               public void setOtherCostCredit(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localOtherCostCreditTracker = true;
                                       } else {
                                          localOtherCostCreditTracker = false;
                                              
                                       }
                                   
                                            this.localOtherCostCredit=param;
                                    

                               }
                            

                        /**
                        * field for OtherCostDebit
                        */

                        
                                    protected java.lang.String localOtherCostDebit ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localOtherCostDebitTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getOtherCostDebit(){
                               return localOtherCostDebit;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param OtherCostDebit
                               */
                               public void setOtherCostDebit(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localOtherCostDebitTracker = true;
                                       } else {
                                          localOtherCostDebitTracker = false;
                                              
                                       }
                                   
                                            this.localOtherCostDebit=param;
                                    

                               }
                            

                        /**
                        * field for ParentWoRelationship
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WoRelationship localParentWoRelationship ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localParentWoRelationshipTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WoRelationship
                           */
                           public  hk.com.mtr.mmis.ws.WoRelationship getParentWoRelationship(){
                               return localParentWoRelationship;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ParentWoRelationship
                               */
                               public void setParentWoRelationship(hk.com.mtr.mmis.ws.WoRelationship param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localParentWoRelationshipTracker = true;
                                       } else {
                                          localParentWoRelationshipTracker = false;
                                              
                                       }
                                   
                                            this.localParentWoRelationship=param;
                                    

                               }
                            

                        /**
                        * field for PersonInCharge
                        */

                        
                                    protected hk.com.mtr.mmis.ws.HumanResource localPersonInCharge ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localPersonInChargeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.HumanResource
                           */
                           public  hk.com.mtr.mmis.ws.HumanResource getPersonInCharge(){
                               return localPersonInCharge;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param PersonInCharge
                               */
                               public void setPersonInCharge(hk.com.mtr.mmis.ws.HumanResource param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localPersonInChargeTracker = true;
                                       } else {
                                          localPersonInChargeTracker = false;
                                              
                                       }
                                   
                                            this.localPersonInCharge=param;
                                    

                               }
                            

                        /**
                        * field for PersonInChargeUserId
                        */

                        
                                    protected java.lang.String localPersonInChargeUserId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localPersonInChargeUserIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getPersonInChargeUserId(){
                               return localPersonInChargeUserId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param PersonInChargeUserId
                               */
                               public void setPersonInChargeUserId(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localPersonInChargeUserIdTracker = true;
                                       } else {
                                          localPersonInChargeUserIdTracker = false;
                                              
                                       }
                                   
                                            this.localPersonInChargeUserId=param;
                                    

                               }
                            

                        /**
                        * field for PersonInchrgCd
                        */

                        
                                    protected java.lang.String localPersonInchrgCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localPersonInchrgCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getPersonInchrgCd(){
                               return localPersonInchrgCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param PersonInchrgCd
                               */
                               public void setPersonInchrgCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localPersonInchrgCdTracker = true;
                                       } else {
                                          localPersonInchrgCdTracker = false;
                                              
                                       }
                                   
                                            this.localPersonInchrgCd=param;
                                    

                               }
                            

                        /**
                        * field for PlanCmplDate
                        */

                        
                                    protected java.util.Calendar localPlanCmplDate ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localPlanCmplDateTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.util.Calendar
                           */
                           public  java.util.Calendar getPlanCmplDate(){
                               return localPlanCmplDate;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param PlanCmplDate
                               */
                               public void setPlanCmplDate(java.util.Calendar param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localPlanCmplDateTracker = true;
                                       } else {
                                          localPlanCmplDateTracker = false;
                                              
                                       }
                                   
                                            this.localPlanCmplDate=param;
                                    

                               }
                            

                        /**
                        * field for PlanStartDate
                        */

                        
                                    protected java.util.Calendar localPlanStartDate ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localPlanStartDateTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.util.Calendar
                           */
                           public  java.util.Calendar getPlanStartDate(){
                               return localPlanStartDate;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param PlanStartDate
                               */
                               public void setPlanStartDate(java.util.Calendar param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localPlanStartDateTracker = true;
                                       } else {
                                          localPlanStartDateTracker = false;
                                              
                                       }
                                   
                                            this.localPlanStartDate=param;
                                    

                               }
                            

                        /**
                        * field for PlannedCmplTime
                        */

                        
                                    protected java.lang.String localPlannedCmplTime ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localPlannedCmplTimeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getPlannedCmplTime(){
                               return localPlannedCmplTime;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param PlannedCmplTime
                               */
                               public void setPlannedCmplTime(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localPlannedCmplTimeTracker = true;
                                       } else {
                                          localPlannedCmplTimeTracker = false;
                                              
                                       }
                                   
                                            this.localPlannedCmplTime=param;
                                    

                               }
                            

                        /**
                        * field for PlannedStartTime
                        */

                        
                                    protected java.lang.String localPlannedStartTime ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localPlannedStartTimeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getPlannedStartTime(){
                               return localPlannedStartTime;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param PlannedStartTime
                               */
                               public void setPlannedStartTime(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localPlannedStartTimeTracker = true;
                                       } else {
                                          localPlannedStartTimeTracker = false;
                                              
                                       }
                                   
                                            this.localPlannedStartTime=param;
                                    

                               }
                            

                        /**
                        * field for PrimaryRecoveryTime
                        */

                        
                                    protected java.lang.String localPrimaryRecoveryTime ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localPrimaryRecoveryTimeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getPrimaryRecoveryTime(){
                               return localPrimaryRecoveryTime;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param PrimaryRecoveryTime
                               */
                               public void setPrimaryRecoveryTime(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localPrimaryRecoveryTimeTracker = true;
                                       } else {
                                          localPrimaryRecoveryTimeTracker = false;
                                              
                                       }
                                   
                                            this.localPrimaryRecoveryTime=param;
                                    

                               }
                            

                        /**
                        * field for Quantity
                        */

                        
                                    protected long localQuantity ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localQuantityTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getQuantity(){
                               return localQuantity;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Quantity
                               */
                               public void setQuantity(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localQuantityTracker = false;
                                              
                                       } else {
                                          localQuantityTracker = true;
                                       }
                                   
                                            this.localQuantity=param;
                                    

                               }
                            

                        /**
                        * field for RelatedMeasurementIds
                        * This was an Array!
                        */

                        
                                    protected java.lang.String[] localRelatedMeasurementIds ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localRelatedMeasurementIdsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String[]
                           */
                           public  java.lang.String[] getRelatedMeasurementIds(){
                               return localRelatedMeasurementIds;
                           }

                           
                        


                               
                              /**
                               * validate the array for RelatedMeasurementIds
                               */
                              protected void validateRelatedMeasurementIds(java.lang.String[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param RelatedMeasurementIds
                              */
                              public void setRelatedMeasurementIds(java.lang.String[] param){
                              
                                   validateRelatedMeasurementIds(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localRelatedMeasurementIdsTracker = true;
                                          } else {
                                             localRelatedMeasurementIdsTracker = true;
                                                 
                                          }
                                      
                                      this.localRelatedMeasurementIds=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param java.lang.String
                             */
                             public void addRelatedMeasurementIds(java.lang.String param){
                                   if (localRelatedMeasurementIds == null){
                                   localRelatedMeasurementIds = new java.lang.String[]{};
                                   }

                            
                                 //update the setting tracker
                                localRelatedMeasurementIdsTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localRelatedMeasurementIds);
                               list.add(param);
                               this.localRelatedMeasurementIds =
                             (java.lang.String[])list.toArray(
                            new java.lang.String[list.size()]);

                             }
                             

                        /**
                        * field for RelatedWoList
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WoRelationship[] localRelatedWoList ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localRelatedWoListTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WoRelationship[]
                           */
                           public  hk.com.mtr.mmis.ws.WoRelationship[] getRelatedWoList(){
                               return localRelatedWoList;
                           }

                           
                        


                               
                              /**
                               * validate the array for RelatedWoList
                               */
                              protected void validateRelatedWoList(hk.com.mtr.mmis.ws.WoRelationship[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param RelatedWoList
                              */
                              public void setRelatedWoList(hk.com.mtr.mmis.ws.WoRelationship[] param){
                              
                                   validateRelatedWoList(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localRelatedWoListTracker = true;
                                          } else {
                                             localRelatedWoListTracker = true;
                                                 
                                          }
                                      
                                      this.localRelatedWoList=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.WoRelationship
                             */
                             public void addRelatedWoList(hk.com.mtr.mmis.ws.WoRelationship param){
                                   if (localRelatedWoList == null){
                                   localRelatedWoList = new hk.com.mtr.mmis.ws.WoRelationship[]{};
                                   }

                            
                                 //update the setting tracker
                                localRelatedWoListTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localRelatedWoList);
                               list.add(param);
                               this.localRelatedWoList =
                             (hk.com.mtr.mmis.ws.WoRelationship[])list.toArray(
                            new hk.com.mtr.mmis.ws.WoRelationship[list.size()]);

                             }
                             

                        /**
                        * field for Remark
                        */

                        
                                    protected java.lang.String localRemark ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localRemarkTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getRemark(){
                               return localRemark;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Remark
                               */
                               public void setRemark(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localRemarkTracker = true;
                                       } else {
                                          localRemarkTracker = false;
                                              
                                       }
                                   
                                            this.localRemark=param;
                                    

                               }
                            

                        /**
                        * field for ReservedField1
                        */

                        
                                    protected java.lang.String localReservedField1 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localReservedField1Tracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getReservedField1(){
                               return localReservedField1;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ReservedField1
                               */
                               public void setReservedField1(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localReservedField1Tracker = true;
                                       } else {
                                          localReservedField1Tracker = false;
                                              
                                       }
                                   
                                            this.localReservedField1=param;
                                    

                               }
                            

                        /**
                        * field for ReservedField2
                        */

                        
                                    protected java.lang.String localReservedField2 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localReservedField2Tracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getReservedField2(){
                               return localReservedField2;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ReservedField2
                               */
                               public void setReservedField2(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localReservedField2Tracker = true;
                                       } else {
                                          localReservedField2Tracker = false;
                                              
                                       }
                                   
                                            this.localReservedField2=param;
                                    

                               }
                            

                        /**
                        * field for ReservedField3
                        */

                        
                                    protected java.lang.String localReservedField3 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localReservedField3Tracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getReservedField3(){
                               return localReservedField3;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ReservedField3
                               */
                               public void setReservedField3(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localReservedField3Tracker = true;
                                       } else {
                                          localReservedField3Tracker = false;
                                              
                                       }
                                   
                                            this.localReservedField3=param;
                                    

                               }
                            

                        /**
                        * field for ServiceDownTime
                        */

                        
                                    protected java.lang.String localServiceDownTime ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localServiceDownTimeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getServiceDownTime(){
                               return localServiceDownTime;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ServiceDownTime
                               */
                               public void setServiceDownTime(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localServiceDownTimeTracker = true;
                                       } else {
                                          localServiceDownTimeTracker = false;
                                              
                                       }
                                   
                                            this.localServiceDownTime=param;
                                    

                               }
                            

                        /**
                        * field for ServiceNotRequireTime
                        */

                        
                                    protected java.lang.String localServiceNotRequireTime ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localServiceNotRequireTimeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getServiceNotRequireTime(){
                               return localServiceNotRequireTime;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ServiceNotRequireTime
                               */
                               public void setServiceNotRequireTime(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localServiceNotRequireTimeTracker = true;
                                       } else {
                                          localServiceNotRequireTimeTracker = false;
                                              
                                       }
                                   
                                            this.localServiceNotRequireTime=param;
                                    

                               }
                            

                        /**
                        * field for ShortLoc
                        */

                        
                                    protected java.lang.String localShortLoc ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localShortLocTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getShortLoc(){
                               return localShortLoc;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ShortLoc
                               */
                               public void setShortLoc(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localShortLocTracker = true;
                                       } else {
                                          localShortLocTracker = false;
                                              
                                       }
                                   
                                            this.localShortLoc=param;
                                    

                               }
                            

                        /**
                        * field for Status
                        */

                        
                                    protected java.lang.String localStatus ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localStatusTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getStatus(){
                               return localStatus;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Status
                               */
                               public void setStatus(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localStatusTracker = true;
                                       } else {
                                          localStatusTracker = false;
                                              
                                       }
                                   
                                            this.localStatus=param;
                                    

                               }
                            

                        /**
                        * field for StatusDesc
                        */

                        
                                    protected java.lang.String localStatusDesc ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localStatusDescTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getStatusDesc(){
                               return localStatusDesc;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param StatusDesc
                               */
                               public void setStatusDesc(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localStatusDescTracker = true;
                                       } else {
                                          localStatusDescTracker = false;
                                              
                                       }
                                   
                                            this.localStatusDesc=param;
                                    

                               }
                            

                        /**
                        * field for StatusHis
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WoStatusHistoryVO localStatusHis ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localStatusHisTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WoStatusHistoryVO
                           */
                           public  hk.com.mtr.mmis.ws.WoStatusHistoryVO getStatusHis(){
                               return localStatusHis;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param StatusHis
                               */
                               public void setStatusHis(hk.com.mtr.mmis.ws.WoStatusHistoryVO param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localStatusHisTracker = true;
                                       } else {
                                          localStatusHisTracker = false;
                                              
                                       }
                                   
                                            this.localStatusHis=param;
                                    

                               }
                            

                        /**
                        * field for StdJob
                        */

                        
                                    protected hk.com.mtr.mmis.ws.StandardJob localStdJob ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localStdJobTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.StandardJob
                           */
                           public  hk.com.mtr.mmis.ws.StandardJob getStdJob(){
                               return localStdJob;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param StdJob
                               */
                               public void setStdJob(hk.com.mtr.mmis.ws.StandardJob param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localStdJobTracker = true;
                                       } else {
                                          localStdJobTracker = false;
                                              
                                       }
                                   
                                            this.localStdJob=param;
                                    

                               }
                            

                        /**
                        * field for StdJobParamListId
                        */

                        
                                    protected long localStdJobParamListId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localStdJobParamListIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getStdJobParamListId(){
                               return localStdJobParamListId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param StdJobParamListId
                               */
                               public void setStdJobParamListId(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localStdJobParamListIdTracker = false;
                                              
                                       } else {
                                          localStdJobParamListIdTracker = true;
                                       }
                                   
                                            this.localStdJobParamListId=param;
                                    

                               }
                            

                        /**
                        * field for StdJobParamSetName
                        */

                        
                                    protected java.lang.String localStdJobParamSetName ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localStdJobParamSetNameTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getStdJobParamSetName(){
                               return localStdJobParamSetName;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param StdJobParamSetName
                               */
                               public void setStdJobParamSetName(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localStdJobParamSetNameTracker = true;
                                       } else {
                                          localStdJobParamSetNameTracker = false;
                                              
                                       }
                                   
                                            this.localStdJobParamSetName=param;
                                    

                               }
                            

                        /**
                        * field for TotalActualHour
                        */

                        
                                    protected double localTotalActualHour ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localTotalActualHourTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getTotalActualHour(){
                               return localTotalActualHour;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param TotalActualHour
                               */
                               public void setTotalActualHour(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localTotalActualHourTracker = false;
                                              
                                       } else {
                                          localTotalActualHourTracker = true;
                                       }
                                   
                                            this.localTotalActualHour=param;
                                    

                               }
                            

                        /**
                        * field for TotalActualLabourCost
                        */

                        
                                    protected double localTotalActualLabourCost ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localTotalActualLabourCostTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getTotalActualLabourCost(){
                               return localTotalActualLabourCost;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param TotalActualLabourCost
                               */
                               public void setTotalActualLabourCost(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localTotalActualLabourCostTracker = false;
                                              
                                       } else {
                                          localTotalActualLabourCostTracker = true;
                                       }
                                   
                                            this.localTotalActualLabourCost=param;
                                    

                               }
                            

                        /**
                        * field for TotalActualMaterialCost
                        */

                        
                                    protected double localTotalActualMaterialCost ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localTotalActualMaterialCostTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getTotalActualMaterialCost(){
                               return localTotalActualMaterialCost;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param TotalActualMaterialCost
                               */
                               public void setTotalActualMaterialCost(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localTotalActualMaterialCostTracker = false;
                                              
                                       } else {
                                          localTotalActualMaterialCostTracker = true;
                                       }
                                   
                                            this.localTotalActualMaterialCost=param;
                                    

                               }
                            

                        /**
                        * field for TotalActualOtherCost
                        */

                        
                                    protected double localTotalActualOtherCost ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localTotalActualOtherCostTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getTotalActualOtherCost(){
                               return localTotalActualOtherCost;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param TotalActualOtherCost
                               */
                               public void setTotalActualOtherCost(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localTotalActualOtherCostTracker = false;
                                              
                                       } else {
                                          localTotalActualOtherCostTracker = true;
                                       }
                                   
                                            this.localTotalActualOtherCost=param;
                                    

                               }
                            

                        /**
                        * field for TotalActualQuantity
                        */

                        
                                    protected double localTotalActualQuantity ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localTotalActualQuantityTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getTotalActualQuantity(){
                               return localTotalActualQuantity;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param TotalActualQuantity
                               */
                               public void setTotalActualQuantity(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localTotalActualQuantityTracker = false;
                                              
                                       } else {
                                          localTotalActualQuantityTracker = true;
                                       }
                                   
                                            this.localTotalActualQuantity=param;
                                    

                               }
                            

                        /**
                        * field for TotalPlanHour
                        */

                        
                                    protected double localTotalPlanHour ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localTotalPlanHourTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getTotalPlanHour(){
                               return localTotalPlanHour;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param TotalPlanHour
                               */
                               public void setTotalPlanHour(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localTotalPlanHourTracker = false;
                                              
                                       } else {
                                          localTotalPlanHourTracker = true;
                                       }
                                   
                                            this.localTotalPlanHour=param;
                                    

                               }
                            

                        /**
                        * field for TotalPlanLabourCost
                        */

                        
                                    protected double localTotalPlanLabourCost ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localTotalPlanLabourCostTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getTotalPlanLabourCost(){
                               return localTotalPlanLabourCost;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param TotalPlanLabourCost
                               */
                               public void setTotalPlanLabourCost(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localTotalPlanLabourCostTracker = false;
                                              
                                       } else {
                                          localTotalPlanLabourCostTracker = true;
                                       }
                                   
                                            this.localTotalPlanLabourCost=param;
                                    

                               }
                            

                        /**
                        * field for TotalPlanMaterialCost
                        */

                        
                                    protected double localTotalPlanMaterialCost ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localTotalPlanMaterialCostTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getTotalPlanMaterialCost(){
                               return localTotalPlanMaterialCost;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param TotalPlanMaterialCost
                               */
                               public void setTotalPlanMaterialCost(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localTotalPlanMaterialCostTracker = false;
                                              
                                       } else {
                                          localTotalPlanMaterialCostTracker = true;
                                       }
                                   
                                            this.localTotalPlanMaterialCost=param;
                                    

                               }
                            

                        /**
                        * field for TotalPlanOtherCost
                        */

                        
                                    protected double localTotalPlanOtherCost ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localTotalPlanOtherCostTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getTotalPlanOtherCost(){
                               return localTotalPlanOtherCost;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param TotalPlanOtherCost
                               */
                               public void setTotalPlanOtherCost(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localTotalPlanOtherCostTracker = false;
                                              
                                       } else {
                                          localTotalPlanOtherCostTracker = true;
                                       }
                                   
                                            this.localTotalPlanOtherCost=param;
                                    

                               }
                            

                        /**
                        * field for TotalPlanQuantity
                        */

                        
                                    protected double localTotalPlanQuantity ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localTotalPlanQuantityTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getTotalPlanQuantity(){
                               return localTotalPlanQuantity;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param TotalPlanQuantity
                               */
                               public void setTotalPlanQuantity(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localTotalPlanQuantityTracker = false;
                                              
                                       } else {
                                          localTotalPlanQuantityTracker = true;
                                       }
                                   
                                            this.localTotalPlanQuantity=param;
                                    

                               }
                            

                        /**
                        * field for TotalRecoveryTime
                        */

                        
                                    protected java.lang.String localTotalRecoveryTime ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localTotalRecoveryTimeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getTotalRecoveryTime(){
                               return localTotalRecoveryTime;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param TotalRecoveryTime
                               */
                               public void setTotalRecoveryTime(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localTotalRecoveryTimeTracker = true;
                                       } else {
                                          localTotalRecoveryTimeTracker = false;
                                              
                                       }
                                   
                                            this.localTotalRecoveryTime=param;
                                    

                               }
                            

                        /**
                        * field for TotalResponseTime
                        */

                        
                                    protected java.lang.String localTotalResponseTime ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localTotalResponseTimeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getTotalResponseTime(){
                               return localTotalResponseTime;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param TotalResponseTime
                               */
                               public void setTotalResponseTime(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localTotalResponseTimeTracker = true;
                                       } else {
                                          localTotalResponseTimeTracker = false;
                                              
                                       }
                                   
                                            this.localTotalResponseTime=param;
                                    

                               }
                            

                        /**
                        * field for TotalSuspensionTime
                        */

                        
                                    protected java.lang.String localTotalSuspensionTime ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localTotalSuspensionTimeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getTotalSuspensionTime(){
                               return localTotalSuspensionTime;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param TotalSuspensionTime
                               */
                               public void setTotalSuspensionTime(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localTotalSuspensionTimeTracker = true;
                                       } else {
                                          localTotalSuspensionTimeTracker = false;
                                              
                                       }
                                   
                                            this.localTotalSuspensionTime=param;
                                    

                               }
                            

                        /**
                        * field for WoActDelLabourCostVOs
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WoActBolVO[] localWoActDelLabourCostVOs ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoActDelLabourCostVOsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WoActBolVO[]
                           */
                           public  hk.com.mtr.mmis.ws.WoActBolVO[] getWoActDelLabourCostVOs(){
                               return localWoActDelLabourCostVOs;
                           }

                           
                        


                               
                              /**
                               * validate the array for WoActDelLabourCostVOs
                               */
                              protected void validateWoActDelLabourCostVOs(hk.com.mtr.mmis.ws.WoActBolVO[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param WoActDelLabourCostVOs
                              */
                              public void setWoActDelLabourCostVOs(hk.com.mtr.mmis.ws.WoActBolVO[] param){
                              
                                   validateWoActDelLabourCostVOs(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localWoActDelLabourCostVOsTracker = true;
                                          } else {
                                             localWoActDelLabourCostVOsTracker = true;
                                                 
                                          }
                                      
                                      this.localWoActDelLabourCostVOs=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.WoActBolVO
                             */
                             public void addWoActDelLabourCostVOs(hk.com.mtr.mmis.ws.WoActBolVO param){
                                   if (localWoActDelLabourCostVOs == null){
                                   localWoActDelLabourCostVOs = new hk.com.mtr.mmis.ws.WoActBolVO[]{};
                                   }

                            
                                 //update the setting tracker
                                localWoActDelLabourCostVOsTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoActDelLabourCostVOs);
                               list.add(param);
                               this.localWoActDelLabourCostVOs =
                             (hk.com.mtr.mmis.ws.WoActBolVO[])list.toArray(
                            new hk.com.mtr.mmis.ws.WoActBolVO[list.size()]);

                             }
                             

                        /**
                        * field for WoActDelMaterialCostVOs
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WoActBomVO[] localWoActDelMaterialCostVOs ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoActDelMaterialCostVOsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WoActBomVO[]
                           */
                           public  hk.com.mtr.mmis.ws.WoActBomVO[] getWoActDelMaterialCostVOs(){
                               return localWoActDelMaterialCostVOs;
                           }

                           
                        


                               
                              /**
                               * validate the array for WoActDelMaterialCostVOs
                               */
                              protected void validateWoActDelMaterialCostVOs(hk.com.mtr.mmis.ws.WoActBomVO[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param WoActDelMaterialCostVOs
                              */
                              public void setWoActDelMaterialCostVOs(hk.com.mtr.mmis.ws.WoActBomVO[] param){
                              
                                   validateWoActDelMaterialCostVOs(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localWoActDelMaterialCostVOsTracker = true;
                                          } else {
                                             localWoActDelMaterialCostVOsTracker = true;
                                                 
                                          }
                                      
                                      this.localWoActDelMaterialCostVOs=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.WoActBomVO
                             */
                             public void addWoActDelMaterialCostVOs(hk.com.mtr.mmis.ws.WoActBomVO param){
                                   if (localWoActDelMaterialCostVOs == null){
                                   localWoActDelMaterialCostVOs = new hk.com.mtr.mmis.ws.WoActBomVO[]{};
                                   }

                            
                                 //update the setting tracker
                                localWoActDelMaterialCostVOsTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoActDelMaterialCostVOs);
                               list.add(param);
                               this.localWoActDelMaterialCostVOs =
                             (hk.com.mtr.mmis.ws.WoActBomVO[])list.toArray(
                            new hk.com.mtr.mmis.ws.WoActBomVO[list.size()]);

                             }
                             

                        /**
                        * field for WoActDelOtherCostVOs
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WoActBooVO[] localWoActDelOtherCostVOs ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoActDelOtherCostVOsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WoActBooVO[]
                           */
                           public  hk.com.mtr.mmis.ws.WoActBooVO[] getWoActDelOtherCostVOs(){
                               return localWoActDelOtherCostVOs;
                           }

                           
                        


                               
                              /**
                               * validate the array for WoActDelOtherCostVOs
                               */
                              protected void validateWoActDelOtherCostVOs(hk.com.mtr.mmis.ws.WoActBooVO[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param WoActDelOtherCostVOs
                              */
                              public void setWoActDelOtherCostVOs(hk.com.mtr.mmis.ws.WoActBooVO[] param){
                              
                                   validateWoActDelOtherCostVOs(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localWoActDelOtherCostVOsTracker = true;
                                          } else {
                                             localWoActDelOtherCostVOsTracker = true;
                                                 
                                          }
                                      
                                      this.localWoActDelOtherCostVOs=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.WoActBooVO
                             */
                             public void addWoActDelOtherCostVOs(hk.com.mtr.mmis.ws.WoActBooVO param){
                                   if (localWoActDelOtherCostVOs == null){
                                   localWoActDelOtherCostVOs = new hk.com.mtr.mmis.ws.WoActBooVO[]{};
                                   }

                            
                                 //update the setting tracker
                                localWoActDelOtherCostVOsTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoActDelOtherCostVOs);
                               list.add(param);
                               this.localWoActDelOtherCostVOs =
                             (hk.com.mtr.mmis.ws.WoActBooVO[])list.toArray(
                            new hk.com.mtr.mmis.ws.WoActBooVO[list.size()]);

                             }
                             

                        /**
                        * field for WoActLabourCostVOs
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WoActBolVO[] localWoActLabourCostVOs ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoActLabourCostVOsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WoActBolVO[]
                           */
                           public  hk.com.mtr.mmis.ws.WoActBolVO[] getWoActLabourCostVOs(){
                               return localWoActLabourCostVOs;
                           }

                           
                        


                               
                              /**
                               * validate the array for WoActLabourCostVOs
                               */
                              protected void validateWoActLabourCostVOs(hk.com.mtr.mmis.ws.WoActBolVO[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param WoActLabourCostVOs
                              */
                              public void setWoActLabourCostVOs(hk.com.mtr.mmis.ws.WoActBolVO[] param){
                              
                                   validateWoActLabourCostVOs(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localWoActLabourCostVOsTracker = true;
                                          } else {
                                             localWoActLabourCostVOsTracker = true;
                                                 
                                          }
                                      
                                      this.localWoActLabourCostVOs=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.WoActBolVO
                             */
                             public void addWoActLabourCostVOs(hk.com.mtr.mmis.ws.WoActBolVO param){
                                   if (localWoActLabourCostVOs == null){
                                   localWoActLabourCostVOs = new hk.com.mtr.mmis.ws.WoActBolVO[]{};
                                   }

                            
                                 //update the setting tracker
                                localWoActLabourCostVOsTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoActLabourCostVOs);
                               list.add(param);
                               this.localWoActLabourCostVOs =
                             (hk.com.mtr.mmis.ws.WoActBolVO[])list.toArray(
                            new hk.com.mtr.mmis.ws.WoActBolVO[list.size()]);

                             }
                             

                        /**
                        * field for WoActLocationVOs
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.LocationRangeVO[] localWoActLocationVOs ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoActLocationVOsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.LocationRangeVO[]
                           */
                           public  hk.com.mtr.mmis.ws.LocationRangeVO[] getWoActLocationVOs(){
                               return localWoActLocationVOs;
                           }

                           
                        


                               
                              /**
                               * validate the array for WoActLocationVOs
                               */
                              protected void validateWoActLocationVOs(hk.com.mtr.mmis.ws.LocationRangeVO[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param WoActLocationVOs
                              */
                              public void setWoActLocationVOs(hk.com.mtr.mmis.ws.LocationRangeVO[] param){
                              
                                   validateWoActLocationVOs(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localWoActLocationVOsTracker = true;
                                          } else {
                                             localWoActLocationVOsTracker = true;
                                                 
                                          }
                                      
                                      this.localWoActLocationVOs=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.LocationRangeVO
                             */
                             public void addWoActLocationVOs(hk.com.mtr.mmis.ws.LocationRangeVO param){
                                   if (localWoActLocationVOs == null){
                                   localWoActLocationVOs = new hk.com.mtr.mmis.ws.LocationRangeVO[]{};
                                   }

                            
                                 //update the setting tracker
                                localWoActLocationVOsTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoActLocationVOs);
                               list.add(param);
                               this.localWoActLocationVOs =
                             (hk.com.mtr.mmis.ws.LocationRangeVO[])list.toArray(
                            new hk.com.mtr.mmis.ws.LocationRangeVO[list.size()]);

                             }
                             

                        /**
                        * field for WoActMaterialCostVOs
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WoActBomVO[] localWoActMaterialCostVOs ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoActMaterialCostVOsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WoActBomVO[]
                           */
                           public  hk.com.mtr.mmis.ws.WoActBomVO[] getWoActMaterialCostVOs(){
                               return localWoActMaterialCostVOs;
                           }

                           
                        


                               
                              /**
                               * validate the array for WoActMaterialCostVOs
                               */
                              protected void validateWoActMaterialCostVOs(hk.com.mtr.mmis.ws.WoActBomVO[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param WoActMaterialCostVOs
                              */
                              public void setWoActMaterialCostVOs(hk.com.mtr.mmis.ws.WoActBomVO[] param){
                              
                                   validateWoActMaterialCostVOs(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localWoActMaterialCostVOsTracker = true;
                                          } else {
                                             localWoActMaterialCostVOsTracker = true;
                                                 
                                          }
                                      
                                      this.localWoActMaterialCostVOs=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.WoActBomVO
                             */
                             public void addWoActMaterialCostVOs(hk.com.mtr.mmis.ws.WoActBomVO param){
                                   if (localWoActMaterialCostVOs == null){
                                   localWoActMaterialCostVOs = new hk.com.mtr.mmis.ws.WoActBomVO[]{};
                                   }

                            
                                 //update the setting tracker
                                localWoActMaterialCostVOsTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoActMaterialCostVOs);
                               list.add(param);
                               this.localWoActMaterialCostVOs =
                             (hk.com.mtr.mmis.ws.WoActBomVO[])list.toArray(
                            new hk.com.mtr.mmis.ws.WoActBomVO[list.size()]);

                             }
                             

                        /**
                        * field for WoActOtherCostVOs
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WoActBooVO[] localWoActOtherCostVOs ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoActOtherCostVOsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WoActBooVO[]
                           */
                           public  hk.com.mtr.mmis.ws.WoActBooVO[] getWoActOtherCostVOs(){
                               return localWoActOtherCostVOs;
                           }

                           
                        


                               
                              /**
                               * validate the array for WoActOtherCostVOs
                               */
                              protected void validateWoActOtherCostVOs(hk.com.mtr.mmis.ws.WoActBooVO[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param WoActOtherCostVOs
                              */
                              public void setWoActOtherCostVOs(hk.com.mtr.mmis.ws.WoActBooVO[] param){
                              
                                   validateWoActOtherCostVOs(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localWoActOtherCostVOsTracker = true;
                                          } else {
                                             localWoActOtherCostVOsTracker = true;
                                                 
                                          }
                                      
                                      this.localWoActOtherCostVOs=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.WoActBooVO
                             */
                             public void addWoActOtherCostVOs(hk.com.mtr.mmis.ws.WoActBooVO param){
                                   if (localWoActOtherCostVOs == null){
                                   localWoActOtherCostVOs = new hk.com.mtr.mmis.ws.WoActBooVO[]{};
                                   }

                            
                                 //update the setting tracker
                                localWoActOtherCostVOsTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoActOtherCostVOs);
                               list.add(param);
                               this.localWoActOtherCostVOs =
                             (hk.com.mtr.mmis.ws.WoActBooVO[])list.toArray(
                            new hk.com.mtr.mmis.ws.WoActBooVO[list.size()]);

                             }
                             

                        /**
                        * field for WoDesp
                        */

                        
                                    protected java.lang.String localWoDesp ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoDespTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getWoDesp(){
                               return localWoDesp;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WoDesp
                               */
                               public void setWoDesp(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localWoDespTracker = true;
                                       } else {
                                          localWoDespTracker = false;
                                              
                                       }
                                   
                                            this.localWoDesp=param;
                                    

                               }
                            

                        /**
                        * field for WoEquipAssocs
                        * This was an Array!
                        */

                        
                                    protected long[] localWoEquipAssocs ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoEquipAssocsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long[]
                           */
                           public  long[] getWoEquipAssocs(){
                               return localWoEquipAssocs;
                           }

                           
                        


                               
                              /**
                               * validate the array for WoEquipAssocs
                               */
                              protected void validateWoEquipAssocs(long[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param WoEquipAssocs
                              */
                              public void setWoEquipAssocs(long[] param){
                              
                                   validateWoEquipAssocs(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localWoEquipAssocsTracker = true;
                                          } else {
                                             localWoEquipAssocsTracker = true;
                                                 
                                          }
                                      
                                      this.localWoEquipAssocs=param;
                              }

                               
                             

                        /**
                        * field for WoFailureDetailVOs
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WoFailureDetailVO[] localWoFailureDetailVOs ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoFailureDetailVOsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WoFailureDetailVO[]
                           */
                           public  hk.com.mtr.mmis.ws.WoFailureDetailVO[] getWoFailureDetailVOs(){
                               return localWoFailureDetailVOs;
                           }

                           
                        


                               
                              /**
                               * validate the array for WoFailureDetailVOs
                               */
                              protected void validateWoFailureDetailVOs(hk.com.mtr.mmis.ws.WoFailureDetailVO[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param WoFailureDetailVOs
                              */
                              public void setWoFailureDetailVOs(hk.com.mtr.mmis.ws.WoFailureDetailVO[] param){
                              
                                   validateWoFailureDetailVOs(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localWoFailureDetailVOsTracker = true;
                                          } else {
                                             localWoFailureDetailVOsTracker = true;
                                                 
                                          }
                                      
                                      this.localWoFailureDetailVOs=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.WoFailureDetailVO
                             */
                             public void addWoFailureDetailVOs(hk.com.mtr.mmis.ws.WoFailureDetailVO param){
                                   if (localWoFailureDetailVOs == null){
                                   localWoFailureDetailVOs = new hk.com.mtr.mmis.ws.WoFailureDetailVO[]{};
                                   }

                            
                                 //update the setting tracker
                                localWoFailureDetailVOsTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoFailureDetailVOs);
                               list.add(param);
                               this.localWoFailureDetailVOs =
                             (hk.com.mtr.mmis.ws.WoFailureDetailVO[])list.toArray(
                            new hk.com.mtr.mmis.ws.WoFailureDetailVO[list.size()]);

                             }
                             

                        /**
                        * field for WoFailureInfoVO
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WoFailureInfoVO localWoFailureInfoVO ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoFailureInfoVOTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WoFailureInfoVO
                           */
                           public  hk.com.mtr.mmis.ws.WoFailureInfoVO getWoFailureInfoVO(){
                               return localWoFailureInfoVO;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WoFailureInfoVO
                               */
                               public void setWoFailureInfoVO(hk.com.mtr.mmis.ws.WoFailureInfoVO param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localWoFailureInfoVOTracker = true;
                                       } else {
                                          localWoFailureInfoVOTracker = false;
                                              
                                       }
                                   
                                            this.localWoFailureInfoVO=param;
                                    

                               }
                            

                        /**
                        * field for WoFollowupActionVOs
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WoFollowupActionVO[] localWoFollowupActionVOs ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoFollowupActionVOsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WoFollowupActionVO[]
                           */
                           public  hk.com.mtr.mmis.ws.WoFollowupActionVO[] getWoFollowupActionVOs(){
                               return localWoFollowupActionVOs;
                           }

                           
                        


                               
                              /**
                               * validate the array for WoFollowupActionVOs
                               */
                              protected void validateWoFollowupActionVOs(hk.com.mtr.mmis.ws.WoFollowupActionVO[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param WoFollowupActionVOs
                              */
                              public void setWoFollowupActionVOs(hk.com.mtr.mmis.ws.WoFollowupActionVO[] param){
                              
                                   validateWoFollowupActionVOs(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localWoFollowupActionVOsTracker = true;
                                          } else {
                                             localWoFollowupActionVOsTracker = true;
                                                 
                                          }
                                      
                                      this.localWoFollowupActionVOs=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.WoFollowupActionVO
                             */
                             public void addWoFollowupActionVOs(hk.com.mtr.mmis.ws.WoFollowupActionVO param){
                                   if (localWoFollowupActionVOs == null){
                                   localWoFollowupActionVOs = new hk.com.mtr.mmis.ws.WoFollowupActionVO[]{};
                                   }

                            
                                 //update the setting tracker
                                localWoFollowupActionVOsTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoFollowupActionVOs);
                               list.add(param);
                               this.localWoFollowupActionVOs =
                             (hk.com.mtr.mmis.ws.WoFollowupActionVO[])list.toArray(
                            new hk.com.mtr.mmis.ws.WoFollowupActionVO[list.size()]);

                             }
                             

                        /**
                        * field for WoJobRequirementVOs
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WoJobRequirementVO[] localWoJobRequirementVOs ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoJobRequirementVOsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WoJobRequirementVO[]
                           */
                           public  hk.com.mtr.mmis.ws.WoJobRequirementVO[] getWoJobRequirementVOs(){
                               return localWoJobRequirementVOs;
                           }

                           
                        


                               
                              /**
                               * validate the array for WoJobRequirementVOs
                               */
                              protected void validateWoJobRequirementVOs(hk.com.mtr.mmis.ws.WoJobRequirementVO[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param WoJobRequirementVOs
                              */
                              public void setWoJobRequirementVOs(hk.com.mtr.mmis.ws.WoJobRequirementVO[] param){
                              
                                   validateWoJobRequirementVOs(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localWoJobRequirementVOsTracker = true;
                                          } else {
                                             localWoJobRequirementVOsTracker = true;
                                                 
                                          }
                                      
                                      this.localWoJobRequirementVOs=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.WoJobRequirementVO
                             */
                             public void addWoJobRequirementVOs(hk.com.mtr.mmis.ws.WoJobRequirementVO param){
                                   if (localWoJobRequirementVOs == null){
                                   localWoJobRequirementVOs = new hk.com.mtr.mmis.ws.WoJobRequirementVO[]{};
                                   }

                            
                                 //update the setting tracker
                                localWoJobRequirementVOsTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoJobRequirementVOs);
                               list.add(param);
                               this.localWoJobRequirementVOs =
                             (hk.com.mtr.mmis.ws.WoJobRequirementVO[])list.toArray(
                            new hk.com.mtr.mmis.ws.WoJobRequirementVO[list.size()]);

                             }
                             

                        /**
                        * field for WoNo
                        */

                        
                                    protected java.lang.String localWoNo ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoNoTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getWoNo(){
                               return localWoNo;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WoNo
                               */
                               public void setWoNo(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localWoNoTracker = true;
                                       } else {
                                          localWoNoTracker = false;
                                              
                                       }
                                   
                                            this.localWoNo=param;
                                    

                               }
                            

                        /**
                        * field for WoPlanLabourCostVOs
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WoPlanBolVO[] localWoPlanLabourCostVOs ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoPlanLabourCostVOsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WoPlanBolVO[]
                           */
                           public  hk.com.mtr.mmis.ws.WoPlanBolVO[] getWoPlanLabourCostVOs(){
                               return localWoPlanLabourCostVOs;
                           }

                           
                        


                               
                              /**
                               * validate the array for WoPlanLabourCostVOs
                               */
                              protected void validateWoPlanLabourCostVOs(hk.com.mtr.mmis.ws.WoPlanBolVO[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param WoPlanLabourCostVOs
                              */
                              public void setWoPlanLabourCostVOs(hk.com.mtr.mmis.ws.WoPlanBolVO[] param){
                              
                                   validateWoPlanLabourCostVOs(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localWoPlanLabourCostVOsTracker = true;
                                          } else {
                                             localWoPlanLabourCostVOsTracker = true;
                                                 
                                          }
                                      
                                      this.localWoPlanLabourCostVOs=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.WoPlanBolVO
                             */
                             public void addWoPlanLabourCostVOs(hk.com.mtr.mmis.ws.WoPlanBolVO param){
                                   if (localWoPlanLabourCostVOs == null){
                                   localWoPlanLabourCostVOs = new hk.com.mtr.mmis.ws.WoPlanBolVO[]{};
                                   }

                            
                                 //update the setting tracker
                                localWoPlanLabourCostVOsTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoPlanLabourCostVOs);
                               list.add(param);
                               this.localWoPlanLabourCostVOs =
                             (hk.com.mtr.mmis.ws.WoPlanBolVO[])list.toArray(
                            new hk.com.mtr.mmis.ws.WoPlanBolVO[list.size()]);

                             }
                             

                        /**
                        * field for WoPlanLocationVOs
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.LocationRangeVO[] localWoPlanLocationVOs ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoPlanLocationVOsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.LocationRangeVO[]
                           */
                           public  hk.com.mtr.mmis.ws.LocationRangeVO[] getWoPlanLocationVOs(){
                               return localWoPlanLocationVOs;
                           }

                           
                        


                               
                              /**
                               * validate the array for WoPlanLocationVOs
                               */
                              protected void validateWoPlanLocationVOs(hk.com.mtr.mmis.ws.LocationRangeVO[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param WoPlanLocationVOs
                              */
                              public void setWoPlanLocationVOs(hk.com.mtr.mmis.ws.LocationRangeVO[] param){
                              
                                   validateWoPlanLocationVOs(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localWoPlanLocationVOsTracker = true;
                                          } else {
                                             localWoPlanLocationVOsTracker = true;
                                                 
                                          }
                                      
                                      this.localWoPlanLocationVOs=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.LocationRangeVO
                             */
                             public void addWoPlanLocationVOs(hk.com.mtr.mmis.ws.LocationRangeVO param){
                                   if (localWoPlanLocationVOs == null){
                                   localWoPlanLocationVOs = new hk.com.mtr.mmis.ws.LocationRangeVO[]{};
                                   }

                            
                                 //update the setting tracker
                                localWoPlanLocationVOsTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoPlanLocationVOs);
                               list.add(param);
                               this.localWoPlanLocationVOs =
                             (hk.com.mtr.mmis.ws.LocationRangeVO[])list.toArray(
                            new hk.com.mtr.mmis.ws.LocationRangeVO[list.size()]);

                             }
                             

                        /**
                        * field for WoPlanMaterialCostVOs
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WoPlanBomVO[] localWoPlanMaterialCostVOs ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoPlanMaterialCostVOsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WoPlanBomVO[]
                           */
                           public  hk.com.mtr.mmis.ws.WoPlanBomVO[] getWoPlanMaterialCostVOs(){
                               return localWoPlanMaterialCostVOs;
                           }

                           
                        


                               
                              /**
                               * validate the array for WoPlanMaterialCostVOs
                               */
                              protected void validateWoPlanMaterialCostVOs(hk.com.mtr.mmis.ws.WoPlanBomVO[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param WoPlanMaterialCostVOs
                              */
                              public void setWoPlanMaterialCostVOs(hk.com.mtr.mmis.ws.WoPlanBomVO[] param){
                              
                                   validateWoPlanMaterialCostVOs(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localWoPlanMaterialCostVOsTracker = true;
                                          } else {
                                             localWoPlanMaterialCostVOsTracker = true;
                                                 
                                          }
                                      
                                      this.localWoPlanMaterialCostVOs=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.WoPlanBomVO
                             */
                             public void addWoPlanMaterialCostVOs(hk.com.mtr.mmis.ws.WoPlanBomVO param){
                                   if (localWoPlanMaterialCostVOs == null){
                                   localWoPlanMaterialCostVOs = new hk.com.mtr.mmis.ws.WoPlanBomVO[]{};
                                   }

                            
                                 //update the setting tracker
                                localWoPlanMaterialCostVOsTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoPlanMaterialCostVOs);
                               list.add(param);
                               this.localWoPlanMaterialCostVOs =
                             (hk.com.mtr.mmis.ws.WoPlanBomVO[])list.toArray(
                            new hk.com.mtr.mmis.ws.WoPlanBomVO[list.size()]);

                             }
                             

                        /**
                        * field for WoPlanOtherCostVOs
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WoPlanBooVO[] localWoPlanOtherCostVOs ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoPlanOtherCostVOsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WoPlanBooVO[]
                           */
                           public  hk.com.mtr.mmis.ws.WoPlanBooVO[] getWoPlanOtherCostVOs(){
                               return localWoPlanOtherCostVOs;
                           }

                           
                        


                               
                              /**
                               * validate the array for WoPlanOtherCostVOs
                               */
                              protected void validateWoPlanOtherCostVOs(hk.com.mtr.mmis.ws.WoPlanBooVO[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param WoPlanOtherCostVOs
                              */
                              public void setWoPlanOtherCostVOs(hk.com.mtr.mmis.ws.WoPlanBooVO[] param){
                              
                                   validateWoPlanOtherCostVOs(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localWoPlanOtherCostVOsTracker = true;
                                          } else {
                                             localWoPlanOtherCostVOsTracker = true;
                                                 
                                          }
                                      
                                      this.localWoPlanOtherCostVOs=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.WoPlanBooVO
                             */
                             public void addWoPlanOtherCostVOs(hk.com.mtr.mmis.ws.WoPlanBooVO param){
                                   if (localWoPlanOtherCostVOs == null){
                                   localWoPlanOtherCostVOs = new hk.com.mtr.mmis.ws.WoPlanBooVO[]{};
                                   }

                            
                                 //update the setting tracker
                                localWoPlanOtherCostVOsTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoPlanOtherCostVOs);
                               list.add(param);
                               this.localWoPlanOtherCostVOs =
                             (hk.com.mtr.mmis.ws.WoPlanBooVO[])list.toArray(
                            new hk.com.mtr.mmis.ws.WoPlanBooVO[list.size()]);

                             }
                             

                        /**
                        * field for WoRecoveryVO
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WoRecoveryVO localWoRecoveryVO ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoRecoveryVOTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WoRecoveryVO
                           */
                           public  hk.com.mtr.mmis.ws.WoRecoveryVO getWoRecoveryVO(){
                               return localWoRecoveryVO;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WoRecoveryVO
                               */
                               public void setWoRecoveryVO(hk.com.mtr.mmis.ws.WoRecoveryVO param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localWoRecoveryVOTracker = true;
                                       } else {
                                          localWoRecoveryVOTracker = false;
                                              
                                       }
                                   
                                            this.localWoRecoveryVO=param;
                                    

                               }
                            

                        /**
                        * field for WoStatusHistoryVOs
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WoStatusHistoryVO[] localWoStatusHistoryVOs ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoStatusHistoryVOsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WoStatusHistoryVO[]
                           */
                           public  hk.com.mtr.mmis.ws.WoStatusHistoryVO[] getWoStatusHistoryVOs(){
                               return localWoStatusHistoryVOs;
                           }

                           
                        


                               
                              /**
                               * validate the array for WoStatusHistoryVOs
                               */
                              protected void validateWoStatusHistoryVOs(hk.com.mtr.mmis.ws.WoStatusHistoryVO[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param WoStatusHistoryVOs
                              */
                              public void setWoStatusHistoryVOs(hk.com.mtr.mmis.ws.WoStatusHistoryVO[] param){
                              
                                   validateWoStatusHistoryVOs(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localWoStatusHistoryVOsTracker = true;
                                          } else {
                                             localWoStatusHistoryVOsTracker = true;
                                                 
                                          }
                                      
                                      this.localWoStatusHistoryVOs=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.WoStatusHistoryVO
                             */
                             public void addWoStatusHistoryVOs(hk.com.mtr.mmis.ws.WoStatusHistoryVO param){
                                   if (localWoStatusHistoryVOs == null){
                                   localWoStatusHistoryVOs = new hk.com.mtr.mmis.ws.WoStatusHistoryVO[]{};
                                   }

                            
                                 //update the setting tracker
                                localWoStatusHistoryVOsTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoStatusHistoryVOs);
                               list.add(param);
                               this.localWoStatusHistoryVOs =
                             (hk.com.mtr.mmis.ws.WoStatusHistoryVO[])list.toArray(
                            new hk.com.mtr.mmis.ws.WoStatusHistoryVO[list.size()]);

                             }
                             

                        /**
                        * field for WoSuspensionVOs
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WoSuspensionVO[] localWoSuspensionVOs ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoSuspensionVOsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WoSuspensionVO[]
                           */
                           public  hk.com.mtr.mmis.ws.WoSuspensionVO[] getWoSuspensionVOs(){
                               return localWoSuspensionVOs;
                           }

                           
                        


                               
                              /**
                               * validate the array for WoSuspensionVOs
                               */
                              protected void validateWoSuspensionVOs(hk.com.mtr.mmis.ws.WoSuspensionVO[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param WoSuspensionVOs
                              */
                              public void setWoSuspensionVOs(hk.com.mtr.mmis.ws.WoSuspensionVO[] param){
                              
                                   validateWoSuspensionVOs(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localWoSuspensionVOsTracker = true;
                                          } else {
                                             localWoSuspensionVOsTracker = true;
                                                 
                                          }
                                      
                                      this.localWoSuspensionVOs=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.WoSuspensionVO
                             */
                             public void addWoSuspensionVOs(hk.com.mtr.mmis.ws.WoSuspensionVO param){
                                   if (localWoSuspensionVOs == null){
                                   localWoSuspensionVOs = new hk.com.mtr.mmis.ws.WoSuspensionVO[]{};
                                   }

                            
                                 //update the setting tracker
                                localWoSuspensionVOsTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoSuspensionVOs);
                               list.add(param);
                               this.localWoSuspensionVOs =
                             (hk.com.mtr.mmis.ws.WoSuspensionVO[])list.toArray(
                            new hk.com.mtr.mmis.ws.WoSuspensionVO[list.size()]);

                             }
                             

                        /**
                        * field for WoTaskVOs
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WoTaskVO[] localWoTaskVOs ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoTaskVOsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WoTaskVO[]
                           */
                           public  hk.com.mtr.mmis.ws.WoTaskVO[] getWoTaskVOs(){
                               return localWoTaskVOs;
                           }

                           
                        


                               
                              /**
                               * validate the array for WoTaskVOs
                               */
                              protected void validateWoTaskVOs(hk.com.mtr.mmis.ws.WoTaskVO[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param WoTaskVOs
                              */
                              public void setWoTaskVOs(hk.com.mtr.mmis.ws.WoTaskVO[] param){
                              
                                   validateWoTaskVOs(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localWoTaskVOsTracker = true;
                                          } else {
                                             localWoTaskVOsTracker = true;
                                                 
                                          }
                                      
                                      this.localWoTaskVOs=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.WoTaskVO
                             */
                             public void addWoTaskVOs(hk.com.mtr.mmis.ws.WoTaskVO param){
                                   if (localWoTaskVOs == null){
                                   localWoTaskVOs = new hk.com.mtr.mmis.ws.WoTaskVO[]{};
                                   }

                            
                                 //update the setting tracker
                                localWoTaskVOsTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localWoTaskVOs);
                               list.add(param);
                               this.localWoTaskVOs =
                             (hk.com.mtr.mmis.ws.WoTaskVO[])list.toArray(
                            new hk.com.mtr.mmis.ws.WoTaskVO[list.size()]);

                             }
                             

                        /**
                        * field for WorkGrp
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WorkGrp localWorkGrp ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWorkGrpTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WorkGrp
                           */
                           public  hk.com.mtr.mmis.ws.WorkGrp getWorkGrp(){
                               return localWorkGrp;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WorkGrp
                               */
                               public void setWorkGrp(hk.com.mtr.mmis.ws.WorkGrp param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localWorkGrpTracker = true;
                                       } else {
                                          localWorkGrpTracker = false;
                                              
                                       }
                                   
                                            this.localWorkGrp=param;
                                    

                               }
                            

                        /**
                        * field for WorkRequests
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WorkRequest[] localWorkRequests ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWorkRequestsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WorkRequest[]
                           */
                           public  hk.com.mtr.mmis.ws.WorkRequest[] getWorkRequests(){
                               return localWorkRequests;
                           }

                           
                        


                               
                              /**
                               * validate the array for WorkRequests
                               */
                              protected void validateWorkRequests(hk.com.mtr.mmis.ws.WorkRequest[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param WorkRequests
                              */
                              public void setWorkRequests(hk.com.mtr.mmis.ws.WorkRequest[] param){
                              
                                   validateWorkRequests(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localWorkRequestsTracker = true;
                                          } else {
                                             localWorkRequestsTracker = true;
                                                 
                                          }
                                      
                                      this.localWorkRequests=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.WorkRequest
                             */
                             public void addWorkRequests(hk.com.mtr.mmis.ws.WorkRequest param){
                                   if (localWorkRequests == null){
                                   localWorkRequests = new hk.com.mtr.mmis.ws.WorkRequest[]{};
                                   }

                            
                                 //update the setting tracker
                                localWorkRequestsTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localWorkRequests);
                               list.add(param);
                               this.localWorkRequests =
                             (hk.com.mtr.mmis.ws.WorkRequest[])list.toArray(
                            new hk.com.mtr.mmis.ws.WorkRequest[list.size()]);

                             }
                             

                        /**
                        * field for WorkTimeRequire
                        */

                        
                                    protected java.lang.String localWorkTimeRequire ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWorkTimeRequireTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getWorkTimeRequire(){
                               return localWorkTimeRequire;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WorkTimeRequire
                               */
                               public void setWorkTimeRequire(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localWorkTimeRequireTracker = true;
                                       } else {
                                          localWorkTimeRequireTracker = false;
                                              
                                       }
                                   
                                            this.localWorkTimeRequire=param;
                                    

                               }
                            

                        /**
                        * field for WrId
                        */

                        
                                    protected java.lang.String localWrId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWrIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getWrId(){
                               return localWrId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WrId
                               */
                               public void setWrId(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localWrIdTracker = true;
                                       } else {
                                          localWrIdTracker = false;
                                              
                                       }
                                   
                                            this.localWrId=param;
                                    

                               }
                            

                        /**
                        * field for EquipmentReferenceName
                        */

                        
                                    protected java.lang.String localEquipmentReferenceName ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localEquipmentReferenceNameTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getEquipmentReferenceName(){
                               return localEquipmentReferenceName;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param EquipmentReferenceName
                               */
                               public void setEquipmentReferenceName(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localEquipmentReferenceNameTracker = true;
                                       } else {
                                          localEquipmentReferenceNameTracker = false;
                                              
                                       }
                                   
                                            this.localEquipmentReferenceName=param;
                                    

                               }
                            

                        /**
                        * field for Segment1
                        */

                        
                                    protected java.lang.String localSegment1 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSegment1Tracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getSegment1(){
                               return localSegment1;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Segment1
                               */
                               public void setSegment1(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localSegment1Tracker = true;
                                       } else {
                                          localSegment1Tracker = false;
                                              
                                       }
                                   
                                            this.localSegment1=param;
                                    

                               }
                            

                        /**
                        * field for Segment2
                        */

                        
                                    protected java.lang.String localSegment2 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSegment2Tracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getSegment2(){
                               return localSegment2;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Segment2
                               */
                               public void setSegment2(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localSegment2Tracker = true;
                                       } else {
                                          localSegment2Tracker = false;
                                              
                                       }
                                   
                                            this.localSegment2=param;
                                    

                               }
                            

                        /**
                        * field for Segment3
                        */

                        
                                    protected java.lang.String localSegment3 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSegment3Tracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getSegment3(){
                               return localSegment3;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Segment3
                               */
                               public void setSegment3(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localSegment3Tracker = true;
                                       } else {
                                          localSegment3Tracker = false;
                                              
                                       }
                                   
                                            this.localSegment3=param;
                                    

                               }
                            

                        /**
                        * field for Segment4
                        */

                        
                                    protected java.lang.String localSegment4 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSegment4Tracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getSegment4(){
                               return localSegment4;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Segment4
                               */
                               public void setSegment4(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localSegment4Tracker = true;
                                       } else {
                                          localSegment4Tracker = false;
                                              
                                       }
                                   
                                            this.localSegment4=param;
                                    

                               }
                            

                        /**
                        * field for TotalLabourCostVariance
                        */

                        
                                    protected double localTotalLabourCostVariance ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localTotalLabourCostVarianceTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getTotalLabourCostVariance(){
                               return localTotalLabourCostVariance;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param TotalLabourCostVariance
                               */
                               public void setTotalLabourCostVariance(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localTotalLabourCostVarianceTracker = false;
                                              
                                       } else {
                                          localTotalLabourCostVarianceTracker = true;
                                       }
                                   
                                            this.localTotalLabourCostVariance=param;
                                    

                               }
                            

                        /**
                        * field for TotalMaterialsCostVariance
                        */

                        
                                    protected double localTotalMaterialsCostVariance ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localTotalMaterialsCostVarianceTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getTotalMaterialsCostVariance(){
                               return localTotalMaterialsCostVariance;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param TotalMaterialsCostVariance
                               */
                               public void setTotalMaterialsCostVariance(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localTotalMaterialsCostVarianceTracker = false;
                                              
                                       } else {
                                          localTotalMaterialsCostVarianceTracker = true;
                                       }
                                   
                                            this.localTotalMaterialsCostVariance=param;
                                    

                               }
                            

                        /**
                        * field for TotalOtherCostVariance
                        */

                        
                                    protected double localTotalOtherCostVariance ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localTotalOtherCostVarianceTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getTotalOtherCostVariance(){
                               return localTotalOtherCostVariance;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param TotalOtherCostVariance
                               */
                               public void setTotalOtherCostVariance(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localTotalOtherCostVarianceTracker = false;
                                              
                                       } else {
                                          localTotalOtherCostVarianceTracker = true;
                                       }
                                   
                                            this.localTotalOtherCostVariance=param;
                                    

                               }
                            

                        /**
                        * field for FinalCostFlag
                        */

                        
                                    protected java.lang.String localFinalCostFlag ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localFinalCostFlagTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getFinalCostFlag(){
                               return localFinalCostFlag;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param FinalCostFlag
                               */
                               public void setFinalCostFlag(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localFinalCostFlagTracker = true;
                                       } else {
                                          localFinalCostFlagTracker = false;
                                              
                                       }
                                   
                                            this.localFinalCostFlag=param;
                                    

                               }
                            

     /**
     * isReaderMTOMAware
     * @return true if the reader supports MTOM
     */
   public static boolean isReaderMTOMAware(javax.xml.stream.XMLStreamReader reader) {
        boolean isReaderMTOMAware = false;
        
        try{
          isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader.getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
        }catch(java.lang.IllegalArgumentException e){
          isReaderMTOMAware = false;
        }
        return isReaderMTOMAware;
   }
     
     
        /**
        *
        * @param parentQName
        * @param factory
        * @return org.apache.axiom.om.OMElement
        */
       public org.apache.axiom.om.OMElement getOMElement (
               final javax.xml.namespace.QName parentQName,
               final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException{


        
               org.apache.axiom.om.OMDataSource dataSource =
                       new org.apache.axis2.databinding.ADBDataSource(this,parentQName){

                 public void serialize(org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
                       WorkOrderVO.this.serialize(parentQName,factory,xmlWriter);
                 }
               };
               return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
               parentQName,factory,dataSource);
            
       }

         public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
                           serialize(parentQName,factory,xmlWriter,false);
         }

         public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               boolean serializeType)
            throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
            
                


                java.lang.String prefix = null;
                java.lang.String namespace = null;
                

                    prefix = parentQName.getPrefix();
                    namespace = parentQName.getNamespaceURI();

                    if ((namespace != null) && (namespace.trim().length() > 0)) {
                        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                        if (writerPrefix != null) {
                            xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                        } else {
                            if (prefix == null) {
                                prefix = generatePrefix(namespace);
                            }

                            xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                            xmlWriter.writeNamespace(prefix, namespace);
                            xmlWriter.setPrefix(prefix, namespace);
                        }
                    } else {
                        xmlWriter.writeStartElement(parentQName.getLocalPart());
                    }
                

                   java.lang.String namespacePrefix = registerPrefix(xmlWriter,"http://ws.mmis.mtr.com.hk/");
                   if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0)){
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           namespacePrefix+":workOrderVO",
                           xmlWriter);
                   } else {
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           "workOrderVO",
                           xmlWriter);
                   }

                if (localActionTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"action", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"action");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("action");
                                    }
                                

                                          if (localAction==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("action cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localAction);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localActualCmplDateTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"actualCmplDate", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"actualCmplDate");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("actualCmplDate");
                                    }
                                

                                          if (localActualCmplDate==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("actualCmplDate cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localActualCmplDate));
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localActualStartDateTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"actualStartDate", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"actualStartDate");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("actualStartDate");
                                    }
                                

                                          if (localActualStartDate==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("actualStartDate cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localActualStartDate));
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localActualStartTimeTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"actualStartTime", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"actualStartTime");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("actualStartTime");
                                    }
                                

                                          if (localActualStartTime==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("actualStartTime cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localActualStartTime);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localChildWolistTracker){
                                       if (localChildWolist!=null){
                                            for (int i = 0;i < localChildWolist.length;i++){
                                                if (localChildWolist[i] != null){
                                                 localChildWolist[i].serialize(new javax.xml.namespace.QName("","childWolist"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"childWolist", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"childWolist");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("childWolist");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"childWolist", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"childWolist");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("childWolist");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localCmpltmnryContractNoTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"cmpltmnryContractNo", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"cmpltmnryContractNo");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("cmpltmnryContractNo");
                                    }
                                

                                          if (localCmpltmnryContractNo==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("cmpltmnryContractNo cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localCmpltmnryContractNo);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localContractDespTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"contractDesp", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"contractDesp");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("contractDesp");
                                    }
                                

                                          if (localContractDesp==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("contractDesp cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localContractDesp);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localContractNoTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"contractNo", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"contractNo");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("contractNo");
                                    }
                                

                                          if (localContractNo==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("contractNo cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localContractNo);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localContractorTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"contractor", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"contractor");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("contractor");
                                    }
                                

                                          if (localContractor==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("contractor cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localContractor);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localContractorInChargeTracker){
                                            if (localContractorInCharge==null){
                                                 throw new org.apache.axis2.databinding.ADBException("contractorInCharge cannot be null!!");
                                            }
                                           localContractorInCharge.serialize(new javax.xml.namespace.QName("","contractorInCharge"),
                                               factory,xmlWriter);
                                        } if (localDetailIDsTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"detailIDs", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"detailIDs");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("detailIDs");
                                    }
                                

                                          if (localDetailIDs==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("detailIDs cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localDetailIDs);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localDetailLocTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"detailLoc", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"detailLoc");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("detailLoc");
                                    }
                                

                                          if (localDetailLoc==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("detailLoc cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localDetailLoc);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localEarPlanStartDateTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"earPlanStartDate", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"earPlanStartDate");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("earPlanStartDate");
                                    }
                                

                                          if (localEarPlanStartDate==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("earPlanStartDate cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localEarPlanStartDate));
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localEngineerInChargeTracker){
                                            if (localEngineerInCharge==null){
                                                 throw new org.apache.axis2.databinding.ADBException("engineerInCharge cannot be null!!");
                                            }
                                           localEngineerInCharge.serialize(new javax.xml.namespace.QName("","engineerInCharge"),
                                               factory,xmlWriter);
                                        } if (localEquipClassTracker){
                                            if (localEquipClass==null){
                                                 throw new org.apache.axis2.databinding.ADBException("equipClass cannot be null!!");
                                            }
                                           localEquipClass.serialize(new javax.xml.namespace.QName("","equipClass"),
                                               factory,xmlWriter);
                                        } if (localEquipDownTimeTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"equipDownTime", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"equipDownTime");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("equipDownTime");
                                    }
                                

                                          if (localEquipDownTime==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("equipDownTime cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localEquipDownTime);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localEquipmentTracker){
                                            if (localEquipment==null){
                                                 throw new org.apache.axis2.databinding.ADBException("equipment cannot be null!!");
                                            }
                                           localEquipment.serialize(new javax.xml.namespace.QName("","equipment"),
                                               factory,xmlWriter);
                                        } if (localFinalizedIndTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"finalizedInd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"finalizedInd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("finalizedInd");
                                    }
                                

                                          if (localFinalizedInd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("finalizedInd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localFinalizedInd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcFinanceRefNoCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcFinanceRefNoCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcFinanceRefNoCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcFinanceRefNoCd");
                                    }
                                

                                          if (localGcFinanceRefNoCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcFinanceRefNoCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcFinanceRefNoCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcPriorityCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcPriorityCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcPriorityCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcPriorityCd");
                                    }
                                

                                          if (localGcPriorityCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcPriorityCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcPriorityCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcProjectNoCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcProjectNoCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcProjectNoCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcProjectNoCd");
                                    }
                                

                                          if (localGcProjectNoCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcProjectNoCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcProjectNoCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcProjectTaskNoCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcProjectTaskNoCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcProjectTaskNoCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcProjectTaskNoCd");
                                    }
                                

                                          if (localGcProjectTaskNoCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcProjectTaskNoCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcProjectTaskNoCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcSvcBreakdownCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcSvcBreakdownCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcSvcBreakdownCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcSvcBreakdownCd");
                                    }
                                

                                          if (localGcSvcBreakdownCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcSvcBreakdownCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcSvcBreakdownCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcWorkNatureLv1CdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcWorkNatureLv1Cd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcWorkNatureLv1Cd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcWorkNatureLv1Cd");
                                    }
                                

                                          if (localGcWorkNatureLv1Cd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcWorkNatureLv1Cd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcWorkNatureLv1Cd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcWorkNatureLv2CdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcWorkNatureLv2Cd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcWorkNatureLv2Cd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcWorkNatureLv2Cd");
                                    }
                                

                                          if (localGcWorkNatureLv2Cd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcWorkNatureLv2Cd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcWorkNatureLv2Cd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localIncidentNumberTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"incidentNumber", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"incidentNumber");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("incidentNumber");
                                    }
                                

                                          if (localIncidentNumber==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("incidentNumber cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localIncidentNumber);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localIncidentVOTracker){
                                            if (localIncidentVO==null){
                                                 throw new org.apache.axis2.databinding.ADBException("incidentVO cannot be null!!");
                                            }
                                           localIncidentVO.serialize(new javax.xml.namespace.QName("","incidentVO"),
                                               factory,xmlWriter);
                                        } if (localLabourCostCreditTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"labourCostCredit", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"labourCostCredit");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("labourCostCredit");
                                    }
                                

                                          if (localLabourCostCredit==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("labourCostCredit cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localLabourCostCredit);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localLabourCostDebitTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"labourCostDebit", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"labourCostDebit");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("labourCostDebit");
                                    }
                                

                                          if (localLabourCostDebit==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("labourCostDebit cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localLabourCostDebit);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localLastPlanStartDateTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"lastPlanStartDate", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"lastPlanStartDate");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("lastPlanStartDate");
                                    }
                                

                                          if (localLastPlanStartDate==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("lastPlanStartDate cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLastPlanStartDate));
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localLocaleTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"locale", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"locale");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("locale");
                                    }
                                

                                          if (localLocale==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("locale cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localLocale);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localMaintainerFinishWorkTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"maintainerFinishWork", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"maintainerFinishWork");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("maintainerFinishWork");
                                    }
                                

                                          if (localMaintainerFinishWork==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("maintainerFinishWork cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMaintainerFinishWork));
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localMaintainerSiteArrivalTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"maintainerSiteArrival", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"maintainerSiteArrival");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("maintainerSiteArrival");
                                    }
                                

                                          if (localMaintainerSiteArrival==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("maintainerSiteArrival cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMaintainerSiteArrival));
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localMaintainerStartWorkTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"maintainerStartWork", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"maintainerStartWork");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("maintainerStartWork");
                                    }
                                

                                          if (localMaintainerStartWork==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("maintainerStartWork cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMaintainerStartWork));
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localMaterialCostCreditTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"materialCostCredit", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"materialCostCredit");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("materialCostCredit");
                                    }
                                

                                          if (localMaterialCostCredit==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("materialCostCredit cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localMaterialCostCredit);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localMaterialCostDebitTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"materialCostDebit", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"materialCostDebit");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("materialCostDebit");
                                    }
                                

                                          if (localMaterialCostDebit==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("materialCostDebit cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localMaterialCostDebit);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localOldWoNoTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"oldWoNo", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"oldWoNo");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("oldWoNo");
                                    }
                                

                                          if (localOldWoNo==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("oldWoNo cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localOldWoNo);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localOneOfRelatedMeasurementIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"oneOfRelatedMeasurementId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"oneOfRelatedMeasurementId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("oneOfRelatedMeasurementId");
                                    }
                                

                                          if (localOneOfRelatedMeasurementId==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("oneOfRelatedMeasurementId cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localOneOfRelatedMeasurementId);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localOpenDateTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"openDate", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"openDate");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("openDate");
                                    }
                                

                                          if (localOpenDate==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("openDate cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localOpenDate));
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localOtherCostCreditTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"otherCostCredit", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"otherCostCredit");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("otherCostCredit");
                                    }
                                

                                          if (localOtherCostCredit==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("otherCostCredit cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localOtherCostCredit);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localOtherCostDebitTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"otherCostDebit", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"otherCostDebit");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("otherCostDebit");
                                    }
                                

                                          if (localOtherCostDebit==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("otherCostDebit cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localOtherCostDebit);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localParentWoRelationshipTracker){
                                            if (localParentWoRelationship==null){
                                                 throw new org.apache.axis2.databinding.ADBException("parentWoRelationship cannot be null!!");
                                            }
                                           localParentWoRelationship.serialize(new javax.xml.namespace.QName("","parentWoRelationship"),
                                               factory,xmlWriter);
                                        } if (localPersonInChargeTracker){
                                            if (localPersonInCharge==null){
                                                 throw new org.apache.axis2.databinding.ADBException("personInCharge cannot be null!!");
                                            }
                                           localPersonInCharge.serialize(new javax.xml.namespace.QName("","personInCharge"),
                                               factory,xmlWriter);
                                        } if (localPersonInChargeUserIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"personInChargeUserId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"personInChargeUserId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("personInChargeUserId");
                                    }
                                

                                          if (localPersonInChargeUserId==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("personInChargeUserId cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localPersonInChargeUserId);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localPersonInchrgCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"personInchrgCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"personInchrgCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("personInchrgCd");
                                    }
                                

                                          if (localPersonInchrgCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("personInchrgCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localPersonInchrgCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localPlanCmplDateTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"planCmplDate", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"planCmplDate");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("planCmplDate");
                                    }
                                

                                          if (localPlanCmplDate==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("planCmplDate cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localPlanCmplDate));
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localPlanStartDateTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"planStartDate", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"planStartDate");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("planStartDate");
                                    }
                                

                                          if (localPlanStartDate==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("planStartDate cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localPlanStartDate));
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localPlannedCmplTimeTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"plannedCmplTime", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"plannedCmplTime");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("plannedCmplTime");
                                    }
                                

                                          if (localPlannedCmplTime==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("plannedCmplTime cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localPlannedCmplTime);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localPlannedStartTimeTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"plannedStartTime", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"plannedStartTime");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("plannedStartTime");
                                    }
                                

                                          if (localPlannedStartTime==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("plannedStartTime cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localPlannedStartTime);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localPrimaryRecoveryTimeTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"primaryRecoveryTime", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"primaryRecoveryTime");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("primaryRecoveryTime");
                                    }
                                

                                          if (localPrimaryRecoveryTime==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("primaryRecoveryTime cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localPrimaryRecoveryTime);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localQuantityTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"quantity", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"quantity");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("quantity");
                                    }
                                
                                               if (localQuantity==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("quantity cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localQuantity));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localRelatedMeasurementIdsTracker){
                             if (localRelatedMeasurementIds!=null) {
                                   namespace = "";
                                   boolean emptyNamespace = namespace == null || namespace.length() == 0;
                                   prefix =  emptyNamespace ? null : xmlWriter.getPrefix(namespace);
                                   for (int i = 0;i < localRelatedMeasurementIds.length;i++){
                                        
                                            if (localRelatedMeasurementIds[i] != null){
                                        
                                                if (!emptyNamespace) {
                                                    if (prefix == null) {
                                                        java.lang.String prefix2 = generatePrefix(namespace);

                                                        xmlWriter.writeStartElement(prefix2,"relatedMeasurementIds", namespace);
                                                        xmlWriter.writeNamespace(prefix2, namespace);
                                                        xmlWriter.setPrefix(prefix2, namespace);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace,"relatedMeasurementIds");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("relatedMeasurementIds");
                                                }

                                            
                                                        xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRelatedMeasurementIds[i]));
                                                    
                                                xmlWriter.writeEndElement();
                                              
                                                } else {
                                                   
                                                           // write null attribute
                                                            namespace = "";
                                                            if (! namespace.equals("")) {
                                                                prefix = xmlWriter.getPrefix(namespace);

                                                                if (prefix == null) {
                                                                    prefix = generatePrefix(namespace);

                                                                    xmlWriter.writeStartElement(prefix,"relatedMeasurementIds", namespace);
                                                                    xmlWriter.writeNamespace(prefix, namespace);
                                                                    xmlWriter.setPrefix(prefix, namespace);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace,"relatedMeasurementIds");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("relatedMeasurementIds");
                                                            }
                                                            writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                            xmlWriter.writeEndElement();
                                                       
                                                }

                                   }
                             } else {
                                 
                                         // write the null attribute
                                        // write null attribute
                                            java.lang.String namespace2 = "";
                                            if (! namespace2.equals("")) {
                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                if (prefix2 == null) {
                                                    prefix2 = generatePrefix(namespace2);

                                                    xmlWriter.writeStartElement(prefix2,"relatedMeasurementIds", namespace2);
                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                } else {
                                                    xmlWriter.writeStartElement(namespace2,"relatedMeasurementIds");
                                                }

                                            } else {
                                                xmlWriter.writeStartElement("relatedMeasurementIds");
                                            }

                                           // write the nil attribute
                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                           xmlWriter.writeEndElement();
                                    
                             }

                        } if (localRelatedWoListTracker){
                                       if (localRelatedWoList!=null){
                                            for (int i = 0;i < localRelatedWoList.length;i++){
                                                if (localRelatedWoList[i] != null){
                                                 localRelatedWoList[i].serialize(new javax.xml.namespace.QName("","relatedWoList"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"relatedWoList", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"relatedWoList");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("relatedWoList");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"relatedWoList", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"relatedWoList");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("relatedWoList");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localRemarkTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"remark", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"remark");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("remark");
                                    }
                                

                                          if (localRemark==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("remark cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localRemark);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localReservedField1Tracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"reservedField1", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"reservedField1");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("reservedField1");
                                    }
                                

                                          if (localReservedField1==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("reservedField1 cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localReservedField1);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localReservedField2Tracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"reservedField2", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"reservedField2");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("reservedField2");
                                    }
                                

                                          if (localReservedField2==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("reservedField2 cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localReservedField2);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localReservedField3Tracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"reservedField3", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"reservedField3");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("reservedField3");
                                    }
                                

                                          if (localReservedField3==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("reservedField3 cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localReservedField3);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localServiceDownTimeTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"serviceDownTime", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"serviceDownTime");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("serviceDownTime");
                                    }
                                

                                          if (localServiceDownTime==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("serviceDownTime cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localServiceDownTime);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localServiceNotRequireTimeTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"serviceNotRequireTime", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"serviceNotRequireTime");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("serviceNotRequireTime");
                                    }
                                

                                          if (localServiceNotRequireTime==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("serviceNotRequireTime cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localServiceNotRequireTime);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localShortLocTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"shortLoc", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"shortLoc");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("shortLoc");
                                    }
                                

                                          if (localShortLoc==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("shortLoc cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localShortLoc);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localStatusTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"status", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"status");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("status");
                                    }
                                

                                          if (localStatus==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("status cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localStatus);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localStatusDescTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"statusDesc", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"statusDesc");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("statusDesc");
                                    }
                                

                                          if (localStatusDesc==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("statusDesc cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localStatusDesc);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localStatusHisTracker){
                                            if (localStatusHis==null){
                                                 throw new org.apache.axis2.databinding.ADBException("statusHis cannot be null!!");
                                            }
                                           localStatusHis.serialize(new javax.xml.namespace.QName("","statusHis"),
                                               factory,xmlWriter);
                                        } if (localStdJobTracker){
                                            if (localStdJob==null){
                                                 throw new org.apache.axis2.databinding.ADBException("stdJob cannot be null!!");
                                            }
                                           localStdJob.serialize(new javax.xml.namespace.QName("","stdJob"),
                                               factory,xmlWriter);
                                        } if (localStdJobParamListIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"stdJobParamListId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"stdJobParamListId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("stdJobParamListId");
                                    }
                                
                                               if (localStdJobParamListId==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("stdJobParamListId cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localStdJobParamListId));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localStdJobParamSetNameTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"stdJobParamSetName", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"stdJobParamSetName");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("stdJobParamSetName");
                                    }
                                

                                          if (localStdJobParamSetName==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("stdJobParamSetName cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localStdJobParamSetName);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localTotalActualHourTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"totalActualHour", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"totalActualHour");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("totalActualHour");
                                    }
                                
                                               if (java.lang.Double.isNaN(localTotalActualHour)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("totalActualHour cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalActualHour));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localTotalActualLabourCostTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"totalActualLabourCost", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"totalActualLabourCost");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("totalActualLabourCost");
                                    }
                                
                                               if (java.lang.Double.isNaN(localTotalActualLabourCost)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("totalActualLabourCost cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalActualLabourCost));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localTotalActualMaterialCostTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"totalActualMaterialCost", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"totalActualMaterialCost");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("totalActualMaterialCost");
                                    }
                                
                                               if (java.lang.Double.isNaN(localTotalActualMaterialCost)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("totalActualMaterialCost cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalActualMaterialCost));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localTotalActualOtherCostTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"totalActualOtherCost", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"totalActualOtherCost");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("totalActualOtherCost");
                                    }
                                
                                               if (java.lang.Double.isNaN(localTotalActualOtherCost)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("totalActualOtherCost cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalActualOtherCost));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localTotalActualQuantityTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"totalActualQuantity", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"totalActualQuantity");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("totalActualQuantity");
                                    }
                                
                                               if (java.lang.Double.isNaN(localTotalActualQuantity)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("totalActualQuantity cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalActualQuantity));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localTotalPlanHourTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"totalPlanHour", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"totalPlanHour");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("totalPlanHour");
                                    }
                                
                                               if (java.lang.Double.isNaN(localTotalPlanHour)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("totalPlanHour cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalPlanHour));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localTotalPlanLabourCostTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"totalPlanLabourCost", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"totalPlanLabourCost");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("totalPlanLabourCost");
                                    }
                                
                                               if (java.lang.Double.isNaN(localTotalPlanLabourCost)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("totalPlanLabourCost cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalPlanLabourCost));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localTotalPlanMaterialCostTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"totalPlanMaterialCost", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"totalPlanMaterialCost");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("totalPlanMaterialCost");
                                    }
                                
                                               if (java.lang.Double.isNaN(localTotalPlanMaterialCost)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("totalPlanMaterialCost cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalPlanMaterialCost));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localTotalPlanOtherCostTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"totalPlanOtherCost", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"totalPlanOtherCost");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("totalPlanOtherCost");
                                    }
                                
                                               if (java.lang.Double.isNaN(localTotalPlanOtherCost)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("totalPlanOtherCost cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalPlanOtherCost));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localTotalPlanQuantityTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"totalPlanQuantity", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"totalPlanQuantity");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("totalPlanQuantity");
                                    }
                                
                                               if (java.lang.Double.isNaN(localTotalPlanQuantity)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("totalPlanQuantity cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalPlanQuantity));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localTotalRecoveryTimeTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"totalRecoveryTime", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"totalRecoveryTime");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("totalRecoveryTime");
                                    }
                                

                                          if (localTotalRecoveryTime==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("totalRecoveryTime cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localTotalRecoveryTime);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localTotalResponseTimeTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"totalResponseTime", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"totalResponseTime");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("totalResponseTime");
                                    }
                                

                                          if (localTotalResponseTime==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("totalResponseTime cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localTotalResponseTime);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localTotalSuspensionTimeTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"totalSuspensionTime", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"totalSuspensionTime");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("totalSuspensionTime");
                                    }
                                

                                          if (localTotalSuspensionTime==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("totalSuspensionTime cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localTotalSuspensionTime);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localWoActDelLabourCostVOsTracker){
                                       if (localWoActDelLabourCostVOs!=null){
                                            for (int i = 0;i < localWoActDelLabourCostVOs.length;i++){
                                                if (localWoActDelLabourCostVOs[i] != null){
                                                 localWoActDelLabourCostVOs[i].serialize(new javax.xml.namespace.QName("","woActDelLabourCostVOs"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"woActDelLabourCostVOs", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"woActDelLabourCostVOs");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("woActDelLabourCostVOs");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"woActDelLabourCostVOs", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"woActDelLabourCostVOs");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("woActDelLabourCostVOs");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localWoActDelMaterialCostVOsTracker){
                                       if (localWoActDelMaterialCostVOs!=null){
                                            for (int i = 0;i < localWoActDelMaterialCostVOs.length;i++){
                                                if (localWoActDelMaterialCostVOs[i] != null){
                                                 localWoActDelMaterialCostVOs[i].serialize(new javax.xml.namespace.QName("","woActDelMaterialCostVOs"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"woActDelMaterialCostVOs", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"woActDelMaterialCostVOs");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("woActDelMaterialCostVOs");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"woActDelMaterialCostVOs", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"woActDelMaterialCostVOs");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("woActDelMaterialCostVOs");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localWoActDelOtherCostVOsTracker){
                                       if (localWoActDelOtherCostVOs!=null){
                                            for (int i = 0;i < localWoActDelOtherCostVOs.length;i++){
                                                if (localWoActDelOtherCostVOs[i] != null){
                                                 localWoActDelOtherCostVOs[i].serialize(new javax.xml.namespace.QName("","woActDelOtherCostVOs"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"woActDelOtherCostVOs", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"woActDelOtherCostVOs");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("woActDelOtherCostVOs");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"woActDelOtherCostVOs", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"woActDelOtherCostVOs");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("woActDelOtherCostVOs");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localWoActLabourCostVOsTracker){
                                       if (localWoActLabourCostVOs!=null){
                                            for (int i = 0;i < localWoActLabourCostVOs.length;i++){
                                                if (localWoActLabourCostVOs[i] != null){
                                                 localWoActLabourCostVOs[i].serialize(new javax.xml.namespace.QName("","woActLabourCostVOs"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"woActLabourCostVOs", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"woActLabourCostVOs");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("woActLabourCostVOs");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"woActLabourCostVOs", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"woActLabourCostVOs");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("woActLabourCostVOs");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localWoActLocationVOsTracker){
                                       if (localWoActLocationVOs!=null){
                                            for (int i = 0;i < localWoActLocationVOs.length;i++){
                                                if (localWoActLocationVOs[i] != null){
                                                 localWoActLocationVOs[i].serialize(new javax.xml.namespace.QName("","woActLocationVOs"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"woActLocationVOs", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"woActLocationVOs");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("woActLocationVOs");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"woActLocationVOs", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"woActLocationVOs");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("woActLocationVOs");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localWoActMaterialCostVOsTracker){
                                       if (localWoActMaterialCostVOs!=null){
                                            for (int i = 0;i < localWoActMaterialCostVOs.length;i++){
                                                if (localWoActMaterialCostVOs[i] != null){
                                                 localWoActMaterialCostVOs[i].serialize(new javax.xml.namespace.QName("","woActMaterialCostVOs"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"woActMaterialCostVOs", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"woActMaterialCostVOs");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("woActMaterialCostVOs");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"woActMaterialCostVOs", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"woActMaterialCostVOs");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("woActMaterialCostVOs");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localWoActOtherCostVOsTracker){
                                       if (localWoActOtherCostVOs!=null){
                                            for (int i = 0;i < localWoActOtherCostVOs.length;i++){
                                                if (localWoActOtherCostVOs[i] != null){
                                                 localWoActOtherCostVOs[i].serialize(new javax.xml.namespace.QName("","woActOtherCostVOs"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"woActOtherCostVOs", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"woActOtherCostVOs");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("woActOtherCostVOs");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"woActOtherCostVOs", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"woActOtherCostVOs");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("woActOtherCostVOs");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localWoDespTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"woDesp", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"woDesp");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("woDesp");
                                    }
                                

                                          if (localWoDesp==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("woDesp cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localWoDesp);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localWoEquipAssocsTracker){
                             if (localWoEquipAssocs!=null) {
                                   namespace = "";
                                   boolean emptyNamespace = namespace == null || namespace.length() == 0;
                                   prefix =  emptyNamespace ? null : xmlWriter.getPrefix(namespace);
                                   for (int i = 0;i < localWoEquipAssocs.length;i++){
                                        
                                                   if (localWoEquipAssocs[i]!=java.lang.Long.MIN_VALUE) {
                                               
                                                if (!emptyNamespace) {
                                                    if (prefix == null) {
                                                        java.lang.String prefix2 = generatePrefix(namespace);

                                                        xmlWriter.writeStartElement(prefix2,"woEquipAssocs", namespace);
                                                        xmlWriter.writeNamespace(prefix2, namespace);
                                                        xmlWriter.setPrefix(prefix2, namespace);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace,"woEquipAssocs");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("woEquipAssocs");
                                                }

                                            
                                                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localWoEquipAssocs[i]));
                                                xmlWriter.writeEndElement();
                                            
                                                } else {
                                                   
                                                           // write null attribute
                                                            namespace = "";
                                                            if (! namespace.equals("")) {
                                                                prefix = xmlWriter.getPrefix(namespace);

                                                                if (prefix == null) {
                                                                    prefix = generatePrefix(namespace);

                                                                    xmlWriter.writeStartElement(prefix,"woEquipAssocs", namespace);
                                                                    xmlWriter.writeNamespace(prefix, namespace);
                                                                    xmlWriter.setPrefix(prefix, namespace);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace,"woEquipAssocs");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("woEquipAssocs");
                                                            }
                                                            writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                            xmlWriter.writeEndElement();
                                                       
                                                }

                                   }
                             } else {
                                 
                                         // write the null attribute
                                        // write null attribute
                                            java.lang.String namespace2 = "";
                                            if (! namespace2.equals("")) {
                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                if (prefix2 == null) {
                                                    prefix2 = generatePrefix(namespace2);

                                                    xmlWriter.writeStartElement(prefix2,"woEquipAssocs", namespace2);
                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                } else {
                                                    xmlWriter.writeStartElement(namespace2,"woEquipAssocs");
                                                }

                                            } else {
                                                xmlWriter.writeStartElement("woEquipAssocs");
                                            }

                                           // write the nil attribute
                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                           xmlWriter.writeEndElement();
                                    
                             }

                        } if (localWoFailureDetailVOsTracker){
                                       if (localWoFailureDetailVOs!=null){
                                            for (int i = 0;i < localWoFailureDetailVOs.length;i++){
                                                if (localWoFailureDetailVOs[i] != null){
                                                 localWoFailureDetailVOs[i].serialize(new javax.xml.namespace.QName("","woFailureDetailVOs"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"woFailureDetailVOs", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"woFailureDetailVOs");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("woFailureDetailVOs");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"woFailureDetailVOs", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"woFailureDetailVOs");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("woFailureDetailVOs");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localWoFailureInfoVOTracker){
                                            if (localWoFailureInfoVO==null){
                                                 throw new org.apache.axis2.databinding.ADBException("woFailureInfoVO cannot be null!!");
                                            }
                                           localWoFailureInfoVO.serialize(new javax.xml.namespace.QName("","woFailureInfoVO"),
                                               factory,xmlWriter);
                                        } if (localWoFollowupActionVOsTracker){
                                       if (localWoFollowupActionVOs!=null){
                                            for (int i = 0;i < localWoFollowupActionVOs.length;i++){
                                                if (localWoFollowupActionVOs[i] != null){
                                                 localWoFollowupActionVOs[i].serialize(new javax.xml.namespace.QName("","woFollowupActionVOs"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"woFollowupActionVOs", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"woFollowupActionVOs");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("woFollowupActionVOs");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"woFollowupActionVOs", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"woFollowupActionVOs");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("woFollowupActionVOs");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localWoJobRequirementVOsTracker){
                                       if (localWoJobRequirementVOs!=null){
                                            for (int i = 0;i < localWoJobRequirementVOs.length;i++){
                                                if (localWoJobRequirementVOs[i] != null){
                                                 localWoJobRequirementVOs[i].serialize(new javax.xml.namespace.QName("","woJobRequirementVOs"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"woJobRequirementVOs", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"woJobRequirementVOs");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("woJobRequirementVOs");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"woJobRequirementVOs", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"woJobRequirementVOs");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("woJobRequirementVOs");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localWoNoTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"woNo", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"woNo");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("woNo");
                                    }
                                

                                          if (localWoNo==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("woNo cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localWoNo);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localWoPlanLabourCostVOsTracker){
                                       if (localWoPlanLabourCostVOs!=null){
                                            for (int i = 0;i < localWoPlanLabourCostVOs.length;i++){
                                                if (localWoPlanLabourCostVOs[i] != null){
                                                 localWoPlanLabourCostVOs[i].serialize(new javax.xml.namespace.QName("","woPlanLabourCostVOs"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"woPlanLabourCostVOs", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"woPlanLabourCostVOs");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("woPlanLabourCostVOs");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"woPlanLabourCostVOs", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"woPlanLabourCostVOs");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("woPlanLabourCostVOs");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localWoPlanLocationVOsTracker){
                                       if (localWoPlanLocationVOs!=null){
                                            for (int i = 0;i < localWoPlanLocationVOs.length;i++){
                                                if (localWoPlanLocationVOs[i] != null){
                                                 localWoPlanLocationVOs[i].serialize(new javax.xml.namespace.QName("","woPlanLocationVOs"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"woPlanLocationVOs", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"woPlanLocationVOs");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("woPlanLocationVOs");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"woPlanLocationVOs", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"woPlanLocationVOs");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("woPlanLocationVOs");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localWoPlanMaterialCostVOsTracker){
                                       if (localWoPlanMaterialCostVOs!=null){
                                            for (int i = 0;i < localWoPlanMaterialCostVOs.length;i++){
                                                if (localWoPlanMaterialCostVOs[i] != null){
                                                 localWoPlanMaterialCostVOs[i].serialize(new javax.xml.namespace.QName("","woPlanMaterialCostVOs"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"woPlanMaterialCostVOs", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"woPlanMaterialCostVOs");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("woPlanMaterialCostVOs");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"woPlanMaterialCostVOs", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"woPlanMaterialCostVOs");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("woPlanMaterialCostVOs");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localWoPlanOtherCostVOsTracker){
                                       if (localWoPlanOtherCostVOs!=null){
                                            for (int i = 0;i < localWoPlanOtherCostVOs.length;i++){
                                                if (localWoPlanOtherCostVOs[i] != null){
                                                 localWoPlanOtherCostVOs[i].serialize(new javax.xml.namespace.QName("","woPlanOtherCostVOs"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"woPlanOtherCostVOs", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"woPlanOtherCostVOs");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("woPlanOtherCostVOs");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"woPlanOtherCostVOs", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"woPlanOtherCostVOs");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("woPlanOtherCostVOs");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localWoRecoveryVOTracker){
                                            if (localWoRecoveryVO==null){
                                                 throw new org.apache.axis2.databinding.ADBException("woRecoveryVO cannot be null!!");
                                            }
                                           localWoRecoveryVO.serialize(new javax.xml.namespace.QName("","woRecoveryVO"),
                                               factory,xmlWriter);
                                        } if (localWoStatusHistoryVOsTracker){
                                       if (localWoStatusHistoryVOs!=null){
                                            for (int i = 0;i < localWoStatusHistoryVOs.length;i++){
                                                if (localWoStatusHistoryVOs[i] != null){
                                                 localWoStatusHistoryVOs[i].serialize(new javax.xml.namespace.QName("","woStatusHistoryVOs"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"woStatusHistoryVOs", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"woStatusHistoryVOs");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("woStatusHistoryVOs");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"woStatusHistoryVOs", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"woStatusHistoryVOs");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("woStatusHistoryVOs");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localWoSuspensionVOsTracker){
                                       if (localWoSuspensionVOs!=null){
                                            for (int i = 0;i < localWoSuspensionVOs.length;i++){
                                                if (localWoSuspensionVOs[i] != null){
                                                 localWoSuspensionVOs[i].serialize(new javax.xml.namespace.QName("","woSuspensionVOs"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"woSuspensionVOs", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"woSuspensionVOs");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("woSuspensionVOs");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"woSuspensionVOs", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"woSuspensionVOs");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("woSuspensionVOs");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localWoTaskVOsTracker){
                                       if (localWoTaskVOs!=null){
                                            for (int i = 0;i < localWoTaskVOs.length;i++){
                                                if (localWoTaskVOs[i] != null){
                                                 localWoTaskVOs[i].serialize(new javax.xml.namespace.QName("","woTaskVOs"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"woTaskVOs", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"woTaskVOs");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("woTaskVOs");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"woTaskVOs", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"woTaskVOs");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("woTaskVOs");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localWorkGrpTracker){
                                            if (localWorkGrp==null){
                                                 throw new org.apache.axis2.databinding.ADBException("workGrp cannot be null!!");
                                            }
                                           localWorkGrp.serialize(new javax.xml.namespace.QName("","workGrp"),
                                               factory,xmlWriter);
                                        } if (localWorkRequestsTracker){
                                       if (localWorkRequests!=null){
                                            for (int i = 0;i < localWorkRequests.length;i++){
                                                if (localWorkRequests[i] != null){
                                                 localWorkRequests[i].serialize(new javax.xml.namespace.QName("","workRequests"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"workRequests", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"workRequests");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("workRequests");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"workRequests", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"workRequests");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("workRequests");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localWorkTimeRequireTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"workTimeRequire", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"workTimeRequire");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("workTimeRequire");
                                    }
                                

                                          if (localWorkTimeRequire==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("workTimeRequire cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localWorkTimeRequire);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localWrIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"wrId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"wrId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("wrId");
                                    }
                                

                                          if (localWrId==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("wrId cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localWrId);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localEquipmentReferenceNameTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"equipmentReferenceName", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"equipmentReferenceName");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("equipmentReferenceName");
                                    }
                                

                                          if (localEquipmentReferenceName==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("equipmentReferenceName cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localEquipmentReferenceName);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSegment1Tracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"segment1", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"segment1");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("segment1");
                                    }
                                

                                          if (localSegment1==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("segment1 cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localSegment1);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSegment2Tracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"segment2", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"segment2");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("segment2");
                                    }
                                

                                          if (localSegment2==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("segment2 cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localSegment2);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSegment3Tracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"segment3", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"segment3");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("segment3");
                                    }
                                

                                          if (localSegment3==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("segment3 cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localSegment3);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSegment4Tracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"segment4", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"segment4");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("segment4");
                                    }
                                

                                          if (localSegment4==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("segment4 cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localSegment4);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localTotalLabourCostVarianceTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"totalLabourCostVariance", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"totalLabourCostVariance");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("totalLabourCostVariance");
                                    }
                                
                                               if (java.lang.Double.isNaN(localTotalLabourCostVariance)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("totalLabourCostVariance cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalLabourCostVariance));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localTotalMaterialsCostVarianceTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"totalMaterialsCostVariance", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"totalMaterialsCostVariance");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("totalMaterialsCostVariance");
                                    }
                                
                                               if (java.lang.Double.isNaN(localTotalMaterialsCostVariance)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("totalMaterialsCostVariance cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalMaterialsCostVariance));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localTotalOtherCostVarianceTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"totalOtherCostVariance", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"totalOtherCostVariance");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("totalOtherCostVariance");
                                    }
                                
                                               if (java.lang.Double.isNaN(localTotalOtherCostVariance)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("totalOtherCostVariance cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalOtherCostVariance));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localFinalCostFlagTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"finalCostFlag", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"finalCostFlag");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("finalCostFlag");
                                    }
                                

                                          if (localFinalCostFlag==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("finalCostFlag cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localFinalCostFlag);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             }
                    xmlWriter.writeEndElement();
               

        }

         /**
          * Util method to write an attribute with the ns prefix
          */
          private void writeAttribute(java.lang.String prefix,java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
              if (xmlWriter.getPrefix(namespace) == null) {
                       xmlWriter.writeNamespace(prefix, namespace);
                       xmlWriter.setPrefix(prefix, namespace);

              }

              xmlWriter.writeAttribute(namespace,attName,attValue);

         }

        /**
          * Util method to write an attribute without the ns prefix
          */
          private void writeAttribute(java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
                if (namespace.equals(""))
              {
                  xmlWriter.writeAttribute(attName,attValue);
              }
              else
              {
                  registerPrefix(xmlWriter, namespace);
                  xmlWriter.writeAttribute(namespace,attName,attValue);
              }
          }


           /**
             * Util method to write an attribute without the ns prefix
             */
            private void writeQNameAttribute(java.lang.String namespace, java.lang.String attName,
                                             javax.xml.namespace.QName qname, javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

                java.lang.String attributeNamespace = qname.getNamespaceURI();
                java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
                if (attributePrefix == null) {
                    attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
                }
                java.lang.String attributeValue;
                if (attributePrefix.trim().length() > 0) {
                    attributeValue = attributePrefix + ":" + qname.getLocalPart();
                } else {
                    attributeValue = qname.getLocalPart();
                }

                if (namespace.equals("")) {
                    xmlWriter.writeAttribute(attName, attributeValue);
                } else {
                    registerPrefix(xmlWriter, namespace);
                    xmlWriter.writeAttribute(namespace, attName, attributeValue);
                }
            }
        /**
         *  method to handle Qnames
         */

        private void writeQName(javax.xml.namespace.QName qname,
                                javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null) {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null) {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix,namespaceURI);
                }

                if (prefix.trim().length() > 0){
                    xmlWriter.writeCharacters(prefix + ":" + org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                } else {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                }

            } else {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
            }
        }

        private void writeQNames(javax.xml.namespace.QName[] qnames,
                                 javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

            if (qnames != null) {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++) {
                    if (i > 0) {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null) {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0)) {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix,namespaceURI);
                        }

                        if (prefix.trim().length() > 0){
                            stringToWrite.append(prefix).append(":").append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        } else {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        }
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }


         /**
         * Register a namespace prefix
         */
         private java.lang.String registerPrefix(javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace) throws javax.xml.stream.XMLStreamException {
                java.lang.String prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null) {
                        prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                    }

                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }

                return prefix;
            }


  
        /**
        * databinding method to get an XML representation of this object
        *
        */
        public javax.xml.stream.XMLStreamReader getPullParser(javax.xml.namespace.QName qName)
                    throws org.apache.axis2.databinding.ADBException{


        
                 java.util.ArrayList elementList = new java.util.ArrayList();
                 java.util.ArrayList attribList = new java.util.ArrayList();

                
                    attribList.add(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema-instance","type"));
                    attribList.add(new javax.xml.namespace.QName("http://ws.mmis.mtr.com.hk/","workOrderVO"));
                 if (localActionTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "action"));
                                 
                                        if (localAction != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localAction));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("action cannot be null!!");
                                        }
                                    } if (localActualCmplDateTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "actualCmplDate"));
                                 
                                        if (localActualCmplDate != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localActualCmplDate));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("actualCmplDate cannot be null!!");
                                        }
                                    } if (localActualStartDateTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "actualStartDate"));
                                 
                                        if (localActualStartDate != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localActualStartDate));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("actualStartDate cannot be null!!");
                                        }
                                    } if (localActualStartTimeTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "actualStartTime"));
                                 
                                        if (localActualStartTime != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localActualStartTime));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("actualStartTime cannot be null!!");
                                        }
                                    } if (localChildWolistTracker){
                             if (localChildWolist!=null) {
                                 for (int i = 0;i < localChildWolist.length;i++){

                                    if (localChildWolist[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "childWolist"));
                                         elementList.add(localChildWolist[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "childWolist"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "childWolist"));
                                        elementList.add(localChildWolist);
                                    
                             }

                        } if (localCmpltmnryContractNoTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "cmpltmnryContractNo"));
                                 
                                        if (localCmpltmnryContractNo != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localCmpltmnryContractNo));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("cmpltmnryContractNo cannot be null!!");
                                        }
                                    } if (localContractDespTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "contractDesp"));
                                 
                                        if (localContractDesp != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localContractDesp));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("contractDesp cannot be null!!");
                                        }
                                    } if (localContractNoTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "contractNo"));
                                 
                                        if (localContractNo != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localContractNo));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("contractNo cannot be null!!");
                                        }
                                    } if (localContractorTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "contractor"));
                                 
                                        if (localContractor != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localContractor));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("contractor cannot be null!!");
                                        }
                                    } if (localContractorInChargeTracker){
                            elementList.add(new javax.xml.namespace.QName("",
                                                                      "contractorInCharge"));
                            
                            
                                    if (localContractorInCharge==null){
                                         throw new org.apache.axis2.databinding.ADBException("contractorInCharge cannot be null!!");
                                    }
                                    elementList.add(localContractorInCharge);
                                } if (localDetailIDsTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "detailIDs"));
                                 
                                        if (localDetailIDs != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localDetailIDs));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("detailIDs cannot be null!!");
                                        }
                                    } if (localDetailLocTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "detailLoc"));
                                 
                                        if (localDetailLoc != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localDetailLoc));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("detailLoc cannot be null!!");
                                        }
                                    } if (localEarPlanStartDateTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "earPlanStartDate"));
                                 
                                        if (localEarPlanStartDate != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localEarPlanStartDate));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("earPlanStartDate cannot be null!!");
                                        }
                                    } if (localEngineerInChargeTracker){
                            elementList.add(new javax.xml.namespace.QName("",
                                                                      "engineerInCharge"));
                            
                            
                                    if (localEngineerInCharge==null){
                                         throw new org.apache.axis2.databinding.ADBException("engineerInCharge cannot be null!!");
                                    }
                                    elementList.add(localEngineerInCharge);
                                } if (localEquipClassTracker){
                            elementList.add(new javax.xml.namespace.QName("",
                                                                      "equipClass"));
                            
                            
                                    if (localEquipClass==null){
                                         throw new org.apache.axis2.databinding.ADBException("equipClass cannot be null!!");
                                    }
                                    elementList.add(localEquipClass);
                                } if (localEquipDownTimeTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "equipDownTime"));
                                 
                                        if (localEquipDownTime != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localEquipDownTime));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("equipDownTime cannot be null!!");
                                        }
                                    } if (localEquipmentTracker){
                            elementList.add(new javax.xml.namespace.QName("",
                                                                      "equipment"));
                            
                            
                                    if (localEquipment==null){
                                         throw new org.apache.axis2.databinding.ADBException("equipment cannot be null!!");
                                    }
                                    elementList.add(localEquipment);
                                } if (localFinalizedIndTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "finalizedInd"));
                                 
                                        if (localFinalizedInd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localFinalizedInd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("finalizedInd cannot be null!!");
                                        }
                                    } if (localGcFinanceRefNoCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcFinanceRefNoCd"));
                                 
                                        if (localGcFinanceRefNoCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcFinanceRefNoCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcFinanceRefNoCd cannot be null!!");
                                        }
                                    } if (localGcPriorityCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcPriorityCd"));
                                 
                                        if (localGcPriorityCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcPriorityCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcPriorityCd cannot be null!!");
                                        }
                                    } if (localGcProjectNoCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcProjectNoCd"));
                                 
                                        if (localGcProjectNoCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcProjectNoCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcProjectNoCd cannot be null!!");
                                        }
                                    } if (localGcProjectTaskNoCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcProjectTaskNoCd"));
                                 
                                        if (localGcProjectTaskNoCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcProjectTaskNoCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcProjectTaskNoCd cannot be null!!");
                                        }
                                    } if (localGcSvcBreakdownCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcSvcBreakdownCd"));
                                 
                                        if (localGcSvcBreakdownCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcSvcBreakdownCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcSvcBreakdownCd cannot be null!!");
                                        }
                                    } if (localGcWorkNatureLv1CdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcWorkNatureLv1Cd"));
                                 
                                        if (localGcWorkNatureLv1Cd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcWorkNatureLv1Cd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcWorkNatureLv1Cd cannot be null!!");
                                        }
                                    } if (localGcWorkNatureLv2CdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcWorkNatureLv2Cd"));
                                 
                                        if (localGcWorkNatureLv2Cd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcWorkNatureLv2Cd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcWorkNatureLv2Cd cannot be null!!");
                                        }
                                    } if (localIncidentNumberTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "incidentNumber"));
                                 
                                        if (localIncidentNumber != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localIncidentNumber));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("incidentNumber cannot be null!!");
                                        }
                                    } if (localIncidentVOTracker){
                            elementList.add(new javax.xml.namespace.QName("",
                                                                      "incidentVO"));
                            
                            
                                    if (localIncidentVO==null){
                                         throw new org.apache.axis2.databinding.ADBException("incidentVO cannot be null!!");
                                    }
                                    elementList.add(localIncidentVO);
                                } if (localLabourCostCreditTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "labourCostCredit"));
                                 
                                        if (localLabourCostCredit != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLabourCostCredit));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("labourCostCredit cannot be null!!");
                                        }
                                    } if (localLabourCostDebitTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "labourCostDebit"));
                                 
                                        if (localLabourCostDebit != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLabourCostDebit));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("labourCostDebit cannot be null!!");
                                        }
                                    } if (localLastPlanStartDateTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "lastPlanStartDate"));
                                 
                                        if (localLastPlanStartDate != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLastPlanStartDate));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("lastPlanStartDate cannot be null!!");
                                        }
                                    } if (localLocaleTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "locale"));
                                 
                                        if (localLocale != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLocale));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("locale cannot be null!!");
                                        }
                                    } if (localMaintainerFinishWorkTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "maintainerFinishWork"));
                                 
                                        if (localMaintainerFinishWork != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMaintainerFinishWork));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("maintainerFinishWork cannot be null!!");
                                        }
                                    } if (localMaintainerSiteArrivalTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "maintainerSiteArrival"));
                                 
                                        if (localMaintainerSiteArrival != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMaintainerSiteArrival));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("maintainerSiteArrival cannot be null!!");
                                        }
                                    } if (localMaintainerStartWorkTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "maintainerStartWork"));
                                 
                                        if (localMaintainerStartWork != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMaintainerStartWork));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("maintainerStartWork cannot be null!!");
                                        }
                                    } if (localMaterialCostCreditTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "materialCostCredit"));
                                 
                                        if (localMaterialCostCredit != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMaterialCostCredit));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("materialCostCredit cannot be null!!");
                                        }
                                    } if (localMaterialCostDebitTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "materialCostDebit"));
                                 
                                        if (localMaterialCostDebit != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMaterialCostDebit));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("materialCostDebit cannot be null!!");
                                        }
                                    } if (localOldWoNoTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "oldWoNo"));
                                 
                                        if (localOldWoNo != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localOldWoNo));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("oldWoNo cannot be null!!");
                                        }
                                    } if (localOneOfRelatedMeasurementIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "oneOfRelatedMeasurementId"));
                                 
                                        if (localOneOfRelatedMeasurementId != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localOneOfRelatedMeasurementId));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("oneOfRelatedMeasurementId cannot be null!!");
                                        }
                                    } if (localOpenDateTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "openDate"));
                                 
                                        if (localOpenDate != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localOpenDate));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("openDate cannot be null!!");
                                        }
                                    } if (localOtherCostCreditTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "otherCostCredit"));
                                 
                                        if (localOtherCostCredit != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localOtherCostCredit));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("otherCostCredit cannot be null!!");
                                        }
                                    } if (localOtherCostDebitTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "otherCostDebit"));
                                 
                                        if (localOtherCostDebit != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localOtherCostDebit));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("otherCostDebit cannot be null!!");
                                        }
                                    } if (localParentWoRelationshipTracker){
                            elementList.add(new javax.xml.namespace.QName("",
                                                                      "parentWoRelationship"));
                            
                            
                                    if (localParentWoRelationship==null){
                                         throw new org.apache.axis2.databinding.ADBException("parentWoRelationship cannot be null!!");
                                    }
                                    elementList.add(localParentWoRelationship);
                                } if (localPersonInChargeTracker){
                            elementList.add(new javax.xml.namespace.QName("",
                                                                      "personInCharge"));
                            
                            
                                    if (localPersonInCharge==null){
                                         throw new org.apache.axis2.databinding.ADBException("personInCharge cannot be null!!");
                                    }
                                    elementList.add(localPersonInCharge);
                                } if (localPersonInChargeUserIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "personInChargeUserId"));
                                 
                                        if (localPersonInChargeUserId != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localPersonInChargeUserId));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("personInChargeUserId cannot be null!!");
                                        }
                                    } if (localPersonInchrgCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "personInchrgCd"));
                                 
                                        if (localPersonInchrgCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localPersonInchrgCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("personInchrgCd cannot be null!!");
                                        }
                                    } if (localPlanCmplDateTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "planCmplDate"));
                                 
                                        if (localPlanCmplDate != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localPlanCmplDate));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("planCmplDate cannot be null!!");
                                        }
                                    } if (localPlanStartDateTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "planStartDate"));
                                 
                                        if (localPlanStartDate != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localPlanStartDate));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("planStartDate cannot be null!!");
                                        }
                                    } if (localPlannedCmplTimeTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "plannedCmplTime"));
                                 
                                        if (localPlannedCmplTime != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localPlannedCmplTime));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("plannedCmplTime cannot be null!!");
                                        }
                                    } if (localPlannedStartTimeTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "plannedStartTime"));
                                 
                                        if (localPlannedStartTime != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localPlannedStartTime));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("plannedStartTime cannot be null!!");
                                        }
                                    } if (localPrimaryRecoveryTimeTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "primaryRecoveryTime"));
                                 
                                        if (localPrimaryRecoveryTime != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localPrimaryRecoveryTime));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("primaryRecoveryTime cannot be null!!");
                                        }
                                    } if (localQuantityTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "quantity"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localQuantity));
                            } if (localRelatedMeasurementIdsTracker){
                            if (localRelatedMeasurementIds!=null){
                                  for (int i = 0;i < localRelatedMeasurementIds.length;i++){
                                      
                                         if (localRelatedMeasurementIds[i] != null){
                                          elementList.add(new javax.xml.namespace.QName("",
                                                                              "relatedMeasurementIds"));
                                          elementList.add(
                                          org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRelatedMeasurementIds[i]));
                                          } else {
                                             
                                                    elementList.add(new javax.xml.namespace.QName("",
                                                                              "relatedMeasurementIds"));
                                                    elementList.add(null);
                                                
                                          }
                                      

                                  }
                            } else {
                              
                                    elementList.add(new javax.xml.namespace.QName("",
                                                                              "relatedMeasurementIds"));
                                    elementList.add(null);
                                
                            }

                        } if (localRelatedWoListTracker){
                             if (localRelatedWoList!=null) {
                                 for (int i = 0;i < localRelatedWoList.length;i++){

                                    if (localRelatedWoList[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "relatedWoList"));
                                         elementList.add(localRelatedWoList[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "relatedWoList"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "relatedWoList"));
                                        elementList.add(localRelatedWoList);
                                    
                             }

                        } if (localRemarkTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "remark"));
                                 
                                        if (localRemark != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRemark));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("remark cannot be null!!");
                                        }
                                    } if (localReservedField1Tracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "reservedField1"));
                                 
                                        if (localReservedField1 != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localReservedField1));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("reservedField1 cannot be null!!");
                                        }
                                    } if (localReservedField2Tracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "reservedField2"));
                                 
                                        if (localReservedField2 != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localReservedField2));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("reservedField2 cannot be null!!");
                                        }
                                    } if (localReservedField3Tracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "reservedField3"));
                                 
                                        if (localReservedField3 != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localReservedField3));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("reservedField3 cannot be null!!");
                                        }
                                    } if (localServiceDownTimeTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "serviceDownTime"));
                                 
                                        if (localServiceDownTime != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localServiceDownTime));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("serviceDownTime cannot be null!!");
                                        }
                                    } if (localServiceNotRequireTimeTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "serviceNotRequireTime"));
                                 
                                        if (localServiceNotRequireTime != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localServiceNotRequireTime));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("serviceNotRequireTime cannot be null!!");
                                        }
                                    } if (localShortLocTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "shortLoc"));
                                 
                                        if (localShortLoc != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localShortLoc));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("shortLoc cannot be null!!");
                                        }
                                    } if (localStatusTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "status"));
                                 
                                        if (localStatus != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localStatus));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("status cannot be null!!");
                                        }
                                    } if (localStatusDescTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "statusDesc"));
                                 
                                        if (localStatusDesc != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localStatusDesc));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("statusDesc cannot be null!!");
                                        }
                                    } if (localStatusHisTracker){
                            elementList.add(new javax.xml.namespace.QName("",
                                                                      "statusHis"));
                            
                            
                                    if (localStatusHis==null){
                                         throw new org.apache.axis2.databinding.ADBException("statusHis cannot be null!!");
                                    }
                                    elementList.add(localStatusHis);
                                } if (localStdJobTracker){
                            elementList.add(new javax.xml.namespace.QName("",
                                                                      "stdJob"));
                            
                            
                                    if (localStdJob==null){
                                         throw new org.apache.axis2.databinding.ADBException("stdJob cannot be null!!");
                                    }
                                    elementList.add(localStdJob);
                                } if (localStdJobParamListIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "stdJobParamListId"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localStdJobParamListId));
                            } if (localStdJobParamSetNameTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "stdJobParamSetName"));
                                 
                                        if (localStdJobParamSetName != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localStdJobParamSetName));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("stdJobParamSetName cannot be null!!");
                                        }
                                    } if (localTotalActualHourTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "totalActualHour"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalActualHour));
                            } if (localTotalActualLabourCostTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "totalActualLabourCost"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalActualLabourCost));
                            } if (localTotalActualMaterialCostTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "totalActualMaterialCost"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalActualMaterialCost));
                            } if (localTotalActualOtherCostTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "totalActualOtherCost"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalActualOtherCost));
                            } if (localTotalActualQuantityTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "totalActualQuantity"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalActualQuantity));
                            } if (localTotalPlanHourTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "totalPlanHour"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalPlanHour));
                            } if (localTotalPlanLabourCostTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "totalPlanLabourCost"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalPlanLabourCost));
                            } if (localTotalPlanMaterialCostTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "totalPlanMaterialCost"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalPlanMaterialCost));
                            } if (localTotalPlanOtherCostTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "totalPlanOtherCost"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalPlanOtherCost));
                            } if (localTotalPlanQuantityTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "totalPlanQuantity"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalPlanQuantity));
                            } if (localTotalRecoveryTimeTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "totalRecoveryTime"));
                                 
                                        if (localTotalRecoveryTime != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalRecoveryTime));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("totalRecoveryTime cannot be null!!");
                                        }
                                    } if (localTotalResponseTimeTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "totalResponseTime"));
                                 
                                        if (localTotalResponseTime != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalResponseTime));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("totalResponseTime cannot be null!!");
                                        }
                                    } if (localTotalSuspensionTimeTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "totalSuspensionTime"));
                                 
                                        if (localTotalSuspensionTime != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalSuspensionTime));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("totalSuspensionTime cannot be null!!");
                                        }
                                    } if (localWoActDelLabourCostVOsTracker){
                             if (localWoActDelLabourCostVOs!=null) {
                                 for (int i = 0;i < localWoActDelLabourCostVOs.length;i++){

                                    if (localWoActDelLabourCostVOs[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "woActDelLabourCostVOs"));
                                         elementList.add(localWoActDelLabourCostVOs[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "woActDelLabourCostVOs"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "woActDelLabourCostVOs"));
                                        elementList.add(localWoActDelLabourCostVOs);
                                    
                             }

                        } if (localWoActDelMaterialCostVOsTracker){
                             if (localWoActDelMaterialCostVOs!=null) {
                                 for (int i = 0;i < localWoActDelMaterialCostVOs.length;i++){

                                    if (localWoActDelMaterialCostVOs[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "woActDelMaterialCostVOs"));
                                         elementList.add(localWoActDelMaterialCostVOs[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "woActDelMaterialCostVOs"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "woActDelMaterialCostVOs"));
                                        elementList.add(localWoActDelMaterialCostVOs);
                                    
                             }

                        } if (localWoActDelOtherCostVOsTracker){
                             if (localWoActDelOtherCostVOs!=null) {
                                 for (int i = 0;i < localWoActDelOtherCostVOs.length;i++){

                                    if (localWoActDelOtherCostVOs[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "woActDelOtherCostVOs"));
                                         elementList.add(localWoActDelOtherCostVOs[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "woActDelOtherCostVOs"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "woActDelOtherCostVOs"));
                                        elementList.add(localWoActDelOtherCostVOs);
                                    
                             }

                        } if (localWoActLabourCostVOsTracker){
                             if (localWoActLabourCostVOs!=null) {
                                 for (int i = 0;i < localWoActLabourCostVOs.length;i++){

                                    if (localWoActLabourCostVOs[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "woActLabourCostVOs"));
                                         elementList.add(localWoActLabourCostVOs[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "woActLabourCostVOs"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "woActLabourCostVOs"));
                                        elementList.add(localWoActLabourCostVOs);
                                    
                             }

                        } if (localWoActLocationVOsTracker){
                             if (localWoActLocationVOs!=null) {
                                 for (int i = 0;i < localWoActLocationVOs.length;i++){

                                    if (localWoActLocationVOs[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "woActLocationVOs"));
                                         elementList.add(localWoActLocationVOs[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "woActLocationVOs"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "woActLocationVOs"));
                                        elementList.add(localWoActLocationVOs);
                                    
                             }

                        } if (localWoActMaterialCostVOsTracker){
                             if (localWoActMaterialCostVOs!=null) {
                                 for (int i = 0;i < localWoActMaterialCostVOs.length;i++){

                                    if (localWoActMaterialCostVOs[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "woActMaterialCostVOs"));
                                         elementList.add(localWoActMaterialCostVOs[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "woActMaterialCostVOs"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "woActMaterialCostVOs"));
                                        elementList.add(localWoActMaterialCostVOs);
                                    
                             }

                        } if (localWoActOtherCostVOsTracker){
                             if (localWoActOtherCostVOs!=null) {
                                 for (int i = 0;i < localWoActOtherCostVOs.length;i++){

                                    if (localWoActOtherCostVOs[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "woActOtherCostVOs"));
                                         elementList.add(localWoActOtherCostVOs[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "woActOtherCostVOs"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "woActOtherCostVOs"));
                                        elementList.add(localWoActOtherCostVOs);
                                    
                             }

                        } if (localWoDespTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "woDesp"));
                                 
                                        if (localWoDesp != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localWoDesp));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("woDesp cannot be null!!");
                                        }
                                    } if (localWoEquipAssocsTracker){
                            if (localWoEquipAssocs!=null){
                                  for (int i = 0;i < localWoEquipAssocs.length;i++){
                                      
                                          elementList.add(new javax.xml.namespace.QName("",
                                                                                                                       "woEquipAssocs"));
                                          elementList.add(
                                          org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localWoEquipAssocs[i]));

                                      

                                  }
                            } else {
                              
                                    elementList.add(new javax.xml.namespace.QName("",
                                                                              "woEquipAssocs"));
                                    elementList.add(null);
                                
                            }

                        } if (localWoFailureDetailVOsTracker){
                             if (localWoFailureDetailVOs!=null) {
                                 for (int i = 0;i < localWoFailureDetailVOs.length;i++){

                                    if (localWoFailureDetailVOs[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "woFailureDetailVOs"));
                                         elementList.add(localWoFailureDetailVOs[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "woFailureDetailVOs"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "woFailureDetailVOs"));
                                        elementList.add(localWoFailureDetailVOs);
                                    
                             }

                        } if (localWoFailureInfoVOTracker){
                            elementList.add(new javax.xml.namespace.QName("",
                                                                      "woFailureInfoVO"));
                            
                            
                                    if (localWoFailureInfoVO==null){
                                         throw new org.apache.axis2.databinding.ADBException("woFailureInfoVO cannot be null!!");
                                    }
                                    elementList.add(localWoFailureInfoVO);
                                } if (localWoFollowupActionVOsTracker){
                             if (localWoFollowupActionVOs!=null) {
                                 for (int i = 0;i < localWoFollowupActionVOs.length;i++){

                                    if (localWoFollowupActionVOs[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "woFollowupActionVOs"));
                                         elementList.add(localWoFollowupActionVOs[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "woFollowupActionVOs"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "woFollowupActionVOs"));
                                        elementList.add(localWoFollowupActionVOs);
                                    
                             }

                        } if (localWoJobRequirementVOsTracker){
                             if (localWoJobRequirementVOs!=null) {
                                 for (int i = 0;i < localWoJobRequirementVOs.length;i++){

                                    if (localWoJobRequirementVOs[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "woJobRequirementVOs"));
                                         elementList.add(localWoJobRequirementVOs[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "woJobRequirementVOs"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "woJobRequirementVOs"));
                                        elementList.add(localWoJobRequirementVOs);
                                    
                             }

                        } if (localWoNoTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "woNo"));
                                 
                                        if (localWoNo != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localWoNo));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("woNo cannot be null!!");
                                        }
                                    } if (localWoPlanLabourCostVOsTracker){
                             if (localWoPlanLabourCostVOs!=null) {
                                 for (int i = 0;i < localWoPlanLabourCostVOs.length;i++){

                                    if (localWoPlanLabourCostVOs[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "woPlanLabourCostVOs"));
                                         elementList.add(localWoPlanLabourCostVOs[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "woPlanLabourCostVOs"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "woPlanLabourCostVOs"));
                                        elementList.add(localWoPlanLabourCostVOs);
                                    
                             }

                        } if (localWoPlanLocationVOsTracker){
                             if (localWoPlanLocationVOs!=null) {
                                 for (int i = 0;i < localWoPlanLocationVOs.length;i++){

                                    if (localWoPlanLocationVOs[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "woPlanLocationVOs"));
                                         elementList.add(localWoPlanLocationVOs[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "woPlanLocationVOs"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "woPlanLocationVOs"));
                                        elementList.add(localWoPlanLocationVOs);
                                    
                             }

                        } if (localWoPlanMaterialCostVOsTracker){
                             if (localWoPlanMaterialCostVOs!=null) {
                                 for (int i = 0;i < localWoPlanMaterialCostVOs.length;i++){

                                    if (localWoPlanMaterialCostVOs[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "woPlanMaterialCostVOs"));
                                         elementList.add(localWoPlanMaterialCostVOs[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "woPlanMaterialCostVOs"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "woPlanMaterialCostVOs"));
                                        elementList.add(localWoPlanMaterialCostVOs);
                                    
                             }

                        } if (localWoPlanOtherCostVOsTracker){
                             if (localWoPlanOtherCostVOs!=null) {
                                 for (int i = 0;i < localWoPlanOtherCostVOs.length;i++){

                                    if (localWoPlanOtherCostVOs[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "woPlanOtherCostVOs"));
                                         elementList.add(localWoPlanOtherCostVOs[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "woPlanOtherCostVOs"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "woPlanOtherCostVOs"));
                                        elementList.add(localWoPlanOtherCostVOs);
                                    
                             }

                        } if (localWoRecoveryVOTracker){
                            elementList.add(new javax.xml.namespace.QName("",
                                                                      "woRecoveryVO"));
                            
                            
                                    if (localWoRecoveryVO==null){
                                         throw new org.apache.axis2.databinding.ADBException("woRecoveryVO cannot be null!!");
                                    }
                                    elementList.add(localWoRecoveryVO);
                                } if (localWoStatusHistoryVOsTracker){
                             if (localWoStatusHistoryVOs!=null) {
                                 for (int i = 0;i < localWoStatusHistoryVOs.length;i++){

                                    if (localWoStatusHistoryVOs[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "woStatusHistoryVOs"));
                                         elementList.add(localWoStatusHistoryVOs[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "woStatusHistoryVOs"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "woStatusHistoryVOs"));
                                        elementList.add(localWoStatusHistoryVOs);
                                    
                             }

                        } if (localWoSuspensionVOsTracker){
                             if (localWoSuspensionVOs!=null) {
                                 for (int i = 0;i < localWoSuspensionVOs.length;i++){

                                    if (localWoSuspensionVOs[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "woSuspensionVOs"));
                                         elementList.add(localWoSuspensionVOs[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "woSuspensionVOs"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "woSuspensionVOs"));
                                        elementList.add(localWoSuspensionVOs);
                                    
                             }

                        } if (localWoTaskVOsTracker){
                             if (localWoTaskVOs!=null) {
                                 for (int i = 0;i < localWoTaskVOs.length;i++){

                                    if (localWoTaskVOs[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "woTaskVOs"));
                                         elementList.add(localWoTaskVOs[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "woTaskVOs"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "woTaskVOs"));
                                        elementList.add(localWoTaskVOs);
                                    
                             }

                        } if (localWorkGrpTracker){
                            elementList.add(new javax.xml.namespace.QName("",
                                                                      "workGrp"));
                            
                            
                                    if (localWorkGrp==null){
                                         throw new org.apache.axis2.databinding.ADBException("workGrp cannot be null!!");
                                    }
                                    elementList.add(localWorkGrp);
                                } if (localWorkRequestsTracker){
                             if (localWorkRequests!=null) {
                                 for (int i = 0;i < localWorkRequests.length;i++){

                                    if (localWorkRequests[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "workRequests"));
                                         elementList.add(localWorkRequests[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "workRequests"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "workRequests"));
                                        elementList.add(localWorkRequests);
                                    
                             }

                        } if (localWorkTimeRequireTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "workTimeRequire"));
                                 
                                        if (localWorkTimeRequire != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localWorkTimeRequire));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("workTimeRequire cannot be null!!");
                                        }
                                    } if (localWrIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "wrId"));
                                 
                                        if (localWrId != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localWrId));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("wrId cannot be null!!");
                                        }
                                    } if (localEquipmentReferenceNameTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "equipmentReferenceName"));
                                 
                                        if (localEquipmentReferenceName != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localEquipmentReferenceName));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("equipmentReferenceName cannot be null!!");
                                        }
                                    } if (localSegment1Tracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "segment1"));
                                 
                                        if (localSegment1 != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSegment1));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("segment1 cannot be null!!");
                                        }
                                    } if (localSegment2Tracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "segment2"));
                                 
                                        if (localSegment2 != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSegment2));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("segment2 cannot be null!!");
                                        }
                                    } if (localSegment3Tracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "segment3"));
                                 
                                        if (localSegment3 != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSegment3));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("segment3 cannot be null!!");
                                        }
                                    } if (localSegment4Tracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "segment4"));
                                 
                                        if (localSegment4 != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSegment4));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("segment4 cannot be null!!");
                                        }
                                    } if (localTotalLabourCostVarianceTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "totalLabourCostVariance"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalLabourCostVariance));
                            } if (localTotalMaterialsCostVarianceTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "totalMaterialsCostVariance"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalMaterialsCostVariance));
                            } if (localTotalOtherCostVarianceTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "totalOtherCostVariance"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTotalOtherCostVariance));
                            } if (localFinalCostFlagTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "finalCostFlag"));
                                 
                                        if (localFinalCostFlag != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localFinalCostFlag));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("finalCostFlag cannot be null!!");
                                        }
                                    }

                return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName, elementList.toArray(), attribList.toArray());
            
            

        }

  

     /**
      *  Factory class that keeps the parse method
      */
    public static class Factory{

        
        

        /**
        * static method to create the object
        * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
        *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
        * Postcondition: If this object is an element, the reader is positioned at its end element
        *                If this object is a complex type, the reader is positioned at the end element of its outer element
        */
        public static WorkOrderVO parse(javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{
            WorkOrderVO object =
                new WorkOrderVO();

            int event;
            java.lang.String nillableValue = null;
            java.lang.String prefix ="";
            java.lang.String namespaceuri ="";
            try {
                
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                
                if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","type")!=null){
                  java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                        "type");
                  if (fullTypeName!=null){
                    java.lang.String nsPrefix = null;
                    if (fullTypeName.indexOf(":") > -1){
                        nsPrefix = fullTypeName.substring(0,fullTypeName.indexOf(":"));
                    }
                    nsPrefix = nsPrefix==null?"":nsPrefix;

                    java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":")+1);
                    
                            if (!"workOrderVO".equals(type)){
                                //find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext().getNamespaceURI(nsPrefix);
                                return (WorkOrderVO)hk.com.mtr.mmis.ws.ExtensionMapper.getTypeObject(
                                     nsUri,type,reader);
                              }
                        

                  }
                

                }

                

                
                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();
                

                 
                    
                    reader.next();
                
                        java.util.ArrayList list5 = new java.util.ArrayList();
                    
                        java.util.ArrayList list52 = new java.util.ArrayList();
                    
                        java.util.ArrayList list53 = new java.util.ArrayList();
                    
                        java.util.ArrayList list80 = new java.util.ArrayList();
                    
                        java.util.ArrayList list81 = new java.util.ArrayList();
                    
                        java.util.ArrayList list82 = new java.util.ArrayList();
                    
                        java.util.ArrayList list83 = new java.util.ArrayList();
                    
                        java.util.ArrayList list84 = new java.util.ArrayList();
                    
                        java.util.ArrayList list85 = new java.util.ArrayList();
                    
                        java.util.ArrayList list86 = new java.util.ArrayList();
                    
                        java.util.ArrayList list88 = new java.util.ArrayList();
                    
                        java.util.ArrayList list89 = new java.util.ArrayList();
                    
                        java.util.ArrayList list91 = new java.util.ArrayList();
                    
                        java.util.ArrayList list92 = new java.util.ArrayList();
                    
                        java.util.ArrayList list94 = new java.util.ArrayList();
                    
                        java.util.ArrayList list95 = new java.util.ArrayList();
                    
                        java.util.ArrayList list96 = new java.util.ArrayList();
                    
                        java.util.ArrayList list97 = new java.util.ArrayList();
                    
                        java.util.ArrayList list99 = new java.util.ArrayList();
                    
                        java.util.ArrayList list100 = new java.util.ArrayList();
                    
                        java.util.ArrayList list101 = new java.util.ArrayList();
                    
                        java.util.ArrayList list103 = new java.util.ArrayList();
                    
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","action").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setAction(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","actualCmplDate").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setActualCmplDate(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDateTime(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","actualStartDate").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setActualStartDate(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDateTime(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","actualStartTime").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setActualStartTime(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","childWolist").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list5.add(null);
                                                              reader.next();
                                                          } else {
                                                        list5.add(hk.com.mtr.mmis.ws.WoRelationship.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone5 = false;
                                                        while(!loopDone5){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone5 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","childWolist").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list5.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list5.add(hk.com.mtr.mmis.ws.WoRelationship.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone5 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setChildWolist((hk.com.mtr.mmis.ws.WoRelationship[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.WoRelationship.class,
                                                                list5));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","cmpltmnryContractNo").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setCmpltmnryContractNo(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","contractDesp").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setContractDesp(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","contractNo").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setContractNo(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","contractor").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setContractor(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","contractorInCharge").equals(reader.getName())){
                                
                                                object.setContractorInCharge(hk.com.mtr.mmis.ws.OrganizationUnit.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","detailIDs").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setDetailIDs(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","detailLoc").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setDetailLoc(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","earPlanStartDate").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setEarPlanStartDate(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDateTime(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","engineerInCharge").equals(reader.getName())){
                                
                                                object.setEngineerInCharge(hk.com.mtr.mmis.ws.HumanResource.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","equipClass").equals(reader.getName())){
                                
                                                object.setEquipClass(hk.com.mtr.mmis.ws.EquipClass.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","equipDownTime").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setEquipDownTime(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","equipment").equals(reader.getName())){
                                
                                                object.setEquipment(hk.com.mtr.mmis.ws.Equipment.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","finalizedInd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setFinalizedInd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcFinanceRefNoCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcFinanceRefNoCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcPriorityCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcPriorityCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcProjectNoCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcProjectNoCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcProjectTaskNoCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcProjectTaskNoCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcSvcBreakdownCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcSvcBreakdownCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcWorkNatureLv1Cd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcWorkNatureLv1Cd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcWorkNatureLv2Cd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcWorkNatureLv2Cd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","incidentNumber").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setIncidentNumber(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","incidentVO").equals(reader.getName())){
                                
                                                object.setIncidentVO(hk.com.mtr.mmis.ws.IncidentVO.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","labourCostCredit").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setLabourCostCredit(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","labourCostDebit").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setLabourCostDebit(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","lastPlanStartDate").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setLastPlanStartDate(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDateTime(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","locale").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setLocale(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","maintainerFinishWork").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setMaintainerFinishWork(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDateTime(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","maintainerSiteArrival").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setMaintainerSiteArrival(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDateTime(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","maintainerStartWork").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setMaintainerStartWork(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDateTime(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","materialCostCredit").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setMaterialCostCredit(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","materialCostDebit").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setMaterialCostDebit(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","oldWoNo").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setOldWoNo(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","oneOfRelatedMeasurementId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setOneOfRelatedMeasurementId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","openDate").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setOpenDate(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDateTime(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","otherCostCredit").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setOtherCostCredit(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","otherCostDebit").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setOtherCostDebit(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","parentWoRelationship").equals(reader.getName())){
                                
                                                object.setParentWoRelationship(hk.com.mtr.mmis.ws.WoRelationship.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","personInCharge").equals(reader.getName())){
                                
                                                object.setPersonInCharge(hk.com.mtr.mmis.ws.HumanResource.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","personInChargeUserId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setPersonInChargeUserId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","personInchrgCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setPersonInchrgCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","planCmplDate").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setPlanCmplDate(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDateTime(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","planStartDate").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setPlanStartDate(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDateTime(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","plannedCmplTime").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setPlannedCmplTime(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","plannedStartTime").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setPlannedStartTime(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","primaryRecoveryTime").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setPrimaryRecoveryTime(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","quantity").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setQuantity(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setQuantity(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","relatedMeasurementIds").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                              nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                              if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                  list52.add(null);
                                                       
                                                  reader.next();
                                              } else {
                                            list52.add(reader.getElementText());
                                            }
                                            //loop until we find a start element that is not part of this array
                                            boolean loopDone52 = false;
                                            while(!loopDone52){
                                                // Ensure we are at the EndElement
                                                while (!reader.isEndElement()){
                                                    reader.next();
                                                }
                                                // Step out of this element
                                                reader.next();
                                                // Step to next element event.
                                                while (!reader.isStartElement() && !reader.isEndElement())
                                                    reader.next();
                                                if (reader.isEndElement()){
                                                    //two continuous end elements means we are exiting the xml structure
                                                    loopDone52 = true;
                                                } else {
                                                    if (new javax.xml.namespace.QName("","relatedMeasurementIds").equals(reader.getName())){
                                                         
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list52.add(null);
                                                                   
                                                              reader.next();
                                                          } else {
                                                        list52.add(reader.getElementText());
                                                        }
                                                    }else{
                                                        loopDone52 = true;
                                                    }
                                                }
                                            }
                                            // call the converter utility  to convert and set the array
                                            
                                                    object.setRelatedMeasurementIds((java.lang.String[])
                                                        list52.toArray(new java.lang.String[list52.size()]));
                                                
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","relatedWoList").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list53.add(null);
                                                              reader.next();
                                                          } else {
                                                        list53.add(hk.com.mtr.mmis.ws.WoRelationship.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone53 = false;
                                                        while(!loopDone53){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone53 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","relatedWoList").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list53.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list53.add(hk.com.mtr.mmis.ws.WoRelationship.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone53 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setRelatedWoList((hk.com.mtr.mmis.ws.WoRelationship[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.WoRelationship.class,
                                                                list53));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","remark").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setRemark(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","reservedField1").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setReservedField1(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","reservedField2").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setReservedField2(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","reservedField3").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setReservedField3(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","serviceDownTime").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setServiceDownTime(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","serviceNotRequireTime").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setServiceNotRequireTime(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","shortLoc").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setShortLoc(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","status").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setStatus(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","statusDesc").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setStatusDesc(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","statusHis").equals(reader.getName())){
                                
                                                object.setStatusHis(hk.com.mtr.mmis.ws.WoStatusHistoryVO.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","stdJob").equals(reader.getName())){
                                
                                                object.setStdJob(hk.com.mtr.mmis.ws.StandardJob.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","stdJobParamListId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setStdJobParamListId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setStdJobParamListId(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","stdJobParamSetName").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setStdJobParamSetName(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","totalActualHour").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setTotalActualHour(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setTotalActualHour(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","totalActualLabourCost").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setTotalActualLabourCost(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setTotalActualLabourCost(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","totalActualMaterialCost").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setTotalActualMaterialCost(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setTotalActualMaterialCost(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","totalActualOtherCost").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setTotalActualOtherCost(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setTotalActualOtherCost(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","totalActualQuantity").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setTotalActualQuantity(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setTotalActualQuantity(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","totalPlanHour").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setTotalPlanHour(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setTotalPlanHour(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","totalPlanLabourCost").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setTotalPlanLabourCost(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setTotalPlanLabourCost(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","totalPlanMaterialCost").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setTotalPlanMaterialCost(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setTotalPlanMaterialCost(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","totalPlanOtherCost").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setTotalPlanOtherCost(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setTotalPlanOtherCost(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","totalPlanQuantity").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setTotalPlanQuantity(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setTotalPlanQuantity(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","totalRecoveryTime").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setTotalRecoveryTime(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","totalResponseTime").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setTotalResponseTime(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","totalSuspensionTime").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setTotalSuspensionTime(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woActDelLabourCostVOs").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list80.add(null);
                                                              reader.next();
                                                          } else {
                                                        list80.add(hk.com.mtr.mmis.ws.WoActBolVO.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone80 = false;
                                                        while(!loopDone80){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone80 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","woActDelLabourCostVOs").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list80.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list80.add(hk.com.mtr.mmis.ws.WoActBolVO.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone80 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setWoActDelLabourCostVOs((hk.com.mtr.mmis.ws.WoActBolVO[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.WoActBolVO.class,
                                                                list80));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woActDelMaterialCostVOs").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list81.add(null);
                                                              reader.next();
                                                          } else {
                                                        list81.add(hk.com.mtr.mmis.ws.WoActBomVO.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone81 = false;
                                                        while(!loopDone81){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone81 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","woActDelMaterialCostVOs").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list81.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list81.add(hk.com.mtr.mmis.ws.WoActBomVO.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone81 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setWoActDelMaterialCostVOs((hk.com.mtr.mmis.ws.WoActBomVO[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.WoActBomVO.class,
                                                                list81));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woActDelOtherCostVOs").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list82.add(null);
                                                              reader.next();
                                                          } else {
                                                        list82.add(hk.com.mtr.mmis.ws.WoActBooVO.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone82 = false;
                                                        while(!loopDone82){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone82 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","woActDelOtherCostVOs").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list82.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list82.add(hk.com.mtr.mmis.ws.WoActBooVO.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone82 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setWoActDelOtherCostVOs((hk.com.mtr.mmis.ws.WoActBooVO[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.WoActBooVO.class,
                                                                list82));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woActLabourCostVOs").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list83.add(null);
                                                              reader.next();
                                                          } else {
                                                        list83.add(hk.com.mtr.mmis.ws.WoActBolVO.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone83 = false;
                                                        while(!loopDone83){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone83 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","woActLabourCostVOs").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list83.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list83.add(hk.com.mtr.mmis.ws.WoActBolVO.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone83 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setWoActLabourCostVOs((hk.com.mtr.mmis.ws.WoActBolVO[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.WoActBolVO.class,
                                                                list83));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woActLocationVOs").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list84.add(null);
                                                              reader.next();
                                                          } else {
                                                        list84.add(hk.com.mtr.mmis.ws.LocationRangeVO.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone84 = false;
                                                        while(!loopDone84){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone84 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","woActLocationVOs").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list84.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list84.add(hk.com.mtr.mmis.ws.LocationRangeVO.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone84 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setWoActLocationVOs((hk.com.mtr.mmis.ws.LocationRangeVO[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.LocationRangeVO.class,
                                                                list84));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woActMaterialCostVOs").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list85.add(null);
                                                              reader.next();
                                                          } else {
                                                        list85.add(hk.com.mtr.mmis.ws.WoActBomVO.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone85 = false;
                                                        while(!loopDone85){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone85 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","woActMaterialCostVOs").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list85.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list85.add(hk.com.mtr.mmis.ws.WoActBomVO.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone85 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setWoActMaterialCostVOs((hk.com.mtr.mmis.ws.WoActBomVO[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.WoActBomVO.class,
                                                                list85));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woActOtherCostVOs").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list86.add(null);
                                                              reader.next();
                                                          } else {
                                                        list86.add(hk.com.mtr.mmis.ws.WoActBooVO.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone86 = false;
                                                        while(!loopDone86){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone86 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","woActOtherCostVOs").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list86.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list86.add(hk.com.mtr.mmis.ws.WoActBooVO.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone86 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setWoActOtherCostVOs((hk.com.mtr.mmis.ws.WoActBooVO[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.WoActBooVO.class,
                                                                list86));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woDesp").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setWoDesp(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woEquipAssocs").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                              nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                              if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                  list88.add(String.valueOf(java.lang.Long.MIN_VALUE));
                                                       
                                                  reader.next();
                                              } else {
                                            list88.add(reader.getElementText());
                                            }
                                            //loop until we find a start element that is not part of this array
                                            boolean loopDone88 = false;
                                            while(!loopDone88){
                                                // Ensure we are at the EndElement
                                                while (!reader.isEndElement()){
                                                    reader.next();
                                                }
                                                // Step out of this element
                                                reader.next();
                                                // Step to next element event.
                                                while (!reader.isStartElement() && !reader.isEndElement())
                                                    reader.next();
                                                if (reader.isEndElement()){
                                                    //two continuous end elements means we are exiting the xml structure
                                                    loopDone88 = true;
                                                } else {
                                                    if (new javax.xml.namespace.QName("","woEquipAssocs").equals(reader.getName())){
                                                         
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list88.add(String.valueOf(java.lang.Long.MIN_VALUE));
                                                                   
                                                              reader.next();
                                                          } else {
                                                        list88.add(reader.getElementText());
                                                        }
                                                    }else{
                                                        loopDone88 = true;
                                                    }
                                                }
                                            }
                                            // call the converter utility  to convert and set the array
                                            
                                            object.setWoEquipAssocs((long[])
                                                org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                            long.class,list88));
                                                
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woFailureDetailVOs").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list89.add(null);
                                                              reader.next();
                                                          } else {
                                                        list89.add(hk.com.mtr.mmis.ws.WoFailureDetailVO.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone89 = false;
                                                        while(!loopDone89){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone89 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","woFailureDetailVOs").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list89.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list89.add(hk.com.mtr.mmis.ws.WoFailureDetailVO.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone89 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setWoFailureDetailVOs((hk.com.mtr.mmis.ws.WoFailureDetailVO[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.WoFailureDetailVO.class,
                                                                list89));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woFailureInfoVO").equals(reader.getName())){
                                
                                                object.setWoFailureInfoVO(hk.com.mtr.mmis.ws.WoFailureInfoVO.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woFollowupActionVOs").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list91.add(null);
                                                              reader.next();
                                                          } else {
                                                        list91.add(hk.com.mtr.mmis.ws.WoFollowupActionVO.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone91 = false;
                                                        while(!loopDone91){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone91 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","woFollowupActionVOs").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list91.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list91.add(hk.com.mtr.mmis.ws.WoFollowupActionVO.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone91 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setWoFollowupActionVOs((hk.com.mtr.mmis.ws.WoFollowupActionVO[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.WoFollowupActionVO.class,
                                                                list91));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woJobRequirementVOs").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list92.add(null);
                                                              reader.next();
                                                          } else {
                                                        list92.add(hk.com.mtr.mmis.ws.WoJobRequirementVO.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone92 = false;
                                                        while(!loopDone92){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone92 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","woJobRequirementVOs").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list92.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list92.add(hk.com.mtr.mmis.ws.WoJobRequirementVO.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone92 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setWoJobRequirementVOs((hk.com.mtr.mmis.ws.WoJobRequirementVO[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.WoJobRequirementVO.class,
                                                                list92));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woNo").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setWoNo(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woPlanLabourCostVOs").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list94.add(null);
                                                              reader.next();
                                                          } else {
                                                        list94.add(hk.com.mtr.mmis.ws.WoPlanBolVO.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone94 = false;
                                                        while(!loopDone94){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone94 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","woPlanLabourCostVOs").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list94.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list94.add(hk.com.mtr.mmis.ws.WoPlanBolVO.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone94 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setWoPlanLabourCostVOs((hk.com.mtr.mmis.ws.WoPlanBolVO[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.WoPlanBolVO.class,
                                                                list94));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woPlanLocationVOs").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list95.add(null);
                                                              reader.next();
                                                          } else {
                                                        list95.add(hk.com.mtr.mmis.ws.LocationRangeVO.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone95 = false;
                                                        while(!loopDone95){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone95 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","woPlanLocationVOs").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list95.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list95.add(hk.com.mtr.mmis.ws.LocationRangeVO.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone95 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setWoPlanLocationVOs((hk.com.mtr.mmis.ws.LocationRangeVO[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.LocationRangeVO.class,
                                                                list95));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woPlanMaterialCostVOs").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list96.add(null);
                                                              reader.next();
                                                          } else {
                                                        list96.add(hk.com.mtr.mmis.ws.WoPlanBomVO.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone96 = false;
                                                        while(!loopDone96){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone96 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","woPlanMaterialCostVOs").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list96.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list96.add(hk.com.mtr.mmis.ws.WoPlanBomVO.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone96 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setWoPlanMaterialCostVOs((hk.com.mtr.mmis.ws.WoPlanBomVO[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.WoPlanBomVO.class,
                                                                list96));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woPlanOtherCostVOs").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list97.add(null);
                                                              reader.next();
                                                          } else {
                                                        list97.add(hk.com.mtr.mmis.ws.WoPlanBooVO.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone97 = false;
                                                        while(!loopDone97){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone97 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","woPlanOtherCostVOs").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list97.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list97.add(hk.com.mtr.mmis.ws.WoPlanBooVO.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone97 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setWoPlanOtherCostVOs((hk.com.mtr.mmis.ws.WoPlanBooVO[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.WoPlanBooVO.class,
                                                                list97));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woRecoveryVO").equals(reader.getName())){
                                
                                                object.setWoRecoveryVO(hk.com.mtr.mmis.ws.WoRecoveryVO.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woStatusHistoryVOs").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list99.add(null);
                                                              reader.next();
                                                          } else {
                                                        list99.add(hk.com.mtr.mmis.ws.WoStatusHistoryVO.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone99 = false;
                                                        while(!loopDone99){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone99 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","woStatusHistoryVOs").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list99.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list99.add(hk.com.mtr.mmis.ws.WoStatusHistoryVO.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone99 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setWoStatusHistoryVOs((hk.com.mtr.mmis.ws.WoStatusHistoryVO[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.WoStatusHistoryVO.class,
                                                                list99));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woSuspensionVOs").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list100.add(null);
                                                              reader.next();
                                                          } else {
                                                        list100.add(hk.com.mtr.mmis.ws.WoSuspensionVO.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone100 = false;
                                                        while(!loopDone100){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone100 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","woSuspensionVOs").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list100.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list100.add(hk.com.mtr.mmis.ws.WoSuspensionVO.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone100 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setWoSuspensionVOs((hk.com.mtr.mmis.ws.WoSuspensionVO[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.WoSuspensionVO.class,
                                                                list100));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woTaskVOs").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list101.add(null);
                                                              reader.next();
                                                          } else {
                                                        list101.add(hk.com.mtr.mmis.ws.WoTaskVO.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone101 = false;
                                                        while(!loopDone101){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone101 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","woTaskVOs").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list101.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list101.add(hk.com.mtr.mmis.ws.WoTaskVO.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone101 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setWoTaskVOs((hk.com.mtr.mmis.ws.WoTaskVO[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.WoTaskVO.class,
                                                                list101));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","workGrp").equals(reader.getName())){
                                
                                                object.setWorkGrp(hk.com.mtr.mmis.ws.WorkGrp.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","workRequests").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list103.add(null);
                                                              reader.next();
                                                          } else {
                                                        list103.add(hk.com.mtr.mmis.ws.WorkRequest.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone103 = false;
                                                        while(!loopDone103){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone103 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","workRequests").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list103.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list103.add(hk.com.mtr.mmis.ws.WorkRequest.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone103 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setWorkRequests((hk.com.mtr.mmis.ws.WorkRequest[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.WorkRequest.class,
                                                                list103));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","workTimeRequire").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setWorkTimeRequire(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","wrId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setWrId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","equipmentReferenceName").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setEquipmentReferenceName(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","segment1").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setSegment1(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","segment2").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setSegment2(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","segment3").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setSegment3(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","segment4").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setSegment4(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","totalLabourCostVariance").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setTotalLabourCostVariance(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setTotalLabourCostVariance(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","totalMaterialsCostVariance").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setTotalMaterialsCostVariance(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setTotalMaterialsCostVariance(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","totalOtherCostVariance").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setTotalOtherCostVariance(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setTotalOtherCostVariance(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","finalCostFlag").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setFinalCostFlag(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                  
                            while (!reader.isStartElement() && !reader.isEndElement())
                                reader.next();
                            
                                if (reader.isStartElement())
                                // A start element we are not expecting indicates a trailing invalid property
                                throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader.getLocalName());
                            



            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }

        }//end of factory class

        

        }
           
          