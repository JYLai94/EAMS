
/**
 * WorkOrderServicePortSkeletonInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: SNAPSHOT  Built on : Jan 10, 2009 (05:26:14 CST)
 */
    package hk.com.mtr.mmis.ws;
    /**
     *  WorkOrderServicePortSkeletonInterface java skeleton interface for the axisService
     */
    public interface WorkOrderServicePortSkeletonInterface {
     
         
        /**
         * Auto generated method signature
         * 
                                    * @param retrieveWorkOrder
             * @throws WorkOrderException : 
         */

        
                public hk.com.mtr.mmis.ws.RetrieveWorkOrderResponseE retrieveWorkOrder
                (
                  hk.com.mtr.mmis.ws.RetrieveWorkOrderE retrieveWorkOrder
                 )
            throws WorkOrderException;
        
         
        /**
         * Auto generated method signature
         * 
                                    * @param retrieveWorkOrderList
             * @throws WorkOrderException : 
         */

        
                public hk.com.mtr.mmis.ws.RetrieveWorkOrderListResponseE retrieveWorkOrderList
                (
                  hk.com.mtr.mmis.ws.RetrieveWorkOrderListE retrieveWorkOrderList
                 )
            throws WorkOrderException;
        
         }
    