
/**
 * WorkOrderException.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: SNAPSHOT  Built on : Jan 10, 2009 (05:26:14 CST)
 */

package hk.com.mtr.mmis.ws;

public class WorkOrderException extends java.lang.Exception{
    
    private hk.com.mtr.mmis.ws.MMISWebServiceExceptionE faultMessage;
    
    public WorkOrderException() {
        super("WorkOrderException");
    }
           
    public WorkOrderException(java.lang.String s) {
       super(s);
    }
    
    public WorkOrderException(java.lang.String s, java.lang.Throwable ex) {
      super(s, ex);
    }
    
    public void setFaultMessage(hk.com.mtr.mmis.ws.MMISWebServiceExceptionE msg){
       faultMessage = msg;
    }
    
    public hk.com.mtr.mmis.ws.MMISWebServiceExceptionE getFaultMessage(){
       return faultMessage;
    }
}
    