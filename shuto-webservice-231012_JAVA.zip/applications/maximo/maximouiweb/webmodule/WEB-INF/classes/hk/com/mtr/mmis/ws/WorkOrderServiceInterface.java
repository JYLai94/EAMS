/**
 * WorkOrderServiceInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package hk.com.mtr.mmis.ws;

import javax.xml.parsers.ParserConfigurationException;

import psdi.util.MXException;

public interface WorkOrderServiceInterface  {
//    public hk.com.mtr.mmis.ws.WorkOrderVO[] retrieveWorkOrderList(java.lang.String[] workOrderNo) throws java.rmi.RemoteException, hk.com.mtr.mmis.ws.MMISWebServiceException;
//    public hk.com.mtr.mmis.ws.WorkOrderVO retrieveWorkOrder(java.lang.String workOrderNo) throws java.rmi.RemoteException, hk.com.mtr.mmis.ws.MMISWebServiceException;
    
//    public abstract hk.com.mtr.mmis.ws.WorkOrderVO[] retrieveWorkOrderList(java.lang.String[] workOrderNo) throws java.rmi.RemoteException;
//	public abstract WorkOrderVO[] retrieveWorkOrderListXXXXXX(String [] workOrderNo) throws java.rmi.RemoteException,MXException,WorkOrderException;
//	public abstract WorkOrderVO retrieveWorkOrderXXXXXX(java.lang.String workOrderNo) throws java.rmi.RemoteException,MXException,WorkOrderException;
	public abstract String retrieveWorkOrder(java.lang.String workOrderNo) throws java.rmi.RemoteException,MXException,WorkOrderException,ParserConfigurationException;
    
//    public abstract String retrieveWorkOrderYYY(String workOrderNo)
//			 throws MXException,RemoteException,WorkOrderException; 
}
