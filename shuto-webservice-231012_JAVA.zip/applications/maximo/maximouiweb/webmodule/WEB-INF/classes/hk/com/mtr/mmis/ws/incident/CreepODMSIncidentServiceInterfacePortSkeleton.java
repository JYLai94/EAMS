
package hk.com.mtr.mmis.ws.incident;

import java.rmi.RemoteException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import psdi.app.ticket.Incident;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.server.MXServer;
import psdi.util.MXException;

// Referenced classes of package hk.com.mtr.mmis.ws.incident:
//            CreepODMSIncidentServiceInterfacePortSkeletonInterface, CreepODMSIncidentException, ResultObjectArray, _return, 
//            WmODMSIncidentUploadVOList, WmODMSIncidentUploadVOArray, ResultObject, WmODMSIncidentUploadVO, 
//            IncidentValidator

public class CreepODMSIncidentServiceInterfacePortSkeleton
    implements CreepODMSIncidentServiceInterfacePortSkeletonInterface
{

    public CreepODMSIncidentServiceInterfacePortSkeleton()
    {
    }

    public _return createIncident(WmODMSIncidentUploadVOList wmODMSIncidentUploadVOList0)
        throws CreepODMSIncidentException
    {
        ResultObjectArray resultObjectArray = new ResultObjectArray();
        List resp = new ArrayList();
        List ret = new ArrayList();
        _return _returnResult = new _return();
        if(wmODMSIncidentUploadVOList0 == null || wmODMSIncidentUploadVOList0.getWmODMSIncidentUploadVOList() == null || wmODMSIncidentUploadVOList0.getWmODMSIncidentUploadVOList().getItem() == null)
        {
            System.out.println("~~~~~~~14 error~~~~~~");
            ResultObject ro = new ResultObject();
            ro.setResultCode("-14");
            ro.setResultMessage("InvocationTargetException");
            resultObjectArray.addItem(ro);
            ret.add(resultObjectArray);
            _returnResult.set_return(resultObjectArray);
            return _returnResult;
        }
        WmODMSIncidentUploadVO awmodmsincidentuploadvo[];
        int j = (awmodmsincidentuploadvo = wmODMSIncidentUploadVOList0.getWmODMSIncidentUploadVOList().getItem()).length;
        for(int i = 0; i < j; i++)
        {
            WmODMSIncidentUploadVO vo = awmodmsincidentuploadvo[i];
            ResultObject ro = new ResultObject();
            List mes = new ArrayList();
            try
            {
                String v_id = vo.getIncidentId();
                Boolean v_flag = Boolean.valueOf(false);
                Boolean v_flag2 = Boolean.valueOf(false);
                Boolean isExist = Boolean.valueOf(findincident(v_id));
                if(isExist.booleanValue())
                {
                    v_flag = Boolean.valueOf(checkIncident2(vo, ro));
                    if(!v_flag.booleanValue())
                        v_flag2 = Boolean.valueOf(updateIncident(vo));
                } else
                {
                    v_flag = Boolean.valueOf(checkIncident(vo, ro));
                    if(!v_flag.booleanValue())
                        v_flag2 = Boolean.valueOf(insertIncident(vo));
                }
                if(ro.getResultMessage() == null && !v_flag.booleanValue() && v_flag2.booleanValue())
                {
                    ro.setResultCode("0");
                    ro.setResultMessage("Success");
                } else
                if(ro.getResultMessage() == null && !v_flag.booleanValue())
                {
                    ro.setResultCode("-18");
                    ro.setResultMessage("Other Exception");
                }
                resultObjectArray.addItem(ro);
            }
            catch(RuntimeException e3)
            {
                e3.printStackTrace();
                ro.setResultMessage("RuntimeException");
                ro.setResultCode("-16");
                System.out.println("~~~~~RuntimeException~~~~~~");
                resultObjectArray.addItem(ro);
            }
            catch(RemoteException e2)
            {
                ro.setResultMessage("DB2Exception,Please contact  administrator.");
                ro.setResultCode("-17");
                System.out.println("~~~~~RemoteException~~~~~~");
            }
            catch(MXException e)
            {
                ro.setResultMessage("Other Exception");
                ro.setResultCode("-18");
                System.out.println("~~~~~MXException~~~~~~");
            }
            ro.setIncidentId(vo.getIncidentId());
        }

        System.out.println((new StringBuilder("~~~~~ok2~~~~~~")).append(resultObjectArray.getItem().length).toString());
        ret.add(resultObjectArray);
        _returnResult.set_return(resultObjectArray);
        return _returnResult;
    }

    private boolean findincident(String incidentid)
        throws RemoteException, MXException
    {
        MboSetRemote msr = MXServer.getMXServer().getMboSet("INCIDENT", MXServer.getMXServer().getSystemUserInfo());
        msr.setWhere((new StringBuilder("TICKETID ='")).append(incidentid).append("'").toString());
        msr.reset();
        if(msr.isEmpty())
        {
            msr.close();
            return false;
        } else
        {
            msr.close();
            return true;
        }
    }

    private boolean updateIncident(WmODMSIncidentUploadVO vo)
        throws RemoteException, MXException
    {
        String v_id = vo.getIncidentId();
        try{
            System.out.println("~~~~~~~now enter skel updateincident~~~~~~");
            MboSetRemote  msr = MXServer.getMXServer().getMboSet("INCIDENT", MXServer.getMXServer().getSystemUserInfo());
            msr.setWhere("TICKETID ='"+v_id +"'");
            msr.reset();
            if (!msr.isEmpty())//�����߼�
            {
                Incident mbo = (Incident)msr.getMbo(0);
                double v_delayminutes = vo.getInitialDelayMinutes()/60;
                double v_initminutes = vo.getAccessDelayMinutes()/60;                
                if (vo.localInitialDelayMinutesTracker)
                    mbo.setValue("MTR_INITIAL_DELAY", vo.getInitialDelayMinutes() );
                if (vo.localAccessDelayMinutesTracker)
                    mbo.setValue("MTR_ACCUMULATED_DELAY",  vo.getAccessDelayMinutes() );
                if (vo.localAffectedTrainCountTracker)
                    mbo.setValue("MTR_NO_OF_TRAIN_AFFECTED",  vo.getAffectedTrainCount() );
                if (vo.localTrainNoTracker)
                    mbo.setValue("MTR_INCIDENT_TRAIN_NO",  vo.getTrainNo());
                if (vo.localWithdrawnTrainCountTracker)
                    mbo.setValue("MTR_NO_OF_TRAIN_WITHDRAWN",  vo.getWithdrawnTrainCount());
                if (vo.localCancelledTrainCountTracker)
                    mbo.setValue("MTR_NO_OF_TRAIN_CANCELLED",  vo.getCancelledTrainCount() );
                if (vo.localCancelledTripCountTracker)
                    mbo.setValue("MTR_NO_OF_TRIP_CANCELLED",  vo.getCancelledTripCount() );
                if (vo.localChangeoverTrainCountTracker)
                    mbo.setValue("MTR_NO_OF_TRAIN_CHANGED_OVER",  vo.getChangeoverTrainCount() );
                if (vo.localLineCdTracker)
                    mbo.setValue("MTR_ACTUAL_LINE_ID",  vo.getLineCd() );
                String v_status ="";
                if (vo.localStatusTracker)
                {
                    if (vo.getStatus().equals("0") )
                    {
                        v_status = "RESOLVED";
                    }
                    else
                        v_status = "INPROG";
                }
                System.out.println("~~~~~~~status is ~~~~~~" + v_status);                
                if (vo.localLastUpdDatetimeTracker)
                {
                    mbo.setFieldFlag("CHANGEDATE", 7L, false);
                    String value = vo.getLastUpdDatetime();
                    if (value.length() == 16)
                        value = "20" +value;
                    else if (value.length() == 8)
                        value = value.substring(0,4)+"-"+ value.substring(4,6) +"-" +value.substring(6,8);
                    SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd");
                    if (!value.equals(""))
                    {
                        try {
                            Date dd = df.parse(value);
                            mbo.setValue("STATUSDATE", dd ,2L );
                        } catch (ParseException e) {
                            e.printStackTrace();
                            return false;
                        }
                    }
                }
//                mbo.setValue("CHANGEBY",  MXServer.getMXServer().getSystemUserInfo().getPersonId() );    
                mbo.changeStatus(v_status, MXServer.getMXServer().getDate(), "");
                msr.save();  
                msr.close();
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    private boolean insertIncident(WmODMSIncidentUploadVO vo)
        throws RemoteException, MXException
    {
        try{
            System.out.println("~~~~~~~now enter skel insertincident~~~~~~");
            MboSetRemote  msr = MXServer.getMXServer().getMboSet("INCIDENT", MXServer.getMXServer().getSystemUserInfo());
            MboRemote mbo = msr.add();
            double v_delayminutes = vo.getInitialDelayMinutes()/60;
            double v_initminutes = vo.getAccessDelayMinutes()/60;            
            mbo.setValue("TICKETID",  vo.getIncidentId() );
            mbo.setValue("MTR_INITIAL_DELAY",  vo.getInitialDelayMinutes() );
            mbo.setValue("MTR_ACCUMULATED_DELAY",  vo.getAccessDelayMinutes() );
            mbo.setValue("MTR_NO_OF_TRAIN_AFFECTED",  vo.getAffectedTrainCount() );
            mbo.setValue("MTR_INCIDENT_TRAIN_NO",  vo.getTrainNo());
            mbo.setValue("MTR_NO_OF_TRAIN_WITHDRAWN",  vo.getWithdrawnTrainCount());
            mbo.setValue("MTR_NO_OF_TRAIN_CANCELLED",  vo.getCancelledTrainCount() );
            mbo.setValue("MTR_NO_OF_TRIP_CANCELLED",  vo.getCancelledTripCount() );
            mbo.setValue("MTR_NO_OF_TRAIN_CHANGED_OVER",  vo.getChangeoverTrainCount() );
            mbo.setValue("MTR_ACTUAL_LINE_ID",  vo.getLineCd() );
            mbo.setValue("MTR_URN",  1);           

            mbo.setFieldFlag("STATUS", 7L, false);
            String v_status = "";
            if (vo.getStatus().equals("0") )
            {
                //mbo.setValue("STATUS",  "RESOLVED" ,11L);
                v_status = "RESOLVED";
            }
            else
                v_status = "INPROG";
                //mbo.setValue("STATUS",  "DISABLED" );   
            System.out.println("~~~~~~~status is ~~~~~~" + v_status);
            mbo.setFieldFlag("CHANGEDATE", 7L, false);
            //ʱ��д��
            String value = vo.getLastUpdDatetime();
            if (value.length() == 16)
                value = "20" +value;
            else if (value.length() == 8)
                value = value.substring(0,4)+"-"+ value.substring(4,6) +"-" +value.substring(6,8);
            //System.out.println("111111="+ value );
            SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd");
            if (!value.equals(""))
            {
                try {
                    Date dd = df.parse(value);
                    mbo.setValue("CHANGEDATE", dd ,11L );
                    mbo.setValue("STATUSDATE", dd ,11L );

                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
            mbo.setValue("MTR_CREATED_BY",   MXServer.getMXServer().getSystemUserInfo().getPersonId() );
            mbo.setValue("MTR_CREATE_DATE",  MXServer.getMXServer().getDate() );
            //mbo.setValue("CHANGEBY",  MXServer.getMXServer().getSystemUserInfo().getPersonId() );       
            Long v_id = mbo.getLong( mbo.getUniqueIDName());
            msr.save();
            Incident newmbo = (Incident)msr.getMboForUniqueId(v_id);
            if (newmbo !=null)
                newmbo.changeStatus(v_status, MXServer.getMXServer().getDate(), "");
            msr.save();               
            msr.close();
        }catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    private boolean checkIncident(WmODMSIncidentUploadVO vo, ResultObject ro)
        throws RemoteException, MXException
    {
        List checkret = new ArrayList();
        if(vo.getLineCd() != null)
        {
            MboSetRemote msr = MXServer.getMXServer().getMboSet("LOCATIONS", MXServer.getMXServer().getSystemUserInfo());
            msr.setWhere((new StringBuilder("LOCATION ='")).append(vo.getLineCd()).append("'").toString());
            msr.reset();
            if(msr.isEmpty())
            {
                ro.setResultCode("-15");
                ro.setResultMessage((new StringBuilder("Line No.")).append(vo.getLineCd()).append("  is Not Exist").toString());
                return true;
            }
        }
        checkret = IncidentValidator.validateWSIncident(vo);
        if(checkret.size() > 0)
        {
            ro.setResultCode((String)checkret.get(0));
            ro.setResultMessage((String)checkret.get(1));
            return true;
        } else
        {
            return false;
        }
    }

    private boolean checkIncident2(WmODMSIncidentUploadVO vo, ResultObject ro)
        throws RemoteException, MXException
    {
        List checkret = new ArrayList();
        if(vo.getLineCd() != null)
        {
            MboSetRemote msr = MXServer.getMXServer().getMboSet("LOCATIONS", MXServer.getMXServer().getSystemUserInfo());
            msr.setWhere((new StringBuilder("LOCATION ='")).append(vo.getLineCd()).append("'").toString());
            msr.reset();
            if(msr.isEmpty())
            {
                ro.setResultCode("-22");
                ro.setResultMessage((new StringBuilder("Could not update the URN No.(")).append(vo.getIncidentId()).append(")'s Line No. for it isn't matching the exist location.").toString());
                return true;
            }
        }
        checkret = IncidentValidator.validateWSIncident(vo);
        if(checkret.size() > 0)
        {
            ro.setResultCode((String)checkret.get(0));
            ro.setResultMessage((String)checkret.get(1));
            return true;
        } else
        {
            return false;
        }
    }
}