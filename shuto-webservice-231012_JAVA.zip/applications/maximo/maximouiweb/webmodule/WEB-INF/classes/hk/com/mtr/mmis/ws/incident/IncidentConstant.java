/*
 * Copyright (c) 2023 shutu, Inc. All rights reserved.
 */
package hk.com.mtr.mmis.ws.incident;

/**
 * 
 * @author shutu
 */
public class IncidentConstant {

    public static final String incident_success="SUCESS"; 
    public static final String incident_URNerror="URN No. could not be null.";
    public static final String incident_Nullerror="Flag Disabled. could not be null.";
    public static final String incident_0or1error="Flag Disabled only be 0 or 1";
    public static final String incident_NullUpdtime="Last Updated Time could not be null.";
    public static final String incident_InitDelayerror="Initial Delay format must like '99999.9999'.";
    public static final String incident_AccDelayerror="Accumulate Delay format must like '99999.9999'.";
    public static final String incident_Affecterror="No.of Trains Affected format must like '99999.9999'.";
    public static final String incident_WithDrownerror="No. of Trains Withdrawn format must like '99999.9999'.";
    public static final String incident_TrainsCancelerror="No. of Trains Cancelled format must like '99999.9999'.";
    public static final String incident_TripsCancelerror="No. of Trips Cancelled format must like '99999.9999'.";
    public static final String incident_ChangedOvererror="No. of Trains Changed Over format must like '999999999'.";
    public static final String incident_Updtimeerror="Last Updated Time format list 'yyyyMMdd' or 'yyyyMMddHHmmss' or 'yyyyMMddHHmmss999' or 'yyyyMMddHHmmss.999'";
    public static final String incident_IllegalAccessException="IllegalAccessException";
    public static final String incident_InvocationTargetException="InvocationTargetException";
    public static final String incident_LineNoerror="Line No. XXX  is Not Exist";
    public static final String incident_RuntimeException="RuntimeException";
    public static final String incident_DB2Exception="DB2Exception,Please contact  administrator.";
    public static final String incident_OtherException="Other Exception";
    
    
    public static String unicodeToUtf8(String theString) {  
        char aChar;  
        int len = theString.length();  
        StringBuffer outBuffer = new StringBuffer(len);  
        for (int x = 0; x < len;) {  
            aChar = theString.charAt(x++);  
            if (aChar == '\\') {  
                aChar = theString.charAt(x++);  
                if (aChar == 'u') {  
                    // Read the xxxx  
                    int value = 0;  
                    for (int i = 0; i < 4; i++) {  
                        aChar = theString.charAt(x++);  
                        switch (aChar) {  
                        case '0':  
                        case '1':  
                        case '2':  
                        case '3':  
                        case '4':  
                        case '5':  
                        case '6':  
                        case '7':  
                        case '8':  
                        case '9':  
                           value = (value << 4) + aChar - '0';  
                            break;  
                        case 'a':  
                        case 'b':  
                        case 'c':  
                        case 'd':  
                        case 'e':  
                        case 'f':  
                            value = (value << 4) + 10 + aChar - 'a';  
                            break;  
                        case 'A':  
                        case 'B':  
                        case 'C':  
                        case 'D':  
                        case 'E':  
                        case 'F':  
                            value = (value << 4) + 10 + aChar - 'A';  
                            break;  
                       default:  
                            throw new IllegalArgumentException(  
                                    "Malformed   \\uxxxx   encoding.");  
                        }  
                    }  
                    outBuffer.append((char) value);  
                } else {  
                    if (aChar == 't')  
                        aChar = '\t';  
                    else if (aChar == 'r')  
                        aChar = '\r';  
                    else if (aChar == 'n')  
                        aChar = '\n';  
                    else if (aChar == 'f')  
                        aChar = '\f';  
                    outBuffer.append(aChar);  
                }  
            } else 
                outBuffer.append(aChar);  
        }  
        return outBuffer.toString();  
    }
}
