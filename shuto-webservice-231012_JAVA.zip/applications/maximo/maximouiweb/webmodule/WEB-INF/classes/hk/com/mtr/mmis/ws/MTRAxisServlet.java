/*
 * Copyright (c) 2023 shutu, Inc. All rights reserved.
 */
package hk.com.mtr.mmis.ws;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.axis2.transport.TransportListener;
import org.apache.axis2.transport.http.AxisServlet;

/**
 * 
 * Copyright (c) 2023 shutu, Inc. All rights reserved.
 */
public class MTRAxisServlet extends AxisServlet implements TransportListener {

    /* (non-Javadoc)
     * ��֮ǰ����У��ͻ�ȡ
     * @see org.apache.axis2.transport.http.AxisServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {        
        System.out.println("~~~~~~~~~~soap enter begin~~~~~~~~~----");
//        String v_name  = request.getHeader("Username");
//        String v_psd  = request.getHeader("Username");
//        System.out.println("~~~~~name~~~~"+v_name);
        super.doPost(request, response);
        System.out.println("~~~~~~~~~~soap enter end~~~~~~~~~----");
    }
    
    
}
