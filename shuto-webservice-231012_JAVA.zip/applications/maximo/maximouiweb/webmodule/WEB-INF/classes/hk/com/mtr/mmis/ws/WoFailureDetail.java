
/**
 * WoFailureDetail.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: SNAPSHOT  Built on : Jan 10, 2009 (05:26:17 CST)
 */
            
                package hk.com.mtr.mmis.ws;
            

            /**
            *  WoFailureDetail bean class
            */
        
        public  class WoFailureDetail extends hk.com.mtr.mmis.ws.BaseVO
        implements org.apache.axis2.databinding.ADBBean{
        /* This type was generated from the piece of schema that had
                name = woFailureDetail
                Namespace URI = http://ws.mmis.mtr.com.hk/
                Namespace Prefix = ns1
                */
            

        private static java.lang.String generatePrefix(java.lang.String namespace) {
            if(namespace.equals("http://ws.mmis.mtr.com.hk/")){
                return "ns1";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        

                        /**
                        * field for ComponentQty
                        */

                        
                                    protected double localComponentQty ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localComponentQtyTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getComponentQty(){
                               return localComponentQty;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ComponentQty
                               */
                               public void setComponentQty(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localComponentQtyTracker = false;
                                              
                                       } else {
                                          localComponentQtyTracker = true;
                                       }
                                   
                                            this.localComponentQty=param;
                                    

                               }
                            

                        /**
                        * field for FailureDetailId
                        */

                        
                                    protected long localFailureDetailId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localFailureDetailIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getFailureDetailId(){
                               return localFailureDetailId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param FailureDetailId
                               */
                               public void setFailureDetailId(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localFailureDetailIdTracker = false;
                                              
                                       } else {
                                          localFailureDetailIdTracker = true;
                                       }
                                   
                                            this.localFailureDetailId=param;
                                    

                               }
                            

                        /**
                        * field for GcFailureActionCd
                        */

                        
                                    protected java.lang.String localGcFailureActionCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcFailureActionCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcFailureActionCd(){
                               return localGcFailureActionCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcFailureActionCd
                               */
                               public void setGcFailureActionCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcFailureActionCdTracker = true;
                                       } else {
                                          localGcFailureActionCdTracker = false;
                                              
                                       }
                                   
                                            this.localGcFailureActionCd=param;
                                    

                               }
                            

                        /**
                        * field for GcFailureCauseCd
                        */

                        
                                    protected java.lang.String localGcFailureCauseCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcFailureCauseCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcFailureCauseCd(){
                               return localGcFailureCauseCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcFailureCauseCd
                               */
                               public void setGcFailureCauseCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcFailureCauseCdTracker = true;
                                       } else {
                                          localGcFailureCauseCdTracker = false;
                                              
                                       }
                                   
                                            this.localGcFailureCauseCd=param;
                                    

                               }
                            

                        /**
                        * field for GcFailureCd
                        */

                        
                                    protected java.lang.String localGcFailureCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcFailureCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcFailureCd(){
                               return localGcFailureCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcFailureCd
                               */
                               public void setGcFailureCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcFailureCdTracker = true;
                                       } else {
                                          localGcFailureCdTracker = false;
                                              
                                       }
                                   
                                            this.localGcFailureCd=param;
                                    

                               }
                            

                        /**
                        * field for GcFailureComponentCd
                        */

                        
                                    protected java.lang.String localGcFailureComponentCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcFailureComponentCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcFailureComponentCd(){
                               return localGcFailureComponentCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcFailureComponentCd
                               */
                               public void setGcFailureComponentCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcFailureComponentCdTracker = true;
                                       } else {
                                          localGcFailureComponentCdTracker = false;
                                              
                                       }
                                   
                                            this.localGcFailureComponentCd=param;
                                    

                               }
                            

                        /**
                        * field for GcReplaceComponentCd
                        */

                        
                                    protected java.lang.String localGcReplaceComponentCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcReplaceComponentCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcReplaceComponentCd(){
                               return localGcReplaceComponentCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcReplaceComponentCd
                               */
                               public void setGcReplaceComponentCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcReplaceComponentCdTracker = true;
                                       } else {
                                          localGcReplaceComponentCdTracker = false;
                                              
                                       }
                                   
                                            this.localGcReplaceComponentCd=param;
                                    

                               }
                            

                        /**
                        * field for RecordInd
                        */

                        
                                    protected java.lang.String localRecordInd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localRecordIndTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getRecordInd(){
                               return localRecordInd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param RecordInd
                               */
                               public void setRecordInd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localRecordIndTracker = true;
                                       } else {
                                          localRecordIndTracker = false;
                                              
                                       }
                                   
                                            this.localRecordInd=param;
                                    

                               }
                            

                        /**
                        * field for Remarks
                        */

                        
                                    protected java.lang.String localRemarks ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localRemarksTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getRemarks(){
                               return localRemarks;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Remarks
                               */
                               public void setRemarks(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localRemarksTracker = true;
                                       } else {
                                          localRemarksTracker = false;
                                              
                                       }
                                   
                                            this.localRemarks=param;
                                    

                               }
                            

                        /**
                        * field for ReservedField1
                        */

                        
                                    protected java.lang.String localReservedField1 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localReservedField1Tracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getReservedField1(){
                               return localReservedField1;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ReservedField1
                               */
                               public void setReservedField1(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localReservedField1Tracker = true;
                                       } else {
                                          localReservedField1Tracker = false;
                                              
                                       }
                                   
                                            this.localReservedField1=param;
                                    

                               }
                            

                        /**
                        * field for ReservedField2
                        */

                        
                                    protected java.lang.String localReservedField2 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localReservedField2Tracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getReservedField2(){
                               return localReservedField2;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ReservedField2
                               */
                               public void setReservedField2(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localReservedField2Tracker = true;
                                       } else {
                                          localReservedField2Tracker = false;
                                              
                                       }
                                   
                                            this.localReservedField2=param;
                                    

                               }
                            

                        /**
                        * field for ReservedField3
                        */

                        
                                    protected java.lang.String localReservedField3 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localReservedField3Tracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getReservedField3(){
                               return localReservedField3;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ReservedField3
                               */
                               public void setReservedField3(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localReservedField3Tracker = true;
                                       } else {
                                          localReservedField3Tracker = false;
                                              
                                       }
                                   
                                            this.localReservedField3=param;
                                    

                               }
                            

                        /**
                        * field for RootComponentInd
                        */

                        
                                    protected java.lang.String localRootComponentInd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localRootComponentIndTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getRootComponentInd(){
                               return localRootComponentInd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param RootComponentInd
                               */
                               public void setRootComponentInd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localRootComponentIndTracker = true;
                                       } else {
                                          localRootComponentIndTracker = false;
                                              
                                       }
                                   
                                            this.localRootComponentInd=param;
                                    

                               }
                            

     /**
     * isReaderMTOMAware
     * @return true if the reader supports MTOM
     */
   public static boolean isReaderMTOMAware(javax.xml.stream.XMLStreamReader reader) {
        boolean isReaderMTOMAware = false;
        
        try{
          isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader.getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
        }catch(java.lang.IllegalArgumentException e){
          isReaderMTOMAware = false;
        }
        return isReaderMTOMAware;
   }
     
     
        /**
        *
        * @param parentQName
        * @param factory
        * @return org.apache.axiom.om.OMElement
        */
       public org.apache.axiom.om.OMElement getOMElement (
               final javax.xml.namespace.QName parentQName,
               final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException{


        
               org.apache.axiom.om.OMDataSource dataSource =
                       new org.apache.axis2.databinding.ADBDataSource(this,parentQName){

                 public void serialize(org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
                       WoFailureDetail.this.serialize(parentQName,factory,xmlWriter);
                 }
               };
               return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
               parentQName,factory,dataSource);
            
       }

         public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
                           serialize(parentQName,factory,xmlWriter,false);
         }

         public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               boolean serializeType)
            throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
            
                


                java.lang.String prefix = null;
                java.lang.String namespace = null;
                

                    prefix = parentQName.getPrefix();
                    namespace = parentQName.getNamespaceURI();

                    if ((namespace != null) && (namespace.trim().length() > 0)) {
                        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                        if (writerPrefix != null) {
                            xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                        } else {
                            if (prefix == null) {
                                prefix = generatePrefix(namespace);
                            }

                            xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                            xmlWriter.writeNamespace(prefix, namespace);
                            xmlWriter.setPrefix(prefix, namespace);
                        }
                    } else {
                        xmlWriter.writeStartElement(parentQName.getLocalPart());
                    }
                

                   java.lang.String namespacePrefix = registerPrefix(xmlWriter,"http://ws.mmis.mtr.com.hk/");
                   if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0)){
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           namespacePrefix+":woFailureDetail",
                           xmlWriter);
                   } else {
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           "woFailureDetail",
                           xmlWriter);
                   }

                if (localComponentQtyTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"componentQty", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"componentQty");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("componentQty");
                                    }
                                
                                               if (java.lang.Double.isNaN(localComponentQty)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("componentQty cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localComponentQty));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localFailureDetailIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"failureDetailId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"failureDetailId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("failureDetailId");
                                    }
                                
                                               if (localFailureDetailId==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("failureDetailId cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localFailureDetailId));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcFailureActionCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcFailureActionCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcFailureActionCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcFailureActionCd");
                                    }
                                

                                          if (localGcFailureActionCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcFailureActionCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcFailureActionCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcFailureCauseCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcFailureCauseCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcFailureCauseCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcFailureCauseCd");
                                    }
                                

                                          if (localGcFailureCauseCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcFailureCauseCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcFailureCauseCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcFailureCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcFailureCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcFailureCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcFailureCd");
                                    }
                                

                                          if (localGcFailureCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcFailureCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcFailureCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcFailureComponentCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcFailureComponentCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcFailureComponentCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcFailureComponentCd");
                                    }
                                

                                          if (localGcFailureComponentCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcFailureComponentCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcFailureComponentCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcReplaceComponentCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcReplaceComponentCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcReplaceComponentCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcReplaceComponentCd");
                                    }
                                

                                          if (localGcReplaceComponentCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcReplaceComponentCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcReplaceComponentCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localRecordIndTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"recordInd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"recordInd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("recordInd");
                                    }
                                

                                          if (localRecordInd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("recordInd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localRecordInd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localRemarksTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"remarks", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"remarks");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("remarks");
                                    }
                                

                                          if (localRemarks==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("remarks cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localRemarks);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localReservedField1Tracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"reservedField1", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"reservedField1");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("reservedField1");
                                    }
                                

                                          if (localReservedField1==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("reservedField1 cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localReservedField1);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localReservedField2Tracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"reservedField2", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"reservedField2");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("reservedField2");
                                    }
                                

                                          if (localReservedField2==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("reservedField2 cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localReservedField2);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localReservedField3Tracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"reservedField3", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"reservedField3");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("reservedField3");
                                    }
                                

                                          if (localReservedField3==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("reservedField3 cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localReservedField3);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localRootComponentIndTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"rootComponentInd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"rootComponentInd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("rootComponentInd");
                                    }
                                

                                          if (localRootComponentInd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("rootComponentInd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localRootComponentInd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             }
                    xmlWriter.writeEndElement();
               

        }

         /**
          * Util method to write an attribute with the ns prefix
          */
          private void writeAttribute(java.lang.String prefix,java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
              if (xmlWriter.getPrefix(namespace) == null) {
                       xmlWriter.writeNamespace(prefix, namespace);
                       xmlWriter.setPrefix(prefix, namespace);

              }

              xmlWriter.writeAttribute(namespace,attName,attValue);

         }

        /**
          * Util method to write an attribute without the ns prefix
          */
          private void writeAttribute(java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
                if (namespace.equals(""))
              {
                  xmlWriter.writeAttribute(attName,attValue);
              }
              else
              {
                  registerPrefix(xmlWriter, namespace);
                  xmlWriter.writeAttribute(namespace,attName,attValue);
              }
          }


           /**
             * Util method to write an attribute without the ns prefix
             */
            private void writeQNameAttribute(java.lang.String namespace, java.lang.String attName,
                                             javax.xml.namespace.QName qname, javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

                java.lang.String attributeNamespace = qname.getNamespaceURI();
                java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
                if (attributePrefix == null) {
                    attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
                }
                java.lang.String attributeValue;
                if (attributePrefix.trim().length() > 0) {
                    attributeValue = attributePrefix + ":" + qname.getLocalPart();
                } else {
                    attributeValue = qname.getLocalPart();
                }

                if (namespace.equals("")) {
                    xmlWriter.writeAttribute(attName, attributeValue);
                } else {
                    registerPrefix(xmlWriter, namespace);
                    xmlWriter.writeAttribute(namespace, attName, attributeValue);
                }
            }
        /**
         *  method to handle Qnames
         */

        private void writeQName(javax.xml.namespace.QName qname,
                                javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null) {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null) {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix,namespaceURI);
                }

                if (prefix.trim().length() > 0){
                    xmlWriter.writeCharacters(prefix + ":" + org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                } else {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                }

            } else {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
            }
        }

        private void writeQNames(javax.xml.namespace.QName[] qnames,
                                 javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

            if (qnames != null) {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++) {
                    if (i > 0) {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null) {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0)) {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix,namespaceURI);
                        }

                        if (prefix.trim().length() > 0){
                            stringToWrite.append(prefix).append(":").append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        } else {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        }
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }


         /**
         * Register a namespace prefix
         */
         private java.lang.String registerPrefix(javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace) throws javax.xml.stream.XMLStreamException {
                java.lang.String prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null) {
                        prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                    }

                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }

                return prefix;
            }


  
        /**
        * databinding method to get an XML representation of this object
        *
        */
        public javax.xml.stream.XMLStreamReader getPullParser(javax.xml.namespace.QName qName)
                    throws org.apache.axis2.databinding.ADBException{


        
                 java.util.ArrayList elementList = new java.util.ArrayList();
                 java.util.ArrayList attribList = new java.util.ArrayList();

                
                    attribList.add(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema-instance","type"));
                    attribList.add(new javax.xml.namespace.QName("http://ws.mmis.mtr.com.hk/","woFailureDetail"));
                 if (localComponentQtyTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "componentQty"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localComponentQty));
                            } if (localFailureDetailIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "failureDetailId"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localFailureDetailId));
                            } if (localGcFailureActionCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcFailureActionCd"));
                                 
                                        if (localGcFailureActionCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcFailureActionCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcFailureActionCd cannot be null!!");
                                        }
                                    } if (localGcFailureCauseCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcFailureCauseCd"));
                                 
                                        if (localGcFailureCauseCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcFailureCauseCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcFailureCauseCd cannot be null!!");
                                        }
                                    } if (localGcFailureCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcFailureCd"));
                                 
                                        if (localGcFailureCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcFailureCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcFailureCd cannot be null!!");
                                        }
                                    } if (localGcFailureComponentCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcFailureComponentCd"));
                                 
                                        if (localGcFailureComponentCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcFailureComponentCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcFailureComponentCd cannot be null!!");
                                        }
                                    } if (localGcReplaceComponentCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcReplaceComponentCd"));
                                 
                                        if (localGcReplaceComponentCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcReplaceComponentCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcReplaceComponentCd cannot be null!!");
                                        }
                                    } if (localRecordIndTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "recordInd"));
                                 
                                        if (localRecordInd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRecordInd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("recordInd cannot be null!!");
                                        }
                                    } if (localRemarksTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "remarks"));
                                 
                                        if (localRemarks != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRemarks));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("remarks cannot be null!!");
                                        }
                                    } if (localReservedField1Tracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "reservedField1"));
                                 
                                        if (localReservedField1 != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localReservedField1));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("reservedField1 cannot be null!!");
                                        }
                                    } if (localReservedField2Tracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "reservedField2"));
                                 
                                        if (localReservedField2 != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localReservedField2));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("reservedField2 cannot be null!!");
                                        }
                                    } if (localReservedField3Tracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "reservedField3"));
                                 
                                        if (localReservedField3 != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localReservedField3));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("reservedField3 cannot be null!!");
                                        }
                                    } if (localRootComponentIndTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "rootComponentInd"));
                                 
                                        if (localRootComponentInd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRootComponentInd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("rootComponentInd cannot be null!!");
                                        }
                                    }

                return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName, elementList.toArray(), attribList.toArray());
            
            

        }

  

     /**
      *  Factory class that keeps the parse method
      */
    public static class Factory{

        
        

        /**
        * static method to create the object
        * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
        *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
        * Postcondition: If this object is an element, the reader is positioned at its end element
        *                If this object is a complex type, the reader is positioned at the end element of its outer element
        */
        public static WoFailureDetail parse(javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{
            WoFailureDetail object =
                new WoFailureDetail();

            int event;
            java.lang.String nillableValue = null;
            java.lang.String prefix ="";
            java.lang.String namespaceuri ="";
            try {
                
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                
                if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","type")!=null){
                  java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                        "type");
                  if (fullTypeName!=null){
                    java.lang.String nsPrefix = null;
                    if (fullTypeName.indexOf(":") > -1){
                        nsPrefix = fullTypeName.substring(0,fullTypeName.indexOf(":"));
                    }
                    nsPrefix = nsPrefix==null?"":nsPrefix;

                    java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":")+1);
                    
                            if (!"woFailureDetail".equals(type)){
                                //find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext().getNamespaceURI(nsPrefix);
                                return (WoFailureDetail)hk.com.mtr.mmis.ws.ExtensionMapper.getTypeObject(
                                     nsUri,type,reader);
                              }
                        

                  }
                

                }

                

                
                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();
                

                 
                    
                    reader.next();
                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","componentQty").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setComponentQty(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setComponentQty(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","failureDetailId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setFailureDetailId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setFailureDetailId(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcFailureActionCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcFailureActionCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcFailureCauseCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcFailureCauseCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcFailureCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcFailureCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcFailureComponentCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcFailureComponentCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcReplaceComponentCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcReplaceComponentCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","recordInd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setRecordInd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","remarks").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setRemarks(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","reservedField1").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setReservedField1(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","reservedField2").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setReservedField2(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","reservedField3").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setReservedField3(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","rootComponentInd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setRootComponentInd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                  
                            while (!reader.isStartElement() && !reader.isEndElement())
                                reader.next();
                            
                                if (reader.isStartElement())
                                // A start element we are not expecting indicates a trailing invalid property
                                throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader.getLocalName());
                            



            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }

        }//end of factory class

        

        }
           
          