/*
 * Copyright (c) 2023 shutu, Inc. All rights reserved.
 */
package hk.com.mtr.mmis.ws.incident;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 
 * @author shutu
 */
public class IncidentValidator {

    public final static String ERROR_CODE_1 = "-1";
    public final static String ERROR_CODE_1_MSG = "URN No. could not be null.";
    public final static String ERROR_CODE_2 = "-2";
    public final static String ERROR_CODE_2_MSG = "Flag Disabled. could not be null.";
    public final static String ERROR_CODE_3 = "-3";
    public final static String ERROR_CODE_3_MSG = "Flag Disabled only be 0 or 1";
    public final static String ERROR_CODE_4 = "-4";
    public final static String ERROR_CODE_4_MSG = "Last Updated Time could not be null.";

    public final static String ERROR_CODE_5 = "-5";
    public final static String ERROR_CODE_5_MSG = "Initial Delay format must like '99999.9999'.";
    public final static String ERROR_CODE_6 = "-6";
    public final static String ERROR_CODE_6_MSG = "Accumulate Delay format must like '99999.9999'.";
    public final static String ERROR_CODE_7 = "-7";
    public final static String ERROR_CODE_7_MSG = "No.of Trains Affected format must like '99999.9999'.";
    public final static String ERROR_CODE_8 = "-8";
    public final static String ERROR_CODE_8_MSG = "No. of Trains Withdrawn format must like '99999.9999'.";
    public final static String ERROR_CODE_9 = "-9";
    public final static String ERROR_CODE_9_MSG = "No. of Trains Cancelled format must like '99999.9999'.";
    public final static String ERROR_CODE_10 = "-10";
    public final static String ERROR_CODE_10_MSG = "No. of Trips Cancelled format must like '99999.9999'.";
    public final static String ERROR_CODE_11 = "-11";
    public final static String ERROR_CODE_11_MSG = "In this System,No. of Trains Changed Over is limited '99999999'.";

    public final static String ERROR_CODE_12 = "-12";
    public final static String ERROR_CODE_12_MSG = "Last Updated Time format like 'yyyyMMdd' " + "or 'yyyyMMddHHmmss' or 'yyyyMMddHHmmss999'.";

    public final static String ERROR_CODE_19 = "-19";
    public final static String ERROR_CODE_19_MSG = "Incident Train No. length must < 16.";

    public final static String ERROR_CODE_20 = "-20";
    public final static String ERROR_CODE_20_MSG = "Last Updated Time is not effective,please cheack again.";

    public final static String ERROR_CODE_21 = "-21";
    public final static String ERROR_CODE_21_MSG = "URN No. should not beginning with 0 and the length = 13 or the length> 13.";

    public static List<String> validateWSIncident(WmODMSIncidentUploadVO uploadVO) {

        List<String> messages = new ArrayList<String>();

        if (uploadVO.getIncidentId() == null || uploadVO.getIncidentId().equalsIgnoreCase("") || (uploadVO.getIncidentId().equalsIgnoreCase("?"))) {// incidentId
                                                                                                                                                    // not null
            messages.add(ERROR_CODE_1);
            messages.add(ERROR_CODE_1_MSG);
            return messages;

        } else if (uploadVO.getIncidentId().startsWith("0") || uploadVO.getIncidentId().length()>13 ) 
        {
            messages.add(ERROR_CODE_21);
            messages.add(ERROR_CODE_21_MSG);
            return messages;
        } else{
            uploadVO.setIncidentId(uploadVO.getIncidentId().toUpperCase());
        }
        if (uploadVO.getStatus() == null || uploadVO.getStatus().equalsIgnoreCase("") || (uploadVO.getStatus().equalsIgnoreCase("?"))) {
            messages.add(ERROR_CODE_2);
            messages.add(ERROR_CODE_2_MSG);
            return messages;
        } else {
            if (uploadVO.getStatus().equals("0") || uploadVO.getStatus().equals("1")) {
                if (uploadVO.getStatus().equalsIgnoreCase("0")) {
                    uploadVO.setStatus("1");
                } else if (uploadVO.getStatus().equalsIgnoreCase("1")) {
                    uploadVO.setStatus("0");
                }

            } else {
                messages.add(ERROR_CODE_3);
                messages.add(ERROR_CODE_3_MSG);
                return messages;
            }
        }
        if (uploadVO.getLastUpdDatetime() == null || uploadVO.getLastUpdDatetime().equalsIgnoreCase("")
                || (uploadVO.getLastUpdDatetime().equalsIgnoreCase("?"))) {
            messages.add(ERROR_CODE_4);
            messages.add(ERROR_CODE_4_MSG);
            return messages;
        } else if (!isTimeLegal(uploadVO.getLastUpdDatetime())) {
            messages.add(ERROR_CODE_12);
            messages.add(ERROR_CODE_12_MSG);
            return messages;
        } else
            try {
                if (!isValidTime(uploadVO.getLastUpdDatetime())) {
                    messages.add(ERROR_CODE_20);
                    messages.add(ERROR_CODE_20_MSG);
                    return messages;
                }
            } catch (Exception e) {
            }            
        //�����Ϊ��
        if (!Double.isNaN(uploadVO.getInitialDelayMinutes())) {
            if (!isNumberLegal(uploadVO.getInitialDelayMinutes()+"")) {
                messages.add(ERROR_CODE_5);
                messages.add(ERROR_CODE_5_MSG);
                return messages;
            } 
        } else {
            uploadVO.setInitialDelayMinutes(0.00d);
        }
        //�����Ϊ��
        if (!Double.isNaN(uploadVO.getAccessDelayMinutes())) {
            if (!isNumberLegal(uploadVO.getAccessDelayMinutes()+"")) {
                messages.add(ERROR_CODE_6);
                messages.add(ERROR_CODE_6_MSG);
                return messages;
            }
        } else {
            uploadVO.setAccessDelayMinutes(0.00d);
        }
        //���Ϊ��
        if (Double.isNaN(uploadVO.getAffectedTrainCount())) {
            uploadVO.setAffectedTrainCount(0.00d);
        } else if (!isNumberLegal(uploadVO.getAffectedTrainCount()+"")) {
                messages.add(ERROR_CODE_7);
                messages.add(ERROR_CODE_7_MSG);
                return messages;
            }
        
        if (!Double.isNaN(uploadVO.getWithdrawnTrainCount())) {
            if (!isNumberLegal(uploadVO.getWithdrawnTrainCount()+"")) {
                messages.add(ERROR_CODE_8);
                messages.add(ERROR_CODE_8_MSG);
                return messages;
            }
        } else {
            uploadVO.setWithdrawnTrainCount(0.00d);
        }

        if (!Double.isNaN(uploadVO.getCancelledTrainCount())) {
            if (!isNumberLegal(uploadVO.getCancelledTrainCount()+"")) {
                messages.add(ERROR_CODE_9);
                messages.add(ERROR_CODE_9_MSG);
                return messages;
            } 
        } else {
            uploadVO.setCancelledTrainCount(0.00d);
        }

        if (!Double.isNaN(uploadVO.getCancelledTripCount())) {
            if (!isNumberLegal(uploadVO.getCancelledTripCount()+"")) {
                messages.add(ERROR_CODE_10);
                messages.add(ERROR_CODE_10_MSG);
                return messages;
            }
        } else {
            uploadVO.setCancelledTripCount(0.00d);
        }

        if (!Double.isNaN(uploadVO.getChangeoverTrainCount())) {
            Pattern a = Pattern.compile("^([-|+]{0,1})?[0-9]{0,8}$");
            Matcher b = a.matcher(uploadVO.getChangeoverTrainCount()+"");
            if (!b.matches()) {
                messages.add(ERROR_CODE_11);
                messages.add(ERROR_CODE_11_MSG);
                return messages;
            }
        } else {
            uploadVO.setChangeoverTrainCount(0);
        }
        if (uploadVO.getLineCd() != null) {
            if (uploadVO.getLineCd().equalsIgnoreCase("") || (uploadVO.getLineCd().equalsIgnoreCase("?"))) {
                uploadVO.setLineCd(null);
            }
        }
        if (uploadVO.getTrainNo() != null) {
            if (uploadVO.getTrainNo().equalsIgnoreCase("") || (uploadVO.getTrainNo().equalsIgnoreCase("?"))) {
                uploadVO.setTrainNo(null);
            } else {
                if (uploadVO.getTrainNo().length() > 15) {
                    messages.add(ERROR_CODE_19);
                    messages.add(ERROR_CODE_19_MSG);
                    return messages;
                }
            }
        }

        return messages;
    }
    
    
    
    public static Boolean isNumberLegal(String patternString) {
         Pattern a=Pattern.compile("^([-|+]*)?[0-9]{0,5}.[0-9]{0,4}$");
          Matcher b=a.matcher(patternString); 
         if(b.matches()) {
               return true ;
         } else {
               return false ;
         }
    }
    public static Boolean isTimeLegal(String patternString) {
        System.out.println(patternString);
        Pattern a=Pattern.compile("^(\\d{8})((\\d{6})(\\d{3})?)?$");
          Matcher b=a.matcher(patternString); 
         if(b.matches()) {
               return true ;
         } else {
               return false ;
         }
    }
     public static boolean isValidTime(String cal) throws Exception{
            try{
                 DateFormat df = null;
                    System.out.println(cal.toString());
                    String s = cal;
                    if(s.length()==8){
                        df = new SimpleDateFormat("yyyyMMdd");
                        }
                        if(s.length()==14){
                           df = new SimpleDateFormat("yyyyMMddHHmmss");
                           }
                        if(s.length()>14){
                            if(!s.contains("."))
                            s = s.substring(0, 14)+s.substring(14);
                            System.out.println();
                             df = new SimpleDateFormat("yyyyMMddHHmmssSSS");
                        }
                        df.setLenient(false);
                        Date date = df.parse(s);
                         System.out.println(date);
                         System.out.println(date.getTime());
                return true;
            }
            catch(ParseException exp){
                 return false;
            }
        }
}
