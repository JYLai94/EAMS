package hk.com.mtr.mmis.ws.incident;

/**
 * 
 * @author 
 */
public interface CreepODMSIncidentServiceInterfacePortSkeletonInterface
{

    public abstract _return createIncident(WmODMSIncidentUploadVOList wmodmsincidentuploadvolist)
        throws CreepODMSIncidentException;
}