
/**
 * LocationRangeVO.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: SNAPSHOT  Built on : Jan 10, 2009 (05:26:17 CST)
 */
            
                package hk.com.mtr.mmis.ws;
            

            /**
            *  LocationRangeVO bean class
            */
        
        public  class LocationRangeVO extends hk.com.mtr.mmis.ws.BaseVO
        implements org.apache.axis2.databinding.ADBBean{
        /* This type was generated from the piece of schema that had
                name = locationRangeVO
                Namespace URI = http://ws.mmis.mtr.com.hk/
                Namespace Prefix = ns1
                */
            

        private static java.lang.String generatePrefix(java.lang.String namespace) {
            if(namespace.equals("http://ws.mmis.mtr.com.hk/")){
                return "ns1";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        

                        /**
                        * field for GcDirectionCd
                        */

                        
                                    protected java.lang.String localGcDirectionCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcDirectionCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcDirectionCd(){
                               return localGcDirectionCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcDirectionCd
                               */
                               public void setGcDirectionCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcDirectionCdTracker = true;
                                       } else {
                                          localGcDirectionCdTracker = false;
                                              
                                       }
                                   
                                            this.localGcDirectionCd=param;
                                    

                               }
                            

                        /**
                        * field for GcDirectionDesp
                        */

                        
                                    protected java.lang.String localGcDirectionDesp ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcDirectionDespTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcDirectionDesp(){
                               return localGcDirectionDesp;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcDirectionDesp
                               */
                               public void setGcDirectionDesp(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcDirectionDespTracker = true;
                                       } else {
                                          localGcDirectionDespTracker = false;
                                              
                                       }
                                   
                                            this.localGcDirectionDesp=param;
                                    

                               }
                            

                        /**
                        * field for KmFrom
                        */

                        
                                    protected double localKmFrom ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localKmFromTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getKmFrom(){
                               return localKmFrom;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param KmFrom
                               */
                               public void setKmFrom(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localKmFromTracker = false;
                                              
                                       } else {
                                          localKmFromTracker = true;
                                       }
                                   
                                            this.localKmFrom=param;
                                    

                               }
                            

                        /**
                        * field for KmTo
                        */

                        
                                    protected double localKmTo ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localKmToTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getKmTo(){
                               return localKmTo;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param KmTo
                               */
                               public void setKmTo(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localKmToTracker = false;
                                              
                                       } else {
                                          localKmToTracker = true;
                                       }
                                   
                                            this.localKmTo=param;
                                    

                               }
                            

                        /**
                        * field for LineCd
                        */

                        
                                    protected java.lang.String localLineCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localLineCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getLineCd(){
                               return localLineCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param LineCd
                               */
                               public void setLineCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localLineCdTracker = true;
                                       } else {
                                          localLineCdTracker = false;
                                              
                                       }
                                   
                                            this.localLineCd=param;
                                    

                               }
                            

                        /**
                        * field for LineId
                        */

                        
                                    protected long localLineId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localLineIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getLineId(){
                               return localLineId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param LineId
                               */
                               public void setLineId(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localLineIdTracker = false;
                                              
                                       } else {
                                          localLineIdTracker = true;
                                       }
                                   
                                            this.localLineId=param;
                                    

                               }
                            

                        /**
                        * field for LocationFromCd
                        */

                        
                                    protected java.lang.String localLocationFromCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localLocationFromCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getLocationFromCd(){
                               return localLocationFromCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param LocationFromCd
                               */
                               public void setLocationFromCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localLocationFromCdTracker = true;
                                       } else {
                                          localLocationFromCdTracker = false;
                                              
                                       }
                                   
                                            this.localLocationFromCd=param;
                                    

                               }
                            

                        /**
                        * field for LocationFromId
                        */

                        
                                    protected long localLocationFromId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localLocationFromIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getLocationFromId(){
                               return localLocationFromId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param LocationFromId
                               */
                               public void setLocationFromId(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localLocationFromIdTracker = false;
                                              
                                       } else {
                                          localLocationFromIdTracker = true;
                                       }
                                   
                                            this.localLocationFromId=param;
                                    

                               }
                            

                        /**
                        * field for LocationToCd
                        */

                        
                                    protected java.lang.String localLocationToCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localLocationToCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getLocationToCd(){
                               return localLocationToCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param LocationToCd
                               */
                               public void setLocationToCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localLocationToCdTracker = true;
                                       } else {
                                          localLocationToCdTracker = false;
                                              
                                       }
                                   
                                            this.localLocationToCd=param;
                                    

                               }
                            

                        /**
                        * field for LocationToId
                        */

                        
                                    protected long localLocationToId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localLocationToIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getLocationToId(){
                               return localLocationToId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param LocationToId
                               */
                               public void setLocationToId(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localLocationToIdTracker = false;
                                              
                                       } else {
                                          localLocationToIdTracker = true;
                                       }
                                   
                                            this.localLocationToId=param;
                                    

                               }
                            

                        /**
                        * field for LocationType
                        */

                        
                                    protected java.lang.String localLocationType ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localLocationTypeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getLocationType(){
                               return localLocationType;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param LocationType
                               */
                               public void setLocationType(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localLocationTypeTracker = true;
                                       } else {
                                          localLocationTypeTracker = false;
                                              
                                       }
                                   
                                            this.localLocationType=param;
                                    

                               }
                            

                        /**
                        * field for RefFromLocs
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.RefLocationVO[] localRefFromLocs ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localRefFromLocsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.RefLocationVO[]
                           */
                           public  hk.com.mtr.mmis.ws.RefLocationVO[] getRefFromLocs(){
                               return localRefFromLocs;
                           }

                           
                        


                               
                              /**
                               * validate the array for RefFromLocs
                               */
                              protected void validateRefFromLocs(hk.com.mtr.mmis.ws.RefLocationVO[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param RefFromLocs
                              */
                              public void setRefFromLocs(hk.com.mtr.mmis.ws.RefLocationVO[] param){
                              
                                   validateRefFromLocs(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localRefFromLocsTracker = true;
                                          } else {
                                             localRefFromLocsTracker = true;
                                                 
                                          }
                                      
                                      this.localRefFromLocs=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.RefLocationVO
                             */
                             public void addRefFromLocs(hk.com.mtr.mmis.ws.RefLocationVO param){
                                   if (localRefFromLocs == null){
                                   localRefFromLocs = new hk.com.mtr.mmis.ws.RefLocationVO[]{};
                                   }

                            
                                 //update the setting tracker
                                localRefFromLocsTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localRefFromLocs);
                               list.add(param);
                               this.localRefFromLocs =
                             (hk.com.mtr.mmis.ws.RefLocationVO[])list.toArray(
                            new hk.com.mtr.mmis.ws.RefLocationVO[list.size()]);

                             }
                             

                        /**
                        * field for RefLocFromId
                        */

                        
                                    protected long localRefLocFromId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localRefLocFromIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getRefLocFromId(){
                               return localRefLocFromId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param RefLocFromId
                               */
                               public void setRefLocFromId(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localRefLocFromIdTracker = false;
                                              
                                       } else {
                                          localRefLocFromIdTracker = true;
                                       }
                                   
                                            this.localRefLocFromId=param;
                                    

                               }
                            

                        /**
                        * field for RefLocToId
                        */

                        
                                    protected long localRefLocToId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localRefLocToIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getRefLocToId(){
                               return localRefLocToId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param RefLocToId
                               */
                               public void setRefLocToId(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localRefLocToIdTracker = false;
                                              
                                       } else {
                                          localRefLocToIdTracker = true;
                                       }
                                   
                                            this.localRefLocToId=param;
                                    

                               }
                            

                        /**
                        * field for RefToLocs
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.RefLocationVO[] localRefToLocs ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localRefToLocsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.RefLocationVO[]
                           */
                           public  hk.com.mtr.mmis.ws.RefLocationVO[] getRefToLocs(){
                               return localRefToLocs;
                           }

                           
                        


                               
                              /**
                               * validate the array for RefToLocs
                               */
                              protected void validateRefToLocs(hk.com.mtr.mmis.ws.RefLocationVO[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param RefToLocs
                              */
                              public void setRefToLocs(hk.com.mtr.mmis.ws.RefLocationVO[] param){
                              
                                   validateRefToLocs(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localRefToLocsTracker = true;
                                          } else {
                                             localRefToLocsTracker = true;
                                                 
                                          }
                                      
                                      this.localRefToLocs=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.RefLocationVO
                             */
                             public void addRefToLocs(hk.com.mtr.mmis.ws.RefLocationVO param){
                                   if (localRefToLocs == null){
                                   localRefToLocs = new hk.com.mtr.mmis.ws.RefLocationVO[]{};
                                   }

                            
                                 //update the setting tracker
                                localRefToLocsTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localRefToLocs);
                               list.add(param);
                               this.localRefToLocs =
                             (hk.com.mtr.mmis.ws.RefLocationVO[])list.toArray(
                            new hk.com.mtr.mmis.ws.RefLocationVO[list.size()]);

                             }
                             

                        /**
                        * field for RootFromLocCd
                        */

                        
                                    protected java.lang.String localRootFromLocCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localRootFromLocCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getRootFromLocCd(){
                               return localRootFromLocCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param RootFromLocCd
                               */
                               public void setRootFromLocCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localRootFromLocCdTracker = true;
                                       } else {
                                          localRootFromLocCdTracker = false;
                                              
                                       }
                                   
                                            this.localRootFromLocCd=param;
                                    

                               }
                            

                        /**
                        * field for RootFromLocId
                        */

                        
                                    protected long localRootFromLocId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localRootFromLocIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getRootFromLocId(){
                               return localRootFromLocId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param RootFromLocId
                               */
                               public void setRootFromLocId(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localRootFromLocIdTracker = false;
                                              
                                       } else {
                                          localRootFromLocIdTracker = true;
                                       }
                                   
                                            this.localRootFromLocId=param;
                                    

                               }
                            

                        /**
                        * field for RootToLocCd
                        */

                        
                                    protected java.lang.String localRootToLocCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localRootToLocCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getRootToLocCd(){
                               return localRootToLocCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param RootToLocCd
                               */
                               public void setRootToLocCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localRootToLocCdTracker = true;
                                       } else {
                                          localRootToLocCdTracker = false;
                                              
                                       }
                                   
                                            this.localRootToLocCd=param;
                                    

                               }
                            

                        /**
                        * field for RootToLocId
                        */

                        
                                    protected long localRootToLocId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localRootToLocIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getRootToLocId(){
                               return localRootToLocId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param RootToLocId
                               */
                               public void setRootToLocId(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localRootToLocIdTracker = false;
                                              
                                       } else {
                                          localRootToLocIdTracker = true;
                                       }
                                   
                                            this.localRootToLocId=param;
                                    

                               }
                            

                        /**
                        * field for SelectedFromLocId
                        */

                        
                                    protected long localSelectedFromLocId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSelectedFromLocIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getSelectedFromLocId(){
                               return localSelectedFromLocId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param SelectedFromLocId
                               */
                               public void setSelectedFromLocId(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localSelectedFromLocIdTracker = false;
                                              
                                       } else {
                                          localSelectedFromLocIdTracker = true;
                                       }
                                   
                                            this.localSelectedFromLocId=param;
                                    

                               }
                            

                        /**
                        * field for SelectedKmFrom
                        */

                        
                                    protected double localSelectedKmFrom ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSelectedKmFromTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getSelectedKmFrom(){
                               return localSelectedKmFrom;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param SelectedKmFrom
                               */
                               public void setSelectedKmFrom(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localSelectedKmFromTracker = false;
                                              
                                       } else {
                                          localSelectedKmFromTracker = true;
                                       }
                                   
                                            this.localSelectedKmFrom=param;
                                    

                               }
                            

                        /**
                        * field for SelectedKmTo
                        */

                        
                                    protected double localSelectedKmTo ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSelectedKmToTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getSelectedKmTo(){
                               return localSelectedKmTo;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param SelectedKmTo
                               */
                               public void setSelectedKmTo(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localSelectedKmToTracker = false;
                                              
                                       } else {
                                          localSelectedKmToTracker = true;
                                       }
                                   
                                            this.localSelectedKmTo=param;
                                    

                               }
                            

                        /**
                        * field for SelectedToLocId
                        */

                        
                                    protected long localSelectedToLocId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSelectedToLocIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getSelectedToLocId(){
                               return localSelectedToLocId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param SelectedToLocId
                               */
                               public void setSelectedToLocId(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localSelectedToLocIdTracker = false;
                                              
                                       } else {
                                          localSelectedToLocIdTracker = true;
                                       }
                                   
                                            this.localSelectedToLocId=param;
                                    

                               }
                            

                        /**
                        * field for SubLocationFrom
                        */

                        
                                    protected java.lang.String localSubLocationFrom ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSubLocationFromTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getSubLocationFrom(){
                               return localSubLocationFrom;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param SubLocationFrom
                               */
                               public void setSubLocationFrom(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localSubLocationFromTracker = true;
                                       } else {
                                          localSubLocationFromTracker = false;
                                              
                                       }
                                   
                                            this.localSubLocationFrom=param;
                                    

                               }
                            

                        /**
                        * field for SubLocationTo
                        */

                        
                                    protected java.lang.String localSubLocationTo ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSubLocationToTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getSubLocationTo(){
                               return localSubLocationTo;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param SubLocationTo
                               */
                               public void setSubLocationTo(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localSubLocationToTracker = true;
                                       } else {
                                          localSubLocationToTracker = false;
                                              
                                       }
                                   
                                            this.localSubLocationTo=param;
                                    

                               }
                            

                        /**
                        * field for SupplementInfo
                        */

                        
                                    protected java.lang.String localSupplementInfo ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSupplementInfoTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getSupplementInfo(){
                               return localSupplementInfo;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param SupplementInfo
                               */
                               public void setSupplementInfo(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localSupplementInfoTracker = true;
                                       } else {
                                          localSupplementInfoTracker = false;
                                              
                                       }
                                   
                                            this.localSupplementInfo=param;
                                    

                               }
                            

     /**
     * isReaderMTOMAware
     * @return true if the reader supports MTOM
     */
   public static boolean isReaderMTOMAware(javax.xml.stream.XMLStreamReader reader) {
        boolean isReaderMTOMAware = false;
        
        try{
          isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader.getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
        }catch(java.lang.IllegalArgumentException e){
          isReaderMTOMAware = false;
        }
        return isReaderMTOMAware;
   }
     
     
        /**
        *
        * @param parentQName
        * @param factory
        * @return org.apache.axiom.om.OMElement
        */
       public org.apache.axiom.om.OMElement getOMElement (
               final javax.xml.namespace.QName parentQName,
               final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException{


        
               org.apache.axiom.om.OMDataSource dataSource =
                       new org.apache.axis2.databinding.ADBDataSource(this,parentQName){

                 public void serialize(org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
                       LocationRangeVO.this.serialize(parentQName,factory,xmlWriter);
                 }
               };
               return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
               parentQName,factory,dataSource);
            
       }

         public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
                           serialize(parentQName,factory,xmlWriter,false);
         }

         public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               boolean serializeType)
            throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
            
                


                java.lang.String prefix = null;
                java.lang.String namespace = null;
                

                    prefix = parentQName.getPrefix();
                    namespace = parentQName.getNamespaceURI();

                    if ((namespace != null) && (namespace.trim().length() > 0)) {
                        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                        if (writerPrefix != null) {
                            xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                        } else {
                            if (prefix == null) {
                                prefix = generatePrefix(namespace);
                            }

                            xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                            xmlWriter.writeNamespace(prefix, namespace);
                            xmlWriter.setPrefix(prefix, namespace);
                        }
                    } else {
                        xmlWriter.writeStartElement(parentQName.getLocalPart());
                    }
                

                   java.lang.String namespacePrefix = registerPrefix(xmlWriter,"http://ws.mmis.mtr.com.hk/");
                   if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0)){
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           namespacePrefix+":locationRangeVO",
                           xmlWriter);
                   } else {
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           "locationRangeVO",
                           xmlWriter);
                   }

                if (localGcDirectionCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcDirectionCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcDirectionCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcDirectionCd");
                                    }
                                

                                          if (localGcDirectionCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcDirectionCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcDirectionCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcDirectionDespTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcDirectionDesp", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcDirectionDesp");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcDirectionDesp");
                                    }
                                

                                          if (localGcDirectionDesp==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcDirectionDesp cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcDirectionDesp);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localKmFromTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"kmFrom", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"kmFrom");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("kmFrom");
                                    }
                                
                                               if (java.lang.Double.isNaN(localKmFrom)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("kmFrom cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localKmFrom));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localKmToTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"kmTo", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"kmTo");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("kmTo");
                                    }
                                
                                               if (java.lang.Double.isNaN(localKmTo)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("kmTo cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localKmTo));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localLineCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"lineCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"lineCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("lineCd");
                                    }
                                

                                          if (localLineCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("lineCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localLineCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localLineIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"lineId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"lineId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("lineId");
                                    }
                                
                                               if (localLineId==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("lineId cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLineId));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localLocationFromCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"locationFromCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"locationFromCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("locationFromCd");
                                    }
                                

                                          if (localLocationFromCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("locationFromCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localLocationFromCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localLocationFromIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"locationFromId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"locationFromId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("locationFromId");
                                    }
                                
                                               if (localLocationFromId==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("locationFromId cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLocationFromId));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localLocationToCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"locationToCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"locationToCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("locationToCd");
                                    }
                                

                                          if (localLocationToCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("locationToCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localLocationToCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localLocationToIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"locationToId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"locationToId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("locationToId");
                                    }
                                
                                               if (localLocationToId==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("locationToId cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLocationToId));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localLocationTypeTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"locationType", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"locationType");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("locationType");
                                    }
                                

                                          if (localLocationType==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("locationType cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localLocationType);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localRefFromLocsTracker){
                                       if (localRefFromLocs!=null){
                                            for (int i = 0;i < localRefFromLocs.length;i++){
                                                if (localRefFromLocs[i] != null){
                                                 localRefFromLocs[i].serialize(new javax.xml.namespace.QName("","refFromLocs"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"refFromLocs", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"refFromLocs");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("refFromLocs");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"refFromLocs", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"refFromLocs");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("refFromLocs");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localRefLocFromIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"refLocFromId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"refLocFromId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("refLocFromId");
                                    }
                                
                                               if (localRefLocFromId==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("refLocFromId cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRefLocFromId));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localRefLocToIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"refLocToId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"refLocToId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("refLocToId");
                                    }
                                
                                               if (localRefLocToId==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("refLocToId cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRefLocToId));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localRefToLocsTracker){
                                       if (localRefToLocs!=null){
                                            for (int i = 0;i < localRefToLocs.length;i++){
                                                if (localRefToLocs[i] != null){
                                                 localRefToLocs[i].serialize(new javax.xml.namespace.QName("","refToLocs"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"refToLocs", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"refToLocs");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("refToLocs");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"refToLocs", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"refToLocs");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("refToLocs");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localRootFromLocCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"rootFromLocCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"rootFromLocCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("rootFromLocCd");
                                    }
                                

                                          if (localRootFromLocCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("rootFromLocCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localRootFromLocCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localRootFromLocIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"rootFromLocId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"rootFromLocId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("rootFromLocId");
                                    }
                                
                                               if (localRootFromLocId==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("rootFromLocId cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRootFromLocId));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localRootToLocCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"rootToLocCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"rootToLocCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("rootToLocCd");
                                    }
                                

                                          if (localRootToLocCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("rootToLocCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localRootToLocCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localRootToLocIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"rootToLocId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"rootToLocId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("rootToLocId");
                                    }
                                
                                               if (localRootToLocId==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("rootToLocId cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRootToLocId));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSelectedFromLocIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"selectedFromLocId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"selectedFromLocId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("selectedFromLocId");
                                    }
                                
                                               if (localSelectedFromLocId==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("selectedFromLocId cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSelectedFromLocId));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSelectedKmFromTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"selectedKmFrom", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"selectedKmFrom");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("selectedKmFrom");
                                    }
                                
                                               if (java.lang.Double.isNaN(localSelectedKmFrom)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("selectedKmFrom cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSelectedKmFrom));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSelectedKmToTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"selectedKmTo", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"selectedKmTo");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("selectedKmTo");
                                    }
                                
                                               if (java.lang.Double.isNaN(localSelectedKmTo)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("selectedKmTo cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSelectedKmTo));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSelectedToLocIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"selectedToLocId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"selectedToLocId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("selectedToLocId");
                                    }
                                
                                               if (localSelectedToLocId==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("selectedToLocId cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSelectedToLocId));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSubLocationFromTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"subLocationFrom", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"subLocationFrom");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("subLocationFrom");
                                    }
                                

                                          if (localSubLocationFrom==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("subLocationFrom cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localSubLocationFrom);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSubLocationToTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"subLocationTo", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"subLocationTo");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("subLocationTo");
                                    }
                                

                                          if (localSubLocationTo==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("subLocationTo cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localSubLocationTo);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSupplementInfoTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"supplementInfo", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"supplementInfo");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("supplementInfo");
                                    }
                                

                                          if (localSupplementInfo==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("supplementInfo cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localSupplementInfo);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             }
                    xmlWriter.writeEndElement();
               

        }

         /**
          * Util method to write an attribute with the ns prefix
          */
          private void writeAttribute(java.lang.String prefix,java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
              if (xmlWriter.getPrefix(namespace) == null) {
                       xmlWriter.writeNamespace(prefix, namespace);
                       xmlWriter.setPrefix(prefix, namespace);

              }

              xmlWriter.writeAttribute(namespace,attName,attValue);

         }

        /**
          * Util method to write an attribute without the ns prefix
          */
          private void writeAttribute(java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
                if (namespace.equals(""))
              {
                  xmlWriter.writeAttribute(attName,attValue);
              }
              else
              {
                  registerPrefix(xmlWriter, namespace);
                  xmlWriter.writeAttribute(namespace,attName,attValue);
              }
          }


           /**
             * Util method to write an attribute without the ns prefix
             */
            private void writeQNameAttribute(java.lang.String namespace, java.lang.String attName,
                                             javax.xml.namespace.QName qname, javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

                java.lang.String attributeNamespace = qname.getNamespaceURI();
                java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
                if (attributePrefix == null) {
                    attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
                }
                java.lang.String attributeValue;
                if (attributePrefix.trim().length() > 0) {
                    attributeValue = attributePrefix + ":" + qname.getLocalPart();
                } else {
                    attributeValue = qname.getLocalPart();
                }

                if (namespace.equals("")) {
                    xmlWriter.writeAttribute(attName, attributeValue);
                } else {
                    registerPrefix(xmlWriter, namespace);
                    xmlWriter.writeAttribute(namespace, attName, attributeValue);
                }
            }
        /**
         *  method to handle Qnames
         */

        private void writeQName(javax.xml.namespace.QName qname,
                                javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null) {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null) {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix,namespaceURI);
                }

                if (prefix.trim().length() > 0){
                    xmlWriter.writeCharacters(prefix + ":" + org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                } else {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                }

            } else {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
            }
        }

        private void writeQNames(javax.xml.namespace.QName[] qnames,
                                 javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

            if (qnames != null) {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++) {
                    if (i > 0) {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null) {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0)) {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix,namespaceURI);
                        }

                        if (prefix.trim().length() > 0){
                            stringToWrite.append(prefix).append(":").append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        } else {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        }
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }


         /**
         * Register a namespace prefix
         */
         private java.lang.String registerPrefix(javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace) throws javax.xml.stream.XMLStreamException {
                java.lang.String prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null) {
                        prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                    }

                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }

                return prefix;
            }


  
        /**
        * databinding method to get an XML representation of this object
        *
        */
        public javax.xml.stream.XMLStreamReader getPullParser(javax.xml.namespace.QName qName)
                    throws org.apache.axis2.databinding.ADBException{


        
                 java.util.ArrayList elementList = new java.util.ArrayList();
                 java.util.ArrayList attribList = new java.util.ArrayList();

                
                    attribList.add(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema-instance","type"));
                    attribList.add(new javax.xml.namespace.QName("http://ws.mmis.mtr.com.hk/","locationRangeVO"));
                 if (localGcDirectionCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcDirectionCd"));
                                 
                                        if (localGcDirectionCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcDirectionCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcDirectionCd cannot be null!!");
                                        }
                                    } if (localGcDirectionDespTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcDirectionDesp"));
                                 
                                        if (localGcDirectionDesp != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcDirectionDesp));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcDirectionDesp cannot be null!!");
                                        }
                                    } if (localKmFromTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "kmFrom"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localKmFrom));
                            } if (localKmToTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "kmTo"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localKmTo));
                            } if (localLineCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "lineCd"));
                                 
                                        if (localLineCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLineCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("lineCd cannot be null!!");
                                        }
                                    } if (localLineIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "lineId"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLineId));
                            } if (localLocationFromCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "locationFromCd"));
                                 
                                        if (localLocationFromCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLocationFromCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("locationFromCd cannot be null!!");
                                        }
                                    } if (localLocationFromIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "locationFromId"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLocationFromId));
                            } if (localLocationToCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "locationToCd"));
                                 
                                        if (localLocationToCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLocationToCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("locationToCd cannot be null!!");
                                        }
                                    } if (localLocationToIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "locationToId"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLocationToId));
                            } if (localLocationTypeTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "locationType"));
                                 
                                        if (localLocationType != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLocationType));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("locationType cannot be null!!");
                                        }
                                    } if (localRefFromLocsTracker){
                             if (localRefFromLocs!=null) {
                                 for (int i = 0;i < localRefFromLocs.length;i++){

                                    if (localRefFromLocs[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "refFromLocs"));
                                         elementList.add(localRefFromLocs[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "refFromLocs"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "refFromLocs"));
                                        elementList.add(localRefFromLocs);
                                    
                             }

                        } if (localRefLocFromIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "refLocFromId"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRefLocFromId));
                            } if (localRefLocToIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "refLocToId"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRefLocToId));
                            } if (localRefToLocsTracker){
                             if (localRefToLocs!=null) {
                                 for (int i = 0;i < localRefToLocs.length;i++){

                                    if (localRefToLocs[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "refToLocs"));
                                         elementList.add(localRefToLocs[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "refToLocs"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "refToLocs"));
                                        elementList.add(localRefToLocs);
                                    
                             }

                        } if (localRootFromLocCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "rootFromLocCd"));
                                 
                                        if (localRootFromLocCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRootFromLocCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("rootFromLocCd cannot be null!!");
                                        }
                                    } if (localRootFromLocIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "rootFromLocId"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRootFromLocId));
                            } if (localRootToLocCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "rootToLocCd"));
                                 
                                        if (localRootToLocCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRootToLocCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("rootToLocCd cannot be null!!");
                                        }
                                    } if (localRootToLocIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "rootToLocId"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRootToLocId));
                            } if (localSelectedFromLocIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "selectedFromLocId"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSelectedFromLocId));
                            } if (localSelectedKmFromTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "selectedKmFrom"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSelectedKmFrom));
                            } if (localSelectedKmToTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "selectedKmTo"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSelectedKmTo));
                            } if (localSelectedToLocIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "selectedToLocId"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSelectedToLocId));
                            } if (localSubLocationFromTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "subLocationFrom"));
                                 
                                        if (localSubLocationFrom != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSubLocationFrom));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("subLocationFrom cannot be null!!");
                                        }
                                    } if (localSubLocationToTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "subLocationTo"));
                                 
                                        if (localSubLocationTo != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSubLocationTo));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("subLocationTo cannot be null!!");
                                        }
                                    } if (localSupplementInfoTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "supplementInfo"));
                                 
                                        if (localSupplementInfo != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSupplementInfo));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("supplementInfo cannot be null!!");
                                        }
                                    }

                return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName, elementList.toArray(), attribList.toArray());
            
            

        }

  

     /**
      *  Factory class that keeps the parse method
      */
    public static class Factory{

        
        

        /**
        * static method to create the object
        * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
        *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
        * Postcondition: If this object is an element, the reader is positioned at its end element
        *                If this object is a complex type, the reader is positioned at the end element of its outer element
        */
        public static LocationRangeVO parse(javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{
            LocationRangeVO object =
                new LocationRangeVO();

            int event;
            java.lang.String nillableValue = null;
            java.lang.String prefix ="";
            java.lang.String namespaceuri ="";
            try {
                
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                
                if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","type")!=null){
                  java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                        "type");
                  if (fullTypeName!=null){
                    java.lang.String nsPrefix = null;
                    if (fullTypeName.indexOf(":") > -1){
                        nsPrefix = fullTypeName.substring(0,fullTypeName.indexOf(":"));
                    }
                    nsPrefix = nsPrefix==null?"":nsPrefix;

                    java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":")+1);
                    
                            if (!"locationRangeVO".equals(type)){
                                //find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext().getNamespaceURI(nsPrefix);
                                return (LocationRangeVO)hk.com.mtr.mmis.ws.ExtensionMapper.getTypeObject(
                                     nsUri,type,reader);
                              }
                        

                  }
                

                }

                

                
                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();
                

                 
                    
                    reader.next();
                
                        java.util.ArrayList list12 = new java.util.ArrayList();
                    
                        java.util.ArrayList list15 = new java.util.ArrayList();
                    
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcDirectionCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcDirectionCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcDirectionDesp").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcDirectionDesp(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","kmFrom").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setKmFrom(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setKmFrom(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","kmTo").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setKmTo(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setKmTo(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","lineCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setLineCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","lineId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setLineId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setLineId(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","locationFromCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setLocationFromCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","locationFromId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setLocationFromId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setLocationFromId(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","locationToCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setLocationToCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","locationToId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setLocationToId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setLocationToId(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","locationType").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setLocationType(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","refFromLocs").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list12.add(null);
                                                              reader.next();
                                                          } else {
                                                        list12.add(hk.com.mtr.mmis.ws.RefLocationVO.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone12 = false;
                                                        while(!loopDone12){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone12 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","refFromLocs").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list12.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list12.add(hk.com.mtr.mmis.ws.RefLocationVO.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone12 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setRefFromLocs((hk.com.mtr.mmis.ws.RefLocationVO[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.RefLocationVO.class,
                                                                list12));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","refLocFromId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setRefLocFromId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setRefLocFromId(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","refLocToId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setRefLocToId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setRefLocToId(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","refToLocs").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list15.add(null);
                                                              reader.next();
                                                          } else {
                                                        list15.add(hk.com.mtr.mmis.ws.RefLocationVO.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone15 = false;
                                                        while(!loopDone15){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone15 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","refToLocs").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list15.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list15.add(hk.com.mtr.mmis.ws.RefLocationVO.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone15 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setRefToLocs((hk.com.mtr.mmis.ws.RefLocationVO[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.RefLocationVO.class,
                                                                list15));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","rootFromLocCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setRootFromLocCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","rootFromLocId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setRootFromLocId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setRootFromLocId(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","rootToLocCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setRootToLocCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","rootToLocId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setRootToLocId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setRootToLocId(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","selectedFromLocId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setSelectedFromLocId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setSelectedFromLocId(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","selectedKmFrom").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setSelectedKmFrom(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setSelectedKmFrom(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","selectedKmTo").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setSelectedKmTo(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setSelectedKmTo(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","selectedToLocId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setSelectedToLocId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setSelectedToLocId(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","subLocationFrom").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setSubLocationFrom(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","subLocationTo").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setSubLocationTo(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","supplementInfo").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setSupplementInfo(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                  
                            while (!reader.isStartElement() && !reader.isEndElement())
                                reader.next();
                            
                                if (reader.isStartElement())
                                // A start element we are not expecting indicates a trailing invalid property
                                throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader.getLocalName());
                            



            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }

        }//end of factory class

        

        }
           
          