
/**
 * StdJobParamSubset.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: SNAPSHOT  Built on : Jan 10, 2009 (05:26:17 CST)
 */
            
                package hk.com.mtr.mmis.ws;
            

            /**
            *  StdJobParamSubset bean class
            */
        
        public  class StdJobParamSubset extends hk.com.mtr.mmis.ws.BaseVO
        implements org.apache.axis2.databinding.ADBBean{
        /* This type was generated from the piece of schema that had
                name = stdJobParamSubset
                Namespace URI = http://ws.mmis.mtr.com.hk/
                Namespace Prefix = ns1
                */
            

        private static java.lang.String generatePrefix(java.lang.String namespace) {
            if(namespace.equals("http://ws.mmis.mtr.com.hk/")){
                return "ns1";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        

                        /**
                        * field for AdjustScheduleCd
                        */

                        
                                    protected java.lang.String localAdjustScheduleCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localAdjustScheduleCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getAdjustScheduleCd(){
                               return localAdjustScheduleCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param AdjustScheduleCd
                               */
                               public void setAdjustScheduleCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localAdjustScheduleCdTracker = true;
                                       } else {
                                          localAdjustScheduleCdTracker = false;
                                              
                                       }
                                   
                                            this.localAdjustScheduleCd=param;
                                    

                               }
                            

                        /**
                        * field for BuId
                        */

                        
                                    protected long localBuId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localBuIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getBuId(){
                               return localBuId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param BuId
                               */
                               public void setBuId(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localBuIdTracker = false;
                                              
                                       } else {
                                          localBuIdTracker = true;
                                       }
                                   
                                            this.localBuId=param;
                                    

                               }
                            

                        /**
                        * field for ChangeRemark
                        */

                        
                                    protected java.lang.String localChangeRemark ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localChangeRemarkTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getChangeRemark(){
                               return localChangeRemark;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ChangeRemark
                               */
                               public void setChangeRemark(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localChangeRemarkTracker = true;
                                       } else {
                                          localChangeRemarkTracker = false;
                                              
                                       }
                                   
                                            this.localChangeRemark=param;
                                    

                               }
                            

                        /**
                        * field for ContractCd
                        */

                        
                                    protected java.lang.String localContractCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localContractCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getContractCd(){
                               return localContractCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ContractCd
                               */
                               public void setContractCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localContractCdTracker = true;
                                       } else {
                                          localContractCdTracker = false;
                                              
                                       }
                                   
                                            this.localContractCd=param;
                                    

                               }
                            

                        /**
                        * field for ContractID
                        */

                        
                                    protected long localContractID ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localContractIDTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getContractID(){
                               return localContractID;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ContractID
                               */
                               public void setContractID(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localContractIDTracker = false;
                                              
                                       } else {
                                          localContractIDTracker = true;
                                       }
                                   
                                            this.localContractID=param;
                                    

                               }
                            

                        /**
                        * field for ContractNO
                        */

                        
                                    protected java.lang.String localContractNO ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localContractNOTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getContractNO(){
                               return localContractNO;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ContractNO
                               */
                               public void setContractNO(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localContractNOTracker = true;
                                       } else {
                                          localContractNOTracker = false;
                                              
                                       }
                                   
                                            this.localContractNO=param;
                                    

                               }
                            

                        /**
                        * field for DayPreference
                        */

                        
                                    protected long localDayPreference ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localDayPreferenceTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getDayPreference(){
                               return localDayPreference;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param DayPreference
                               */
                               public void setDayPreference(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localDayPreferenceTracker = false;
                                              
                                       } else {
                                          localDayPreferenceTracker = true;
                                       }
                                   
                                            this.localDayPreference=param;
                                    

                               }
                            

                        /**
                        * field for EffEndDate
                        */

                        
                                    protected java.util.Calendar localEffEndDate ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localEffEndDateTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.util.Calendar
                           */
                           public  java.util.Calendar getEffEndDate(){
                               return localEffEndDate;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param EffEndDate
                               */
                               public void setEffEndDate(java.util.Calendar param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localEffEndDateTracker = true;
                                       } else {
                                          localEffEndDateTracker = false;
                                              
                                       }
                                   
                                            this.localEffEndDate=param;
                                    

                               }
                            

                        /**
                        * field for EffStartDate
                        */

                        
                                    protected java.util.Calendar localEffStartDate ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localEffStartDateTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.util.Calendar
                           */
                           public  java.util.Calendar getEffStartDate(){
                               return localEffStartDate;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param EffStartDate
                               */
                               public void setEffStartDate(java.util.Calendar param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localEffStartDateTracker = true;
                                       } else {
                                          localEffStartDateTracker = false;
                                              
                                       }
                                   
                                            this.localEffStartDate=param;
                                    

                               }
                            

                        /**
                        * field for EstimateJobDur
                        */

                        
                                    protected long localEstimateJobDur ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localEstimateJobDurTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getEstimateJobDur(){
                               return localEstimateJobDur;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param EstimateJobDur
                               */
                               public void setEstimateJobDur(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localEstimateJobDurTracker = false;
                                              
                                       } else {
                                          localEstimateJobDurTracker = true;
                                       }
                                   
                                            this.localEstimateJobDur=param;
                                    

                               }
                            

                        /**
                        * field for FactorFitment
                        */

                        
                                    protected boolean localFactorFitment ;
                                

                           /**
                           * Auto generated getter method
                           * @return boolean
                           */
                           public  boolean getFactorFitment(){
                               return localFactorFitment;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param FactorFitment
                               */
                               public void setFactorFitment(boolean param){
                            
                                            this.localFactorFitment=param;
                                    

                               }
                            

                        /**
                        * field for FirstMeasurementInterval
                        */

                        
                                    protected double localFirstMeasurementInterval ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localFirstMeasurementIntervalTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getFirstMeasurementInterval(){
                               return localFirstMeasurementInterval;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param FirstMeasurementInterval
                               */
                               public void setFirstMeasurementInterval(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localFirstMeasurementIntervalTracker = false;
                                              
                                       } else {
                                          localFirstMeasurementIntervalTracker = true;
                                       }
                                   
                                            this.localFirstMeasurementInterval=param;
                                    

                               }
                            

                        /**
                        * field for FirstMeasurementMaxAdv
                        */

                        
                                    protected double localFirstMeasurementMaxAdv ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localFirstMeasurementMaxAdvTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getFirstMeasurementMaxAdv(){
                               return localFirstMeasurementMaxAdv;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param FirstMeasurementMaxAdv
                               */
                               public void setFirstMeasurementMaxAdv(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localFirstMeasurementMaxAdvTracker = false;
                                              
                                       } else {
                                          localFirstMeasurementMaxAdvTracker = true;
                                       }
                                   
                                            this.localFirstMeasurementMaxAdv=param;
                                    

                               }
                            

                        /**
                        * field for FirstMeasurementMaxPost
                        */

                        
                                    protected double localFirstMeasurementMaxPost ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localFirstMeasurementMaxPostTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getFirstMeasurementMaxPost(){
                               return localFirstMeasurementMaxPost;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param FirstMeasurementMaxPost
                               */
                               public void setFirstMeasurementMaxPost(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localFirstMeasurementMaxPostTracker = false;
                                              
                                       } else {
                                          localFirstMeasurementMaxPostTracker = true;
                                       }
                                   
                                            this.localFirstMeasurementMaxPost=param;
                                    

                               }
                            

                        /**
                        * field for FirstMeasurementTypeId
                        */

                        
                                    protected long localFirstMeasurementTypeId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localFirstMeasurementTypeIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getFirstMeasurementTypeId(){
                               return localFirstMeasurementTypeId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param FirstMeasurementTypeId
                               */
                               public void setFirstMeasurementTypeId(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localFirstMeasurementTypeIdTracker = false;
                                              
                                       } else {
                                          localFirstMeasurementTypeIdTracker = true;
                                       }
                                   
                                            this.localFirstMeasurementTypeId=param;
                                    

                               }
                            

                        /**
                        * field for FirstMeasurementTypeName
                        */

                        
                                    protected java.lang.String localFirstMeasurementTypeName ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localFirstMeasurementTypeNameTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getFirstMeasurementTypeName(){
                               return localFirstMeasurementTypeName;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param FirstMeasurementTypeName
                               */
                               public void setFirstMeasurementTypeName(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localFirstMeasurementTypeNameTracker = true;
                                       } else {
                                          localFirstMeasurementTypeNameTracker = false;
                                              
                                       }
                                   
                                            this.localFirstMeasurementTypeName=param;
                                    

                               }
                            

                        /**
                        * field for FirstMeasurementUom
                        */

                        
                                    protected java.lang.String localFirstMeasurementUom ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localFirstMeasurementUomTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getFirstMeasurementUom(){
                               return localFirstMeasurementUom;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param FirstMeasurementUom
                               */
                               public void setFirstMeasurementUom(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localFirstMeasurementUomTracker = true;
                                       } else {
                                          localFirstMeasurementUomTracker = false;
                                              
                                       }
                                   
                                            this.localFirstMeasurementUom=param;
                                    

                               }
                            

                        /**
                        * field for GcFinanceRefNoCD
                        */

                        
                                    protected java.lang.String localGcFinanceRefNoCD ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcFinanceRefNoCDTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcFinanceRefNoCD(){
                               return localGcFinanceRefNoCD;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcFinanceRefNoCD
                               */
                               public void setGcFinanceRefNoCD(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcFinanceRefNoCDTracker = true;
                                       } else {
                                          localGcFinanceRefNoCDTracker = false;
                                              
                                       }
                                   
                                            this.localGcFinanceRefNoCD=param;
                                    

                               }
                            

                        /**
                        * field for GcPriorityCd
                        */

                        
                                    protected java.lang.String localGcPriorityCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcPriorityCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcPriorityCd(){
                               return localGcPriorityCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcPriorityCd
                               */
                               public void setGcPriorityCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcPriorityCdTracker = true;
                                       } else {
                                          localGcPriorityCdTracker = false;
                                              
                                       }
                                   
                                            this.localGcPriorityCd=param;
                                    

                               }
                            

                        /**
                        * field for GcProjectNoCD
                        */

                        
                                    protected java.lang.String localGcProjectNoCD ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcProjectNoCDTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcProjectNoCD(){
                               return localGcProjectNoCD;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcProjectNoCD
                               */
                               public void setGcProjectNoCD(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcProjectNoCDTracker = true;
                                       } else {
                                          localGcProjectNoCDTracker = false;
                                              
                                       }
                                   
                                            this.localGcProjectNoCD=param;
                                    

                               }
                            

                        /**
                        * field for GcProjectTakkNoCD
                        */

                        
                                    protected java.lang.String localGcProjectTakkNoCD ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcProjectTakkNoCDTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcProjectTakkNoCD(){
                               return localGcProjectTakkNoCD;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcProjectTakkNoCD
                               */
                               public void setGcProjectTakkNoCD(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcProjectTakkNoCDTracker = true;
                                       } else {
                                          localGcProjectTakkNoCDTracker = false;
                                              
                                       }
                                   
                                            this.localGcProjectTakkNoCD=param;
                                    

                               }
                            

                        /**
                        * field for GcSsdCalculationMethodCd
                        */

                        
                                    protected java.lang.String localGcSsdCalculationMethodCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcSsdCalculationMethodCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcSsdCalculationMethodCd(){
                               return localGcSsdCalculationMethodCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcSsdCalculationMethodCd
                               */
                               public void setGcSsdCalculationMethodCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcSsdCalculationMethodCdTracker = true;
                                       } else {
                                          localGcSsdCalculationMethodCdTracker = false;
                                              
                                       }
                                   
                                            this.localGcSsdCalculationMethodCd=param;
                                    

                               }
                            

                        /**
                        * field for GcTabuMethodCd
                        */

                        
                                    protected java.lang.String localGcTabuMethodCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcTabuMethodCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcTabuMethodCd(){
                               return localGcTabuMethodCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcTabuMethodCd
                               */
                               public void setGcTabuMethodCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcTabuMethodCdTracker = true;
                                       } else {
                                          localGcTabuMethodCdTracker = false;
                                              
                                       }
                                   
                                            this.localGcTabuMethodCd=param;
                                    

                               }
                            

                        /**
                        * field for GcWorkTimeReqCd
                        */

                        
                                    protected java.lang.String localGcWorkTimeReqCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcWorkTimeReqCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcWorkTimeReqCd(){
                               return localGcWorkTimeReqCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcWorkTimeReqCd
                               */
                               public void setGcWorkTimeReqCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcWorkTimeReqCdTracker = true;
                                       } else {
                                          localGcWorkTimeReqCdTracker = false;
                                              
                                       }
                                   
                                            this.localGcWorkTimeReqCd=param;
                                    

                               }
                            

                        /**
                        * field for LastUpdDatetime
                        */

                        
                                    protected java.util.Calendar localLastUpdDatetime ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localLastUpdDatetimeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.util.Calendar
                           */
                           public  java.util.Calendar getLastUpdDatetime(){
                               return localLastUpdDatetime;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param LastUpdDatetime
                               */
                               public void setLastUpdDatetime(java.util.Calendar param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localLastUpdDatetimeTracker = true;
                                       } else {
                                          localLastUpdDatetimeTracker = false;
                                              
                                       }
                                   
                                            this.localLastUpdDatetime=param;
                                    

                               }
                            

                        /**
                        * field for LastUpdUserId
                        */

                        
                                    protected long localLastUpdUserId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localLastUpdUserIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getLastUpdUserId(){
                               return localLastUpdUserId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param LastUpdUserId
                               */
                               public void setLastUpdUserId(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localLastUpdUserIdTracker = false;
                                              
                                       } else {
                                          localLastUpdUserIdTracker = true;
                                       }
                                   
                                            this.localLastUpdUserId=param;
                                    

                               }
                            

                        /**
                        * field for MaxOverdue
                        */

                        
                                    protected long localMaxOverdue ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localMaxOverdueTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getMaxOverdue(){
                               return localMaxOverdue;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param MaxOverdue
                               */
                               public void setMaxOverdue(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localMaxOverdueTracker = false;
                                              
                                       } else {
                                          localMaxOverdueTracker = true;
                                       }
                                   
                                            this.localMaxOverdue=param;
                                    

                               }
                            

                        /**
                        * field for MaxTlrncMeasurementName
                        */

                        
                                    protected java.lang.String localMaxTlrncMeasurementName ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localMaxTlrncMeasurementNameTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getMaxTlrncMeasurementName(){
                               return localMaxTlrncMeasurementName;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param MaxTlrncMeasurementName
                               */
                               public void setMaxTlrncMeasurementName(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localMaxTlrncMeasurementNameTracker = true;
                                       } else {
                                          localMaxTlrncMeasurementNameTracker = false;
                                              
                                       }
                                   
                                            this.localMaxTlrncMeasurementName=param;
                                    

                               }
                            

                        /**
                        * field for MaxTlrncMeasurementRange
                        */

                        
                                    protected double localMaxTlrncMeasurementRange ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localMaxTlrncMeasurementRangeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getMaxTlrncMeasurementRange(){
                               return localMaxTlrncMeasurementRange;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param MaxTlrncMeasurementRange
                               */
                               public void setMaxTlrncMeasurementRange(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localMaxTlrncMeasurementRangeTracker = false;
                                              
                                       } else {
                                          localMaxTlrncMeasurementRangeTracker = true;
                                       }
                                   
                                            this.localMaxTlrncMeasurementRange=param;
                                    

                               }
                            

                        /**
                        * field for MaxTlrncMeasurementTypeId
                        */

                        
                                    protected long localMaxTlrncMeasurementTypeId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localMaxTlrncMeasurementTypeIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getMaxTlrncMeasurementTypeId(){
                               return localMaxTlrncMeasurementTypeId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param MaxTlrncMeasurementTypeId
                               */
                               public void setMaxTlrncMeasurementTypeId(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localMaxTlrncMeasurementTypeIdTracker = false;
                                              
                                       } else {
                                          localMaxTlrncMeasurementTypeIdTracker = true;
                                       }
                                   
                                            this.localMaxTlrncMeasurementTypeId=param;
                                    

                               }
                            

                        /**
                        * field for MaxToleranceRange
                        */

                        
                                    protected long localMaxToleranceRange ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localMaxToleranceRangeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getMaxToleranceRange(){
                               return localMaxToleranceRange;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param MaxToleranceRange
                               */
                               public void setMaxToleranceRange(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localMaxToleranceRangeTracker = false;
                                              
                                       } else {
                                          localMaxToleranceRangeTracker = true;
                                       }
                                   
                                            this.localMaxToleranceRange=param;
                                    

                               }
                            

                        /**
                        * field for MtMeasurementEmpty
                        */

                        
                                    protected boolean localMtMeasurementEmpty ;
                                

                           /**
                           * Auto generated getter method
                           * @return boolean
                           */
                           public  boolean getMtMeasurementEmpty(){
                               return localMtMeasurementEmpty;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param MtMeasurementEmpty
                               */
                               public void setMtMeasurementEmpty(boolean param){
                            
                                            this.localMtMeasurementEmpty=param;
                                    

                               }
                            

                        /**
                        * field for MtUom
                        */

                        
                                    protected java.lang.String localMtUom ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localMtUomTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getMtUom(){
                               return localMtUom;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param MtUom
                               */
                               public void setMtUom(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localMtUomTracker = true;
                                       } else {
                                          localMtUomTracker = false;
                                              
                                       }
                                   
                                            this.localMtUom=param;
                                    

                               }
                            

                        /**
                        * field for SchFactorFitment
                        */

                        
                                    protected java.lang.String localSchFactorFitment ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSchFactorFitmentTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getSchFactorFitment(){
                               return localSchFactorFitment;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param SchFactorFitment
                               */
                               public void setSchFactorFitment(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localSchFactorFitmentTracker = true;
                                       } else {
                                          localSchFactorFitmentTracker = false;
                                              
                                       }
                                   
                                            this.localSchFactorFitment=param;
                                    

                               }
                            

                        /**
                        * field for SchFactorStdJobCd
                        */

                        
                                    protected java.lang.String localSchFactorStdJobCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSchFactorStdJobCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getSchFactorStdJobCd(){
                               return localSchFactorStdJobCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param SchFactorStdJobCd
                               */
                               public void setSchFactorStdJobCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localSchFactorStdJobCdTracker = true;
                                       } else {
                                          localSchFactorStdJobCdTracker = false;
                                              
                                       }
                                   
                                            this.localSchFactorStdJobCd=param;
                                    

                               }
                            

                        /**
                        * field for SchFactorStdJobId
                        */

                        
                                    protected java.lang.String localSchFactorStdJobId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSchFactorStdJobIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getSchFactorStdJobId(){
                               return localSchFactorStdJobId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param SchFactorStdJobId
                               */
                               public void setSchFactorStdJobId(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localSchFactorStdJobIdTracker = true;
                                       } else {
                                          localSchFactorStdJobIdTracker = false;
                                              
                                       }
                                   
                                            this.localSchFactorStdJobId=param;
                                    

                               }
                            

                        /**
                        * field for SecondMeasurementInterval
                        */

                        
                                    protected double localSecondMeasurementInterval ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSecondMeasurementIntervalTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getSecondMeasurementInterval(){
                               return localSecondMeasurementInterval;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param SecondMeasurementInterval
                               */
                               public void setSecondMeasurementInterval(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localSecondMeasurementIntervalTracker = false;
                                              
                                       } else {
                                          localSecondMeasurementIntervalTracker = true;
                                       }
                                   
                                            this.localSecondMeasurementInterval=param;
                                    

                               }
                            

                        /**
                        * field for SecondMeasurementMaxAdv
                        */

                        
                                    protected double localSecondMeasurementMaxAdv ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSecondMeasurementMaxAdvTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getSecondMeasurementMaxAdv(){
                               return localSecondMeasurementMaxAdv;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param SecondMeasurementMaxAdv
                               */
                               public void setSecondMeasurementMaxAdv(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localSecondMeasurementMaxAdvTracker = false;
                                              
                                       } else {
                                          localSecondMeasurementMaxAdvTracker = true;
                                       }
                                   
                                            this.localSecondMeasurementMaxAdv=param;
                                    

                               }
                            

                        /**
                        * field for SecondMeasurementMaxPost
                        */

                        
                                    protected double localSecondMeasurementMaxPost ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSecondMeasurementMaxPostTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getSecondMeasurementMaxPost(){
                               return localSecondMeasurementMaxPost;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param SecondMeasurementMaxPost
                               */
                               public void setSecondMeasurementMaxPost(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localSecondMeasurementMaxPostTracker = false;
                                              
                                       } else {
                                          localSecondMeasurementMaxPostTracker = true;
                                       }
                                   
                                            this.localSecondMeasurementMaxPost=param;
                                    

                               }
                            

                        /**
                        * field for SecondMeasurementTypeId
                        */

                        
                                    protected long localSecondMeasurementTypeId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSecondMeasurementTypeIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getSecondMeasurementTypeId(){
                               return localSecondMeasurementTypeId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param SecondMeasurementTypeId
                               */
                               public void setSecondMeasurementTypeId(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localSecondMeasurementTypeIdTracker = false;
                                              
                                       } else {
                                          localSecondMeasurementTypeIdTracker = true;
                                       }
                                   
                                            this.localSecondMeasurementTypeId=param;
                                    

                               }
                            

                        /**
                        * field for SecondMeasurementTypeName
                        */

                        
                                    protected java.lang.String localSecondMeasurementTypeName ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSecondMeasurementTypeNameTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getSecondMeasurementTypeName(){
                               return localSecondMeasurementTypeName;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param SecondMeasurementTypeName
                               */
                               public void setSecondMeasurementTypeName(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localSecondMeasurementTypeNameTracker = true;
                                       } else {
                                          localSecondMeasurementTypeNameTracker = false;
                                              
                                       }
                                   
                                            this.localSecondMeasurementTypeName=param;
                                    

                               }
                            

                        /**
                        * field for SecondMeasurementUom
                        */

                        
                                    protected java.lang.String localSecondMeasurementUom ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSecondMeasurementUomTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getSecondMeasurementUom(){
                               return localSecondMeasurementUom;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param SecondMeasurementUom
                               */
                               public void setSecondMeasurementUom(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localSecondMeasurementUomTracker = true;
                                       } else {
                                          localSecondMeasurementUomTracker = false;
                                              
                                       }
                                   
                                            this.localSecondMeasurementUom=param;
                                    

                               }
                            

                        /**
                        * field for StatutoryInd
                        */

                        
                                    protected java.lang.String localStatutoryInd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localStatutoryIndTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getStatutoryInd(){
                               return localStatutoryInd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param StatutoryInd
                               */
                               public void setStatutoryInd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localStatutoryIndTracker = true;
                                       } else {
                                          localStatutoryIndTracker = false;
                                              
                                       }
                                   
                                            this.localStatutoryInd=param;
                                    

                               }
                            

                        /**
                        * field for StdJobBillOfLabours
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.StdJobBillOfLabour[] localStdJobBillOfLabours ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localStdJobBillOfLaboursTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.StdJobBillOfLabour[]
                           */
                           public  hk.com.mtr.mmis.ws.StdJobBillOfLabour[] getStdJobBillOfLabours(){
                               return localStdJobBillOfLabours;
                           }

                           
                        


                               
                              /**
                               * validate the array for StdJobBillOfLabours
                               */
                              protected void validateStdJobBillOfLabours(hk.com.mtr.mmis.ws.StdJobBillOfLabour[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param StdJobBillOfLabours
                              */
                              public void setStdJobBillOfLabours(hk.com.mtr.mmis.ws.StdJobBillOfLabour[] param){
                              
                                   validateStdJobBillOfLabours(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localStdJobBillOfLaboursTracker = true;
                                          } else {
                                             localStdJobBillOfLaboursTracker = true;
                                                 
                                          }
                                      
                                      this.localStdJobBillOfLabours=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.StdJobBillOfLabour
                             */
                             public void addStdJobBillOfLabours(hk.com.mtr.mmis.ws.StdJobBillOfLabour param){
                                   if (localStdJobBillOfLabours == null){
                                   localStdJobBillOfLabours = new hk.com.mtr.mmis.ws.StdJobBillOfLabour[]{};
                                   }

                            
                                 //update the setting tracker
                                localStdJobBillOfLaboursTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localStdJobBillOfLabours);
                               list.add(param);
                               this.localStdJobBillOfLabours =
                             (hk.com.mtr.mmis.ws.StdJobBillOfLabour[])list.toArray(
                            new hk.com.mtr.mmis.ws.StdJobBillOfLabour[list.size()]);

                             }
                             

                        /**
                        * field for StdJobBillOfMaterials
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.StdJobBillOfMaterial[] localStdJobBillOfMaterials ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localStdJobBillOfMaterialsTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.StdJobBillOfMaterial[]
                           */
                           public  hk.com.mtr.mmis.ws.StdJobBillOfMaterial[] getStdJobBillOfMaterials(){
                               return localStdJobBillOfMaterials;
                           }

                           
                        


                               
                              /**
                               * validate the array for StdJobBillOfMaterials
                               */
                              protected void validateStdJobBillOfMaterials(hk.com.mtr.mmis.ws.StdJobBillOfMaterial[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param StdJobBillOfMaterials
                              */
                              public void setStdJobBillOfMaterials(hk.com.mtr.mmis.ws.StdJobBillOfMaterial[] param){
                              
                                   validateStdJobBillOfMaterials(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localStdJobBillOfMaterialsTracker = true;
                                          } else {
                                             localStdJobBillOfMaterialsTracker = true;
                                                 
                                          }
                                      
                                      this.localStdJobBillOfMaterials=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.StdJobBillOfMaterial
                             */
                             public void addStdJobBillOfMaterials(hk.com.mtr.mmis.ws.StdJobBillOfMaterial param){
                                   if (localStdJobBillOfMaterials == null){
                                   localStdJobBillOfMaterials = new hk.com.mtr.mmis.ws.StdJobBillOfMaterial[]{};
                                   }

                            
                                 //update the setting tracker
                                localStdJobBillOfMaterialsTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localStdJobBillOfMaterials);
                               list.add(param);
                               this.localStdJobBillOfMaterials =
                             (hk.com.mtr.mmis.ws.StdJobBillOfMaterial[])list.toArray(
                            new hk.com.mtr.mmis.ws.StdJobBillOfMaterial[list.size()]);

                             }
                             

                        /**
                        * field for StdJobBillOfOtherses
                        * This was an Array!
                        */

                        
                                    protected hk.com.mtr.mmis.ws.StdJobBillOfOthers[] localStdJobBillOfOtherses ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localStdJobBillOfOthersesTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.StdJobBillOfOthers[]
                           */
                           public  hk.com.mtr.mmis.ws.StdJobBillOfOthers[] getStdJobBillOfOtherses(){
                               return localStdJobBillOfOtherses;
                           }

                           
                        


                               
                              /**
                               * validate the array for StdJobBillOfOtherses
                               */
                              protected void validateStdJobBillOfOtherses(hk.com.mtr.mmis.ws.StdJobBillOfOthers[] param){
                             
                              }


                             /**
                              * Auto generated setter method
                              * @param param StdJobBillOfOtherses
                              */
                              public void setStdJobBillOfOtherses(hk.com.mtr.mmis.ws.StdJobBillOfOthers[] param){
                              
                                   validateStdJobBillOfOtherses(param);

                               
                                          if (param != null){
                                             //update the setting tracker
                                             localStdJobBillOfOthersesTracker = true;
                                          } else {
                                             localStdJobBillOfOthersesTracker = true;
                                                 
                                          }
                                      
                                      this.localStdJobBillOfOtherses=param;
                              }

                               
                             
                             /**
                             * Auto generated add method for the array for convenience
                             * @param param hk.com.mtr.mmis.ws.StdJobBillOfOthers
                             */
                             public void addStdJobBillOfOtherses(hk.com.mtr.mmis.ws.StdJobBillOfOthers param){
                                   if (localStdJobBillOfOtherses == null){
                                   localStdJobBillOfOtherses = new hk.com.mtr.mmis.ws.StdJobBillOfOthers[]{};
                                   }

                            
                                 //update the setting tracker
                                localStdJobBillOfOthersesTracker = true;
                            

                               java.util.List list =
                            org.apache.axis2.databinding.utils.ConverterUtil.toList(localStdJobBillOfOtherses);
                               list.add(param);
                               this.localStdJobBillOfOtherses =
                             (hk.com.mtr.mmis.ws.StdJobBillOfOthers[])list.toArray(
                            new hk.com.mtr.mmis.ws.StdJobBillOfOthers[list.size()]);

                             }
                             

                        /**
                        * field for StdJobParamSubsetId
                        */

                        
                                    protected long localStdJobParamSubsetId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localStdJobParamSubsetIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getStdJobParamSubsetId(){
                               return localStdJobParamSubsetId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param StdJobParamSubsetId
                               */
                               public void setStdJobParamSubsetId(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localStdJobParamSubsetIdTracker = false;
                                              
                                       } else {
                                          localStdJobParamSubsetIdTracker = true;
                                       }
                                   
                                            this.localStdJobParamSubsetId=param;
                                    

                               }
                            

                        /**
                        * field for TimeInterval
                        */

                        
                                    protected long localTimeInterval ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localTimeIntervalTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getTimeInterval(){
                               return localTimeInterval;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param TimeInterval
                               */
                               public void setTimeInterval(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localTimeIntervalTracker = false;
                                              
                                       } else {
                                          localTimeIntervalTracker = true;
                                       }
                                   
                                            this.localTimeInterval=param;
                                    

                               }
                            

                        /**
                        * field for TimeMaxAdv
                        */

                        
                                    protected long localTimeMaxAdv ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localTimeMaxAdvTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getTimeMaxAdv(){
                               return localTimeMaxAdv;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param TimeMaxAdv
                               */
                               public void setTimeMaxAdv(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localTimeMaxAdvTracker = false;
                                              
                                       } else {
                                          localTimeMaxAdvTracker = true;
                                       }
                                   
                                            this.localTimeMaxAdv=param;
                                    

                               }
                            

                        /**
                        * field for TimeMaxPost
                        */

                        
                                    protected long localTimeMaxPost ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localTimeMaxPostTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getTimeMaxPost(){
                               return localTimeMaxPost;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param TimeMaxPost
                               */
                               public void setTimeMaxPost(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localTimeMaxPostTracker = false;
                                              
                                       } else {
                                          localTimeMaxPostTracker = true;
                                       }
                                   
                                            this.localTimeMaxPost=param;
                                    

                               }
                            

                        /**
                        * field for WkGrp
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WorkGrp localWkGrp ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWkGrpTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WorkGrp
                           */
                           public  hk.com.mtr.mmis.ws.WorkGrp getWkGrp(){
                               return localWkGrp;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WkGrp
                               */
                               public void setWkGrp(hk.com.mtr.mmis.ws.WorkGrp param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localWkGrpTracker = true;
                                       } else {
                                          localWkGrpTracker = false;
                                              
                                       }
                                   
                                            this.localWkGrp=param;
                                    

                               }
                            

                        /**
                        * field for WkGrpCd
                        */

                        
                                    protected java.lang.String localWkGrpCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWkGrpCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getWkGrpCd(){
                               return localWkGrpCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WkGrpCd
                               */
                               public void setWkGrpCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localWkGrpCdTracker = true;
                                       } else {
                                          localWkGrpCdTracker = false;
                                              
                                       }
                                   
                                            this.localWkGrpCd=param;
                                    

                               }
                            

     /**
     * isReaderMTOMAware
     * @return true if the reader supports MTOM
     */
   public static boolean isReaderMTOMAware(javax.xml.stream.XMLStreamReader reader) {
        boolean isReaderMTOMAware = false;
        
        try{
          isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader.getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
        }catch(java.lang.IllegalArgumentException e){
          isReaderMTOMAware = false;
        }
        return isReaderMTOMAware;
   }
     
     
        /**
        *
        * @param parentQName
        * @param factory
        * @return org.apache.axiom.om.OMElement
        */
       public org.apache.axiom.om.OMElement getOMElement (
               final javax.xml.namespace.QName parentQName,
               final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException{


        
               org.apache.axiom.om.OMDataSource dataSource =
                       new org.apache.axis2.databinding.ADBDataSource(this,parentQName){

                 public void serialize(org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
                       StdJobParamSubset.this.serialize(parentQName,factory,xmlWriter);
                 }
               };
               return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
               parentQName,factory,dataSource);
            
       }

         public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
                           serialize(parentQName,factory,xmlWriter,false);
         }

         public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               boolean serializeType)
            throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
            
                


                java.lang.String prefix = null;
                java.lang.String namespace = null;
                

                    prefix = parentQName.getPrefix();
                    namespace = parentQName.getNamespaceURI();

                    if ((namespace != null) && (namespace.trim().length() > 0)) {
                        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                        if (writerPrefix != null) {
                            xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                        } else {
                            if (prefix == null) {
                                prefix = generatePrefix(namespace);
                            }

                            xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                            xmlWriter.writeNamespace(prefix, namespace);
                            xmlWriter.setPrefix(prefix, namespace);
                        }
                    } else {
                        xmlWriter.writeStartElement(parentQName.getLocalPart());
                    }
                

                   java.lang.String namespacePrefix = registerPrefix(xmlWriter,"http://ws.mmis.mtr.com.hk/");
                   if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0)){
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           namespacePrefix+":stdJobParamSubset",
                           xmlWriter);
                   } else {
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           "stdJobParamSubset",
                           xmlWriter);
                   }

                if (localAdjustScheduleCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"adjustScheduleCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"adjustScheduleCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("adjustScheduleCd");
                                    }
                                

                                          if (localAdjustScheduleCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("adjustScheduleCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localAdjustScheduleCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localBuIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"buId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"buId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("buId");
                                    }
                                
                                               if (localBuId==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("buId cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localBuId));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localChangeRemarkTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"changeRemark", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"changeRemark");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("changeRemark");
                                    }
                                

                                          if (localChangeRemark==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("changeRemark cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localChangeRemark);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localContractCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"contractCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"contractCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("contractCd");
                                    }
                                

                                          if (localContractCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("contractCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localContractCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localContractIDTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"contractID", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"contractID");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("contractID");
                                    }
                                
                                               if (localContractID==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("contractID cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localContractID));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localContractNOTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"contractNO", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"contractNO");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("contractNO");
                                    }
                                

                                          if (localContractNO==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("contractNO cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localContractNO);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localDayPreferenceTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"dayPreference", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"dayPreference");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("dayPreference");
                                    }
                                
                                               if (localDayPreference==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("dayPreference cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localDayPreference));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localEffEndDateTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"effEndDate", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"effEndDate");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("effEndDate");
                                    }
                                

                                          if (localEffEndDate==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("effEndDate cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localEffEndDate));
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localEffStartDateTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"effStartDate", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"effStartDate");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("effStartDate");
                                    }
                                

                                          if (localEffStartDate==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("effStartDate cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localEffStartDate));
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localEstimateJobDurTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"estimateJobDur", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"estimateJobDur");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("estimateJobDur");
                                    }
                                
                                               if (localEstimateJobDur==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("estimateJobDur cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localEstimateJobDur));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             }
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"factorFitment", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"factorFitment");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("factorFitment");
                                    }
                                
                                               if (false) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("factorFitment cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localFactorFitment));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                              if (localFirstMeasurementIntervalTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"firstMeasurementInterval", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"firstMeasurementInterval");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("firstMeasurementInterval");
                                    }
                                
                                               if (java.lang.Double.isNaN(localFirstMeasurementInterval)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("firstMeasurementInterval cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localFirstMeasurementInterval));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localFirstMeasurementMaxAdvTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"firstMeasurementMaxAdv", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"firstMeasurementMaxAdv");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("firstMeasurementMaxAdv");
                                    }
                                
                                               if (java.lang.Double.isNaN(localFirstMeasurementMaxAdv)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("firstMeasurementMaxAdv cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localFirstMeasurementMaxAdv));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localFirstMeasurementMaxPostTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"firstMeasurementMaxPost", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"firstMeasurementMaxPost");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("firstMeasurementMaxPost");
                                    }
                                
                                               if (java.lang.Double.isNaN(localFirstMeasurementMaxPost)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("firstMeasurementMaxPost cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localFirstMeasurementMaxPost));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localFirstMeasurementTypeIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"firstMeasurementTypeId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"firstMeasurementTypeId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("firstMeasurementTypeId");
                                    }
                                
                                               if (localFirstMeasurementTypeId==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("firstMeasurementTypeId cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localFirstMeasurementTypeId));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localFirstMeasurementTypeNameTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"firstMeasurementTypeName", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"firstMeasurementTypeName");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("firstMeasurementTypeName");
                                    }
                                

                                          if (localFirstMeasurementTypeName==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("firstMeasurementTypeName cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localFirstMeasurementTypeName);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localFirstMeasurementUomTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"firstMeasurementUom", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"firstMeasurementUom");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("firstMeasurementUom");
                                    }
                                

                                          if (localFirstMeasurementUom==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("firstMeasurementUom cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localFirstMeasurementUom);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcFinanceRefNoCDTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcFinanceRefNoCD", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcFinanceRefNoCD");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcFinanceRefNoCD");
                                    }
                                

                                          if (localGcFinanceRefNoCD==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcFinanceRefNoCD cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcFinanceRefNoCD);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcPriorityCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcPriorityCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcPriorityCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcPriorityCd");
                                    }
                                

                                          if (localGcPriorityCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcPriorityCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcPriorityCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcProjectNoCDTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcProjectNoCD", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcProjectNoCD");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcProjectNoCD");
                                    }
                                

                                          if (localGcProjectNoCD==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcProjectNoCD cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcProjectNoCD);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcProjectTakkNoCDTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcProjectTakkNoCD", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcProjectTakkNoCD");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcProjectTakkNoCD");
                                    }
                                

                                          if (localGcProjectTakkNoCD==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcProjectTakkNoCD cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcProjectTakkNoCD);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcSsdCalculationMethodCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcSsdCalculationMethodCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcSsdCalculationMethodCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcSsdCalculationMethodCd");
                                    }
                                

                                          if (localGcSsdCalculationMethodCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcSsdCalculationMethodCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcSsdCalculationMethodCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcTabuMethodCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcTabuMethodCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcTabuMethodCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcTabuMethodCd");
                                    }
                                

                                          if (localGcTabuMethodCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcTabuMethodCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcTabuMethodCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcWorkTimeReqCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcWorkTimeReqCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcWorkTimeReqCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcWorkTimeReqCd");
                                    }
                                

                                          if (localGcWorkTimeReqCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcWorkTimeReqCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcWorkTimeReqCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localLastUpdDatetimeTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"lastUpdDatetime", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"lastUpdDatetime");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("lastUpdDatetime");
                                    }
                                

                                          if (localLastUpdDatetime==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("lastUpdDatetime cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLastUpdDatetime));
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localLastUpdUserIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"lastUpdUserId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"lastUpdUserId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("lastUpdUserId");
                                    }
                                
                                               if (localLastUpdUserId==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("lastUpdUserId cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLastUpdUserId));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localMaxOverdueTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"maxOverdue", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"maxOverdue");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("maxOverdue");
                                    }
                                
                                               if (localMaxOverdue==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("maxOverdue cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMaxOverdue));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localMaxTlrncMeasurementNameTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"maxTlrncMeasurementName", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"maxTlrncMeasurementName");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("maxTlrncMeasurementName");
                                    }
                                

                                          if (localMaxTlrncMeasurementName==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("maxTlrncMeasurementName cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localMaxTlrncMeasurementName);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localMaxTlrncMeasurementRangeTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"maxTlrncMeasurementRange", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"maxTlrncMeasurementRange");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("maxTlrncMeasurementRange");
                                    }
                                
                                               if (java.lang.Double.isNaN(localMaxTlrncMeasurementRange)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("maxTlrncMeasurementRange cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMaxTlrncMeasurementRange));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localMaxTlrncMeasurementTypeIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"maxTlrncMeasurementTypeId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"maxTlrncMeasurementTypeId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("maxTlrncMeasurementTypeId");
                                    }
                                
                                               if (localMaxTlrncMeasurementTypeId==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("maxTlrncMeasurementTypeId cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMaxTlrncMeasurementTypeId));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localMaxToleranceRangeTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"maxToleranceRange", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"maxToleranceRange");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("maxToleranceRange");
                                    }
                                
                                               if (localMaxToleranceRange==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("maxToleranceRange cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMaxToleranceRange));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             }
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"mtMeasurementEmpty", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"mtMeasurementEmpty");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("mtMeasurementEmpty");
                                    }
                                
                                               if (false) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("mtMeasurementEmpty cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMtMeasurementEmpty));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                              if (localMtUomTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"mtUom", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"mtUom");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("mtUom");
                                    }
                                

                                          if (localMtUom==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("mtUom cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localMtUom);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSchFactorFitmentTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"schFactorFitment", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"schFactorFitment");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("schFactorFitment");
                                    }
                                

                                          if (localSchFactorFitment==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("schFactorFitment cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localSchFactorFitment);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSchFactorStdJobCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"schFactorStdJobCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"schFactorStdJobCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("schFactorStdJobCd");
                                    }
                                

                                          if (localSchFactorStdJobCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("schFactorStdJobCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localSchFactorStdJobCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSchFactorStdJobIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"schFactorStdJobId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"schFactorStdJobId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("schFactorStdJobId");
                                    }
                                

                                          if (localSchFactorStdJobId==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("schFactorStdJobId cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localSchFactorStdJobId);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSecondMeasurementIntervalTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"secondMeasurementInterval", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"secondMeasurementInterval");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("secondMeasurementInterval");
                                    }
                                
                                               if (java.lang.Double.isNaN(localSecondMeasurementInterval)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("secondMeasurementInterval cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSecondMeasurementInterval));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSecondMeasurementMaxAdvTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"secondMeasurementMaxAdv", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"secondMeasurementMaxAdv");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("secondMeasurementMaxAdv");
                                    }
                                
                                               if (java.lang.Double.isNaN(localSecondMeasurementMaxAdv)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("secondMeasurementMaxAdv cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSecondMeasurementMaxAdv));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSecondMeasurementMaxPostTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"secondMeasurementMaxPost", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"secondMeasurementMaxPost");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("secondMeasurementMaxPost");
                                    }
                                
                                               if (java.lang.Double.isNaN(localSecondMeasurementMaxPost)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("secondMeasurementMaxPost cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSecondMeasurementMaxPost));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSecondMeasurementTypeIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"secondMeasurementTypeId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"secondMeasurementTypeId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("secondMeasurementTypeId");
                                    }
                                
                                               if (localSecondMeasurementTypeId==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("secondMeasurementTypeId cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSecondMeasurementTypeId));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSecondMeasurementTypeNameTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"secondMeasurementTypeName", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"secondMeasurementTypeName");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("secondMeasurementTypeName");
                                    }
                                

                                          if (localSecondMeasurementTypeName==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("secondMeasurementTypeName cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localSecondMeasurementTypeName);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSecondMeasurementUomTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"secondMeasurementUom", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"secondMeasurementUom");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("secondMeasurementUom");
                                    }
                                

                                          if (localSecondMeasurementUom==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("secondMeasurementUom cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localSecondMeasurementUom);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localStatutoryIndTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"statutoryInd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"statutoryInd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("statutoryInd");
                                    }
                                

                                          if (localStatutoryInd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("statutoryInd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localStatutoryInd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localStdJobBillOfLaboursTracker){
                                       if (localStdJobBillOfLabours!=null){
                                            for (int i = 0;i < localStdJobBillOfLabours.length;i++){
                                                if (localStdJobBillOfLabours[i] != null){
                                                 localStdJobBillOfLabours[i].serialize(new javax.xml.namespace.QName("","stdJobBillOfLabours"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"stdJobBillOfLabours", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"stdJobBillOfLabours");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("stdJobBillOfLabours");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"stdJobBillOfLabours", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"stdJobBillOfLabours");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("stdJobBillOfLabours");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localStdJobBillOfMaterialsTracker){
                                       if (localStdJobBillOfMaterials!=null){
                                            for (int i = 0;i < localStdJobBillOfMaterials.length;i++){
                                                if (localStdJobBillOfMaterials[i] != null){
                                                 localStdJobBillOfMaterials[i].serialize(new javax.xml.namespace.QName("","stdJobBillOfMaterials"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"stdJobBillOfMaterials", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"stdJobBillOfMaterials");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("stdJobBillOfMaterials");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"stdJobBillOfMaterials", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"stdJobBillOfMaterials");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("stdJobBillOfMaterials");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localStdJobBillOfOthersesTracker){
                                       if (localStdJobBillOfOtherses!=null){
                                            for (int i = 0;i < localStdJobBillOfOtherses.length;i++){
                                                if (localStdJobBillOfOtherses[i] != null){
                                                 localStdJobBillOfOtherses[i].serialize(new javax.xml.namespace.QName("","stdJobBillOfOtherses"),
                                                           factory,xmlWriter);
                                                } else {
                                                   
                                                            // write null attribute
                                                            java.lang.String namespace2 = "";
                                                            if (! namespace2.equals("")) {
                                                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                                if (prefix2 == null) {
                                                                    prefix2 = generatePrefix(namespace2);

                                                                    xmlWriter.writeStartElement(prefix2,"stdJobBillOfOtherses", namespace2);
                                                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                                                    xmlWriter.setPrefix(prefix2, namespace2);

                                                                } else {
                                                                    xmlWriter.writeStartElement(namespace2,"stdJobBillOfOtherses");
                                                                }

                                                            } else {
                                                                xmlWriter.writeStartElement("stdJobBillOfOtherses");
                                                            }

                                                           // write the nil attribute
                                                           writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                                           xmlWriter.writeEndElement();
                                                    
                                                }

                                            }
                                     } else {
                                        
                                                // write null attribute
                                                java.lang.String namespace2 = "";
                                                if (! namespace2.equals("")) {
                                                    java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                                    if (prefix2 == null) {
                                                        prefix2 = generatePrefix(namespace2);

                                                        xmlWriter.writeStartElement(prefix2,"stdJobBillOfOtherses", namespace2);
                                                        xmlWriter.writeNamespace(prefix2, namespace2);
                                                        xmlWriter.setPrefix(prefix2, namespace2);

                                                    } else {
                                                        xmlWriter.writeStartElement(namespace2,"stdJobBillOfOtherses");
                                                    }

                                                } else {
                                                    xmlWriter.writeStartElement("stdJobBillOfOtherses");
                                                }

                                               // write the nil attribute
                                               writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","nil","1",xmlWriter);
                                               xmlWriter.writeEndElement();
                                        
                                    }
                                 } if (localStdJobParamSubsetIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"stdJobParamSubsetId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"stdJobParamSubsetId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("stdJobParamSubsetId");
                                    }
                                
                                               if (localStdJobParamSubsetId==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("stdJobParamSubsetId cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localStdJobParamSubsetId));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localTimeIntervalTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"timeInterval", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"timeInterval");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("timeInterval");
                                    }
                                
                                               if (localTimeInterval==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("timeInterval cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTimeInterval));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localTimeMaxAdvTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"timeMaxAdv", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"timeMaxAdv");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("timeMaxAdv");
                                    }
                                
                                               if (localTimeMaxAdv==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("timeMaxAdv cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTimeMaxAdv));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localTimeMaxPostTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"timeMaxPost", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"timeMaxPost");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("timeMaxPost");
                                    }
                                
                                               if (localTimeMaxPost==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("timeMaxPost cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTimeMaxPost));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localWkGrpTracker){
                                            if (localWkGrp==null){
                                                 throw new org.apache.axis2.databinding.ADBException("wkGrp cannot be null!!");
                                            }
                                           localWkGrp.serialize(new javax.xml.namespace.QName("","wkGrp"),
                                               factory,xmlWriter);
                                        } if (localWkGrpCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"wkGrpCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"wkGrpCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("wkGrpCd");
                                    }
                                

                                          if (localWkGrpCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("wkGrpCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localWkGrpCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             }
                    xmlWriter.writeEndElement();
               

        }

         /**
          * Util method to write an attribute with the ns prefix
          */
          private void writeAttribute(java.lang.String prefix,java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
              if (xmlWriter.getPrefix(namespace) == null) {
                       xmlWriter.writeNamespace(prefix, namespace);
                       xmlWriter.setPrefix(prefix, namespace);

              }

              xmlWriter.writeAttribute(namespace,attName,attValue);

         }

        /**
          * Util method to write an attribute without the ns prefix
          */
          private void writeAttribute(java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
                if (namespace.equals(""))
              {
                  xmlWriter.writeAttribute(attName,attValue);
              }
              else
              {
                  registerPrefix(xmlWriter, namespace);
                  xmlWriter.writeAttribute(namespace,attName,attValue);
              }
          }


           /**
             * Util method to write an attribute without the ns prefix
             */
            private void writeQNameAttribute(java.lang.String namespace, java.lang.String attName,
                                             javax.xml.namespace.QName qname, javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

                java.lang.String attributeNamespace = qname.getNamespaceURI();
                java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
                if (attributePrefix == null) {
                    attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
                }
                java.lang.String attributeValue;
                if (attributePrefix.trim().length() > 0) {
                    attributeValue = attributePrefix + ":" + qname.getLocalPart();
                } else {
                    attributeValue = qname.getLocalPart();
                }

                if (namespace.equals("")) {
                    xmlWriter.writeAttribute(attName, attributeValue);
                } else {
                    registerPrefix(xmlWriter, namespace);
                    xmlWriter.writeAttribute(namespace, attName, attributeValue);
                }
            }
        /**
         *  method to handle Qnames
         */

        private void writeQName(javax.xml.namespace.QName qname,
                                javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null) {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null) {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix,namespaceURI);
                }

                if (prefix.trim().length() > 0){
                    xmlWriter.writeCharacters(prefix + ":" + org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                } else {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                }

            } else {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
            }
        }

        private void writeQNames(javax.xml.namespace.QName[] qnames,
                                 javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

            if (qnames != null) {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++) {
                    if (i > 0) {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null) {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0)) {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix,namespaceURI);
                        }

                        if (prefix.trim().length() > 0){
                            stringToWrite.append(prefix).append(":").append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        } else {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        }
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }


         /**
         * Register a namespace prefix
         */
         private java.lang.String registerPrefix(javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace) throws javax.xml.stream.XMLStreamException {
                java.lang.String prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null) {
                        prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                    }

                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }

                return prefix;
            }


  
        /**
        * databinding method to get an XML representation of this object
        *
        */
        public javax.xml.stream.XMLStreamReader getPullParser(javax.xml.namespace.QName qName)
                    throws org.apache.axis2.databinding.ADBException{


        
                 java.util.ArrayList elementList = new java.util.ArrayList();
                 java.util.ArrayList attribList = new java.util.ArrayList();

                
                    attribList.add(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema-instance","type"));
                    attribList.add(new javax.xml.namespace.QName("http://ws.mmis.mtr.com.hk/","stdJobParamSubset"));
                 if (localAdjustScheduleCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "adjustScheduleCd"));
                                 
                                        if (localAdjustScheduleCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localAdjustScheduleCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("adjustScheduleCd cannot be null!!");
                                        }
                                    } if (localBuIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "buId"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localBuId));
                            } if (localChangeRemarkTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "changeRemark"));
                                 
                                        if (localChangeRemark != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localChangeRemark));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("changeRemark cannot be null!!");
                                        }
                                    } if (localContractCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "contractCd"));
                                 
                                        if (localContractCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localContractCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("contractCd cannot be null!!");
                                        }
                                    } if (localContractIDTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "contractID"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localContractID));
                            } if (localContractNOTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "contractNO"));
                                 
                                        if (localContractNO != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localContractNO));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("contractNO cannot be null!!");
                                        }
                                    } if (localDayPreferenceTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "dayPreference"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localDayPreference));
                            } if (localEffEndDateTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "effEndDate"));
                                 
                                        if (localEffEndDate != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localEffEndDate));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("effEndDate cannot be null!!");
                                        }
                                    } if (localEffStartDateTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "effStartDate"));
                                 
                                        if (localEffStartDate != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localEffStartDate));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("effStartDate cannot be null!!");
                                        }
                                    } if (localEstimateJobDurTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "estimateJobDur"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localEstimateJobDur));
                            }
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "factorFitment"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localFactorFitment));
                             if (localFirstMeasurementIntervalTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "firstMeasurementInterval"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localFirstMeasurementInterval));
                            } if (localFirstMeasurementMaxAdvTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "firstMeasurementMaxAdv"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localFirstMeasurementMaxAdv));
                            } if (localFirstMeasurementMaxPostTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "firstMeasurementMaxPost"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localFirstMeasurementMaxPost));
                            } if (localFirstMeasurementTypeIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "firstMeasurementTypeId"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localFirstMeasurementTypeId));
                            } if (localFirstMeasurementTypeNameTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "firstMeasurementTypeName"));
                                 
                                        if (localFirstMeasurementTypeName != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localFirstMeasurementTypeName));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("firstMeasurementTypeName cannot be null!!");
                                        }
                                    } if (localFirstMeasurementUomTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "firstMeasurementUom"));
                                 
                                        if (localFirstMeasurementUom != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localFirstMeasurementUom));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("firstMeasurementUom cannot be null!!");
                                        }
                                    } if (localGcFinanceRefNoCDTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcFinanceRefNoCD"));
                                 
                                        if (localGcFinanceRefNoCD != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcFinanceRefNoCD));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcFinanceRefNoCD cannot be null!!");
                                        }
                                    } if (localGcPriorityCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcPriorityCd"));
                                 
                                        if (localGcPriorityCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcPriorityCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcPriorityCd cannot be null!!");
                                        }
                                    } if (localGcProjectNoCDTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcProjectNoCD"));
                                 
                                        if (localGcProjectNoCD != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcProjectNoCD));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcProjectNoCD cannot be null!!");
                                        }
                                    } if (localGcProjectTakkNoCDTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcProjectTakkNoCD"));
                                 
                                        if (localGcProjectTakkNoCD != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcProjectTakkNoCD));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcProjectTakkNoCD cannot be null!!");
                                        }
                                    } if (localGcSsdCalculationMethodCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcSsdCalculationMethodCd"));
                                 
                                        if (localGcSsdCalculationMethodCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcSsdCalculationMethodCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcSsdCalculationMethodCd cannot be null!!");
                                        }
                                    } if (localGcTabuMethodCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcTabuMethodCd"));
                                 
                                        if (localGcTabuMethodCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcTabuMethodCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcTabuMethodCd cannot be null!!");
                                        }
                                    } if (localGcWorkTimeReqCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcWorkTimeReqCd"));
                                 
                                        if (localGcWorkTimeReqCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcWorkTimeReqCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcWorkTimeReqCd cannot be null!!");
                                        }
                                    } if (localLastUpdDatetimeTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "lastUpdDatetime"));
                                 
                                        if (localLastUpdDatetime != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLastUpdDatetime));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("lastUpdDatetime cannot be null!!");
                                        }
                                    } if (localLastUpdUserIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "lastUpdUserId"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLastUpdUserId));
                            } if (localMaxOverdueTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "maxOverdue"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMaxOverdue));
                            } if (localMaxTlrncMeasurementNameTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "maxTlrncMeasurementName"));
                                 
                                        if (localMaxTlrncMeasurementName != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMaxTlrncMeasurementName));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("maxTlrncMeasurementName cannot be null!!");
                                        }
                                    } if (localMaxTlrncMeasurementRangeTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "maxTlrncMeasurementRange"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMaxTlrncMeasurementRange));
                            } if (localMaxTlrncMeasurementTypeIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "maxTlrncMeasurementTypeId"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMaxTlrncMeasurementTypeId));
                            } if (localMaxToleranceRangeTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "maxToleranceRange"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMaxToleranceRange));
                            }
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "mtMeasurementEmpty"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMtMeasurementEmpty));
                             if (localMtUomTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "mtUom"));
                                 
                                        if (localMtUom != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localMtUom));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("mtUom cannot be null!!");
                                        }
                                    } if (localSchFactorFitmentTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "schFactorFitment"));
                                 
                                        if (localSchFactorFitment != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSchFactorFitment));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("schFactorFitment cannot be null!!");
                                        }
                                    } if (localSchFactorStdJobCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "schFactorStdJobCd"));
                                 
                                        if (localSchFactorStdJobCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSchFactorStdJobCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("schFactorStdJobCd cannot be null!!");
                                        }
                                    } if (localSchFactorStdJobIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "schFactorStdJobId"));
                                 
                                        if (localSchFactorStdJobId != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSchFactorStdJobId));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("schFactorStdJobId cannot be null!!");
                                        }
                                    } if (localSecondMeasurementIntervalTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "secondMeasurementInterval"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSecondMeasurementInterval));
                            } if (localSecondMeasurementMaxAdvTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "secondMeasurementMaxAdv"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSecondMeasurementMaxAdv));
                            } if (localSecondMeasurementMaxPostTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "secondMeasurementMaxPost"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSecondMeasurementMaxPost));
                            } if (localSecondMeasurementTypeIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "secondMeasurementTypeId"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSecondMeasurementTypeId));
                            } if (localSecondMeasurementTypeNameTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "secondMeasurementTypeName"));
                                 
                                        if (localSecondMeasurementTypeName != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSecondMeasurementTypeName));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("secondMeasurementTypeName cannot be null!!");
                                        }
                                    } if (localSecondMeasurementUomTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "secondMeasurementUom"));
                                 
                                        if (localSecondMeasurementUom != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSecondMeasurementUom));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("secondMeasurementUom cannot be null!!");
                                        }
                                    } if (localStatutoryIndTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "statutoryInd"));
                                 
                                        if (localStatutoryInd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localStatutoryInd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("statutoryInd cannot be null!!");
                                        }
                                    } if (localStdJobBillOfLaboursTracker){
                             if (localStdJobBillOfLabours!=null) {
                                 for (int i = 0;i < localStdJobBillOfLabours.length;i++){

                                    if (localStdJobBillOfLabours[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "stdJobBillOfLabours"));
                                         elementList.add(localStdJobBillOfLabours[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "stdJobBillOfLabours"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "stdJobBillOfLabours"));
                                        elementList.add(localStdJobBillOfLabours);
                                    
                             }

                        } if (localStdJobBillOfMaterialsTracker){
                             if (localStdJobBillOfMaterials!=null) {
                                 for (int i = 0;i < localStdJobBillOfMaterials.length;i++){

                                    if (localStdJobBillOfMaterials[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "stdJobBillOfMaterials"));
                                         elementList.add(localStdJobBillOfMaterials[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "stdJobBillOfMaterials"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "stdJobBillOfMaterials"));
                                        elementList.add(localStdJobBillOfMaterials);
                                    
                             }

                        } if (localStdJobBillOfOthersesTracker){
                             if (localStdJobBillOfOtherses!=null) {
                                 for (int i = 0;i < localStdJobBillOfOtherses.length;i++){

                                    if (localStdJobBillOfOtherses[i] != null){
                                         elementList.add(new javax.xml.namespace.QName("",
                                                                          "stdJobBillOfOtherses"));
                                         elementList.add(localStdJobBillOfOtherses[i]);
                                    } else {
                                        
                                                elementList.add(new javax.xml.namespace.QName("",
                                                                          "stdJobBillOfOtherses"));
                                                elementList.add(null);
                                            
                                    }

                                 }
                             } else {
                                 
                                        elementList.add(new javax.xml.namespace.QName("",
                                                                          "stdJobBillOfOtherses"));
                                        elementList.add(localStdJobBillOfOtherses);
                                    
                             }

                        } if (localStdJobParamSubsetIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "stdJobParamSubsetId"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localStdJobParamSubsetId));
                            } if (localTimeIntervalTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "timeInterval"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTimeInterval));
                            } if (localTimeMaxAdvTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "timeMaxAdv"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTimeMaxAdv));
                            } if (localTimeMaxPostTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "timeMaxPost"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTimeMaxPost));
                            } if (localWkGrpTracker){
                            elementList.add(new javax.xml.namespace.QName("",
                                                                      "wkGrp"));
                            
                            
                                    if (localWkGrp==null){
                                         throw new org.apache.axis2.databinding.ADBException("wkGrp cannot be null!!");
                                    }
                                    elementList.add(localWkGrp);
                                } if (localWkGrpCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "wkGrpCd"));
                                 
                                        if (localWkGrpCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localWkGrpCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("wkGrpCd cannot be null!!");
                                        }
                                    }

                return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName, elementList.toArray(), attribList.toArray());
            
            

        }

  

     /**
      *  Factory class that keeps the parse method
      */
    public static class Factory{

        
        

        /**
        * static method to create the object
        * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
        *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
        * Postcondition: If this object is an element, the reader is positioned at its end element
        *                If this object is a complex type, the reader is positioned at the end element of its outer element
        */
        public static StdJobParamSubset parse(javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{
            StdJobParamSubset object =
                new StdJobParamSubset();

            int event;
            java.lang.String nillableValue = null;
            java.lang.String prefix ="";
            java.lang.String namespaceuri ="";
            try {
                
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                
                if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","type")!=null){
                  java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                        "type");
                  if (fullTypeName!=null){
                    java.lang.String nsPrefix = null;
                    if (fullTypeName.indexOf(":") > -1){
                        nsPrefix = fullTypeName.substring(0,fullTypeName.indexOf(":"));
                    }
                    nsPrefix = nsPrefix==null?"":nsPrefix;

                    java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":")+1);
                    
                            if (!"stdJobParamSubset".equals(type)){
                                //find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext().getNamespaceURI(nsPrefix);
                                return (StdJobParamSubset)hk.com.mtr.mmis.ws.ExtensionMapper.getTypeObject(
                                     nsUri,type,reader);
                              }
                        

                  }
                

                }

                

                
                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();
                

                 
                    
                    reader.next();
                
                        java.util.ArrayList list44 = new java.util.ArrayList();
                    
                        java.util.ArrayList list45 = new java.util.ArrayList();
                    
                        java.util.ArrayList list46 = new java.util.ArrayList();
                    
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","adjustScheduleCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setAdjustScheduleCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","buId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setBuId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setBuId(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","changeRemark").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setChangeRemark(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","contractCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setContractCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","contractID").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setContractID(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setContractID(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","contractNO").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setContractNO(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","dayPreference").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setDayPreference(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setDayPreference(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","effEndDate").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setEffEndDate(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDateTime(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","effStartDate").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setEffStartDate(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDateTime(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","estimateJobDur").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setEstimateJobDur(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setEstimateJobDur(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","factorFitment").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setFactorFitment(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToBoolean(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                else{
                                    // A start element we are not expecting indicates an invalid parameter was passed
                                    throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader.getLocalName());
                                }
                            
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","firstMeasurementInterval").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setFirstMeasurementInterval(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setFirstMeasurementInterval(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","firstMeasurementMaxAdv").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setFirstMeasurementMaxAdv(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setFirstMeasurementMaxAdv(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","firstMeasurementMaxPost").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setFirstMeasurementMaxPost(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setFirstMeasurementMaxPost(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","firstMeasurementTypeId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setFirstMeasurementTypeId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setFirstMeasurementTypeId(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","firstMeasurementTypeName").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setFirstMeasurementTypeName(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","firstMeasurementUom").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setFirstMeasurementUom(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcFinanceRefNoCD").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcFinanceRefNoCD(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcPriorityCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcPriorityCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcProjectNoCD").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcProjectNoCD(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcProjectTakkNoCD").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcProjectTakkNoCD(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcSsdCalculationMethodCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcSsdCalculationMethodCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcTabuMethodCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcTabuMethodCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcWorkTimeReqCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcWorkTimeReqCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","lastUpdDatetime").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setLastUpdDatetime(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDateTime(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","lastUpdUserId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setLastUpdUserId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setLastUpdUserId(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","maxOverdue").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setMaxOverdue(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setMaxOverdue(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","maxTlrncMeasurementName").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setMaxTlrncMeasurementName(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","maxTlrncMeasurementRange").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setMaxTlrncMeasurementRange(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setMaxTlrncMeasurementRange(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","maxTlrncMeasurementTypeId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setMaxTlrncMeasurementTypeId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setMaxTlrncMeasurementTypeId(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","maxToleranceRange").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setMaxToleranceRange(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setMaxToleranceRange(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","mtMeasurementEmpty").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setMtMeasurementEmpty(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToBoolean(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                else{
                                    // A start element we are not expecting indicates an invalid parameter was passed
                                    throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader.getLocalName());
                                }
                            
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","mtUom").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setMtUom(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","schFactorFitment").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setSchFactorFitment(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","schFactorStdJobCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setSchFactorStdJobCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","schFactorStdJobId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setSchFactorStdJobId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","secondMeasurementInterval").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setSecondMeasurementInterval(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setSecondMeasurementInterval(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","secondMeasurementMaxAdv").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setSecondMeasurementMaxAdv(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setSecondMeasurementMaxAdv(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","secondMeasurementMaxPost").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setSecondMeasurementMaxPost(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setSecondMeasurementMaxPost(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","secondMeasurementTypeId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setSecondMeasurementTypeId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setSecondMeasurementTypeId(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","secondMeasurementTypeName").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setSecondMeasurementTypeName(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","secondMeasurementUom").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setSecondMeasurementUom(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","statutoryInd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setStatutoryInd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","stdJobBillOfLabours").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list44.add(null);
                                                              reader.next();
                                                          } else {
                                                        list44.add(hk.com.mtr.mmis.ws.StdJobBillOfLabour.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone44 = false;
                                                        while(!loopDone44){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone44 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","stdJobBillOfLabours").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list44.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list44.add(hk.com.mtr.mmis.ws.StdJobBillOfLabour.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone44 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setStdJobBillOfLabours((hk.com.mtr.mmis.ws.StdJobBillOfLabour[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.StdJobBillOfLabour.class,
                                                                list44));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","stdJobBillOfMaterials").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list45.add(null);
                                                              reader.next();
                                                          } else {
                                                        list45.add(hk.com.mtr.mmis.ws.StdJobBillOfMaterial.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone45 = false;
                                                        while(!loopDone45){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone45 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","stdJobBillOfMaterials").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list45.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list45.add(hk.com.mtr.mmis.ws.StdJobBillOfMaterial.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone45 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setStdJobBillOfMaterials((hk.com.mtr.mmis.ws.StdJobBillOfMaterial[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.StdJobBillOfMaterial.class,
                                                                list45));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","stdJobBillOfOtherses").equals(reader.getName())){
                                
                                    
                                    
                                    // Process the array and step past its final element's end.
                                    
                                                          nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                          if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                              list46.add(null);
                                                              reader.next();
                                                          } else {
                                                        list46.add(hk.com.mtr.mmis.ws.StdJobBillOfOthers.Factory.parse(reader));
                                                                }
                                                        //loop until we find a start element that is not part of this array
                                                        boolean loopDone46 = false;
                                                        while(!loopDone46){
                                                            // We should be at the end element, but make sure
                                                            while (!reader.isEndElement())
                                                                reader.next();
                                                            // Step out of this element
                                                            reader.next();
                                                            // Step to next element event.
                                                            while (!reader.isStartElement() && !reader.isEndElement())
                                                                reader.next();
                                                            if (reader.isEndElement()){
                                                                //two continuous end elements means we are exiting the xml structure
                                                                loopDone46 = true;
                                                            } else {
                                                                if (new javax.xml.namespace.QName("","stdJobBillOfOtherses").equals(reader.getName())){
                                                                    
                                                                      nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","nil");
                                                                      if ("true".equals(nillableValue) || "1".equals(nillableValue)){
                                                                          list46.add(null);
                                                                          reader.next();
                                                                      } else {
                                                                    list46.add(hk.com.mtr.mmis.ws.StdJobBillOfOthers.Factory.parse(reader));
                                                                        }
                                                                }else{
                                                                    loopDone46 = true;
                                                                }
                                                            }
                                                        }
                                                        // call the converter utility  to convert and set the array
                                                        
                                                        object.setStdJobBillOfOtherses((hk.com.mtr.mmis.ws.StdJobBillOfOthers[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                                                                hk.com.mtr.mmis.ws.StdJobBillOfOthers.class,
                                                                list46));
                                                            
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","stdJobParamSubsetId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setStdJobParamSubsetId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setStdJobParamSubsetId(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","timeInterval").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setTimeInterval(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setTimeInterval(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","timeMaxAdv").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setTimeMaxAdv(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setTimeMaxAdv(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","timeMaxPost").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setTimeMaxPost(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setTimeMaxPost(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","wkGrp").equals(reader.getName())){
                                
                                                object.setWkGrp(hk.com.mtr.mmis.ws.WorkGrp.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","wkGrpCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setWkGrpCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                  
                            while (!reader.isStartElement() && !reader.isEndElement())
                                reader.next();
                            
                                if (reader.isStartElement())
                                // A start element we are not expecting indicates a trailing invalid property
                                throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader.getLocalName());
                            



            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }

        }//end of factory class

        

        }
           
          