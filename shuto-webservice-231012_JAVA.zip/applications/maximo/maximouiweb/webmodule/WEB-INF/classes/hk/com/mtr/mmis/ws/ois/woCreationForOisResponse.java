package hk.com.mtr.mmis.ws.ois;

import java.util.List;

public class woCreationForOisResponse {
    String woNo;
    List<hk.com.mtr.mmis.ws.ois.resultList> resultList;
    String returnStatus;

    public String getWoNo() {
        return woNo;
    }

    public void setWoNo(String woNo) {
        this.woNo = woNo;
    }

    public List<hk.com.mtr.mmis.ws.ois.resultList> getResultList() {
        return resultList;
    }

    public void setResultList(List<hk.com.mtr.mmis.ws.ois.resultList> resultList) {
        this.resultList = resultList;
    }

    public String getReturnStatus() {
        return returnStatus;
    }

    public void setReturnStatus(String returnStatus) {
        this.returnStatus = returnStatus;
    }
}
