package hk.com.mtr.mmis.ws.incident;

/**
 * 
 * @author 
 */
public class CreepODMSIncidentException extends Exception
{

    public CreepODMSIncidentException()
    {
        super("CreepODMSIncidentException");
    }

    public CreepODMSIncidentException(String s)
    {
        super(s);
    }

    public CreepODMSIncidentException(String s, Throwable ex)
    {
        super(s, ex);
    }

    public void setFaultMessage(IncidentFaultInfo msg)
    {
        faultMessage = msg;
    }

    public IncidentFaultInfo getFaultMessage()
    {
        return faultMessage;
    }

    private IncidentFaultInfo faultMessage;
}
