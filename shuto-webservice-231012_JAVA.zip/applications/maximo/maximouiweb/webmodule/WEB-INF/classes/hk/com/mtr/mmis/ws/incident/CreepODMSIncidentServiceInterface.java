package hk.com.mtr.mmis.ws.incident;

import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Document;

import psdi.util.MXException;

/**
 * 
 * @author shutu
 */
public interface CreepODMSIncidentServiceInterface {

    
    public abstract  List<ResultObjectArray> createIncident(WmODMSIncidentUploadVOArray wmODMSIncidentUploadVOList)throws MXException;
    
}
