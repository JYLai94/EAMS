
/**
 * ExtensionMapper.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: SNAPSHOT  Built on : Jan 10, 2009 (05:26:17 CST)
 */

            package hk.com.mtr.mmis.ws;
            /**
            *  ExtensionMapper class
            */
        
        public  class ExtensionMapper{

          public static java.lang.Object getTypeObject(java.lang.String namespaceURI,
                                                       java.lang.String typeName,
                                                       javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woFollowupAction".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoFollowupAction.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "refLocationVO".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.RefLocationVO.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "incident".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.Incident.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "stdJobParamSubset".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.StdJobParamSubset.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "stdJobParamSet".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.StdJobParamSet.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "workRequest".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WorkRequest.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "incidentVO".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.IncidentVO.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "planBillOfMaterial".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.PlanBillOfMaterial.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "workGrp".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WorkGrp.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woActBolVO".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoActBolVO.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "planBillOfOthers".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.PlanBillOfOthers.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woActBooVO".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoActBooVO.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woJobRequirement".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoJobRequirement.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "retrieveWorkOrder".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.RetrieveWorkOrder.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woStatusHistoryVO".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoStatusHistoryVO.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woRecoveryVO".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoRecoveryVO.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woFailureDetail".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoFailureDetail.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "actualBillOfOther".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.ActualBillOfOther.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woPlanBolVO".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoPlanBolVO.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "standardJob".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.StandardJob.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woFollowupActionVO".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoFollowupActionVO.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "planBillOfLabour".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.PlanBillOfLabour.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woFailureInfoVO".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoFailureInfoVO.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "retrieveWorkOrderResponse".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.RetrieveWorkOrderResponse.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woJobRequirementVO".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoJobRequirementVO.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "humanResource".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.HumanResource.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "equipClass".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.EquipClass.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woFailureInfo".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoFailureInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "equipment".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.Equipment.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woTask".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoTask.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woRelationship".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoRelationship.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "organizationUnit".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.OrganizationUnit.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "stdJobBillOfLabour".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.StdJobBillOfLabour.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "locationRangeVO".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.LocationRangeVO.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "retrieveWorkOrderListResponse".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.RetrieveWorkOrderListResponse.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "actualBillOfLabour".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.ActualBillOfLabour.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "MMISWebServiceException".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.MMISWebServiceException.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woSuspensionVO".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoSuspensionVO.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woFailureDetailVO".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoFailureDetailVO.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "workOrderVO".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WorkOrderVO.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "stdJobBillOfOthers".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.StdJobBillOfOthers.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woStatusHistory".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoStatusHistory.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woActBomVO".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoActBomVO.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "retrieveWorkOrderList".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.RetrieveWorkOrderList.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "baseVO".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.BaseVO.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "stdJobBillOfMaterial".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.StdJobBillOfMaterial.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "actualBillOfMaterial".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.ActualBillOfMaterial.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woPlanBomVO".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoPlanBomVO.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woPlanBooVO".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoPlanBooVO.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woRecovery".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoRecovery.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woSuspension".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoSuspension.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "stockRate".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.StockRate.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "stock".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.Stock.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "woTaskVO".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.WoTaskVO.Factory.parse(reader);
                        

                  }

              
             throw new org.apache.axis2.databinding.ADBException("Unsupported type " + namespaceURI + " " + typeName);
          }

        }
    