package hk.com.mtr.mmis.ws.ois;

import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.server.MXServer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class WorkOrderCreatedImpl implements WorkOrderCreate {
    @Override
    public woCreationForOisResponse oisWoCreationVO(oisWoCreationInputVO oisWoCreationInputVO, String userAccount) {
        System.out.println("----getEquipNo--" + oisWoCreationInputVO.getEquipNo());
        System.out.println("----OISINT057-userAccount--" + userAccount);
        //add trim as OIS will pass space into this variable - start
        userAccount=userAccount.trim();
        //add trim as OIS will pass space into this variable - end
        String wonum = "";
        String messageCode = "";
        String message = "";
        String MTR_CONTRACT="";
        String ReturnStatus="";
        try {
            //MboSetRemote person = MXServer.getMXServer().getMboSet("PERSON", MXServer.getMXServer().getSystemUserInfo());
//            person.setWhere("PERSONID='" + userAccount + "'");
//            person.reset();
            MboSetRemote maxuser = MXServer.getMXServer().getMboSet("MAXUSER", MXServer.getMXServer().getSystemUserInfo());
            String userAccount1=userAccount+"@MTR.COM.HK";
            maxuser.setWhere("USERID='" + userAccount1 + "'");
            System.out.println("---OISINT057-userAccount1---"+userAccount1);
            maxuser.reset();
            if(maxuser.isEmpty()){
                messageCode="1";
                message="Invalid User Account";
            }else{
                String status = maxuser.getMbo(0).getString("STATUS");
                if (status.equals("INACTIVE")) {
                    messageCode = "2";
                    message = "Account status is invalid.";
                }else{
//                    Date hiredate = person.getMbo(0).getDate("HIREDATE");
//                    if (hiredate==null) {
//                        messageCode = "5";
//                        message = "hiredate is null";
//                    }else{
//                        if(hiredate.after(MXServer.getMXServer().getDate())){
//                            messageCode = "5";
//                            message = "Account is before effective date.";//聘用日期必须在当天日期之后才能显示错误信息
//                        }else{
//                            Date TERMINATIONDATE=person.getMbo(0).getDate("TERMINATIONDATE");
//                            if (TERMINATIONDATE==null) {
//                                messageCode = "6";
//                                message = "TERMINATIONDATE is  null.";
//                            }else{
//                                if (TERMINATIONDATE.before(MXServer.getMXServer().getDate())) {
//                                    messageCode = "6";
//                                    message = "Account is after effective date.";  //终止日期必须在当前时间之前才能显示错误信息
//                                }else{
                                    String equipType=oisWoCreationInputVO.getEquipType();
                                    if(equipType.isEmpty()){
                                        messageCode="7";
                                        message="Equipment type was missing.";
                                    }else{
                                        String stdJobCode=oisWoCreationInputVO.getStdJobCode();
                                        if(stdJobCode.isEmpty()) {
                                            messageCode = "8";
                                            message = "Standard job code was missing.";
                                        }else{
                                            String equipID=oisWoCreationInputVO.getEquipNo();
                                            if(equipID.isEmpty()){
                                                messageCode="9";
                                                message="Equipment ID was missing.";
                                            }else{
                                                String majorMinor=oisWoCreationInputVO.getMajorMinor();
                                                if(majorMinor.isEmpty()){
                                                    messageCode="10";
                                                    message="Major / Minor failure was missing.";
                                                }else{
                                                    String majorFailureSymptomCode=oisWoCreationInputVO.getMajorFailureSymptomCode();
                                                    if(majorFailureSymptomCode.isEmpty()){
                                                        messageCode="11";
                                                        message="Major failure symptom was missing.";
                                                    }else{
                                                        String priorityCodeId=oisWoCreationInputVO.getPriorityCodeCd();
                                                        if(priorityCodeId.isEmpty()){
                                                            messageCode="13";
                                                            message="Priority was missing.";
                                                        }else{
                                                            String planStartTime=oisWoCreationInputVO.getPlanStartTime();
                                                            if(planStartTime.isEmpty()){
                                                                messageCode="16";
                                                                message="Planned start date time was missing.";
                                                            }else{
                                                                String planCmplTime=oisWoCreationInputVO.getPlanCmplTime();
                                                                if(planCmplTime.isEmpty()){
                                                                    messageCode="17";
                                                                    message="Planned completion date time was missing.";
                                                                }else{
                                                                    String workNatureLv1=oisWoCreationInputVO.getWorkNatureLv1();
                                                                    if(workNatureLv1.isEmpty()){
                                                                        messageCode="18";
                                                                        message="Work nature level 1 was missing.";
                                                                    }else{
                                                                        String workNatureLv2=oisWoCreationInputVO.getWorkNatureLv2();
                                                                        if(workNatureLv2.isEmpty()) {
                                                                            messageCode = "19";
                                                                            message = "Work nature level 2 was missing.";
                                                                        }else{
                                                                            String lineCode=oisWoCreationInputVO.getLineCode();
                                                                            MboSetRemote LOCATIONS=MXServer.getMXServer().getMboSet("LOCATIONS",MXServer.getMXServer().getSystemUserInfo());
                                                                            LOCATIONS.setWhere("LOCATION='"+lineCode+"'");
                                                                            LOCATIONS.reset();
                                                                            if(LOCATIONS.isEmpty()){
                                                                                messageCode="20";
                                                                                message="Invalid Line.";
                                                                            }else{
                                                                                String location=oisWoCreationInputVO.getLocationCode();
                                                                                LOCATIONS.setWhere("LOCATION='"+location+"'");
                                                                                LOCATIONS.reset();
                                                                                if(LOCATIONS.getMbo(0)==null){
                                                                                    messageCode="21";
                                                                                    message="Invalid Location.";
                                                                                }else{
                                                                                    String MTR_ASSETCLASS=oisWoCreationInputVO.getEquipType();
                                                                                    MboSetRemote MTR_OA_RPT_EQGP=MXServer.getMXServer().getMboSet("MTR_OA_RPT_EQGP",MXServer.getMXServer().getSystemUserInfo());
                                                                                    MTR_OA_RPT_EQGP.setWhere("MTR_DESC='"+MTR_ASSETCLASS+"'");
                                                                                    MTR_OA_RPT_EQGP.reset();
                                                                                    if(MTR_OA_RPT_EQGP.isEmpty()){
                                                                                        messageCode="22";
                                                                                        message="Invalid Equipment Type.";
                                                                                    }else{
                                                                                        String inHouseInd=oisWoCreationInputVO.getInHouseInd();
                                                                                            if(("I").equals(inHouseInd) || ("O").equals(inHouseInd)) {
                                                                                                if (("O").equals(inHouseInd)) {
                                                                                                    String jupnum = oisWoCreationInputVO.getStdJobCode();
                                                                                                    MboSetRemote jobplan = MXServer.getMXServer().getMboSet("JOBPLAN", MXServer.getMXServer().getSystemUserInfo());
                                                                                                    jobplan.setWhere("JPNUM='" + jupnum + "'");
                                                                                                    jobplan.reset();
                                                                                                    if (!jobplan.isEmpty()) {
                                                                                                        MTR_CONTRACT = jobplan.getMbo(0).getString("MTR_CONTRACT");
                                                                                                    }
                                                                                                }
                                                                                                    String jpnum = oisWoCreationInputVO.getStdJobCode();
                                                                                                    MboSetRemote JOBPLAN = MXServer.getMXServer().getMboSet("JOBPLAN", MXServer.getMXServer().getSystemUserInfo());
                                                                                                    JOBPLAN.setWhere("JPNUM='" + jpnum + "'");
                                                                                                    JOBPLAN.reset();
                                                                                                    if (JOBPLAN.isEmpty()) {
                                                                                                        messageCode = "24";
                                                                                                        message = "Invalid Standard job code.";
                                                                                                    } else {
                                                                                                        String worktype = oisWoCreationInputVO.getWorkNatureLv1();
                                                                                                        MboSetRemote Type = MXServer.getMXServer().getMboSet("WORKTYPE", MXServer.getMXServer().getSystemUserInfo());
                                                                                                        Type.setWhere("WORKTYPE='" + worktype + "'");
                                                                                                        Type.reset();
                                                                                                        if (Type.isEmpty()) {
                                                                                                            messageCode = "25";
                                                                                                            message = "Invalid Wok nature.";
                                                                                                        } else {
                                                                                                            String assetnum = oisWoCreationInputVO.getEquipNo();
                                                                                                            MboSetRemote asset = MXServer.getMXServer().getMboSet("ASSET", MXServer.getMXServer().getSystemUserInfo());
                                                                                                            asset.setWhere("assetnum='" + assetnum + "'");
                                                                                                            asset.reset();
                                                                                                            if (asset.isEmpty()) {
                                                                                                                messageCode = "26";
                                                                                                                message = "Invalid Equipment ID.";
                                                                                                            } else {
                                                                                                                String assetStatus = asset.getMbo(0).getString("status");
                                                                                                                if (("DISPOSE").equals(assetStatus) || ("PADLOCK").equals(assetStatus) || ("DECOMMISSION").equals(assetStatus)) {
                                                                                                                    messageCode = "27";
                                                                                                                    message = "The equipment is inactive.";
                                                                                                                } else {
                                                                                                                    String major = oisWoCreationInputVO.getMajorFailureSymptomCode();
                                                                                                                    MboSetRemote mtr_oa = MXServer.getMXServer().getMboSet("MTR_OA", MXServer.getMXServer().getSystemUserInfo());
                                                                                                                    mtr_oa.setWhere("MTR_FAULT='" + major + "'");
                                                                                                                    mtr_oa.reset();
                                                                                                                    System.out.println("=======>"+major+"<======第一个major");
                                                                                                                    if (mtr_oa.isEmpty()) {
                                                                                                                        System.out.println("第一个29有问题");
                                                                                                                        messageCode = "29";
                                                                                                                        message = "Invalid Major failure symptom.";
                                                                                                                    } else {
                                                                                                                        String ASSETNUM = oisWoCreationInputVO.getEquipNo();
                                                                                                                        MboSetRemote ASSET = MXServer.getMXServer().getMboSet("ASSET", MXServer.getMXServer().getSystemUserInfo());
                                                                                                                        ASSET.setWhere("'"+ASSETNUM+"'"+" IN (SELECT ASSETNUM FROM ASSET WHERE ASSETNUM like '%L&E%' or assetnum like '%AFC%G%')");
                                                                                                                        //ASSET.setWhere("assetnum='" + ASSETNUM + "'" + " and (assetnum like '%L&E%' or assetnum like '%AFC%G%' )");
                                                                                                                        ASSET.reset();
                                                                                                                        System.out.println("=======>"+ASSETNUM+"<======第一个资产名称");
                                                                                                                        if (ASSET.isEmpty()) {
                                                                                                                            System.out.println("第二个29有问题");
                                                                                                                            messageCode = "29";
                                                                                                                            message = "Invalid Major failure symptom.";
                                                                                                                        } else {
                                                                                                                            MboSetRemote MTR_OA = MXServer.getMXServer().getMboSet("MTR_OA", MXServer.getMXServer().getSystemUserInfo());
                                                                                                                            MTR_OA.setWhere("'"+major+"'"+" in (select MTR_FAULT from mtr_oa where MTR_FAULT like 'G%' or MTR_FAULT like 'L%')");
                                                                                                                                //MTR_OA.setWhere("MTR_FAULT='" + major + "'" + " and (MTR_FAULT like 'L%' or MTR_FAULT like 'G%')");
                                                                                                                            MTR_OA.reset();
                                                                                                                            System.out.println("=======>"+major+"<======第二个major");
                                                                                                                            if (MTR_OA.isEmpty()) {
                                                                                                                                System.out.println("第三个29有问题");
                                                                                                                                messageCode = "29";
                                                                                                                                message = "Invalid Major failure symptom.";
                                                                                                                            } else {
                                                                                                                                MboSetRemote assetMboSet = MXServer.getMXServer().getMboSet("ASSET", MXServer.getMXServer().getSystemUserInfo());
                                                                                                                                assetMboSet.setWhere("assetnum='" + ASSETNUM + "'");
                                                                                                                                assetMboSet.reset();
                                                                                                                                int MTR_ISOA = assetMboSet.getMbo(0).getInt("MTR_ISOA");
                                                                                                                                System.out.println("=======>"+ASSETNUM+"<======第二个资产名称");
                                                                                                                                System.out.println("=======>"+MTR_ISOA+"<======MTR_ISOA");
                                                                                                                                if (MTR_ISOA!=1) {
                                                                                                                                    System.out.println("第四个29有问题");
                                                                                                                                    messageCode = "29";
                                                                                                                                    message = "Invalid Major failure symptom.";
                                                                                                                                } else {
                                                                                                                                    MboSetRemote Mtr_oaMbo = MXServer.getMXServer().getMboSet("MTR_OA", MXServer.getMXServer().getSystemUserInfo());
                                                                                                                                    Mtr_oaMbo.setWhere("MTR_FAULT='" + major + "'");
                                                                                                                                    Mtr_oaMbo.reset();
                                                                                                                                    String type = Mtr_oaMbo.getMbo(0).getString("MTR_FAULTTYPE");
                                                                                                                                    System.out.println("=======>"+type+"<======2");
                                                                                                                                    String majorcode = oisWoCreationInputVO.getMajorMinorfailureCode();
                                                                                                                                    System.out.println("========>>"+majorcode+"<<========");
                                                                                                                                    if ("MAJOR".equals(type)) {
                                                                                                                                        if (!"OOS".equals(majorcode)) {
                                                                                                                                            messageCode = "28";
                                                                                                                                            message = "Invalid Major / Minor failure.";
                                                                                                                                        }
                                                                                                                                    } else if ("MINOR".equals(type)) {
                                                                                                                                        if (!"".equals(majorcode) || majorcode!=null) {
                                                                                                                                            messageCode = "28";
                                                                                                                                            message = "Invalid Major / Minor failure.";
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                    //else {
                                                                                                                                        String symptom = oisWoCreationInputVO.getSymptomCodeCd();
                                                                                                                                        String CLASSSTRUCTUREID = assetMboSet.getMbo(0).getString("CLASSSTRUCTUREID");
                                                                                                                                        MboSetRemote mtr_symptom = MXServer.getMXServer().getMboSet("MTR_SYMPTOM", MXServer.getMXServer().getSystemUserInfo());
                                                                                                                                        mtr_symptom.setWhere("MTR_CLASSIFICATIONID = (select CLASSIFICATIONID from CLASSSTRUCTURE where CLASSSTRUCTUREID ='" + CLASSSTRUCTUREID + "')" + "  and MTR_SYMPTOM='" + symptom + "'");
                                                                                                                                        mtr_symptom.reset();
                                                                                                                                        if (mtr_symptom.isEmpty()) {
                                                                                                                                            messageCode = "30";
                                                                                                                                            message = "Invalid Symptom.";
                                                                                                                                        } else {
                                                                                                                                            String priority = oisWoCreationInputVO.getPriorityCodeCd();
                                                                                                                                            MboSetRemote numericdomain = MXServer.getMXServer().getMboSet("NUMERICDOMAIN", MXServer.getMXServer().getSystemUserInfo());
                                                                                                                                            numericdomain.setWhere("VALUE='" + priority + "'");
                                                                                                                                            numericdomain.reset();
                                                                                                                                            if (numericdomain.isEmpty()) {
                                                                                                                                                messageCode = "31";
                                                                                                                                                message = "Invalid priority.";
                                                                                                                                            } else {
                                                                                                                                                SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
                                                                                                                                                String planTime = oisWoCreationInputVO.getPlanStartTime();
                                                                                                                                                String y = planTime.substring(0, 4);
                                                                                                                                                String m = planTime.substring(4, 6);
                                                                                                                                                String d = planTime.substring(6, 8);
                                                                                                                                                String startTime = y + "-" + m + "-" + d;
                                                                                                                                                Date startTime1 = format1.parse(startTime);
                                                                                                                                                String cmplTime = oisWoCreationInputVO.getPlanCmplTime();
                                                                                                                                                String y1 = cmplTime.substring(0, 4);
                                                                                                                                                String m1 = cmplTime.substring(4, 6);
                                                                                                                                                String d1 = cmplTime.substring(6, 8);
                                                                                                                                                String endTime = y1 + "-" + m1 + "-" + d1;
                                                                                                                                                Date endTime1 = format1.parse(endTime);
                                                                                                                                                if (startTime1.after(endTime1)) {
                                                                                                                                                    messageCode = "32";
                                                                                                                                                    message = "Plan start datetime could not later than plan completion datetime.";
                                                                                                                                                } else {
                                                                                                                                                    String DESC = oisWoCreationInputVO.getWoDesp();
                                                                                                                                                    if (DESC.length() > 600) {
                                                                                                                                                        messageCode = "33";
                                                                                                                                                        message = "Length of work order description exceeded max length 600.";
                                                                                                                                                    } else {

                                                                                                                                                        //change to validate the User account person - start
                                                                                                                                                        MboSetRemote Accountperson = MXServer.getMXServer().getMboSet("MAXUSER", MXServer.getMXServer().getSystemUserInfo());
                                                                                                                                                        // userAccout
                                                                                                                                                        Accountperson.setWhere("USERID='" + userAccount1 + "' AND PERSONID IS NOT NULL");
                                                                                                                                                        Accountperson.reset();
                                                                                                                                                        if (Accountperson.isEmpty()) {
                                                                                                                                                            messageCode = "34";
                                                                                                                                                            message = "The User Account XXX must link with a staff.";
                                                                                                                                                            //change to validate the User account person - en
                                                                                                                                                        } else {
                                                                                                                                                            String symptom1 = oisWoCreationInputVO.getSymptomCodeCd();
                                                                                                                                                            String remark = oisWoCreationInputVO.getRemark();
                                                                                                                                                            if ("Others".equals(symptom1) && "".equals(remark)) {
                                                                                                                                                                messageCode = "35";
                                                                                                                                                                message = "When symptom value is Others and remark missing";
                                                                                                                                                            } else {
                                                                                                                                                                System.out.println("创建工单成功");
                                                                                                                                                                MboSetRemote mrs = MXServer.getMXServer().getMboSet("WORKORDER", MXServer.getMXServer().getSystemUserInfo());
                                                                                                                                                                MboRemote mbo = mrs.add();
                                                                                                                                                                wonum = mbo.getString("wonum");
                                                                                                                                                                String locationCode = oisWoCreationInputVO.getLocationCode();
                                                                                                                                                                String majorMinorfailureCode = oisWoCreationInputVO.getMajorMinorfailureCode();
                                                                                                                                                                //shutDownTime
                                                                                                                                                                String shutDownTime = oisWoCreationInputVO.getShutDownTime();
                                                                                                                                                                String y2 = shutDownTime.substring(0, 4);
                                                                                                                                                                String m2 = shutDownTime.substring(4, 6);
                                                                                                                                                                String d2 = shutDownTime.substring(6, 8);
                                                                                                                                                                String time = y2 + "-" + m2 + "-" + d2;
                                                                                                                                                                //reportTime
                                                                                                                                                                String reportTime = oisWoCreationInputVO.getReportTime();
                                                                                                                                                                String y3 = reportTime.substring(0, 4);
                                                                                                                                                                String m3 = reportTime.substring(4, 6);
                                                                                                                                                                String d3 = reportTime.substring(6, 8);
                                                                                                                                                                String time1 = y3 + "-" + m3 + "-" + d3;
                                                                                                                                                                //planStartTime
                                                                                                                                                                String y4 = planStartTime.substring(0, 4);
                                                                                                                                                                String m4 = planStartTime.substring(4, 6);
                                                                                                                                                                String d4 = planStartTime.substring(6, 8);
                                                                                                                                                                String time2 = y4 + "-" + m4 + "-" + d4;
                                                                                                                                                                //planCmplTime
                                                                                                                                                                String y5 = planCmplTime.substring(0, 4);
                                                                                                                                                                String m5 = planCmplTime.substring(4, 6);
                                                                                                                                                                String d5 = planCmplTime.substring(6, 8);
                                                                                                                                                                String time3 = y5 + "-" + m5 + "-" + d5;

                                                                                                                                                                //infoContractor
                                                                                                                                                                String infoContractor = oisWoCreationInputVO.getInfoContractor();
                                                                                                                                                                String y6 = infoContractor.substring(0, 4);
                                                                                                                                                                String m6 = infoContractor.substring(4, 6);
                                                                                                                                                                String d6 = infoContractor.substring(6, 8);
                                                                                                                                                                String time6 = y6 + "-" + m6 + "-" + d6;

                                                                                                                                                                DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                                                                                                                                                                Date shutDownTime1 = null;
                                                                                                                                                                Date reportTime1 = null;
                                                                                                                                                                Date planStartTime1 = null;
                                                                                                                                                                Date planCmplTime1 = null;
                                                                                                                                                                Date infoContractor1 = null;
                                                                                                                                                                shutDownTime1 = df.parse(time);
                                                                                                                                                                reportTime1 = df.parse(time1);
                                                                                                                                                                planStartTime1 = df.parse(time2);
                                                                                                                                                                planCmplTime1 = df.parse(time3);
                                                                                                                                                                infoContractor1 = df.parse(time6);
                                                                                                                                                                mbo.setValue("MTR_OARPTGRP", MTR_ASSETCLASS); //3 - Gate
                                                                                                                                                                mbo.setValue("MTR_ACTUAL_LINE_ID", lineCode);  // SIL
                                                                                                                                                                mbo.setValue("MTR_PLANLOCATION",locationCode); //ADM
                                                                                                                                                                mbo.setValue("MTR_ACTUAL_FROM_LOC_ID",locationCode); //ADM
                                                                                                                                                               // mbo.setValue("MTR_IS_CONTRACTOR", inHouseInd);
                                                                                                                                                                mbo.setValue("MTR_ACTUAL_FROM_LOC_ID", stdJobCode);//11T
                                                                                                                                                                mbo.setValue("WORKTYPE", workNatureLv1);//CM
                                                                                                                                                                mbo.setValue("MTR_JOBNATURE", workNatureLv2);//CF
                                                                                                                                                                mbo.setValue("ASSETNUM", equipID); //ADM-AFC-KRG-23
                                                                                                                                                                mbo.setValue("MTR_OASHUTDOWNCODE", majorMinorfailureCode); //OOS
//                                                                                                                                                                mbo.setValue("MTR_MAJORMINORFAILURE","GM06");
                                                                                                                                                                mbo.setValue("DESCRIPTION", DESC); //TEST
                                                                                                                                                                mbo.setValue("MTR_SYMPTOM", symptom); //CDISE
                                                                                                                                                                mbo.setValue("WOPRIORITY", priorityCodeId); //30
                                                                                                                                                                mbo.setValue("MTR_ASSETSHUTDOWN", shutDownTime1);//2021-12-13
                                                                                                                                                                mbo.setValue("REPORTDATE", reportTime1);//2021-12-13
                                                                                                                                                                mbo.setValue("SCHEDSTART", planStartTime1);//2024-05-29
                                                                                                                                                                mbo.setValue("SCHEDFINISH", planCmplTime1);//2024-05-29
                                                                                                                                                                mbo.setValue("MTR_INFORM_CONTRACTOR_DATE", infoContractor1);//2022-03-26
                                                                                                                                                                mbo.setValue("CONTRACT", MTR_CONTRACT); //
                                                                                                                                                                mbo.setValue("MTR_MAJORMINORFAILURE",majorFailureSymptomCode);
                                                                                                                                                               // mbo.setValue("MTR_MAJORMINORFAILURE", majorFailureSymptomCode); //GM06
                                                                                                                                                                System.out.println("生成的工单编号是多少" + wonum);
                                                                                                                                                                messageCode = "0";
                                                                                                                                                                message = "工单创建完成";
                                                                                                                                                                mrs.save();
                                                                                                                                                                mrs.close();
                                                                                                                                                            }
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }else{
                                                                                                messageCode = "23";
                                                                                                message = "Invalid In house / Outsource.";
                                                                                            }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                //}
                           // }
                       // }
                  //  }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        woCreationForOisResponse wo =new woCreationForOisResponse();
        List<resultList> resultList=new ArrayList<>();
        hk.com.mtr.mmis.ws.ois.resultList re=new resultList();
        re.setResultCode(messageCode);
        re.setResultMsg(message);
        resultList.add(re);
        wo.setWoNo(wonum);
        wo.setResultList(resultList);
        if("0".equals(messageCode)){
            ReturnStatus="0";
        }else{
            ReturnStatus="1";
        }
        wo.setReturnStatus(ReturnStatus);
        return wo;
    }
}