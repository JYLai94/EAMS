
/**
 * ActualBillOfLabour.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: SNAPSHOT  Built on : Jan 10, 2009 (05:26:17 CST)
 */
            
                package hk.com.mtr.mmis.ws;
            

            /**
            *  ActualBillOfLabour bean class
            */
        
        public  class ActualBillOfLabour
        implements org.apache.axis2.databinding.ADBBean{
        /* This type was generated from the piece of schema that had
                name = actualBillOfLabour
                Namespace URI = http://ws.mmis.mtr.com.hk/
                Namespace Prefix = ns1
                */
            

        private static java.lang.String generatePrefix(java.lang.String namespace) {
            if(namespace.equals("http://ws.mmis.mtr.com.hk/")){
                return "ns1";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        

                        /**
                        * field for Amount
                        */

                        
                                    protected double localAmount ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localAmountTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getAmount(){
                               return localAmount;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Amount
                               */
                               public void setAmount(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localAmountTracker = false;
                                              
                                       } else {
                                          localAmountTracker = true;
                                       }
                                   
                                            this.localAmount=param;
                                    

                               }
                            

                        /**
                        * field for CalculatedInd
                        */

                        
                                    protected java.lang.String localCalculatedInd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localCalculatedIndTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getCalculatedInd(){
                               return localCalculatedInd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param CalculatedInd
                               */
                               public void setCalculatedInd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localCalculatedIndTracker = true;
                                       } else {
                                          localCalculatedIndTracker = false;
                                              
                                       }
                                   
                                            this.localCalculatedInd=param;
                                    

                               }
                            

                        /**
                        * field for ChargingWkGrpId
                        */

                        
                                    protected java.lang.String localChargingWkGrpId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localChargingWkGrpIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getChargingWkGrpId(){
                               return localChargingWkGrpId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ChargingWkGrpId
                               */
                               public void setChargingWkGrpId(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localChargingWkGrpIdTracker = true;
                                       } else {
                                          localChargingWkGrpIdTracker = false;
                                              
                                       }
                                   
                                            this.localChargingWkGrpId=param;
                                    

                               }
                            

                        /**
                        * field for CreditAccount
                        */

                        
                                    protected java.lang.String localCreditAccount ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localCreditAccountTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getCreditAccount(){
                               return localCreditAccount;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param CreditAccount
                               */
                               public void setCreditAccount(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localCreditAccountTracker = true;
                                       } else {
                                          localCreditAccountTracker = false;
                                              
                                       }
                                   
                                            this.localCreditAccount=param;
                                    

                               }
                            

                        /**
                        * field for DebitAccount
                        */

                        
                                    protected java.lang.String localDebitAccount ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localDebitAccountTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getDebitAccount(){
                               return localDebitAccount;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param DebitAccount
                               */
                               public void setDebitAccount(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localDebitAccountTracker = true;
                                       } else {
                                          localDebitAccountTracker = false;
                                              
                                       }
                                   
                                            this.localDebitAccount=param;
                                    

                               }
                            

                        /**
                        * field for GcHrsTypeCd
                        */

                        
                                    protected java.lang.String localGcHrsTypeCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcHrsTypeCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcHrsTypeCd(){
                               return localGcHrsTypeCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcHrsTypeCd
                               */
                               public void setGcHrsTypeCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcHrsTypeCdTracker = true;
                                       } else {
                                          localGcHrsTypeCdTracker = false;
                                              
                                       }
                                   
                                            this.localGcHrsTypeCd=param;
                                    

                               }
                            

                        /**
                        * field for GcReferenceTypeCd
                        */

                        
                                    protected java.lang.String localGcReferenceTypeCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcReferenceTypeCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcReferenceTypeCd(){
                               return localGcReferenceTypeCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcReferenceTypeCd
                               */
                               public void setGcReferenceTypeCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcReferenceTypeCdTracker = true;
                                       } else {
                                          localGcReferenceTypeCdTracker = false;
                                              
                                       }
                                   
                                            this.localGcReferenceTypeCd=param;
                                    

                               }
                            

                        /**
                        * field for GcResourceTypeCd
                        */

                        
                                    protected java.lang.String localGcResourceTypeCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcResourceTypeCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcResourceTypeCd(){
                               return localGcResourceTypeCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcResourceTypeCd
                               */
                               public void setGcResourceTypeCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcResourceTypeCdTracker = true;
                                       } else {
                                          localGcResourceTypeCdTracker = false;
                                              
                                       }
                                   
                                            this.localGcResourceTypeCd=param;
                                    

                               }
                            

                        /**
                        * field for GcWorkNatureLv1Cd
                        */

                        
                                    protected java.lang.String localGcWorkNatureLv1Cd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcWorkNatureLv1CdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcWorkNatureLv1Cd(){
                               return localGcWorkNatureLv1Cd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcWorkNatureLv1Cd
                               */
                               public void setGcWorkNatureLv1Cd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcWorkNatureLv1CdTracker = true;
                                       } else {
                                          localGcWorkNatureLv1CdTracker = false;
                                              
                                       }
                                   
                                            this.localGcWorkNatureLv1Cd=param;
                                    

                               }
                            

                        /**
                        * field for GcWorkNatureLv2Cd
                        */

                        
                                    protected java.lang.String localGcWorkNatureLv2Cd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localGcWorkNatureLv2CdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getGcWorkNatureLv2Cd(){
                               return localGcWorkNatureLv2Cd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param GcWorkNatureLv2Cd
                               */
                               public void setGcWorkNatureLv2Cd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localGcWorkNatureLv2CdTracker = true;
                                       } else {
                                          localGcWorkNatureLv2CdTracker = false;
                                              
                                       }
                                   
                                            this.localGcWorkNatureLv2Cd=param;
                                    

                               }
                            

                        /**
                        * field for HrUserId
                        */

                        
                                    protected java.lang.String localHrUserId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localHrUserIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getHrUserId(){
                               return localHrUserId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param HrUserId
                               */
                               public void setHrUserId(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localHrUserIdTracker = true;
                                       } else {
                                          localHrUserIdTracker = false;
                                              
                                       }
                                   
                                            this.localHrUserId=param;
                                    

                               }
                            

                        /**
                        * field for LabourMinutes
                        */

                        
                                    protected double localLabourMinutes ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localLabourMinutesTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return double
                           */
                           public  double getLabourMinutes(){
                               return localLabourMinutes;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param LabourMinutes
                               */
                               public void setLabourMinutes(double param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (java.lang.Double.isNaN(param)) {
                                           localLabourMinutesTracker = false;
                                              
                                       } else {
                                          localLabourMinutesTracker = true;
                                       }
                                   
                                            this.localLabourMinutes=param;
                                    

                               }
                            

                        /**
                        * field for ReferenceNo
                        */

                        
                                    protected java.lang.String localReferenceNo ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localReferenceNoTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getReferenceNo(){
                               return localReferenceNo;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ReferenceNo
                               */
                               public void setReferenceNo(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localReferenceNoTracker = true;
                                       } else {
                                          localReferenceNoTracker = false;
                                              
                                       }
                                   
                                            this.localReferenceNo=param;
                                    

                               }
                            

                        /**
                        * field for Remarks1
                        */

                        
                                    protected java.lang.String localRemarks1 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localRemarks1Tracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getRemarks1(){
                               return localRemarks1;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Remarks1
                               */
                               public void setRemarks1(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localRemarks1Tracker = true;
                                       } else {
                                          localRemarks1Tracker = false;
                                              
                                       }
                                   
                                            this.localRemarks1=param;
                                    

                               }
                            

                        /**
                        * field for Remarks2
                        */

                        
                                    protected java.lang.String localRemarks2 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localRemarks2Tracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getRemarks2(){
                               return localRemarks2;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Remarks2
                               */
                               public void setRemarks2(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localRemarks2Tracker = true;
                                       } else {
                                          localRemarks2Tracker = false;
                                              
                                       }
                                   
                                            this.localRemarks2=param;
                                    

                               }
                            

                        /**
                        * field for Remarks3
                        */

                        
                                    protected java.lang.String localRemarks3 ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localRemarks3Tracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getRemarks3(){
                               return localRemarks3;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Remarks3
                               */
                               public void setRemarks3(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localRemarks3Tracker = true;
                                       } else {
                                          localRemarks3Tracker = false;
                                              
                                       }
                                   
                                            this.localRemarks3=param;
                                    

                               }
                            

                        /**
                        * field for Status
                        */

                        
                                    protected java.lang.String localStatus ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localStatusTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getStatus(){
                               return localStatus;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param Status
                               */
                               public void setStatus(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localStatusTracker = true;
                                       } else {
                                          localStatusTracker = false;
                                              
                                       }
                                   
                                            this.localStatus=param;
                                    

                               }
                            

                        /**
                        * field for TxnDate
                        */

                        
                                    protected java.util.Calendar localTxnDate ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localTxnDateTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.util.Calendar
                           */
                           public  java.util.Calendar getTxnDate(){
                               return localTxnDate;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param TxnDate
                               */
                               public void setTxnDate(java.util.Calendar param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localTxnDateTracker = true;
                                       } else {
                                          localTxnDateTracker = false;
                                              
                                       }
                                   
                                            this.localTxnDate=param;
                                    

                               }
                            

                        /**
                        * field for WoActualBolId
                        */

                        
                                    protected long localWoActualBolId ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoActualBolIdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return long
                           */
                           public  long getWoActualBolId(){
                               return localWoActualBolId;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WoActualBolId
                               */
                               public void setWoActualBolId(long param){
                            
                                       // setting primitive attribute tracker to true
                                       
                                               if (param==java.lang.Long.MIN_VALUE) {
                                           localWoActualBolIdTracker = false;
                                              
                                       } else {
                                          localWoActualBolIdTracker = true;
                                       }
                                   
                                            this.localWoActualBolId=param;
                                    

                               }
                            

     /**
     * isReaderMTOMAware
     * @return true if the reader supports MTOM
     */
   public static boolean isReaderMTOMAware(javax.xml.stream.XMLStreamReader reader) {
        boolean isReaderMTOMAware = false;
        
        try{
          isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader.getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
        }catch(java.lang.IllegalArgumentException e){
          isReaderMTOMAware = false;
        }
        return isReaderMTOMAware;
   }
     
     
        /**
        *
        * @param parentQName
        * @param factory
        * @return org.apache.axiom.om.OMElement
        */
       public org.apache.axiom.om.OMElement getOMElement (
               final javax.xml.namespace.QName parentQName,
               final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException{


        
               org.apache.axiom.om.OMDataSource dataSource =
                       new org.apache.axis2.databinding.ADBDataSource(this,parentQName){

                 public void serialize(org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
                       ActualBillOfLabour.this.serialize(parentQName,factory,xmlWriter);
                 }
               };
               return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
               parentQName,factory,dataSource);
            
       }

         public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
                           serialize(parentQName,factory,xmlWriter,false);
         }

         public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               boolean serializeType)
            throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
            
                


                java.lang.String prefix = null;
                java.lang.String namespace = null;
                

                    prefix = parentQName.getPrefix();
                    namespace = parentQName.getNamespaceURI();

                    if ((namespace != null) && (namespace.trim().length() > 0)) {
                        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                        if (writerPrefix != null) {
                            xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                        } else {
                            if (prefix == null) {
                                prefix = generatePrefix(namespace);
                            }

                            xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                            xmlWriter.writeNamespace(prefix, namespace);
                            xmlWriter.setPrefix(prefix, namespace);
                        }
                    } else {
                        xmlWriter.writeStartElement(parentQName.getLocalPart());
                    }
                
                  if (serializeType){
               

                   java.lang.String namespacePrefix = registerPrefix(xmlWriter,"http://ws.mmis.mtr.com.hk/");
                   if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0)){
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           namespacePrefix+":actualBillOfLabour",
                           xmlWriter);
                   } else {
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           "actualBillOfLabour",
                           xmlWriter);
                   }

               
                   }
                if (localAmountTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"amount", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"amount");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("amount");
                                    }
                                
                                               if (java.lang.Double.isNaN(localAmount)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("amount cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localAmount));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localCalculatedIndTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"calculatedInd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"calculatedInd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("calculatedInd");
                                    }
                                

                                          if (localCalculatedInd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("calculatedInd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localCalculatedInd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localChargingWkGrpIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"chargingWkGrpId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"chargingWkGrpId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("chargingWkGrpId");
                                    }
                                

                                          if (localChargingWkGrpId==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("chargingWkGrpId cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localChargingWkGrpId);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localCreditAccountTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"creditAccount", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"creditAccount");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("creditAccount");
                                    }
                                

                                          if (localCreditAccount==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("creditAccount cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localCreditAccount);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localDebitAccountTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"debitAccount", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"debitAccount");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("debitAccount");
                                    }
                                

                                          if (localDebitAccount==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("debitAccount cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localDebitAccount);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcHrsTypeCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcHrsTypeCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcHrsTypeCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcHrsTypeCd");
                                    }
                                

                                          if (localGcHrsTypeCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcHrsTypeCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcHrsTypeCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcReferenceTypeCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcReferenceTypeCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcReferenceTypeCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcReferenceTypeCd");
                                    }
                                

                                          if (localGcReferenceTypeCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcReferenceTypeCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcReferenceTypeCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcResourceTypeCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcResourceTypeCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcResourceTypeCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcResourceTypeCd");
                                    }
                                

                                          if (localGcResourceTypeCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcResourceTypeCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcResourceTypeCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcWorkNatureLv1CdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcWorkNatureLv1Cd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcWorkNatureLv1Cd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcWorkNatureLv1Cd");
                                    }
                                

                                          if (localGcWorkNatureLv1Cd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcWorkNatureLv1Cd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcWorkNatureLv1Cd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localGcWorkNatureLv2CdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"gcWorkNatureLv2Cd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"gcWorkNatureLv2Cd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("gcWorkNatureLv2Cd");
                                    }
                                

                                          if (localGcWorkNatureLv2Cd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("gcWorkNatureLv2Cd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localGcWorkNatureLv2Cd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localHrUserIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"hrUserId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"hrUserId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("hrUserId");
                                    }
                                

                                          if (localHrUserId==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("hrUserId cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localHrUserId);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localLabourMinutesTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"labourMinutes", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"labourMinutes");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("labourMinutes");
                                    }
                                
                                               if (java.lang.Double.isNaN(localLabourMinutes)) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("labourMinutes cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLabourMinutes));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localReferenceNoTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"referenceNo", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"referenceNo");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("referenceNo");
                                    }
                                

                                          if (localReferenceNo==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("referenceNo cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localReferenceNo);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localRemarks1Tracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"remarks1", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"remarks1");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("remarks1");
                                    }
                                

                                          if (localRemarks1==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("remarks1 cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localRemarks1);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localRemarks2Tracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"remarks2", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"remarks2");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("remarks2");
                                    }
                                

                                          if (localRemarks2==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("remarks2 cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localRemarks2);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localRemarks3Tracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"remarks3", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"remarks3");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("remarks3");
                                    }
                                

                                          if (localRemarks3==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("remarks3 cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localRemarks3);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localStatusTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"status", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"status");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("status");
                                    }
                                

                                          if (localStatus==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("status cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localStatus);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localTxnDateTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"txnDate", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"txnDate");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("txnDate");
                                    }
                                

                                          if (localTxnDate==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("txnDate cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTxnDate));
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localWoActualBolIdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"woActualBolId", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"woActualBolId");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("woActualBolId");
                                    }
                                
                                               if (localWoActualBolId==java.lang.Long.MIN_VALUE) {
                                           
                                                         throw new org.apache.axis2.databinding.ADBException("woActualBolId cannot be null!!");
                                                      
                                               } else {
                                                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localWoActualBolId));
                                               }
                                    
                                   xmlWriter.writeEndElement();
                             }
                    xmlWriter.writeEndElement();
               

        }

         /**
          * Util method to write an attribute with the ns prefix
          */
          private void writeAttribute(java.lang.String prefix,java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
              if (xmlWriter.getPrefix(namespace) == null) {
                       xmlWriter.writeNamespace(prefix, namespace);
                       xmlWriter.setPrefix(prefix, namespace);

              }

              xmlWriter.writeAttribute(namespace,attName,attValue);

         }

        /**
          * Util method to write an attribute without the ns prefix
          */
          private void writeAttribute(java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
                if (namespace.equals(""))
              {
                  xmlWriter.writeAttribute(attName,attValue);
              }
              else
              {
                  registerPrefix(xmlWriter, namespace);
                  xmlWriter.writeAttribute(namespace,attName,attValue);
              }
          }


           /**
             * Util method to write an attribute without the ns prefix
             */
            private void writeQNameAttribute(java.lang.String namespace, java.lang.String attName,
                                             javax.xml.namespace.QName qname, javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

                java.lang.String attributeNamespace = qname.getNamespaceURI();
                java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
                if (attributePrefix == null) {
                    attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
                }
                java.lang.String attributeValue;
                if (attributePrefix.trim().length() > 0) {
                    attributeValue = attributePrefix + ":" + qname.getLocalPart();
                } else {
                    attributeValue = qname.getLocalPart();
                }

                if (namespace.equals("")) {
                    xmlWriter.writeAttribute(attName, attributeValue);
                } else {
                    registerPrefix(xmlWriter, namespace);
                    xmlWriter.writeAttribute(namespace, attName, attributeValue);
                }
            }
        /**
         *  method to handle Qnames
         */

        private void writeQName(javax.xml.namespace.QName qname,
                                javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null) {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null) {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix,namespaceURI);
                }

                if (prefix.trim().length() > 0){
                    xmlWriter.writeCharacters(prefix + ":" + org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                } else {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                }

            } else {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
            }
        }

        private void writeQNames(javax.xml.namespace.QName[] qnames,
                                 javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

            if (qnames != null) {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++) {
                    if (i > 0) {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null) {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0)) {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix,namespaceURI);
                        }

                        if (prefix.trim().length() > 0){
                            stringToWrite.append(prefix).append(":").append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        } else {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        }
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }


         /**
         * Register a namespace prefix
         */
         private java.lang.String registerPrefix(javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace) throws javax.xml.stream.XMLStreamException {
                java.lang.String prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null) {
                        prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                    }

                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }

                return prefix;
            }


  
        /**
        * databinding method to get an XML representation of this object
        *
        */
        public javax.xml.stream.XMLStreamReader getPullParser(javax.xml.namespace.QName qName)
                    throws org.apache.axis2.databinding.ADBException{


        
                 java.util.ArrayList elementList = new java.util.ArrayList();
                 java.util.ArrayList attribList = new java.util.ArrayList();

                 if (localAmountTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "amount"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localAmount));
                            } if (localCalculatedIndTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "calculatedInd"));
                                 
                                        if (localCalculatedInd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localCalculatedInd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("calculatedInd cannot be null!!");
                                        }
                                    } if (localChargingWkGrpIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "chargingWkGrpId"));
                                 
                                        if (localChargingWkGrpId != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localChargingWkGrpId));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("chargingWkGrpId cannot be null!!");
                                        }
                                    } if (localCreditAccountTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "creditAccount"));
                                 
                                        if (localCreditAccount != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localCreditAccount));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("creditAccount cannot be null!!");
                                        }
                                    } if (localDebitAccountTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "debitAccount"));
                                 
                                        if (localDebitAccount != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localDebitAccount));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("debitAccount cannot be null!!");
                                        }
                                    } if (localGcHrsTypeCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcHrsTypeCd"));
                                 
                                        if (localGcHrsTypeCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcHrsTypeCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcHrsTypeCd cannot be null!!");
                                        }
                                    } if (localGcReferenceTypeCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcReferenceTypeCd"));
                                 
                                        if (localGcReferenceTypeCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcReferenceTypeCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcReferenceTypeCd cannot be null!!");
                                        }
                                    } if (localGcResourceTypeCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcResourceTypeCd"));
                                 
                                        if (localGcResourceTypeCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcResourceTypeCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcResourceTypeCd cannot be null!!");
                                        }
                                    } if (localGcWorkNatureLv1CdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcWorkNatureLv1Cd"));
                                 
                                        if (localGcWorkNatureLv1Cd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcWorkNatureLv1Cd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcWorkNatureLv1Cd cannot be null!!");
                                        }
                                    } if (localGcWorkNatureLv2CdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "gcWorkNatureLv2Cd"));
                                 
                                        if (localGcWorkNatureLv2Cd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localGcWorkNatureLv2Cd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("gcWorkNatureLv2Cd cannot be null!!");
                                        }
                                    } if (localHrUserIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "hrUserId"));
                                 
                                        if (localHrUserId != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localHrUserId));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("hrUserId cannot be null!!");
                                        }
                                    } if (localLabourMinutesTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "labourMinutes"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localLabourMinutes));
                            } if (localReferenceNoTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "referenceNo"));
                                 
                                        if (localReferenceNo != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localReferenceNo));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("referenceNo cannot be null!!");
                                        }
                                    } if (localRemarks1Tracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "remarks1"));
                                 
                                        if (localRemarks1 != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRemarks1));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("remarks1 cannot be null!!");
                                        }
                                    } if (localRemarks2Tracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "remarks2"));
                                 
                                        if (localRemarks2 != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRemarks2));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("remarks2 cannot be null!!");
                                        }
                                    } if (localRemarks3Tracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "remarks3"));
                                 
                                        if (localRemarks3 != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localRemarks3));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("remarks3 cannot be null!!");
                                        }
                                    } if (localStatusTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "status"));
                                 
                                        if (localStatus != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localStatus));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("status cannot be null!!");
                                        }
                                    } if (localTxnDateTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "txnDate"));
                                 
                                        if (localTxnDate != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTxnDate));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("txnDate cannot be null!!");
                                        }
                                    } if (localWoActualBolIdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "woActualBolId"));
                                 
                                elementList.add(
                                   org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localWoActualBolId));
                            }

                return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName, elementList.toArray(), attribList.toArray());
            
            

        }

  

     /**
      *  Factory class that keeps the parse method
      */
    public static class Factory{

        
        

        /**
        * static method to create the object
        * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
        *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
        * Postcondition: If this object is an element, the reader is positioned at its end element
        *                If this object is a complex type, the reader is positioned at the end element of its outer element
        */
        public static ActualBillOfLabour parse(javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{
            ActualBillOfLabour object =
                new ActualBillOfLabour();

            int event;
            java.lang.String nillableValue = null;
            java.lang.String prefix ="";
            java.lang.String namespaceuri ="";
            try {
                
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                
                if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","type")!=null){
                  java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                        "type");
                  if (fullTypeName!=null){
                    java.lang.String nsPrefix = null;
                    if (fullTypeName.indexOf(":") > -1){
                        nsPrefix = fullTypeName.substring(0,fullTypeName.indexOf(":"));
                    }
                    nsPrefix = nsPrefix==null?"":nsPrefix;

                    java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":")+1);
                    
                            if (!"actualBillOfLabour".equals(type)){
                                //find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext().getNamespaceURI(nsPrefix);
                                return (ActualBillOfLabour)hk.com.mtr.mmis.ws.ExtensionMapper.getTypeObject(
                                     nsUri,type,reader);
                              }
                        

                  }
                

                }

                

                
                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();
                

                 
                    
                    reader.next();
                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","amount").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setAmount(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setAmount(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","calculatedInd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setCalculatedInd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","chargingWkGrpId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setChargingWkGrpId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","creditAccount").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setCreditAccount(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","debitAccount").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setDebitAccount(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcHrsTypeCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcHrsTypeCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcReferenceTypeCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcReferenceTypeCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcResourceTypeCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcResourceTypeCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcWorkNatureLv1Cd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcWorkNatureLv1Cd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","gcWorkNatureLv2Cd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setGcWorkNatureLv2Cd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","hrUserId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setHrUserId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","labourMinutes").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setLabourMinutes(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDouble(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setLabourMinutes(java.lang.Double.NaN);
                                           
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","referenceNo").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setReferenceNo(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","remarks1").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setRemarks1(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","remarks2").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setRemarks2(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","remarks3").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setRemarks3(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","status").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setStatus(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","txnDate").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setTxnDate(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToDateTime(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woActualBolId").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setWoActualBolId(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToLong(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                               object.setWoActualBolId(java.lang.Long.MIN_VALUE);
                                           
                                    }
                                  
                            while (!reader.isStartElement() && !reader.isEndElement())
                                reader.next();
                            
                                if (reader.isStartElement())
                                // A start element we are not expecting indicates a trailing invalid property
                                throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader.getLocalName());
                            



            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }

        }//end of factory class

        

        }
           
          