
/**
 * ExtensionMapper.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: SNAPSHOT  Built on : Jan 10, 2009 (05:26:17 CST)
 */

            package hk.com.mtr.mmis.ws.incident;
            /**
            *  ExtensionMapper class
            */
        
        public  class ExtensionMapper{

          public static java.lang.Object getTypeObject(java.lang.String namespaceURI,
                                                       java.lang.String typeName,
                                                       javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{

              
                  if (
                  "http://incident.ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "resultObjectArray".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.incident.ResultObjectArray.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://incident.ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "wmODMSIncidentUploadVO".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.incident.WmODMSIncidentUploadVO.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://incident.ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "IncidentFaultInfo".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.incident.IncidentFaultInfo.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://incident.ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "wmODMSIncidentUploadVOArray".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.incident.WmODMSIncidentUploadVOArray.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://incident.ws.mmis.mtr.com.hk/".equals(namespaceURI) &&
                  "resultObject".equals(typeName)){
                   
                            return  hk.com.mtr.mmis.ws.incident.ResultObject.Factory.parse(reader);
                        

                  }

              
             throw new org.apache.axis2.databinding.ADBException("Unsupported type " + namespaceURI + " " + typeName);
          }

        }
    