package hk.com.mtr.mmis.ws.ois;

public interface WorkOrderCreate {

    woCreationForOisResponse oisWoCreationVO(oisWoCreationInputVO o, String userAccount);

}
