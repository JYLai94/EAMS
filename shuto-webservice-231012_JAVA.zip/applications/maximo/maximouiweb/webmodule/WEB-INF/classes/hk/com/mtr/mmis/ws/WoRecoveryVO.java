
/**
 * WoRecoveryVO.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: SNAPSHOT  Built on : Jan 10, 2009 (05:26:17 CST)
 */
            
                package hk.com.mtr.mmis.ws;
            

            /**
            *  WoRecoveryVO bean class
            */
        
        public  class WoRecoveryVO extends hk.com.mtr.mmis.ws.BaseVO
        implements org.apache.axis2.databinding.ADBBean{
        /* This type was generated from the piece of schema that had
                name = woRecoveryVO
                Namespace URI = http://ws.mmis.mtr.com.hk/
                Namespace Prefix = ns1
                */
            

        private static java.lang.String generatePrefix(java.lang.String namespace) {
            if(namespace.equals("http://ws.mmis.mtr.com.hk/")){
                return "ns1";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        

                        /**
                        * field for ContractorCd
                        */

                        
                                    protected java.lang.String localContractorCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localContractorCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getContractorCd(){
                               return localContractorCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ContractorCd
                               */
                               public void setContractorCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localContractorCdTracker = true;
                                       } else {
                                          localContractorCdTracker = false;
                                              
                                       }
                                   
                                            this.localContractorCd=param;
                                    

                               }
                            

                        /**
                        * field for ContractorFinishWorkTime
                        */

                        
                                    protected java.lang.String localContractorFinishWorkTime ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localContractorFinishWorkTimeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getContractorFinishWorkTime(){
                               return localContractorFinishWorkTime;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ContractorFinishWorkTime
                               */
                               public void setContractorFinishWorkTime(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localContractorFinishWorkTimeTracker = true;
                                       } else {
                                          localContractorFinishWorkTimeTracker = false;
                                              
                                       }
                                   
                                            this.localContractorFinishWorkTime=param;
                                    

                               }
                            

                        /**
                        * field for ContractorSiteArrivalTime
                        */

                        
                                    protected java.lang.String localContractorSiteArrivalTime ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localContractorSiteArrivalTimeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getContractorSiteArrivalTime(){
                               return localContractorSiteArrivalTime;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ContractorSiteArrivalTime
                               */
                               public void setContractorSiteArrivalTime(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localContractorSiteArrivalTimeTracker = true;
                                       } else {
                                          localContractorSiteArrivalTimeTracker = false;
                                              
                                       }
                                   
                                            this.localContractorSiteArrivalTime=param;
                                    

                               }
                            

                        /**
                        * field for ContractorStartWorkTime
                        */

                        
                                    protected java.lang.String localContractorStartWorkTime ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localContractorStartWorkTimeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getContractorStartWorkTime(){
                               return localContractorStartWorkTime;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param ContractorStartWorkTime
                               */
                               public void setContractorStartWorkTime(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localContractorStartWorkTimeTracker = true;
                                       } else {
                                          localContractorStartWorkTimeTracker = false;
                                              
                                       }
                                   
                                            this.localContractorStartWorkTime=param;
                                    

                               }
                            

                        /**
                        * field for EngineerCd
                        */

                        
                                    protected java.lang.String localEngineerCd ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localEngineerCdTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getEngineerCd(){
                               return localEngineerCd;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param EngineerCd
                               */
                               public void setEngineerCd(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localEngineerCdTracker = true;
                                       } else {
                                          localEngineerCdTracker = false;
                                              
                                       }
                                   
                                            this.localEngineerCd=param;
                                    

                               }
                            

                        /**
                        * field for FinishWorkTime
                        */

                        
                                    protected java.lang.String localFinishWorkTime ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localFinishWorkTimeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getFinishWorkTime(){
                               return localFinishWorkTime;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param FinishWorkTime
                               */
                               public void setFinishWorkTime(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localFinishWorkTimeTracker = true;
                                       } else {
                                          localFinishWorkTimeTracker = false;
                                              
                                       }
                                   
                                            this.localFinishWorkTime=param;
                                    

                               }
                            

                        /**
                        * field for InformContractorTime
                        */

                        
                                    protected java.lang.String localInformContractorTime ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localInformContractorTimeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getInformContractorTime(){
                               return localInformContractorTime;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param InformContractorTime
                               */
                               public void setInformContractorTime(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localInformContractorTimeTracker = true;
                                       } else {
                                          localInformContractorTimeTracker = false;
                                              
                                       }
                                   
                                            this.localInformContractorTime=param;
                                    

                               }
                            

                        /**
                        * field for SiteArrivalTime
                        */

                        
                                    protected java.lang.String localSiteArrivalTime ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localSiteArrivalTimeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getSiteArrivalTime(){
                               return localSiteArrivalTime;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param SiteArrivalTime
                               */
                               public void setSiteArrivalTime(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localSiteArrivalTimeTracker = true;
                                       } else {
                                          localSiteArrivalTimeTracker = false;
                                              
                                       }
                                   
                                            this.localSiteArrivalTime=param;
                                    

                               }
                            

                        /**
                        * field for StartWorkTime
                        */

                        
                                    protected java.lang.String localStartWorkTime ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localStartWorkTimeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getStartWorkTime(){
                               return localStartWorkTime;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param StartWorkTime
                               */
                               public void setStartWorkTime(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localStartWorkTimeTracker = true;
                                       } else {
                                          localStartWorkTimeTracker = false;
                                              
                                       }
                                   
                                            this.localStartWorkTime=param;
                                    

                               }
                            

                        /**
                        * field for TempSvcRecoveryTime
                        */

                        
                                    protected java.lang.String localTempSvcRecoveryTime ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localTempSvcRecoveryTimeTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return java.lang.String
                           */
                           public  java.lang.String getTempSvcRecoveryTime(){
                               return localTempSvcRecoveryTime;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param TempSvcRecoveryTime
                               */
                               public void setTempSvcRecoveryTime(java.lang.String param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localTempSvcRecoveryTimeTracker = true;
                                       } else {
                                          localTempSvcRecoveryTimeTracker = false;
                                              
                                       }
                                   
                                            this.localTempSvcRecoveryTime=param;
                                    

                               }
                            

                        /**
                        * field for WoRecovery
                        */

                        
                                    protected hk.com.mtr.mmis.ws.WoRecovery localWoRecovery ;
                                
                           /*  This tracker boolean wil be used to detect whether the user called the set method
                          *   for this attribute. It will be used to determine whether to include this field
                           *   in the serialized XML
                           */
                           protected boolean localWoRecoveryTracker = false ;
                           

                           /**
                           * Auto generated getter method
                           * @return hk.com.mtr.mmis.ws.WoRecovery
                           */
                           public  hk.com.mtr.mmis.ws.WoRecovery getWoRecovery(){
                               return localWoRecovery;
                           }

                           
                        
                            /**
                               * Auto generated setter method
                               * @param param WoRecovery
                               */
                               public void setWoRecovery(hk.com.mtr.mmis.ws.WoRecovery param){
                            
                                       if (param != null){
                                          //update the setting tracker
                                          localWoRecoveryTracker = true;
                                       } else {
                                          localWoRecoveryTracker = false;
                                              
                                       }
                                   
                                            this.localWoRecovery=param;
                                    

                               }
                            

     /**
     * isReaderMTOMAware
     * @return true if the reader supports MTOM
     */
   public static boolean isReaderMTOMAware(javax.xml.stream.XMLStreamReader reader) {
        boolean isReaderMTOMAware = false;
        
        try{
          isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader.getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
        }catch(java.lang.IllegalArgumentException e){
          isReaderMTOMAware = false;
        }
        return isReaderMTOMAware;
   }
     
     
        /**
        *
        * @param parentQName
        * @param factory
        * @return org.apache.axiom.om.OMElement
        */
       public org.apache.axiom.om.OMElement getOMElement (
               final javax.xml.namespace.QName parentQName,
               final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException{


        
               org.apache.axiom.om.OMDataSource dataSource =
                       new org.apache.axis2.databinding.ADBDataSource(this,parentQName){

                 public void serialize(org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
                       WoRecoveryVO.this.serialize(parentQName,factory,xmlWriter);
                 }
               };
               return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
               parentQName,factory,dataSource);
            
       }

         public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
                           serialize(parentQName,factory,xmlWriter,false);
         }

         public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               boolean serializeType)
            throws javax.xml.stream.XMLStreamException, org.apache.axis2.databinding.ADBException{
            
                


                java.lang.String prefix = null;
                java.lang.String namespace = null;
                

                    prefix = parentQName.getPrefix();
                    namespace = parentQName.getNamespaceURI();

                    if ((namespace != null) && (namespace.trim().length() > 0)) {
                        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                        if (writerPrefix != null) {
                            xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                        } else {
                            if (prefix == null) {
                                prefix = generatePrefix(namespace);
                            }

                            xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                            xmlWriter.writeNamespace(prefix, namespace);
                            xmlWriter.setPrefix(prefix, namespace);
                        }
                    } else {
                        xmlWriter.writeStartElement(parentQName.getLocalPart());
                    }
                

                   java.lang.String namespacePrefix = registerPrefix(xmlWriter,"http://ws.mmis.mtr.com.hk/");
                   if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0)){
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           namespacePrefix+":woRecoveryVO",
                           xmlWriter);
                   } else {
                       writeAttribute("xsi","http://www.w3.org/2001/XMLSchema-instance","type",
                           "woRecoveryVO",
                           xmlWriter);
                   }

                if (localContractorCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"contractorCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"contractorCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("contractorCd");
                                    }
                                

                                          if (localContractorCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("contractorCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localContractorCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localContractorFinishWorkTimeTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"contractorFinishWorkTime", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"contractorFinishWorkTime");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("contractorFinishWorkTime");
                                    }
                                

                                          if (localContractorFinishWorkTime==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("contractorFinishWorkTime cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localContractorFinishWorkTime);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localContractorSiteArrivalTimeTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"contractorSiteArrivalTime", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"contractorSiteArrivalTime");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("contractorSiteArrivalTime");
                                    }
                                

                                          if (localContractorSiteArrivalTime==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("contractorSiteArrivalTime cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localContractorSiteArrivalTime);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localContractorStartWorkTimeTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"contractorStartWorkTime", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"contractorStartWorkTime");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("contractorStartWorkTime");
                                    }
                                

                                          if (localContractorStartWorkTime==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("contractorStartWorkTime cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localContractorStartWorkTime);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localEngineerCdTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"engineerCd", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"engineerCd");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("engineerCd");
                                    }
                                

                                          if (localEngineerCd==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("engineerCd cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localEngineerCd);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localFinishWorkTimeTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"finishWorkTime", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"finishWorkTime");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("finishWorkTime");
                                    }
                                

                                          if (localFinishWorkTime==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("finishWorkTime cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localFinishWorkTime);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localInformContractorTimeTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"informContractorTime", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"informContractorTime");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("informContractorTime");
                                    }
                                

                                          if (localInformContractorTime==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("informContractorTime cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localInformContractorTime);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localSiteArrivalTimeTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"siteArrivalTime", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"siteArrivalTime");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("siteArrivalTime");
                                    }
                                

                                          if (localSiteArrivalTime==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("siteArrivalTime cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localSiteArrivalTime);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localStartWorkTimeTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"startWorkTime", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"startWorkTime");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("startWorkTime");
                                    }
                                

                                          if (localStartWorkTime==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("startWorkTime cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localStartWorkTime);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localTempSvcRecoveryTimeTracker){
                                    namespace = "";
                                    if (! namespace.equals("")) {
                                        prefix = xmlWriter.getPrefix(namespace);

                                        if (prefix == null) {
                                            prefix = generatePrefix(namespace);

                                            xmlWriter.writeStartElement(prefix,"tempSvcRecoveryTime", namespace);
                                            xmlWriter.writeNamespace(prefix, namespace);
                                            xmlWriter.setPrefix(prefix, namespace);

                                        } else {
                                            xmlWriter.writeStartElement(namespace,"tempSvcRecoveryTime");
                                        }

                                    } else {
                                        xmlWriter.writeStartElement("tempSvcRecoveryTime");
                                    }
                                

                                          if (localTempSvcRecoveryTime==null){
                                              // write the nil attribute
                                              
                                                     throw new org.apache.axis2.databinding.ADBException("tempSvcRecoveryTime cannot be null!!");
                                                  
                                          }else{

                                        
                                                   xmlWriter.writeCharacters(localTempSvcRecoveryTime);
                                            
                                          }
                                    
                                   xmlWriter.writeEndElement();
                             } if (localWoRecoveryTracker){
                                            if (localWoRecovery==null){
                                                 throw new org.apache.axis2.databinding.ADBException("woRecovery cannot be null!!");
                                            }
                                           localWoRecovery.serialize(new javax.xml.namespace.QName("","woRecovery"),
                                               factory,xmlWriter);
                                        }
                    xmlWriter.writeEndElement();
               

        }

         /**
          * Util method to write an attribute with the ns prefix
          */
          private void writeAttribute(java.lang.String prefix,java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
              if (xmlWriter.getPrefix(namespace) == null) {
                       xmlWriter.writeNamespace(prefix, namespace);
                       xmlWriter.setPrefix(prefix, namespace);

              }

              xmlWriter.writeAttribute(namespace,attName,attValue);

         }

        /**
          * Util method to write an attribute without the ns prefix
          */
          private void writeAttribute(java.lang.String namespace,java.lang.String attName,
                                      java.lang.String attValue,javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException{
                if (namespace.equals(""))
              {
                  xmlWriter.writeAttribute(attName,attValue);
              }
              else
              {
                  registerPrefix(xmlWriter, namespace);
                  xmlWriter.writeAttribute(namespace,attName,attValue);
              }
          }


           /**
             * Util method to write an attribute without the ns prefix
             */
            private void writeQNameAttribute(java.lang.String namespace, java.lang.String attName,
                                             javax.xml.namespace.QName qname, javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

                java.lang.String attributeNamespace = qname.getNamespaceURI();
                java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
                if (attributePrefix == null) {
                    attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
                }
                java.lang.String attributeValue;
                if (attributePrefix.trim().length() > 0) {
                    attributeValue = attributePrefix + ":" + qname.getLocalPart();
                } else {
                    attributeValue = qname.getLocalPart();
                }

                if (namespace.equals("")) {
                    xmlWriter.writeAttribute(attName, attributeValue);
                } else {
                    registerPrefix(xmlWriter, namespace);
                    xmlWriter.writeAttribute(namespace, attName, attributeValue);
                }
            }
        /**
         *  method to handle Qnames
         */

        private void writeQName(javax.xml.namespace.QName qname,
                                javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null) {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null) {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix,namespaceURI);
                }

                if (prefix.trim().length() > 0){
                    xmlWriter.writeCharacters(prefix + ":" + org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                } else {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
                }

            } else {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qname));
            }
        }

        private void writeQNames(javax.xml.namespace.QName[] qnames,
                                 javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException {

            if (qnames != null) {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++) {
                    if (i > 0) {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null) {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0)) {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix,namespaceURI);
                        }

                        if (prefix.trim().length() > 0){
                            stringToWrite.append(prefix).append(":").append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        } else {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                        }
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }


         /**
         * Register a namespace prefix
         */
         private java.lang.String registerPrefix(javax.xml.stream.XMLStreamWriter xmlWriter, java.lang.String namespace) throws javax.xml.stream.XMLStreamException {
                java.lang.String prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null) {
                    prefix = generatePrefix(namespace);

                    while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null) {
                        prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                    }

                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }

                return prefix;
            }


  
        /**
        * databinding method to get an XML representation of this object
        *
        */
        public javax.xml.stream.XMLStreamReader getPullParser(javax.xml.namespace.QName qName)
                    throws org.apache.axis2.databinding.ADBException{


        
                 java.util.ArrayList elementList = new java.util.ArrayList();
                 java.util.ArrayList attribList = new java.util.ArrayList();

                
                    attribList.add(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema-instance","type"));
                    attribList.add(new javax.xml.namespace.QName("http://ws.mmis.mtr.com.hk/","woRecoveryVO"));
                 if (localContractorCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "contractorCd"));
                                 
                                        if (localContractorCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localContractorCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("contractorCd cannot be null!!");
                                        }
                                    } if (localContractorFinishWorkTimeTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "contractorFinishWorkTime"));
                                 
                                        if (localContractorFinishWorkTime != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localContractorFinishWorkTime));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("contractorFinishWorkTime cannot be null!!");
                                        }
                                    } if (localContractorSiteArrivalTimeTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "contractorSiteArrivalTime"));
                                 
                                        if (localContractorSiteArrivalTime != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localContractorSiteArrivalTime));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("contractorSiteArrivalTime cannot be null!!");
                                        }
                                    } if (localContractorStartWorkTimeTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "contractorStartWorkTime"));
                                 
                                        if (localContractorStartWorkTime != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localContractorStartWorkTime));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("contractorStartWorkTime cannot be null!!");
                                        }
                                    } if (localEngineerCdTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "engineerCd"));
                                 
                                        if (localEngineerCd != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localEngineerCd));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("engineerCd cannot be null!!");
                                        }
                                    } if (localFinishWorkTimeTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "finishWorkTime"));
                                 
                                        if (localFinishWorkTime != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localFinishWorkTime));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("finishWorkTime cannot be null!!");
                                        }
                                    } if (localInformContractorTimeTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "informContractorTime"));
                                 
                                        if (localInformContractorTime != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localInformContractorTime));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("informContractorTime cannot be null!!");
                                        }
                                    } if (localSiteArrivalTimeTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "siteArrivalTime"));
                                 
                                        if (localSiteArrivalTime != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localSiteArrivalTime));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("siteArrivalTime cannot be null!!");
                                        }
                                    } if (localStartWorkTimeTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "startWorkTime"));
                                 
                                        if (localStartWorkTime != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localStartWorkTime));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("startWorkTime cannot be null!!");
                                        }
                                    } if (localTempSvcRecoveryTimeTracker){
                                      elementList.add(new javax.xml.namespace.QName("",
                                                                      "tempSvcRecoveryTime"));
                                 
                                        if (localTempSvcRecoveryTime != null){
                                            elementList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localTempSvcRecoveryTime));
                                        } else {
                                           throw new org.apache.axis2.databinding.ADBException("tempSvcRecoveryTime cannot be null!!");
                                        }
                                    } if (localWoRecoveryTracker){
                            elementList.add(new javax.xml.namespace.QName("",
                                                                      "woRecovery"));
                            
                            
                                    if (localWoRecovery==null){
                                         throw new org.apache.axis2.databinding.ADBException("woRecovery cannot be null!!");
                                    }
                                    elementList.add(localWoRecovery);
                                }

                return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName, elementList.toArray(), attribList.toArray());
            
            

        }

  

     /**
      *  Factory class that keeps the parse method
      */
    public static class Factory{

        
        

        /**
        * static method to create the object
        * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
        *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
        * Postcondition: If this object is an element, the reader is positioned at its end element
        *                If this object is a complex type, the reader is positioned at the end element of its outer element
        */
        public static WoRecoveryVO parse(javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{
            WoRecoveryVO object =
                new WoRecoveryVO();

            int event;
            java.lang.String nillableValue = null;
            java.lang.String prefix ="";
            java.lang.String namespaceuri ="";
            try {
                
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                
                if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","type")!=null){
                  java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                        "type");
                  if (fullTypeName!=null){
                    java.lang.String nsPrefix = null;
                    if (fullTypeName.indexOf(":") > -1){
                        nsPrefix = fullTypeName.substring(0,fullTypeName.indexOf(":"));
                    }
                    nsPrefix = nsPrefix==null?"":nsPrefix;

                    java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":")+1);
                    
                            if (!"woRecoveryVO".equals(type)){
                                //find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext().getNamespaceURI(nsPrefix);
                                return (WoRecoveryVO)hk.com.mtr.mmis.ws.ExtensionMapper.getTypeObject(
                                     nsUri,type,reader);
                              }
                        

                  }
                

                }

                

                
                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();
                

                 
                    
                    reader.next();
                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","contractorCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setContractorCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","contractorFinishWorkTime").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setContractorFinishWorkTime(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","contractorSiteArrivalTime").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setContractorSiteArrivalTime(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","contractorStartWorkTime").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setContractorStartWorkTime(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","engineerCd").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setEngineerCd(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","finishWorkTime").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setFinishWorkTime(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","informContractorTime").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setInformContractorTime(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","siteArrivalTime").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setSiteArrivalTime(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","startWorkTime").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setStartWorkTime(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","tempSvcRecoveryTime").equals(reader.getName())){
                                
                                    java.lang.String content = reader.getElementText();
                                    
                                              object.setTempSvcRecoveryTime(
                                                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(content));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                
                                    
                                    while (!reader.isStartElement() && !reader.isEndElement()) reader.next();
                                
                                    if (reader.isStartElement() && new javax.xml.namespace.QName("","woRecovery").equals(reader.getName())){
                                
                                                object.setWoRecovery(hk.com.mtr.mmis.ws.WoRecovery.Factory.parse(reader));
                                              
                                        reader.next();
                                    
                              }  // End of if for expected property start element
                                
                                    else {
                                        
                                    }
                                  
                            while (!reader.isStartElement() && !reader.isEndElement())
                                reader.next();
                            
                                if (reader.isStartElement())
                                // A start element we are not expecting indicates a trailing invalid property
                                throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader.getLocalName());
                            



            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }

        }//end of factory class

        

        }
           
          