package shuto;

import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class OracleStructTransfer {

    public static ARRAY  myMethod(Connection conn,List<Object[]> mrdArrayList) throws SQLException {
        StructDescriptor lineSD = new StructDescriptor("LINE_RECORD_TYPE", conn);
        ArrayDescriptor lineDesc = ArrayDescriptor.createDescriptor("LINE_REC_ARRAY", conn);
        STRUCT[] structs = new STRUCT[mrdArrayList.size()];
        for(int i = 0 ; i < mrdArrayList.size() ; i++){
            structs[i] = new STRUCT(lineSD,conn, mrdArrayList.get(i));
        }
        ARRAY array = new ARRAY(lineDesc, conn, structs);
        return array;
    }

}
