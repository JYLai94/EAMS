package shuto;

public class MaterialRequestDtlArrayVO {

    private static final long serialVersionUID = 14492839093386066L;

    private Long lineId;
    private Long lineNumber;
    private Long lineStatus;
    private String attributeCategory;
    private Long createdBy;
    private String creationDate;
    private String dateRequired;
    private Long fromLocatorId;
    private String fromSubinventoryCode;
    private Long fromSubinventoryId;
    private Long headerId;
    private Long inventoryItemId;
    private Long lastUpdatedBy;
    private String lastUpdateDate;
    private Long lastUpdateLogin;
    private String lotNumber;
    private Long organizationId;
    private Long programApplicationId;
    private Long programId;
    private String programUpdateDate;
    private Long projectId;
    private Double quantity;
    private Long quantityDelivered;
    private Long quantityDetailed;
    private Long reasonId;
    private String reference;
    private Long referenceId;
    private Long referenceTypeCode;
    private Long requestId;
    private Long revision;
    private String serialNumberEnd;
    private String serialNumberStart;
    private String statusDate;
    private Long taskId;
    private Long toAccountId;
    private Long toLocatorId;
    private String toSubinventoryCode;
    private Long toSubinventoryId;
    private Long transactionHeaderId;
    private Long transactionTypeId;
    private Long txnSourceId;
    private Long txnSourceLineId;
    private Long txnSourceLineDetailId;
    private Long transactionSourceTypeId;
    private Long primaryQuantity;
    private Long toOrganizationId;
    private Long pickStrategyId;
    private Long putAwayStrategyId;
    private String uomCode;
    private String unitNumber;
    private Long shipToLocationId;
    private Long fromCostGroupId;
    private Long toCostGroupId;
    private Long lpnId;
    private Long toLpnId;
    private Long pickMethodologyId;
    private Long containerItemId;
    private Long cartonGroupingId;
    private String returnStatus;
    private String dbFlag;
    private String operation;
    private Long inspectionStatus;
    private Long wmsProcessFlag;
    private Long pickSlipNumber;
    private String pickSlipDate;
    private Long shipSetId;
    private Long shipModelId;
    private Long modelQuantity;
    private Long requiredQuantity;
    private String attribute1;
    private String attribute10;
    private String attribute11;
    private String attribute12;
    private String attribute13;
    private String attribute14;
    private String attribute15;
    private String attribute2;
    private String attribute3;
    private String attribute4;
    private String attribute5;
    private String attribute6;
    private String attribute7;
    private String attribute8;
    private String attribute9;
    private Object[] dbObject = new Object[84];

    public Object[] setDate(Object... obj){
        int i=0;
        for (Object o : obj) {
            dbObject[i] = o;
            i++;
        }
        return dbObject;
    }

    public Long getLineId() {
        return lineId;
    }
    public void setLineId(Long lineId) {
        this.lineId = lineId;
        dbObject[0] = lineId;
    }
    public Long getLineNumber() {
        return lineNumber;
    }
    public void setLineNumber(Long lineNumber) {
        this.lineNumber = lineNumber;
        dbObject[1] = lineNumber;
    }
    public Long getLineStatus() {
        return lineStatus;
    }
    public void setLineStatus(Long lineStatus) {
        this.lineStatus = lineStatus;
        dbObject[2] = lineStatus;
    }
    public String getAttributeCategory() {
        return attributeCategory;
    }
    public void setAttributeCategory(String attributeCategory) {
        this.attributeCategory = attributeCategory;
        dbObject[3] = attributeCategory;
    }
    public Long getCreatedBy() {
        return createdBy;
    }
    public void setCreatedBy(Long createdBy) {
        this.createdBy = createdBy;
        dbObject[4] = createdBy;
    }
    public String getCreationDate() {
        return creationDate;
    }
    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
        dbObject[5] = creationDate;
    }
    public String getDateRequired() {
        return dateRequired;
    }
    public void setDateRequired(String dateRequired) {
        this.dateRequired = dateRequired;
        dbObject[6] = dateRequired;
    }
    public Long getFromLocatorId() {
        return fromLocatorId;
    }
    public void setFromLocatorId(Long fromLocatorId) {
        this.fromLocatorId = fromLocatorId;
        dbObject[7] = fromLocatorId;
    }
    public String getFromSubinventoryCode() {
        return fromSubinventoryCode;
    }
    public void setFromSubinventoryCode(String fromSubinventoryCode) {
        this.fromSubinventoryCode = fromSubinventoryCode;
        dbObject[8] = fromSubinventoryCode;
    }
    public Long getFromSubinventoryId() {
        return fromSubinventoryId;
    }
    public void setFromSubinventoryId(Long fromSubinventoryId) {
        this.fromSubinventoryId = fromSubinventoryId;
        dbObject[9] = fromSubinventoryId;
    }
    public Long getHeaderId() {
        return headerId;
    }
    public void setHeaderId(Long headerId) {
        this.headerId = headerId;
        dbObject[10] = headerId;
    }
    public Long getInventoryItemId() {
        return inventoryItemId;
    }
    public void setInventoryItemId(Long inventoryItemId) {
        this.inventoryItemId = inventoryItemId;
        dbObject[11] = inventoryItemId;
    }
    public Long getLastUpdatedBy() {
        return lastUpdatedBy;
    }
    public void setLastUpdatedBy(Long lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
        dbObject[12] = lastUpdatedBy;
    }
    public String getLastUpdateDate() {
        return lastUpdateDate;
    }
    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
        dbObject[13] = lastUpdateDate;
    }
    public Long getLastUpdateLogin() {
        return lastUpdateLogin;
    }
    public void setLastUpdateLogin(Long lastUpdateLogin) {
        this.lastUpdateLogin = lastUpdateLogin;
        dbObject[14] = lastUpdateLogin;
    }
    public String getLotNumber() {
        return lotNumber;
    }
    public void setLotNumber(String lotNumber) {
        this.lotNumber = lotNumber;
        dbObject[15] = lotNumber;
    }
    public Long getOrganizationId() {
        return organizationId;
    }
    public void setOrganizationId(Long organizationId) {
        this.organizationId = organizationId;
        dbObject[16] = organizationId;
    }
    public Long getProgramApplicationId() {
        return programApplicationId;
    }
    public void setProgramApplicationId(Long programApplicationId) {
        this.programApplicationId = programApplicationId;
        dbObject[17] = programApplicationId;
    }
    public Long getProgramId() {
        return programId;
    }
    public void setProgramId(Long programId) {
        this.programId = programId;
        dbObject[18] = programId;
    }
    public String getProgramUpdateDate() {
        return programUpdateDate;
    }
    public void setProgramUpdateDate(String programUpdateDate) {
        this.programUpdateDate = programUpdateDate;
        dbObject[19] = programUpdateDate;
    }
    public Long getProjectId() {
        return projectId;
    }
    public void setProjectId(Long projectId) {
        this.projectId = projectId;
        dbObject[20] = projectId;
    }
    public Double getQuantity() {
        return quantity;
    }
    public void setQuantity(Double quantity) {
        this.quantity = quantity;
        dbObject[21] = quantity;
    }
    public Long getQuantityDelivered() {
        return quantityDelivered;
    }
    public void setQuantityDelivered(Long quantityDelivered) {
        this.quantityDelivered = quantityDelivered;
        dbObject[22] = quantityDelivered;
    }
    public Long getQuantityDetailed() {
        return quantityDetailed;
    }
    public void setQuantityDetailed(Long quantityDetailed) {
        this.quantityDetailed = quantityDetailed;
        dbObject[23] = quantityDetailed;
    }
    public Long getReasonId() {
        return reasonId;
    }
    public void setReasonId(Long reasonId) {
        this.reasonId = reasonId;
        dbObject[24] = reasonId;
    }
    public String getReference() {
        return reference;
    }
    public void setReference(String reference) {
        this.reference = reference;
        dbObject[25] = reference;
    }
    public Long getReferenceId() {
        return referenceId;
    }
    public void setReferenceId(Long referenceId) {
        this.referenceId = referenceId;
        dbObject[26] = referenceId;
    }
    public Long getReferenceTypeCode() {
        return referenceTypeCode;
    }
    public void setReferenceTypeCode(Long referenceTypeCode) {
        this.referenceTypeCode = referenceTypeCode;
        dbObject[27] = referenceTypeCode;
    }
    public Long getRequestId() {
        return requestId;
    }
    public void setRequestId(Long requestId) {
        this.requestId = requestId;
        dbObject[28] = requestId;
    }
    public Long getRevision() {
        return revision;
    }
    public void setRevision(Long revision) {
        this.revision = revision;
        dbObject[29] = revision;
    }
    public String getSerialNumberEnd() {
        return serialNumberEnd;
    }
    public void setSerialNumberEnd(String serialNumberEnd) {
        this.serialNumberEnd = serialNumberEnd;
        dbObject[30] = serialNumberEnd;
    }
    public String getSerialNumberStart() {
        return serialNumberStart;
    }
    public void setSerialNumberStart(String serialNumberStart) {
        this.serialNumberStart = serialNumberStart;
        dbObject[31] = serialNumberStart;
    }
    public String getStatusDate() {
        return statusDate;
    }
    public void setStatusDate(String statusDate) {
        this.statusDate = statusDate;
        dbObject[32] = statusDate;
    }
    public Long getTaskId() {
        return taskId;
    }
    public void setTaskId(Long taskId) {
        this.taskId = taskId;
        dbObject[33] = taskId;
    }
    public Long getToAccountId() {
        return toAccountId;
    }
    public void setToAccountId(Long toAccountId) {
        this.toAccountId = toAccountId;
        dbObject[34] = toAccountId;
    }
    public Long getToLocatorId() {
        return toLocatorId;
    }
    public void setToLocatorId(Long toLocatorId) {
        this.toLocatorId = toLocatorId;
        dbObject[35] = toLocatorId;
    }
    public String getToSubinventoryCode() {
        return toSubinventoryCode;
    }
    public void setToSubinventoryCode(String toSubinventoryCode) {
        this.toSubinventoryCode = toSubinventoryCode;
        dbObject[36] = toSubinventoryCode;
    }
    public Long getToSubinventoryId() {
        return toSubinventoryId;
    }
    public void setToSubinventoryId(Long toSubinventoryId) {
        this.toSubinventoryId = toSubinventoryId;
        dbObject[37] = toSubinventoryCode;
    }
    public Long getTransactionHeaderId() {
        return transactionHeaderId;
    }
    public void setTransactionHeaderId(Long transactionHeaderId) {
        this.transactionHeaderId = transactionHeaderId;
        dbObject[38] = transactionHeaderId;
    }
    public Long getTransactionTypeId() {
        return transactionTypeId;
    }
    public void setTransactionTypeId(Long transactionTypeId) {
        this.transactionTypeId = transactionTypeId;
        dbObject[39] = transactionTypeId;
    }
    public Long getTxnSourceId() {
        return txnSourceId;
    }
    public void setTxnSourceId(Long txnSourceId) {
        this.txnSourceId = txnSourceId;
        dbObject[40] = txnSourceId;
    }
    public Long getTxnSourceLineId() {
        return txnSourceLineId;
    }
    public void setTxnSourceLineId(Long txnSourceLineId) {
        this.txnSourceLineId = txnSourceLineId;
        dbObject[41] = txnSourceLineId;
    }
    public Long getTxnSourceLineDetailId() {
        return txnSourceLineDetailId;
    }
    public void setTxnSourceLineDetailId(Long txnSourceLineDetailId) {
        this.txnSourceLineDetailId = txnSourceLineDetailId;
        dbObject[42] = txnSourceLineDetailId;
    }
    public Long getTransactionSourceTypeId() {
        return transactionSourceTypeId;
    }
    public void setTransactionSourceTypeId(Long transactionSourceTypeId) {
        this.transactionSourceTypeId = transactionSourceTypeId;
        dbObject[43] = transactionSourceTypeId;
    }
    public Long getPrimaryQuantity() {
        return primaryQuantity;
    }
    public void setPrimaryQuantity(Long primaryQuantity) {
        this.primaryQuantity = primaryQuantity;
        dbObject[44] = primaryQuantity;
    }
    public Long getToOrganizationId() {
        return toOrganizationId;
    }
    public void setToOrganizationId(Long toOrganizationId) {
        this.toOrganizationId = toOrganizationId;
        dbObject[45] = toOrganizationId;
    }
    public Long getPickStrategyId() {
        return pickStrategyId;
    }
    public void setPickStrategyId(Long pickStrategyId) {
        this.pickStrategyId = pickStrategyId;
        dbObject[46] = pickStrategyId;
    }
    public Long getPutAwayStrategyId() {
        return putAwayStrategyId;
    }
    public void setPutAwayStrategyId(Long putAwayStrategyId) {
        this.putAwayStrategyId = putAwayStrategyId;
        dbObject[47] = putAwayStrategyId;
    }
    public String getUomCode() {
        return uomCode;
    }
    public void setUomCode(String uomCode) {
        this.uomCode = uomCode;
        dbObject[48] = uomCode;
    }
    public String getUnitNumber() {
        return unitNumber;
    }
    public void setUnitNumber(String unitNumber) {
        this.unitNumber = unitNumber;
        dbObject[49] = unitNumber;
    }
    public Long getShipToLocationId() {
        return shipToLocationId;
    }
    public void setShipToLocationId(Long shipToLocationId) {
        this.shipToLocationId = shipToLocationId;
        dbObject[50] = shipToLocationId;
    }
    public Long getFromCostGroupId() {
        return fromCostGroupId;
    }
    public void setFromCostGroupId(Long fromCostGroupId) {
        this.fromCostGroupId = fromCostGroupId;
        dbObject[51] = fromCostGroupId;
    }
    public Long getToCostGroupId() {
        return toCostGroupId;
    }
    public void setToCostGroupId(Long toCostGroupId) {
        this.toCostGroupId = toCostGroupId;
        dbObject[52] = toCostGroupId;
    }
    public Long getLpnId() {
        return lpnId;
    }
    public void setLpnId(Long lpnId) {
        this.lpnId = lpnId;
        dbObject[53] = lpnId;
    }
    public Long getToLpnId() {
        return toLpnId;
    }
    public void setToLpnId(Long toLpnId) {
        this.toLpnId = toLpnId;
        dbObject[54] = toLpnId;
    }
    public Long getPickMethodologyId() {
        return pickMethodologyId;
    }
    public void setPickMethodologyId(Long pickMethodologyId) {
        this.pickMethodologyId = pickMethodologyId;
        dbObject[55] = pickMethodologyId;
    }
    public Long getContainerItemId() {
        return containerItemId;
    }
    public void setContainerItemId(Long containerItemId) {
        this.containerItemId = containerItemId;
        dbObject[56] = containerItemId;
    }
    public Long getCartonGroupingId() {
        return cartonGroupingId;
    }
    public void setCartonGroupingId(Long cartonGroupingId) {
        this.cartonGroupingId = cartonGroupingId;
        dbObject[57] = cartonGroupingId;
    }
    public String getReturnStatus() {
        return returnStatus;
    }
    public void setReturnStatus(String returnStatus) {
        this.returnStatus = returnStatus;
        dbObject[58] = returnStatus;
    }
    public String getDbFlag() {
        return dbFlag;
    }
    public void setDbFlag(String dbFlag) {
        this.dbFlag = dbFlag;
        dbObject[59] = dbFlag;
    }
    public String getOperation() {
        return operation;
    }
    public void setOperation(String operation) {
        this.operation = operation;
        dbObject[60] = operation;
    }
    public Long getInspectionStatus() {
        return inspectionStatus;
    }
    public void setInspectionStatus(Long inspectionStatus) {
        this.inspectionStatus = inspectionStatus;
        dbObject[61] = inspectionStatus;
    }
    public Long getWmsProcessFlag() {
        return wmsProcessFlag;
    }
    public void setWmsProcessFlag(Long wmsProcessFlag) {
        this.wmsProcessFlag = wmsProcessFlag;
        dbObject[62] = wmsProcessFlag;
    }
    public Long getPickSlipNumber() {
        return pickSlipNumber;
    }
    public void setPickSlipNumber(Long pickSlipNumber) {
        this.pickSlipNumber = pickSlipNumber;
        dbObject[63] = pickSlipNumber;
    }
    public String getPickSlipDate() {
        return pickSlipDate;
    }
    public void setPickSlipDate(String pickSlipDate) {
        this.pickSlipDate = pickSlipDate;
        dbObject[64] = pickSlipDate;
    }
    public Long getShipSetId() {
        return shipSetId;
    }
    public void setShipSetId(Long shipSetId) {
        this.shipSetId = shipSetId;
        dbObject[65] = shipSetId;
    }
    public Long getShipModelId() {
        return shipModelId;
    }
    public void setShipModelId(Long shipModelId) {
        this.shipModelId = shipModelId;
        dbObject[66] = shipModelId;
    }
    public Long getModelQuantity() {
        return modelQuantity;
    }
    public void setModelQuantity(Long modelQuantity) {
        this.modelQuantity = modelQuantity;
        dbObject[67] = modelQuantity;
    }
    public Long getRequiredQuantity() {
        return requiredQuantity;
    }
    public void setRequiredQuantity(Long requiredQuantity) {
        this.requiredQuantity = requiredQuantity;
        dbObject[68] = requiredQuantity;
    }
    public String getAttribute1() {
        return attribute1;
    }
    public void setAttribute1(String attribute1) {
        this.attribute1 = attribute1;
        dbObject[69] = attribute1;
    }

    public String getAttribute2() {
        return attribute2;
    }
    public void setAttribute2(String attribute2) {
        this.attribute2 = attribute2;
        dbObject[70] = attribute2;
    }
    public String getAttribute3() {
        return attribute3;
    }
    public void setAttribute3(String attribute3) {
        this.attribute3 = attribute3;
        dbObject[71] = attribute3;
    }
    public String getAttribute4() {
        return attribute4;
    }
    public void setAttribute4(String attribute4) {
        this.attribute4 = attribute4;
        dbObject[72] = attribute4;
    }
    public String getAttribute5() {
        return attribute5;
    }
    public void setAttribute5(String attribute5) {
        this.attribute5 = attribute5;
        dbObject[73] = attribute5;
    }
    public String getAttribute6() {
        return attribute6;
    }
    public void setAttribute6(String attribute6) {
        this.attribute6 = attribute6;
        dbObject[74] = attribute6;
    }
    public String getAttribute7() {
        return attribute7;
    }
    public void setAttribute7(String attribute7) {
        this.attribute7 = attribute7;
        dbObject[75] = attribute7;
    }
    public String getAttribute8() {
        return attribute8;
    }
    public void setAttribute8(String attribute8) {
        this.attribute8 = attribute8;
        dbObject[76] = attribute8;
    }
    public String getAttribute9() {
        return attribute9;
    }
    public void setAttribute9(String attribute9) {
        this.attribute9 = attribute9;
        dbObject[77] = attribute9;
    }

    public String getAttribute10() {
        return attribute10;
    }
    public void setAttribute10(String attribute10) {
        this.attribute10 = attribute10;
        dbObject[78] = attribute10;
    }
    public String getAttribute11() {
        return attribute11;
    }
    public void setAttribute11(String attribute11) {
        this.attribute11 = attribute11;
        dbObject[79] = attribute11;
    }
    public String getAttribute12() {
        return attribute12;
    }
    public void setAttribute12(String attribute12) {
        this.attribute12 = attribute12;
        dbObject[80] = attribute12;
    }
    public String getAttribute13() {
        return attribute13;
    }
    public void setAttribute13(String attribute13) {
        this.attribute13 = attribute13;
        dbObject[81] = attribute13;
    }
    public String getAttribute14() {
        return attribute14;
    }
    public void setAttribute14(String attribute14) {
        this.attribute14 = attribute14;
        dbObject[82] = attribute14;
    }
    public String getAttribute15() {
        return attribute15;
    }
    public void setAttribute15(String attribute15) {
        this.attribute15 = attribute15;
        dbObject[83] = attribute15;
    }
    public Object[] getDbObject() {
        return dbObject;
    }
    public void setDbObject(Object[] dbObject) {
        this.dbObject = dbObject;
    }
}
