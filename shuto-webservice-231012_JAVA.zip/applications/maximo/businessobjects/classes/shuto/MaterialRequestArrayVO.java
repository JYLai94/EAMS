package shuto;

public class MaterialRequestArrayVO {
    private static final long serialVersionUID = -7804325452603644878L;
    private String attributeCategory;
    private Long createdBy;
    private String creationDate;
    private String dateRequired;
    private String description;
    private String fromSubinventoryCode;
    private Long headerId;
    private Long headerStatus;
    private Long lastUpdatedBy;
    private String lastUpdateDate;
    private Long lastUpdateLogin;
    private Long organizationId;
    private Long programApplicationId;
    private Long programId;
    private String programUpdateDate;
    private Long requestId;
    private String requestNumber;
    private String statusDate;
    private Long toAccountId;
    private String toSubinventoryCode;
    private Long moveorderType;
    private Long transactionTypeId;
    private Long groupingRuleId;
    private Long shipTolocationId;
    private String returnStatus;
    private String dbFlag;
    private String operation;
    private String attribute1;
    private String attribute2;
    private String attribute3;
    private String attribute4;
    private String attribute5;
    private String attribute6;
    private String attribute7;
    private String attribute8;
    private String attribute9;
    private String attribute10;
    private String attribute11;
    private String attribute12;
    private String attribute13;
    private String attribute14;
    private String attribute15;
    private Object[] dbObject = new Object[42];

    public Object[] setDate(Object... obj){
        int i=0;
        for (Object o : obj) {
            dbObject[i] = o;
            i++;
        }
        return dbObject;
    }

    public String getAttributeCategory() {
        return attributeCategory;
    }
    public void setAttributeCategory(String attributeCategory) {
        this.attributeCategory = attributeCategory;
        dbObject[0] = attributeCategory;
    }
    public Long getCreatedBy() {
        return createdBy;
    }
    public void setCreatedBy(Long createdBy) {
        this.createdBy = createdBy;
        dbObject[1] = createdBy;
    }
    public String getCreationDate() {
        return creationDate;
    }
    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
        dbObject[2] = creationDate;
    }
    public String getDateRequired() {
        return dateRequired;
    }
    public void setDateRequired(String dateRequired) {
        this.dateRequired = dateRequired;
        dbObject[3] = dateRequired;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
        dbObject[4] = description;
    }
    public String getFromSubinventoryCode() {
        return fromSubinventoryCode;
    }
    public void setFromSubinventoryCode(String fromSubinventoryCode) {
        this.fromSubinventoryCode = fromSubinventoryCode;
        dbObject[5] = fromSubinventoryCode;
    }
    public Long getHeaderId() {
        return headerId;
    }
    public void setHeaderId(Long headerId) {
        this.headerId = headerId;
        dbObject[6] = headerId;
    }
    public Long getHeaderStatus() {
        return headerStatus;
    }
    public void setHeaderStatus(Long headerStatus) {
        this.headerStatus = headerStatus;
        dbObject[7] = headerStatus;
    }
    public Long getLastUpdatedBy() {
        return lastUpdatedBy;
    }
    public void setLastUpdatedBy(Long lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
        dbObject[8] = lastUpdatedBy;
    }
    public String getLastUpdateDate() {
        return lastUpdateDate;
    }
    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
        dbObject[9] = lastUpdateDate;
    }
    public Long getLastUpdateLogin() {
        return lastUpdateLogin;
    }
    public void setLastUpdateLogin(Long lastUpdateLogin) {
        this.lastUpdateLogin = lastUpdateLogin;
        dbObject[10] = lastUpdateLogin;
    }
    public Long getOrganizationId() {
        return organizationId;
    }
    public void setOrganizationId(Long organizationId) {
        this.organizationId = organizationId;
        dbObject[11] = organizationId;
    }
    public Long getProgramApplicationId() {
        return programApplicationId;
    }
    public void setProgramApplicationId(Long programApplicationId) {
        this.programApplicationId = programApplicationId;
        dbObject[12] = programApplicationId;
    }
    public Long getProgramId() {
        return programId;
    }
    public void setProgramId(Long programId) {
        this.programId = programId;
        dbObject[13] = programId;
    }
    public String getProgramUpdateDate() {
        return programUpdateDate;
    }
    public void setProgramUpdateDate(String programUpdateDate) {
        this.programUpdateDate = programUpdateDate;
        dbObject[14] = programUpdateDate;
    }
    public Long getRequestId() {
        return requestId;
    }
    public void setRequestId(Long requestId) {
        this.requestId = requestId;
        dbObject[15] = requestId;
    }
    public String getRequestNumber() {
        return requestNumber;
    }
    public void setRequestNumber(String requestNumber) {
        this.requestNumber = requestNumber;
        dbObject[16] = requestNumber;
    }
    public String getStatusDate() {
        return statusDate;
    }
    public void setStatusDate(String statusDate) {
        this.statusDate = statusDate;
        dbObject[17] = statusDate;
    }
    public Long getToAccountId() {
        return toAccountId;
    }
    public void setToAccountId(Long toAccountId) {
        this.toAccountId = toAccountId;
        dbObject[18] = toAccountId;
    }
    public String getToSubinventoryCode() {
        return toSubinventoryCode;
    }
    public void setToSubinventoryCode(String toSubinventoryCode) {
        this.toSubinventoryCode = toSubinventoryCode;
        dbObject[19] = toSubinventoryCode;
    }
    public Long getMoveorderType() {
        return moveorderType;
    }
    public void setMoveorderType(Long moveorderType) {
        this.moveorderType = moveorderType;
        dbObject[20] = moveorderType;
    }
    public Long getTransactionTypeId() {
        return transactionTypeId;
    }
    public void setTransactionTypeId(Long transactionTypeId) {
        this.transactionTypeId = transactionTypeId;
        dbObject[21] = transactionTypeId;
    }
    public Long getGroupingRuleId() {
        return groupingRuleId;
    }
    public void setGroupingRuleId(Long groupingRuleId) {
        this.groupingRuleId = groupingRuleId;
        dbObject[22] = groupingRuleId;
    }
    public Long getShipTolocationId() {
        return shipTolocationId;
    }
    public void setShipTolocationId(Long shipTolocationId) {
        this.shipTolocationId = shipTolocationId;
        dbObject[23] = shipTolocationId;
    }
    public String getReturnStatus() {
        return returnStatus;
    }
    public void setReturnStatus(String returnStatus) {
        this.returnStatus = returnStatus;
        dbObject[24] = returnStatus;
    }
    public String getDbFlag() {
        return dbFlag;
    }
    public void setDbFlag(String dbFlag) {
        this.dbFlag = dbFlag;
        dbObject[25] = dbFlag;
    }
    public String getOperation() {
        return operation;
    }
    public void setOperation(String operation) {
        this.operation = operation;
        dbObject[26] = operation;
    }
    public String getAttribute1() {
        return attribute1;
    }
    public void setAttribute1(String attribute1) {
        this.attribute1 = attribute1;
        dbObject[27] = attribute1;
    }
    public String getAttribute2() {
        return attribute2;
    }
    public void setAttribute2(String attribute2) {
        this.attribute2 = attribute2;
        dbObject[28] = attribute2;
    }
    public String getAttribute3() {
        return attribute3;
    }
    public void setAttribute3(String attribute3) {
        this.attribute3 = attribute3;
        dbObject[29] = attribute3;
    }
    public String getAttribute4() {
        return attribute4;
    }
    public void setAttribute4(String attribute4) {
        this.attribute4 = attribute4;
        dbObject[30] = attribute4;
    }
    public String getAttribute5() {
        return attribute5;
    }
    public void setAttribute5(String attribute5) {
        this.attribute5 = attribute5;
        dbObject[31] = attribute5;
    }
    public String getAttribute6() {
        return attribute6;
    }
    public void setAttribute6(String attribute6) {
        this.attribute6 = attribute6;
        dbObject[32] = attribute6;
    }
    public String getAttribute7() {
        return attribute7;
    }
    public void setAttribute7(String attribute7) {
        this.attribute7 = attribute7;
        dbObject[33] = attribute7;
    }
    public String getAttribute8() {
        return attribute8;
    }
    public void setAttribute8(String attribute8) {
        this.attribute8 = attribute8;
        dbObject[34] = attribute8;
    }
    public String getAttribute9() {
        return attribute9;
    }
    public void setAttribute9(String attribute9) {
        this.attribute9 = attribute9;
        dbObject[35] = attribute9;
    }
    public String getAttribute10() {
        return attribute10;
    }
    public void setAttribute10(String attribute10) {
        this.attribute10 = attribute10;
        dbObject[36] = attribute10;
    }
    public String getAttribute11() {
        return attribute11;
    }
    public void setAttribute11(String attribute11) {
        this.attribute11 = attribute11;
        dbObject[37] = attribute11;
    }
    public String getAttribute12() {
        return attribute12;
    }
    public void setAttribute12(String attribute12) {
        this.attribute12 = attribute12;
        dbObject[38] = attribute12;
    }
    public String getAttribute13() {
        return attribute13;
    }
    public void setAttribute13(String attribute13) {
        this.attribute13 = attribute13;
        dbObject[39] = attribute13;
    }
    public String getAttribute14() {
        return attribute14;
    }
    public void setAttribute14(String attribute14) {
        this.attribute14 = attribute14;
        dbObject[40] = attribute14;
    }
    public String getAttribute15() {
        return attribute15;
    }
    public void setAttribute15(String attribute15) {
        this.attribute15 = attribute15;
        dbObject[41] = attribute15;
    }
    public Object[] getDbObject() {
        return dbObject;
    }
    public void setDbObject(Object[] dbObject) {
        this.dbObject = dbObject;
    }
}
